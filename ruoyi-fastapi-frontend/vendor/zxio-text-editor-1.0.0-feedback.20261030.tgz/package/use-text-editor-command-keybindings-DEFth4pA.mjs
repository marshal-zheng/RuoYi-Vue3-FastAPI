import { Extension as Wi } from "@tiptap/core";
import { Plugin as $o, PluginKey as Ho, NodeSelection as zn, TextSelection as ct } from "@tiptap/pm/state";
import { computePosition as Uo, flip as Ko, autoUpdate as Ji, offset as Zi, shift as Xi, size as Yi } from "@floating-ui/dom";
import { Y as Qi, $ as es, a0 as cn, z as qo, a1 as ts, H as bt, G as Go, F as ns, p as os, a2 as is, A as Wo, B as ss, D as rs } from "./runtime-extensions-ClrqjOfa.mjs";
import { an as as } from "./delivery-surfaces-C8goSxeE.mjs";
import { watch as Q, defineAsyncComponent as Dt, defineComponent as Te, inject as yt, computed as S, ref as J, onBeforeUnmount as rt, createBlock as $e, createCommentVNode as ae, openBlock as L, unref as v, withCtx as ht, createElementVNode as D, normalizeClass as q, createElementBlock as F, withModifiers as Ke, createVNode as j, Fragment as Le, renderList as Pe, toDisplayString as me, nextTick as dt, useAttrs as $t, shallowRef as Ne, onMounted as Ht, mergeProps as st, h as Ft, provide as An, normalizeStyle as ft, renderSlot as Ve, reactive as ls, onScopeDispose as kt, isRef as En, normalizeProps as wt, guardReactiveProps as xt, toRef as Xe, resolveComponent as cs, toRaw as bn, withKeys as so, toValue as qe, createTextVNode as Yt, useId as us, Teleport as ds, withDirectives as fs, vShow as ps } from "vue";
import { useNamespace as De, useOverlayZIndex as Mn, useLocale as ms } from "@zxio/zxui/hooks";
import { ZxIcon as xe } from "@zxio/zxui/core";
import { ZxTooltipOrPopover as Qt } from "@zxio/zxui/tooltip-or-popover";
import { bB as Dn, bS as vs, bw as gs, bu as hs, bq as bs, bo as Sn, bP as ys, bz as ks, bC as ws, bQ as xs, bR as Jo, cc as Ts, bG as un, bK as en, d as Is, cd as As, bL as Es, e as Zo, g as Ss, ce as _s, bE as Os, c as Rs, a as Ns, r as Ls, S as Bs, a4 as Cs, $ as zs, a3 as Ms, a0 as Ds, l as Fs, m as Xo, cf as ro, c5 as Ps, c7 as Vs, c0 as js, c1 as $s, bZ as Hs, b_ as Us, c2 as Ks, c3 as qs, c8 as Gs, j as Ws } from "./authoring-action-port-DpxLwJ-t.mjs";
import { useShortcutRuntime as Ut, useParentShortcutOwner as Yo, useShortcutPresentation as Js, useShortcutOwner as Qo, useShortcutAction as jt, useActionView as yn, bindShortcutOwner as Zs } from "@zxio/keybindings/vue";
import { BubbleMenu as ei, FloatingMenu as Xs } from "@tiptap/vue-3/menus";
import { DecorationSet as vt, Decoration as Ys } from "@tiptap/pm/view";
import { useThemeRuntime as Qs, useThemeScope as er, useThemeApp as tr } from "@zxio/zxui/theme-provider";
import { createActionPort as tn } from "@zxio/keybindings/core";
import { n as nr, q as or, m as ti, I as dn, f as ir, H as ao } from "./inline-ai-shortcut-router-a-QG5h2e.mjs";
import { bw as Ye, c as lo, bE as sr, bZ as it, h as ni, cb as mt, bj as rr, r as ar } from "./link-paste-handler-B_hN4OP5.mjs";
import * as oi from "@tiptap/pm/history";
import { Slice as ii, Fragment as si } from "@tiptap/pm/model";
import { E as gt, F as nn, v as Fn, b as lr, S as cr, p as ur, f as dr } from "./envelope-CrN5-dS1.mjs";
import { c as fr } from "./stable-block-ids-CPxz-1sA.mjs";
import { useAIContextScope as pr, createAIContextKnownValues as mr, isAIContextReady as vr, AIContextError as on, captureAIContext as gr, createAIContextId as hr } from "@zxio/zxui/ai-context";
import { z as Pn, q as ri, s as ai, o as br, n as yr } from "./actions-Sd62WBGv.mjs";
import { buildProps as kr, definePropType as Ae, withInstall as wr } from "@zxio/zxui/runtime";
import { EditorContent as xr } from "@tiptap/vue-3";
import { dropPoint as Tr } from "@tiptap/pm/transform";
import { DragHandle as Ir } from "@tiptap/extension-drag-handle-vue-3";
import { createPackageTextEditorRuntimeHostEditorV2 as Ar } from "#runtime-host-authority";
const of = Wi.create(
  {
    name: "floatingQuoteButton",
    addOptions() {
      return {
        onClick: void 0,
        themeOwner: null
      };
    },
    addProseMirrorPlugins() {
      const e = this.options, t = this.editor;
      return [
        new $o({
          key: new Ho("floatingQuoteButton"),
          view: (o) => new Er(o, t, e)
        })
      ];
    }
  }
);
class Er {
  constructor(t, o, n) {
    this.button = null, this.binding = null, this.portalGeneration = 0, this.view = t, this.editor = o, this.options = n, this.createButton();
  }
  createButton() {
    this.button = this.view.dom.ownerDocument.createElement("button"), this.button.className = as("text-editor-quote-button"), this.button.type = "button", this.button.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
    `, this.button.style.cssText = `
      position: absolute;
      display: none;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border: none;
      border-radius: var(--zx-semantic-radius-control);
      background: var(--zx-semantic-action-focus-ring);
      color: var(--zx-semantic-text-primary);
      cursor: pointer;
      z-index: 100;
      transition: background var(--zx-semantic-motion-duration) ease;
    `, this.button.addEventListener("click", this.handleClick.bind(this)), this.button.addEventListener("mouseenter", () => {
      this.button && (this.button.style.background = "var(--zx-semantic-text-primary)");
    }), this.button.addEventListener("mouseleave", () => {
      this.button && (this.button.style.background = "var(--zx-semantic-action-focus-ring)");
    });
  }
  handleClick() {
    if (!this.options.onClick) return;
    const { from: t, to: o } = this.view.state.selection, n = this.editor.state.doc.textBetween(t, o);
    this.options.onClick(n), this.hide();
  }
  update(t) {
    this.view = t;
    const { state: o } = t, { selection: n } = o, { empty: i } = n;
    if (i || this.editor.isEditable) {
      this.hide();
      return;
    }
    this.show();
  }
  async show() {
    if (!this.button) return;
    if (!this.binding) {
      const f = this.options.themeOwner;
      if (!f) return;
      const c = ++this.portalGeneration, u = await f.acquirePortal();
      if (c !== this.portalGeneration) {
        u.ok && u.value.release();
        return;
      }
      if (!u.ok || !this.button) return;
      this.binding = u.value, this.binding.target.appendChild(this.button);
    }
    const t = this.portalGeneration, { from: o, to: n } = this.view.state.selection, i = this.view.coordsAtPos(o), s = this.view.coordsAtPos(n), a = {
      getBoundingClientRect() {
        return {
          x: i.left,
          y: i.top,
          width: s.right - i.left,
          height: s.bottom - i.top,
          top: i.top,
          right: s.right,
          bottom: s.bottom,
          left: i.left
        };
      }
    }, { x: l, y: r } = await Uo(a, this.button, {
      placement: "top",
      middleware: [Qi(4), Ko(), es(4)]
    });
    t !== this.portalGeneration || !this.button || !this.binding || (this.button.style.left = `${l}px`, this.button.style.top = `${r}px`, this.button.style.display = "flex");
  }
  hide() {
    var t, o;
    this.portalGeneration += 1, this.button && (this.button.style.display = "none"), (t = this.button) == null || t.remove(), (o = this.binding) == null || o.release(), this.binding = null;
  }
  destroy() {
    var t;
    this.hide(), (t = this.button) == null || t.remove(), this.button = null;
  }
}
const Sr = (e, t) => {
  if (!e)
    return t.documentState.value;
  t.hasCommentExtension.value && (t.annotationBridgeState.value = ks(
    e.getJSON(),
    t.annotationBridgeState.value
  ));
  const o = ws(
    t.documentState.value,
    t.annotationBridgeState.value
  ), n = xs(e, o, {
    markdownExportMode: t.getMarkdownExportMode()
  });
  return t.documentState.value = n, t.annotationBridgeState.value = Dn(n), n;
}, kn = (e) => Dn(e), _r = (e) => {
  const t = (g = e.editor.value) => Sr(g, e), o = (g) => ys(g), n = (g) => o({
    documentValue: g,
    contentType: "document",
    stableBlockIdentity: e.getStableBlockIdentityOptions()
  }).document, i = (g) => {
    if (!e.editor.value)
      return !1;
    switch (g.sourceType) {
      case "html":
        return Sn(t(e.editor.value)) === g.content;
      case "json":
        return JSON.stringify(e.editor.value.getJSON()) === JSON.stringify(g.content);
      case "markdown":
        return JSON.stringify(t(e.editor.value).body.content) === JSON.stringify(g.document.body.content);
      case "document": {
        const V = n(
          t(e.editor.value)
        ), U = n(
          g.document
        );
        return JSON.stringify(V) === JSON.stringify(U);
      }
    }
  }, s = (g) => {
    e.editor.value && (e.isApplyingExternalContent.value = !0, e.documentState.value = g.document, e.annotationBridgeState.value = Dn(g.document), e.editor.value.commands.setContent(g.content ?? ""), e.isApplyingExternalContent.value = !1);
  }, a = ({
    editor: g,
    document: V,
    outputType: U
  }) => {
    const x = V ?? t(g);
    return Jo(g, {
      outputType: U,
      markdownExportMode: e.getMarkdownExportMode(),
      document: x
    });
  }, l = () => t(e.editor.value), r = () => Sn(l()), f = (g = {}) => bs(l(), {
    mode: g.mode ?? e.getMarkdownExportMode()
  }), c = () => {
    var g;
    return ((g = e.editor.value) == null ? void 0 : g.getJSON()) ?? e.documentState.value.body.content ?? gt().body.content;
  }, u = (g = {}) => hs(l(), g), p = (g = {}) => gs(l(), g), m = (g, V = {}) => {
    if (!e.editor.value)
      return;
    const U = V.contentType ?? (nn(g) ? "document" : typeof g == "string" ? "html" : "json"), x = o({
      baseDocument: e.documentState.value,
      modelValue: g,
      documentValue: U === "document" ? g : void 0,
      content: U === "html" && typeof g == "string" ? g : null,
      contentType: U,
      hydrateAnnotations: e.hasCommentExtension.value,
      stableBlockIdentity: e.getStableBlockIdentityOptions()
    });
    s(x);
  };
  return {
    getCurrentDocument: t,
    resolveHydratedState: o,
    isHydratedStateSynced: i,
    applyHydratedEditorState: s,
    exportEditorContentValue: a,
    getHTML: r,
    getMarkdown: f,
    getJSON: c,
    getDocument: l,
    getText: u,
    getExcerpt: p,
    setContent: m,
    setHTML: (g) => {
      m(g, { contentType: "html" });
    },
    setMarkdown: (g) => {
      m(g, { contentType: "markdown" });
    },
    setJSON: (g) => {
      m(g, { contentType: "json" });
    },
    setDocument: (g) => {
      m(g, { contentType: "document" });
    },
    getRuntimeStatus: () => vs({
      editor: e.editor.value,
      document: l()
    })
  };
};
let Or = 0, Rr = 0;
const Nr = () => `zx-editor-${++Or}`, Lr = () => `zx-asset-task-${++Rr}`, Br = (e) => e.type.startsWith("image/") ? "image" : e.type.startsWith("video/") ? "video" : "file", Cr = (e, t) => {
  var i, s, a;
  const o = e.asset.meta ?? {}, n = e.asset.type === "file" ? {
    ...o,
    fileName: ((i = e.asset.meta) == null ? void 0 : i.fileName) ?? e.asset.title ?? t.name,
    size: typeof ((s = e.asset.meta) == null ? void 0 : s.size) == "number" ? (a = e.asset.meta) == null ? void 0 : a.size : t.size
  } : Object.keys(o).length ? o : void 0;
  return {
    ...e,
    asset: {
      ...e.asset,
      mimeType: e.asset.mimeType ?? (t.type ? t.type : void 0),
      title: e.asset.title ?? t.name,
      ...n ? { meta: n } : {}
    }
  };
}, zr = (e) => {
  var o;
  const t = (o = e.body.content) == null ? void 0 : o.content;
  return !Array.isArray(t) || t.length === 0;
}, Mr = ({
  editor: e,
  filePlatform: t,
  intakeDispatcher: o,
  getCurrentDocument: n,
  editorId: i = Nr()
}) => {
  const s = () => t.value ?? null, a = (p) => {
    var m, y;
    (y = (m = s()) == null ? void 0 : m.onDiagnostic) == null || y.call(m, p);
  }, l = ({
    files: p,
    source: m = "programmatic",
    htmlContent: y,
    dropPos: M = null,
    context: _
  }) => {
    var V;
    const T = e.value, k = T == null ? void 0 : T.state.selection, g = n();
    return {
      source: m,
      files: Array.from(p),
      htmlContent: y,
      dropPos: M,
      selectionFrom: (k == null ? void 0 : k.from) ?? null,
      selectionTo: (k == null ? void 0 : k.to) ?? null,
      editorId: i,
      currentDocumentEmpty: (T == null ? void 0 : T.isEmpty) ?? zr(g),
      context: _,
      constraints: (V = s()) == null ? void 0 : V.constraints
    };
  }, r = async ({
    files: p,
    source: m = "programmatic",
    htmlContent: y,
    dropPos: M = null,
    anchorPos: _ = null,
    context: T
  }) => {
    const k = l({
      files: p,
      source: m,
      htmlContent: y,
      dropPos: M,
      context: T
    }), g = o == null ? void 0 : o.value;
    return g ? g.dispatch({
      event: k,
      anchorPos: _
    }) : {
      event: k,
      decision: {
        intent: "reject",
        code: "intake-dispatcher-missing",
        reason: "dispatcher-missing",
        message: "The unified file intake dispatcher is not configured for this editor instance."
      },
      handled: !1
    };
  }, f = (p, m = {}) => ({
    id: Lr(),
    kind: Br(p),
    status: m.status ?? "queued",
    fileName: p.name,
    mimeType: p.type || "application/octet-stream",
    size: p.size,
    anchorPos: m.anchorPos ?? null,
    previewUrl: m.previewUrl,
    progress: m.progress
  }), c = (p) => {
    var m, y;
    (y = (m = s()) == null ? void 0 : m.onTaskEvent) == null || y.call(m, p);
  };
  return {
    editorId: i,
    getFilePlatform: s,
    emitDiagnostic: a,
    emitTaskEvent: c,
    captureIntakeEvent: l,
    intakeFiles: r,
    createAssetTaskRecord: f,
    uploadAsset: async (p, m = {}) => {
      const y = s();
      if (!(y != null && y.uploadAsset))
        throw new Error("filePlatform.uploadAsset is not provided");
      const M = m.intake ?? l({
        source: m.source,
        files: [p],
        htmlContent: m.htmlContent,
        dropPos: m.dropPos,
        context: m.context
      }), _ = m.emitTaskLifecycle ?? !m.task, T = m.task ?? f(p, {
        anchorPos: m.anchorPos,
        previewUrl: m.previewUrl,
        progress: m.progress
      }), k = {
        ...T,
        status: "uploading"
      };
      _ && (c({
        type: "task-created",
        intake: M,
        task: T
      }), c({
        type: "task-updated",
        intake: M,
        task: k
      }));
      try {
        const g = Cr(
          await y.uploadAsset({
            event: M,
            file: p,
            task: k,
            context: m.context ?? M.context,
            signal: m.signal,
            updateTask: m.updateTask
          }),
          p
        ), V = {
          ...k,
          status: "completed"
        };
        return _ && c({
          type: "task-completed",
          intake: M,
          task: V,
          asset: g
        }), g;
      } catch (g) {
        const V = {
          ...k,
          status: "failed",
          errorMessage: g instanceof Error ? g.message : "Unknown error"
        };
        throw _ && c({
          type: "task-failed",
          intake: M,
          task: V,
          error: {
            message: V.errorMessage
          }
        }), g;
      }
    }
  };
};
class Ot extends Error {
  constructor(t, o) {
    super(o), this.name = "ZxAssetMaterializationError", this.code = t;
  }
}
const Dr = (e, t) => {
  const o = e.state.doc.content.size;
  return typeof t != "number" || !Number.isFinite(t) ? e.state.selection.from : Math.max(0, Math.min(t, o));
}, Fr = (e) => typeof e == "string" && e ? e : void 0, Pr = (e, t, o) => {
  var i;
  const n = t.nodeKind ?? o;
  if (n === "image") {
    const s = e.schema.nodes.image;
    if (!s)
      throw new Ot(
        "asset-materializer-image-missing",
        "The image extension is not available for asset materialization."
      );
    return s.create({
      assetId: t.asset.id,
      src: t.asset.src,
      title: t.asset.title ?? null,
      alt: Fr((i = t.asset.meta) == null ? void 0 : i.alt) ?? t.asset.title ?? null
    });
  }
  if (n === "video") {
    const s = e.schema.nodes.video;
    if (!s)
      throw new Ot(
        "asset-materializer-video-missing",
        "The video extension is not available for asset materialization."
      );
    return s.create({
      assetId: t.asset.id,
      src: t.asset.src
    });
  }
  if (n === "attachment") {
    const s = e.schema.nodes.attachment;
    if (!s)
      throw new Ot(
        "asset-materializer-attachment-missing",
        "The attachment extension is not available for asset materialization."
      );
    return s.create({
      assetId: t.asset.id
    });
  }
  throw new Ot(
    "asset-materializer-node-kind-unsupported",
    `Unsupported asset node kind "${String(n)}".`
  );
}, Vr = async ({
  editor: e,
  documentState: t,
  preferredNodeKind: o,
  resolveTaskPosition: n,
  resolvedAsset: i,
  task: s
}) => {
  if (!e)
    throw new Ot(
      "asset-materializer-editor-missing",
      "The editor instance is unavailable for asset materialization."
    );
  const a = Pr(e, i, o), l = Dr(
    e,
    (n == null ? void 0 : n(s.id)) ?? s.anchorPos
  );
  e.view.dispatch(e.state.tr.insert(l, a)), t.value = gt({
    ...t.value,
    assets: Fn(t.value.assets, [i.asset])
  });
}, jr = 1, $r = (e) => ({
  ...Object.hasOwn(e, "status") ? { status: e.status } : {},
  ...Object.hasOwn(e, "previewUrl") ? { previewUrl: e.previewUrl } : {},
  ...Object.hasOwn(e, "progress") ? { progress: e.progress } : {},
  ...Object.hasOwn(e, "errorCode") ? { errorCode: e.errorCode } : {},
  ...Object.hasOwn(e, "errorMessage") ? {
    errorMessage: e.errorMessage
  } : {}
}), wn = (e, t) => {
  if (t.type === "set") {
    const o = [...e], n = o.findIndex(
      (i) => i.id === t.task.id
    );
    return n === -1 ? (o.push(t.task), o) : (o.splice(n, 1, t.task), o);
  }
  return t.type === "patch" ? e.map(
    (o) => o.id === t.id ? {
      ...o,
      ...$r(t.patch)
    } : o
  ) : e.filter((o) => o.id !== t.id);
}, Hr = () => {
  let e = [];
  const t = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Map(), n = () => {
    const s = {
      tasks: [...e]
    };
    t.forEach((a) => a(s));
  }, i = (s) => e.find((a) => a.id === s) ?? null;
  return {
    getSnapshot: () => ({
      tasks: [...e]
    }),
    getTask: i,
    listTasks: () => [...e],
    patchTask: (s, a) => (e = wn(e, {
      type: "patch",
      id: s,
      patch: a
    }), n(), i(s)),
    registerControls: (s, a) => {
      o.set(s, a);
    },
    removeTask: (s) => {
      o.delete(s), e = wn(e, {
        type: "remove",
        id: s
      }), n();
    },
    retryTask: (s) => {
      var a, l;
      (l = (a = o.get(s)) == null ? void 0 : a.retry) == null || l.call(a);
    },
    setTask: (s) => {
      e = wn(e, {
        type: "set",
        task: s
      }), n();
    },
    subscribe: (s) => (t.add(s), () => {
      t.delete(s);
    }),
    cancelTask: (s) => {
      var a, l;
      (l = (a = o.get(s)) == null ? void 0 : a.cancel) == null || l.call(a);
    },
    requestRemove: (s) => {
      var a, l;
      (l = (a = o.get(s)) == null ? void 0 : a.remove) == null || l.call(a);
    }
  };
}, Ur = (e) => {
  if (!(typeof URL > "u" || typeof URL.createObjectURL != "function"))
    try {
      return URL.createObjectURL(e);
    } catch {
      return;
    }
}, Xt = (e) => {
  if (!(!e || typeof URL > "u" || typeof URL.revokeObjectURL != "function"))
    try {
      URL.revokeObjectURL(e);
    } catch {
    }
}, Kr = (e) => e instanceof DOMException || e instanceof Error ? e.name === "AbortError" : !1, qr = (e, t) => e instanceof Error && e.message ? e.message : t, Gr = ({
  documentState: e,
  editor: t,
  filePlatformRuntime: o,
  maxConcurrentTasks: n = jr
}) => {
  const i = Hr(), s = /* @__PURE__ */ new Map(), a = [], l = /* @__PURE__ */ new Set();
  let r = null;
  const f = (T) => i.getTask(T), c = (T, k, g) => {
    const V = i.patchTask(T, k);
    return V ? (o.emitTaskEvent({
      type: "task-updated",
      intake: g,
      task: V
    }), V) : null;
  }, u = (T, k = "Asset task cancelled.") => {
    var w;
    const g = s.get(T), V = i.getTask(T);
    if (!g || !V || ["completed", "cancelled"].includes(V.status))
      return;
    const U = a.indexOf(T);
    U >= 0 && a.splice(U, 1), (w = g.uploadController) == null || w.abort(), g.uploadController = null;
    const x = i.patchTask(T, {
      status: "cancelled",
      errorCode: void 0,
      errorMessage: void 0,
      progress: void 0
    });
    x && o.emitTaskEvent({
      type: "task-cancelled",
      intake: g.event,
      task: x,
      error: {
        message: k
      }
    });
  }, p = (T) => {
    const k = i.getTask(T);
    k && !["failed", "completed", "cancelled"].includes(k.status) && u(T);
    const g = s.get(T);
    Xt(g == null ? void 0 : g.previewUrl), s.delete(T), i.removeTask(T);
  }, m = (T) => {
    const k = s.get(T), g = i.getTask(T);
    !k || !g || !["failed", "cancelled"].includes(g.status) || !c(
      T,
      {
        status: "queued",
        errorCode: void 0,
        errorMessage: void 0,
        progress: void 0
      },
      k.event
    ) || (a.push(T), y());
  }, y = () => {
    for (; l.size < Math.max(1, n) && a.length > 0; ) {
      const T = a.shift();
      !T || l.has(T) || M(T).catch((k) => {
        o.emitDiagnostic({
          code: "asset-task-runner-unhandled",
          message: k instanceof Error ? k.message : "The asset task runner failed unexpectedly.",
          severity: "error",
          stage: "asset-pipeline",
          cause: k
        });
      });
    }
  }, M = async (T) => {
    var U;
    const k = s.get(T), g = i.getTask(T);
    if (!k || !g)
      return;
    l.add(T), k.uploadController = new AbortController(), k.previewUrl || (k.previewUrl = Ur(k.file)), c(
      T,
      {
        status: "reading",
        previewUrl: k.previewUrl
      },
      k.event
    );
    const V = c(
      T,
      {
        status: "uploading"
      },
      k.event
    );
    if (!V) {
      l.delete(T), k.uploadController = null;
      return;
    }
    try {
      const x = await o.uploadAsset(
        k.file,
        {
          intake: k.event,
          anchorPos: V.anchorPos,
          previewUrl: k.previewUrl,
          context: {
            ...k.event.context ?? {},
            preferredNodeKind: k.preferredNodeKind,
            ...k.preferredNodeKind ? {
              nodeKind: k.preferredNodeKind
            } : {}
          },
          emitTaskLifecycle: !1,
          signal: k.uploadController.signal,
          task: V,
          updateTask: (Z) => {
            c(T, Z, k.event);
          }
        }
      ), w = i.getTask(T);
      if (!w || w.status === "cancelled") {
        Xt(k.previewUrl);
        return;
      }
      const R = c(
        T,
        {
          status: "processing",
          progress: 100
        },
        k.event
      );
      if (!R)
        return;
      await Vr({
        editor: t.value,
        documentState: e,
        preferredNodeKind: k.preferredNodeKind,
        resolveTaskPosition: r ?? ((Z) => {
          var ie;
          return ((ie = i.getTask(Z)) == null ? void 0 : ie.anchorPos) ?? null;
        }),
        resolvedAsset: x,
        task: R
      });
      const X = i.patchTask(T, {
        status: "completed",
        errorCode: void 0,
        errorMessage: void 0,
        progress: 100
      });
      X && o.emitTaskEvent({
        type: "task-completed",
        intake: k.event,
        task: X,
        asset: x
      }), Xt(k.previewUrl);
    } catch (x) {
      if ((U = k.uploadController) != null && U.signal.aborted || Kr(x)) {
        u(T), Xt(k.previewUrl);
        return;
      }
      const w = i.patchTask(T, {
        status: "failed",
        errorCode: x instanceof Error && "code" in x && typeof x.code == "string" ? x.code : "asset-task-failed",
        errorMessage: qr(x, "Asset task failed.")
      });
      w && (o.emitTaskEvent({
        type: "task-failed",
        intake: k.event,
        task: w,
        error: {
          code: w.errorCode,
          message: w.errorMessage ?? "Asset task failed."
        }
      }), o.emitDiagnostic({
        code: w.errorCode ?? "asset-task-failed",
        message: w.errorMessage ?? "Asset task failed.",
        severity: "error",
        stage: x instanceof Ot ? "materialization" : "asset-pipeline",
        intake: k.event,
        task: w,
        cause: x
      }));
    } finally {
      l.delete(T), k.uploadController = null, y();
    }
  };
  return {
    enqueue: ({
      anchorPos: T = null,
      event: k,
      preferredNodeKind: g = null
    }) => k.files.length ? (k.files.forEach((V) => {
      const U = o.createAssetTaskRecord(V, {
        anchorPos: T
      });
      s.set(U.id, {
        event: k,
        file: V,
        preferredNodeKind: g,
        uploadController: null
      }), i.registerControls(U.id, {
        cancel: () => u(U.id),
        remove: () => p(U.id),
        retry: () => m(U.id)
      }), i.setTask(U), o.emitTaskEvent({
        type: "task-created",
        intake: k,
        task: U
      }), a.push(U.id);
    }), y(), !0) : !1,
    getTask: f,
    getTasks: () => i.listTasks(),
    removeTask: p,
    retryTask: m,
    setTaskPositionResolver: (T) => {
      r = T;
    },
    subscribe: (T) => i.subscribe(T),
    cancelTask: (T) => u(T)
  };
};
class _t extends Error {
  constructor(t, o) {
    super(o), this.name = "ZxRemoteEmbedResolutionError", this.code = t;
  }
}
const It = (e) => typeof e == "string" && e.trim().length > 0, Wr = (e, t) => {
  const o = e.state.doc.content.size;
  return typeof t != "number" || !Number.isFinite(t) ? null : Math.max(0, Math.min(t, o));
}, Jr = (e) => {
  var n, i, s, a;
  const t = e.asset, o = {
    ...e.attrs ?? {},
    url: e.url
  };
  return t != null && t.id && !It(o.assetId) && (o.assetId = t.id), t != null && t.title && !It(o.title) && (o.title = t.title), It((n = t == null ? void 0 : t.meta) == null ? void 0 : n.name) && !It(o.name) && (o.name = (i = t.meta) == null ? void 0 : i.name), It((s = t == null ? void 0 : t.meta) == null ? void 0 : s.icon) && !It(o.icon) && (o.icon = (a = t.meta) == null ? void 0 : a.icon), o;
}, Zr = async ({
  anchorPos: e = null,
  documentState: t,
  editor: o,
  event: n,
  filePlatform: i,
  url: s
}) => {
  if (!(i != null && i.resolveRemoteEmbed))
    throw new _t(
      "remote-embed-resolver-missing",
      "The host platform does not provide resolveRemoteEmbed()."
    );
  if (!o)
    throw new _t(
      "remote-embed-editor-missing",
      "The editor instance is unavailable for remote embed materialization."
    );
  const a = await i.resolveRemoteEmbed({
    event: n,
    url: s,
    htmlContent: n.htmlContent,
    context: n.context
  });
  if (!a)
    throw new _t(
      "remote-embed-unresolved",
      `The host platform declined to resolve remote embed URL "${s}".`
    );
  if (!o.schema.nodes.embed)
    throw new _t(
      "remote-embed-node-missing",
      "The embed extension is not available for remote embed materialization."
    );
  const r = o.chain().focus(), f = Wr(o, e);
  if (f !== null && r.setTextSelection(f), !r.insertContent({
    type: "embed",
    attrs: Jr(a)
  }).run())
    throw new _t(
      "remote-embed-materialization-failed",
      `Failed to insert the resolved remote embed for URL "${s}".`
    );
  return a.asset && (t.value = gt({
    ...t.value,
    assets: Fn(t.value.assets, [a.asset])
  })), {
    handled: !0,
    resolution: a
  };
}, Vn = (e) => typeof window < "u" && e === window, li = (e) => typeof e == "function" ? e() ?? null : e ?? null, Xr = (e) => [...e].sort((t, o) => {
  const n = typeof t.pos == "number" ? t.pos : Number.MAX_SAFE_INTEGER, i = typeof o.pos == "number" ? o.pos : Number.MAX_SAFE_INTEGER;
  if (n !== i)
    return n - i;
  const s = typeof t.order == "number" ? t.order : 0, a = typeof o.order == "number" ? o.order : 0;
  return s - a;
}), ci = (e) => !!(e.dom && typeof e.dom.getBoundingClientRect == "function" && e.dom.isConnected !== !1), ui = (e, t) => {
  const o = li(t);
  if (o)
    return o;
  const n = e.find(ci);
  return n ? Ts(n.dom) ?? (typeof window < "u" ? window : null) : typeof window < "u" ? window : null;
}, Yr = (e, t) => {
  const o = li(t);
  if (o != null && Number.isFinite(o))
    return Math.max(o, 0);
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return 0;
  const n = Vn(e) ? document.documentElement : e, i = window.getComputedStyle(n), s = Number.parseFloat(i.scrollPaddingTop || "0") || 0, a = Number.parseFloat(i.paddingTop || "0") || 0;
  return Math.max(s || a, 0);
}, Qr = (e, t) => !e || Vn(e) ? t + 1 : e.getBoundingClientRect().top + t + 1, ea = (e) => {
  if (!e)
    return !1;
  if (!Vn(e))
    return e.scrollHeight <= e.clientHeight + 1 ? !1 : e.scrollTop + e.clientHeight >= e.scrollHeight - 1;
  if (typeof document > "u")
    return !1;
  const t = e.innerHeight || document.documentElement.clientHeight || 0, o = e.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0, n = Math.max(
    document.documentElement.scrollHeight,
    document.body.scrollHeight
  );
  return n <= t + 1 ? !1 : o + t >= n - 1;
}, _n = (e = [], t = {}) => {
  var r, f, c, u;
  const o = Xr(e);
  if (o.length === 0)
    return null;
  const n = o.filter(ci);
  if (n.length === 0)
    return ((r = o.find((p) => p.isActive)) == null ? void 0 : r.id) ?? ((f = o[0]) == null ? void 0 : f.id) ?? null;
  const i = ui(
    n,
    t.scrollContainer
  );
  if (ea(i))
    return ((c = n[n.length - 1]) == null ? void 0 : c.id) ?? null;
  const s = Qr(
    i,
    Yr(i, t.topInset)
  );
  let a = null, l = null;
  for (const p of n) {
    const m = p.dom.getBoundingClientRect();
    m.top <= s && (a = p), !l && m.bottom >= s && (l = p);
  }
  return (a == null ? void 0 : a.id) ?? (l == null ? void 0 : l.id) ?? ((u = n[0]) == null ? void 0 : u.id) ?? null;
}, ta = (e) => {
  let t = _n(
    e.getHeadings(),
    {
      scrollContainer: e.scrollContainer,
      topInset: e.topInset
    }
  ), o = 0, n = null, i = null;
  const s = /* @__PURE__ */ new Set(), a = () => {
    s.forEach((u) => u(t));
  }, l = () => {
    const u = _n(e.getHeadings(), {
      scrollContainer: e.scrollContainer,
      topInset: e.topInset
    });
    u !== t && (t = u, a());
  }, r = () => {
    o || typeof window > "u" || (o = window.requestAnimationFrame(() => {
      o = 0, l();
    }));
  }, f = () => {
    o && typeof window < "u" && (window.cancelAnimationFrame(o), o = 0), n == null || n(), n = null, i = null;
  }, c = () => {
    if (typeof window > "u")
      return;
    const u = ui(
      e.getHeadings(),
      e.scrollContainer
    );
    if (u === i && n || (f(), !u))
      return;
    i = u;
    const p = window;
    u.addEventListener("scroll", r, {
      passive: !0
    }), p.addEventListener("resize", r), n = () => {
      u.removeEventListener("scroll", r), p.removeEventListener("resize", r);
    };
  };
  return {
    getActiveReadingHeadingId() {
      return t;
    },
    subscribe(u) {
      return s.add(u), c(), () => {
        s.delete(u), s.size === 0 && f();
      };
    },
    refresh() {
      c(), l();
    },
    destroy() {
      s.clear(), f();
    }
  };
}, na = (e) => {
  var n;
  const t = (n = e.node) == null ? void 0 : n.attrs, o = t == null ? void 0 : t[cr];
  return typeof o == "string" && o.length > 0 ? o : null;
}, oa = (e) => {
  const t = e.dom;
  if (!(t instanceof HTMLElement))
    return null;
  const o = t.getAttribute(lr) || t.dataset.blockId;
  return typeof o == "string" && o.length > 0 ? o : null;
}, Rt = (e) => oa(e) ?? na(e) ?? e.id, ia = (e, t) => e.id === t || Rt(e) === t, sn = (e) => typeof e == "string" && e.length > 0, co = (e) => {
  if (!e || typeof e != "object")
    return !1;
  const t = e;
  return typeof t.id == "string" && typeof t.pos == "number" && typeof t.textContent == "string" && typeof t.level == "number" && typeof t.itemIndex == "number" && typeof t.dom == "object" && t.dom !== null;
}, sa = (e) => {
  var t;
  return (t = e == null ? void 0 : e.storage) == null ? void 0 : t.tableOfContents;
}, di = (e) => {
  const t = sa(e), o = Array.isArray(t == null ? void 0 : t.content) ? t.content.filter(co) : [];
  return o.length > 0 ? [...o] : Array.isArray(t == null ? void 0 : t.anchors) ? t.anchors.filter(co) : [];
}, jn = (e, t) => ({
  status: "resolved",
  target: {
    target: e,
    ...t
  }
}), ra = (e, t) => {
  if (!sn(e.blockId))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = un(t, e.blockId);
  if (!o)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  const n = en(
    t,
    e.blockId,
    e.offset ?? 0
  ) ?? o.pos;
  return jn(e, {
    key: `block:${e.blockId}`,
    dom: o.dom,
    blockId: e.blockId,
    pos: n,
    selection: {
      from: n,
      to: n
    }
  });
}, aa = (e, t) => {
  if (!sn(e.blockId))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = di(t).find(
    (a) => ia(a, e.blockId)
  ), n = o ? Rt(o) : e.blockId, i = un(t, n);
  if (!i)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  const s = en(t, n, 0) ?? i.pos;
  return jn(e, {
    key: `heading:${n}`,
    dom: (o == null ? void 0 : o.dom) ?? i.dom,
    blockId: n,
    pos: (o == null ? void 0 : o.pos) ?? s,
    selection: {
      from: s,
      to: s
    }
  });
}, la = (e) => {
  const t = e.anchor.start, o = e.anchor.end;
  return !sn(t.blockId) || !sn(o.blockId) || !Number.isFinite(t.offset) || !Number.isFinite(o.offset) || t.offset < 0 || o.offset < 0;
}, ca = (e, t) => {
  if (la(e))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = e.anchor.start, n = e.anchor.end, i = en(
    t,
    o.blockId,
    o.offset
  ), s = en(
    t,
    n.blockId,
    n.offset
  );
  if (i === null || s === null)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  if (s <= i)
    return {
      status: "failed",
      reason: "invalid-target"
    };
  const a = un(t, o.blockId);
  return jn(e, {
    key: `range:${o.blockId}:${o.offset}-${n.blockId}:${n.offset}`,
    dom: (a == null ? void 0 : a.dom) ?? null,
    blockId: o.blockId,
    anchor: e.anchor,
    pos: i,
    selection: {
      from: i,
      to: s
    }
  });
}, ua = (e) => e ? di(e).map((t) => ({
  key: `heading:${Rt(t)}`,
  kind: "heading",
  label: t.textContent,
  blockId: Rt(t),
  outlineEligible: !0,
  shareable: !0
})) : [], da = () => [
  {
    kind: "heading",
    resolve: (e, t) => aa(e, t.editor),
    list: (e) => ua(e.editor)
  },
  {
    kind: "block",
    resolve: (e, t) => ra(e, t.editor)
  },
  {
    kind: "range",
    resolve: (e, t) => ca(e, t.editor)
  }
], fa = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((o) => {
    t.has(o.key) || t.set(o.key, o);
  }), [...t.values()];
}, pa = (e = []) => {
  const t = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Set(), n = (a) => (t.set(a.kind, a), () => {
    t.get(a.kind) === a && t.delete(a.kind);
  }), i = (a) => Array.isArray(a == null ? void 0 : a.kinds) && a.kinds.length > 0 ? [...new Set(a.kinds)] : [...t.keys()], s = (a) => {
    const l = {
      kinds: a
    };
    o.forEach((r) => r(l));
  };
  return e.forEach((a) => {
    n(a);
  }), {
    register: n,
    getProvider(a) {
      return t.get(a) ?? null;
    },
    async resolve(a, l) {
      const r = t.get(a.kind);
      return r ? r.resolve(a, l) : {
        status: "failed",
        reason: "target-unavailable"
      };
    },
    async list(a, l) {
      const r = [];
      for (const f of i(l)) {
        const c = t.get(f);
        if (!(c != null && c.list))
          continue;
        const u = await c.list(a);
        r.push(...u);
      }
      return fa(r);
    },
    invalidate(a) {
      const l = Array.isArray(a) && a.length > 0 ? [...new Set(a)] : [...t.keys()];
      l.forEach((r) => {
        var f, c;
        (c = (f = t.get(r)) == null ? void 0 : f.invalidate) == null || c.call(f);
      }), s(l);
    },
    subscribeInvalidation(a) {
      return o.add(a), () => {
        o.delete(a);
      };
    }
  };
}, ma = [
  "heading",
  "block",
  "range",
  "annotation",
  "bookmark",
  "search-hit",
  "ai-suggestion",
  "presence"
], va = (e) => {
  const t = [
    ...e.invalidationKinds ?? ma
  ], o = () => e.editor.value ? Array.from(Os(e.editor.value).values()).filter((R) => R.nodeType === "heading").map((R, X) => ({
    id: R.blockId,
    dom: R.dom,
    pos: R.pos,
    order: X
  })) : [], n = pa([
    ...da(),
    Ss()
  ]);
  let i = null, s = [];
  const a = ta({
    getHeadings: o,
    scrollContainer: () => _s(e.rootRef.value) ? e.rootRef.value : null
  }), l = (R) => {
    if (!e.editor.value || !R.resolvedTarget.selection || R.request.focusMode !== "editor" || e.editor.value.isEditable === !1)
      return;
    const X = e.editor.value.state.doc.content.size, Z = Math.min(
      Math.max(R.resolvedTarget.selection.from, 0),
      X
    ), ie = Math.min(
      Math.max(R.resolvedTarget.selection.to, 0),
      X
    ), ce = typeof R.resolvedTarget.pos == "number" ? e.editor.value.state.doc.nodeAt(
      R.resolvedTarget.pos
    ) : null, B = Z === ie && ce && (ce.isAtom || ce.isLeaf) ? zn.create(e.editor.value.state.doc, Z) : Z === ie ? ct.near(e.editor.value.state.doc.resolve(Z)) : ct.create(e.editor.value.state.doc, Z, ie);
    e.editor.value.view.dispatch(
      e.editor.value.state.tr.setSelection(B)
    );
  }, r = Is({
    resolver: async (R, X) => n.resolve(R.target, {
      ...X,
      editor: e.editor.value,
      annotations: e.documentState.value.annotations
    }),
    descriptorReader: async (R, X) => n.list(
      {
        ...R,
        editor: e.editor.value,
        annotations: e.documentState.value.annotations
      },
      X
    ),
    observer: a,
    executor: async (R) => (l(R), As(R))
  });
  let f = 0;
  const c = () => {
    var R;
    if (typeof window > "u") {
      r.retryDeferredNavigation(), (R = a.refresh) == null || R.call(a);
      return;
    }
    f || (f = window.requestAnimationFrame(() => {
      var X;
      f = 0, r.retryDeferredNavigation(), (X = a.refresh) == null || X.call(a);
    }));
  }, u = () => {
    n.invalidate(t), c();
  }, p = () => {
    i == null || i(), i = null, s.forEach((Z) => Z()), s = [];
    const R = e.getBookmarkProvider();
    R && (i = n.register(R));
    const X = e.getEphemeralProviders();
    Array.isArray(X) && (s = X.map(
      (Z) => n.register(Z)
    )), u();
  };
  Q(
    () => [e.getBookmarkProvider(), e.getEphemeralProviders()],
    () => {
      p();
    },
    {
      immediate: !0
    }
  );
  const m = (R) => r.navigate(R), y = () => {
    r.cancel();
  }, M = () => r.getSnapshot(), _ = () => Zo(r.getSnapshot()), T = (R) => r.listDescriptors(R), k = (R) => r.syncFromLocation(R), g = (R) => r.createShareableFragment(R), V = (R) => e.editor.value ? Es(e.editor.value, R) : null, U = (R, X = {}) => !e.editor.value || !un(e.editor.value, R) ? !1 : (r.navigate({
    source: "external-api",
    target: {
      kind: "block",
      blockId: R
    },
    align: X.align,
    behavior: X.scrollBehavior,
    focusMode: X.focus === !1 ? "preserve" : "editor",
    history: "none",
    reason: "legacy-block-navigation"
  }), !0);
  return {
    navigationController: r,
    scheduleNavigationRefresh: c,
    refreshNavigationRuntime: u,
    syncEditorNavigationBridge: () => {
      if (!e.editor.value)
        return;
      const R = e.editor.value;
      R.navigationController = r, R.navigate = m, R.cancelNavigation = y, R.getNavigationSnapshot = M, R.getNavigationDebugSnapshot = _, R.listNavigationDescriptors = T, R.syncNavigationFromLocation = k, R.createShareableFragment = g, R.navigateToBlock = U;
    },
    destroy: () => {
      f && typeof window < "u" && (window.cancelAnimationFrame(f), f = 0), i == null || i(), i = null, s.forEach((R) => R()), s = [], r.destroy();
    },
    navigateToBlock: U,
    navigate: m,
    cancelNavigation: y,
    getNavigationSnapshot: M,
    getNavigationDebugSnapshot: _,
    listNavigationDescriptors: T,
    syncNavigationFromLocation: k,
    createShareableFragment: g,
    getBlockElement: V
  };
}, ga = {
  "insert.link": Dt(
    () => import("./insert-link-DCF3o7WR.mjs")
  ),
  "insert.image": Dt(
    () => Promise.resolve().then(() => $l)
  ),
  "insert.video": Dt(
    () => import("./insert-video-B0as12yF.mjs")
  ),
  "insert.iframe": Dt(
    () => import("./InsertIframe-D8EshNoh.mjs")
  ),
  "table.menu": Dt(
    () => import("./table-menu-B_rJSK3k.mjs")
  )
}, ha = (e = {}) => Rs({
  ...e,
  renderers: { ...ga, ...e.renderers }
}), ba = [
  "fixed-menu",
  "bubble-menu",
  "floating-menu"
], sf = {
  id: "document-workbench-toolbar-platform",
  package: "@zxio/text-editor",
  role: "toolbar-engine",
  owns: [
    "editor-command-truth",
    "toolbar-state-snapshots",
    "editor-toolbar-contributions",
    "toolbar-surface-contracts"
  ],
  doesNotOwn: ["workbench-layout", "shell-actions", "host-product-semantics"],
  legacyCompat: {
    menuModel: "MenuButton/MenuButtonConfig",
    surfaces: ba,
    status: "removed",
    replacementSurfaces: ["workbench-top", "bubble", "floating"]
  }
}, fi = (e) => {
  const t = [], o = /* @__PURE__ */ new Map();
  for (const n of e) {
    const i = Math.max(0, n.width), s = o.get(n.groupId);
    if (s == null) {
      o.set(n.groupId, t.length), t.push({
        id: n.groupId,
        width: i,
        itemIds: [n.id],
        priority: n.priority
      });
      continue;
    }
    const a = t[s];
    a.width += i, a.itemIds.push(n.id), a.priority = Math.min(a.priority, n.priority);
  }
  return t;
}, ya = (e) => {
  const t = e.items.filter((c) => c.width >= 0);
  if (t.length === 0 || e.containerWidth <= 0)
    return {
      visibleIds: [],
      overflowIds: t.map((c) => c.id)
    };
  const o = fi(t);
  if (o.length === 0)
    return { visibleIds: [], overflowIds: [] };
  if (o.reduce((c, u) => c + u.width, 0) <= e.containerWidth)
    return {
      visibleIds: o.flatMap((c) => c.itemIds),
      overflowIds: []
    };
  const i = Math.max(0, e.moreButtonWidth), s = Math.max(0, e.containerWidth - i), a = [];
  let l = 0;
  for (const c of o) {
    if (l + c.width <= s) {
      a.push(c), l += c.width;
      continue;
    }
    break;
  }
  a.length === 0 && o[0].width <= s && a.push(o[0]);
  const r = new Set(a.flatMap((c) => c.itemIds)), f = t.map((c) => c.id).filter((c) => !r.has(c));
  return {
    visibleIds: [...r],
    overflowIds: f
  };
}, ka = (e) => {
  const t = e.items.filter((u) => u.width >= 0);
  if (t.length === 0 || e.containerWidth <= 0)
    return e.overflowIds.length === t.length;
  const o = fi(t);
  if (o.length === 0)
    return e.overflowIds.length === 0;
  const n = new Set(e.overflowIds);
  let i = o.length;
  for (let u = 0; u < o.length; u += 1) {
    const p = o[u];
    if (p.itemIds.some((y) => n.has(y))) {
      if (!p.itemIds.every((y) => n.has(y)))
        return !1;
      i = u;
      break;
    }
  }
  for (let u = i; u < o.length; u += 1)
    if (!o[u].itemIds.every((m) => n.has(m)))
      return !1;
  const a = o.slice(0, i).reduce((u, p) => u + p.width, 0), l = o.reduce((u, p) => u + p.width, 0);
  if (i === o.length)
    return l <= e.containerWidth;
  const r = Math.max(0, e.moreButtonWidth), f = Math.max(0, e.containerWidth - r);
  if (a > f)
    return !1;
  const c = o[i];
  return a + c.width > f;
}, pi = Symbol(
  "basicRichTextFieldContext"
), wa = (e, t) => Ye(e, {
  ...t,
  characters: Number.MAX_SAFE_INTEGER,
  bytes: Number.MAX_SAFE_INTEGER,
  nodes: Number.MAX_SAFE_INTEGER
}), xa = Object.freeze([
  {
    skillId: "improve-writing",
    label: "Improve writing",
    commandId: "improve-writing",
    description: "Clarify and strengthen the selected text"
  },
  {
    skillId: "proofread",
    label: "Proofread",
    commandId: "proofread",
    description: "Fix grammar and spelling"
  },
  {
    skillId: "explain",
    label: "Explain",
    commandId: "explain",
    description: "Explain the selected text"
  },
  {
    skillId: "reformat",
    label: "Reformat",
    commandId: "reformat",
    description: "Reformat the selected text"
  }
]), Ta = Object.freeze([
  {
    id: "continue-writing",
    label: "Continue writing",
    commandId: "continue-writing",
    parameters: Object.freeze({}),
    icon: "lucide:pen-line"
  },
  {
    id: "draft-outline",
    label: "Draft an outline",
    commandId: "draft-outline",
    parameters: Object.freeze({}),
    icon: "lucide:list-tree"
  },
  {
    id: "brainstorm-ideas",
    label: "Brainstorm ideas",
    commandId: "brainstorm-ideas",
    parameters: Object.freeze({}),
    icon: "lucide:lightbulb"
  }
]), On = (e) => e === "brewing" ? { kind: "close-presentation" } : e === "reviewing" ? { kind: "dismiss-review-ui" } : e === "skills" || e === "user-input" || e === "selection-bubble" ? { kind: "close-idle" } : { kind: "noop" }, Ia = [
  {
    id: nr,
    label: "Ask AI",
    shortcutBindingId: "textEditor.askAI.open"
  }
], Aa = ["aria-label", "aria-haspopup", "aria-expanded"], Ea = /* @__PURE__ */ Te({
  name: "ZxDragHandle",
  __name: "drag-handle",
  props: {
    editor: {},
    showPlus: { type: Boolean },
    onPlusClick: { type: Function },
    askAIBridge: {}
  },
  setup(e) {
    const t = e, o = De("drag-handle"), n = yt("editor", null), i = S(() => t.editor ?? (n == null ? void 0 : n.value) ?? null), s = J(-1), a = J(null), l = J(!1), r = J(null), f = J([]), c = J(null), u = J(!1), p = {
      duration: 100,
      offset: [0, 0],
      zIndex: 99
    }, m = Ia, { text: y } = cn({
      runtime: () => {
        var N;
        return (N = qo(i.value)) == null ? void 0 : N.runtime;
      },
      bindingId: "textEditor.askAI.open"
    }), M = S(() => t.askAIBridge ?? null), _ = (N) => {
      s.value = N.pos, a.value = N.node, N.node || w();
    }, T = () => {
      var K;
      const N = (K = a.value) == null ? void 0 : K.attrs, O = N == null ? void 0 : N.blockId;
      return typeof O == "string" && O.length > 0 ? O : null;
    }, k = () => {
      var se;
      const N = i.value;
      if (!N) return;
      const O = s.value;
      if (O < 0 || !a.value) return;
      const K = O + a.value.nodeSize;
      N.chain().focus().insertContentAt(K, { type: "paragraph" }).focus(K + 1).run(), (se = t.onPlusClick) == null || se.call(t), w();
    }, g = () => {
      c.value = null, u.value = !1;
    }, V = () => {
      u.value = !0, c.value && (c.value.exceeded = !0), w();
    }, U = (N) => {
      var K;
      if (!M.value) return;
      c.value = {
        pointerId: N.pointerId,
        x: N.clientX,
        y: N.clientY,
        exceeded: !1
      }, u.value = !1;
      const O = N.currentTarget;
      if (O instanceof HTMLElement) {
        (K = O.setPointerCapture) == null || K.call(O, N.pointerId);
        const se = (le) => {
          const pe = c.value;
          if (!pe || pe.pointerId !== le.pointerId) return;
          const be = le.clientX - pe.x, ve = le.clientY - pe.y;
          (Math.hypot(be, ve) > or || u.value) && (pe.exceeded = !0, w());
        }, ge = (le) => {
          var pe;
          (pe = O.releasePointerCapture) == null || pe.call(O, le.pointerId), O.removeEventListener("pointermove", se), O.removeEventListener("pointerup", ge), O.removeEventListener("pointercancel", ge);
        };
        O.addEventListener("pointermove", se), O.addEventListener("pointerup", ge), O.addEventListener("pointercancel", ge);
      }
    }, x = async () => {
      var N;
      M.value && (l.value = !0, await dt(), (N = f.value[0]) == null || N.focus());
    }, w = () => {
      l.value = !1;
    }, R = (N) => {
      if (!M.value) return;
      const O = c.value;
      if (!O || O.pointerId !== N.pointerId) return;
      const K = !O.exceeded && !u.value && N.button === 0;
      g(), K && x();
    }, X = (N) => {
      M.value && (N.preventDefault(), N.stopPropagation());
    }, Z = (N) => {
      M.value && (N.key === "Enter" || N.key === " " ? (N.preventDefault(), x()) : N.key === "Escape" && w());
    }, ie = () => {
      const N = M.value;
      if (!N) return;
      const O = T();
      N.openInvocation({
        surface: "block-handle",
        ...O ? { blockIds: [O] } : {}
      }), w();
    }, ce = (N) => {
      var O;
      N.key === "Escape" ? (N.preventDefault(), w()) : N.key === "Enter" || N.key === " " ? (N.preventDefault(), ie()) : (N.key === "ArrowDown" || N.key === "ArrowUp") && (N.preventDefault(), (O = f.value[0]) == null || O.focus());
    }, B = (N) => {
      var K;
      if (!l.value) return;
      const O = N.target;
      O instanceof Node && ((K = r.value) != null && K.contains(O) || w());
    }, C = (N) => {
      N.key === "Escape" && l.value && w();
    };
    return Q(l, (N) => {
      typeof document > "u" || (N ? (document.addEventListener("pointerdown", B, !0), document.addEventListener("keydown", C, !0)) : (document.removeEventListener("pointerdown", B, !0), document.removeEventListener("keydown", C, !0)));
    }), rt(() => {
      typeof document > "u" || (document.removeEventListener("pointerdown", B, !0), document.removeEventListener("keydown", C, !0));
    }), (N, O) => i.value ? (L(), $e(v(Ir), {
      key: 0,
      editor: i.value,
      "tippy-options": p,
      "on-node-change": _
    }, {
      default: ht(() => [
        D("div", {
          class: q(v(o).b()),
          onDragstart: V
        }, [
          e.showPlus ? (L(), F("button", {
            key: 0,
            type: "button",
            class: q(v(o).e("btn")),
            "aria-label": "insert block",
            onMousedown: O[0] || (O[0] = Ke(() => {
            }, ["prevent", "stop"])),
            onClick: Ke(k, ["prevent", "stop"])
          }, [
            j(v(xe), { icon: "lucide:plus" })
          ], 34)) : ae("", !0),
          D("button", {
            type: "button",
            class: q([
              v(o).e("btn"),
              v(o).e("grip"),
              v(o).is("menu-enabled", !!M.value)
            ]),
            "aria-label": M.value ? "block actions" : "drag handle",
            "aria-haspopup": M.value ? "menu" : void 0,
            "aria-expanded": M.value ? l.value : void 0,
            onPointerdown: U,
            onPointerup: R,
            onPointercancel: g,
            onClick: X,
            onKeydown: Z
          }, [
            j(v(xe), { icon: "lucide:grip-vertical" })
          ], 42, Aa),
          l.value && M.value ? (L(), F("div", {
            key: 1,
            ref_key: "menuRef",
            ref: r,
            class: q(v(o).e("menu")),
            role: "menu",
            "aria-label": "Block actions"
          }, [
            (L(!0), F(Le, null, Pe(v(m), (K) => (L(), F("button", {
              key: K.id,
              ref_for: !0,
              ref_key: "menuItemRefs",
              ref: f,
              type: "button",
              class: q(v(o).e("menu-item")),
              role: "menuitem",
              onClick: Ke(ie, ["stop"]),
              onKeydown: ce
            }, [
              D("span", null, me(K.label), 1),
              D("kbd", {
                class: q(v(o).e("shortcut"))
              }, me(v(y)), 3)
            ], 34))), 128))
          ], 2)) : ae("", !0)
        ], 34)
      ]),
      _: 1
    }, 8, ["editor"])) : ae("", !0);
  }
}), Sa = 8, uo = (e) => !!(e && typeof e == "object" && typeof e.on == "function" && typeof e.off == "function"), _a = (e, t) => {
  if (e.size !== t.size)
    return !1;
  for (const o of e)
    if (!t.has(o))
      return !1;
  return !0;
}, Oa = (e) => {
  const t = [];
  let o = [];
  const n = () => {
    o.length !== 0 && (t.push(o), o = []);
  };
  for (const i of e) {
    if (i.definition.kind === "separator") {
      n();
      continue;
    }
    if (i.definition.kind === "spacer") {
      n(), t.push([i]);
      continue;
    }
    o.push(i);
  }
  return n(), t;
}, Ze = (e) => {
  e.preventDefault();
}, fo = (e) => e.kind === "dropdown", xn = (e) => e.kind === "select", po = (e) => e.kind === "color", mo = (e) => e.kind === "split-button", Rn = (e, t) => e == null || t == null ? e == null && t == null : e === t || String(e) === String(t), Ra = (e, t) => e.find((o) => Rn(o.value, t)) ?? null, Na = (e) => !!(e && (typeof e == "object" || typeof e == "function" && ("setup" in e || "render" in e || "__asyncLoader" in e))), La = (e) => typeof e == "function" && !Na(e), mi = /* @__PURE__ */ Te({
  name: "TextEditorToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    surface: {
      type: String,
      default: "workbench-top"
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    }
  },
  setup(e) {
    const t = De("text-editor-toolbar"), {
      text: o
    } = ts(), n = $t(), i = yt("editor", null), s = S(() => e.editor ?? (i == null ? void 0 : i.value) ?? null), {
      binding: a
    } = bt(e.themeOwner), l = Ne(null), r = Ne(null), f = Ne(lo()), c = J(""), u = J(null), p = J(null), m = J(null), y = J(null), M = J(/* @__PURE__ */ new Set()), _ = J(!1);
    let T = null, k = null, g = !1, V = !1, U = !1, x = !1;
    const w = S(() => e.surface === "workbench-top"), R = (d) => {
      l.value = Ns({
        contributions: [...e.includeDefaultContribution ? [ha()] : [], ...Ls(d), ...e.contributions]
      });
    }, X = (d) => [...d.capabilities].sort().join("|"), Z = (d) => {
      var A;
      const h = ((A = l.value) == null ? void 0 : A.resolveState(d)) ?? lo();
      return f.value = h, h;
    }, ie = (d, h = Z(d)) => {
      var A;
      r.value = ((A = l.value) == null ? void 0 : A.prepareSurface(e.surface, {
        editor: d,
        state: h
      })) ?? {
        surface: e.surface,
        items: []
      }, c.value = X(h);
    }, ce = () => {
      const d = s.value, h = Z(d);
      (!r.value || r.value.surface !== e.surface || c.value !== X(h)) && ie(d, h);
    }, B = () => {
      U || (U = !0, Promise.resolve().then(() => {
        U = !1, !x && ce();
      }));
    }, C = (d) => {
      uo(d) && (d.off("selectionUpdate", B), d.off("transaction", B));
    }, N = (d) => {
      uo(d) && (d.on("selectionUpdate", B), d.on("transaction", B));
    };
    Q(s, (d, h) => {
      C(h), N(d), R(d), ie(d);
    }, {
      immediate: !0
    }), Q(() => [e.includeDefaultContribution, e.contributions], () => {
      R(s.value), ie(s.value);
    }, {
      deep: !0
    }), Q(() => e.surface, () => {
      ie(s.value);
    }), rt(() => {
      x = !0, k == null || k.disconnect(), k = null, C(s.value);
    });
    const O = S(() => {
      var d;
      return (r.value && ((d = l.value) == null ? void 0 : d.resolvePreparedSurface(r.value, {
        editor: s.value,
        state: f.value
      }))) ?? {
        surface: e.surface,
        state: f.value,
        items: []
      };
    }), K = S(() => Oa(O.value.items)), se = (d, h) => {
      var A;
      return ((A = d[0]) == null ? void 0 : A.definition.id) ?? `group-${h}`;
    }, ge = (d, h) => {
      const A = d.querySelector(`[data-overflow-group="${h}"]`);
      return Math.max(0, (A == null ? void 0 : A.getBoundingClientRect().width) ?? 0);
    }, le = (d) => {
      const h = y.value;
      return h ? h.getBoundingClientRect().width + (Number.parseFloat(window.getComputedStyle(h).marginLeft) || 0) + (Number.parseFloat(d.columnGap) || 0) : 0;
    }, pe = S(() => O.value.items.map((d) => {
      const h = d.resolved.value == null ? "" : String(d.resolved.value), A = d.definition.label ?? "";
      return `${d.definition.id}:${d.definition.kind}:${h}:${A}`;
    }).join("|")), be = (d = {}) => {
      if (!w.value || g || x) {
        d.force && (V = !0);
        return;
      }
      d.force && (V = !0), g = !0, dt(() => {
        requestAnimationFrame(() => {
          if (g = !1, x || !w.value) {
            V = !1;
            return;
          }
          const h = p.value, A = m.value, P = K.value, ue = V;
          if (V = !1, !h || !A || P.length === 0) {
            M.value.size > 0 && (M.value = /* @__PURE__ */ new Set()), T = null;
            return;
          }
          const Be = window.getComputedStyle(h), pt = (Number.parseFloat(Be.paddingLeft) || 0) + (Number.parseFloat(Be.paddingRight) || 0), Tt = Math.max(0, h.getBoundingClientRect().width - pt);
          if (!ue && T != null && Math.abs(Tt - T) < 1)
            return;
          const Nt = P.flatMap((nt, Bt) => {
            const qt = se(nt, Bt), Gt = ge(A, qt);
            return nt.map((Ct, mn) => ({
              id: Ct.definition.id,
              width: mn === 0 ? Gt : 0,
              groupId: qt,
              priority: Ct.definition.priority ?? Bt * 100
            }));
          }), Kt = {
            containerWidth: Math.max(0, Tt - Sa),
            moreButtonWidth: le(Be),
            items: Nt
          }, fn = [...M.value];
          if (ka({
            ...Kt,
            overflowIds: fn
          }) && !ue) {
            T = Tt;
            return;
          }
          const pn = ya(Kt), Lt = new Set(pn.overflowIds);
          _a(Lt, M.value) || (M.value = Lt), T = Tt, Lt.size === 0 && (_.value = !1);
        });
      });
    };
    Ht(() => {
      !w.value || typeof ResizeObserver > "u" || (k = new ResizeObserver((d) => {
        be({
          force: d.some((h) => h.target !== p.value)
        });
      }), p.value && k.observe(p.value), y.value && k.observe(y.value), be());
    }), Q(() => [w.value, pe.value], ([d]) => {
      if (!d) {
        M.value = /* @__PURE__ */ new Set(), _.value = !1, T = null;
        return;
      }
      k && p.value && k.observe(p.value), be({
        force: !0
      });
    }), Q(p, (d, h) => {
      k && (h && k.unobserve(h), d && w.value && (k.observe(d), be()));
    }), Q(y, (d, h) => {
      k && (h && k.unobserve(h), d && k.observe(d));
    });
    const ve = () => ({
      editor: s.value,
      snapshot: f.value
    }), de = (d, h) => {
      u.value = h ? d : u.value === d ? null : u.value;
    }, _e = () => {
      u.value = null;
    }, Ee = (d) => o(d.definition.id, d.definition.label ?? d.definition.id), ee = (d) => o(`option:${d.id}`, d.label), ne = (d) => {
      if (!xn(d.definition))
        return Ee(d);
      const h = Ra(d.definition.options, d.resolved.value);
      return h ? ee(h) : d.resolved.value != null ? String(d.resolved.value) : Ee(d);
    }, he = (d) => d ? typeof d == "string" ? j(xe, {
      icon: d,
      class: t.e("button-icon")
    }, null) : Ft(d, {
      class: t.e("button-icon")
    }) : null, oe = (d, h) => typeof h == "boolean" ? h : !!d.definition.icon && (d.definition.kind === "action" || d.definition.kind === "toggle" || d.definition.kind === "color" || d.definition.kind === "custom"), ze = (d, h = {}) => {
      const A = oe(d, h.iconOnly), P = h.label ?? Ee(d);
      return j(Le, null, [!h.hideIcon && d.definition.icon ? j("span", {
        class: t.e("button-icon-shell"),
        "aria-hidden": "true"
      }, [he(d.definition.icon)]) : null, A ? null : j("span", {
        class: t.e("button-label")
      }, [P]), h.showCaret ? j("span", {
        class: t.e("button-caret"),
        "aria-hidden": "true"
      }, [j(xe, {
        icon: "lucide:chevron-down"
      }, null)]) : null, d.resolved.indicatorColor ? j("span", {
        class: t.e("button-indicator"),
        style: {
          backgroundColor: d.resolved.indicatorColor
        },
        "aria-hidden": "true"
      }, null) : null]);
    }, Fe = (d, h = {}) => j(Le, null, [j("span", {
      class: t.e("button-icon-shell"),
      "aria-hidden": "true"
    }, [he(d.definition.icon), d.resolved.indicatorColor ? j("span", {
      class: t.e("button-indicator"),
      style: {
        backgroundColor: d.resolved.indicatorColor
      }
    }, null) : null]), j("span", {
      class: t.e("menu-item-label")
    }, [h.label ?? Ee(d)]), h.value ? j("span", {
      class: t.e("menu-item-value")
    }, [h.value]) : null, h.showCaret ? j("span", {
      class: t.e("button-caret"),
      "aria-hidden": "true"
    }, [j(xe, {
      icon: "lucide:chevron-right"
    }, null)]) : null]), Je = async (d) => {
      await Bs(d.definition, {
        ...ve(),
        surface: e.surface,
        capabilities: O.value.state.capabilities
      });
    }, Qe = async (d, h) => {
      var A, P;
      fo(d.definition) && (await ((P = (A = d.definition).onOptionSelect) == null ? void 0 : P.call(A, h, ve())), _e());
    }, W = async (d, h) => {
      if (xn(d.definition)) {
        await d.definition.onValueChange(h, ve()), _e();
        return;
      }
      po(d.definition) && (await d.definition.onValueChange(typeof h == "string" ? h : null, ve()), _e());
    }, ye = async (d) => {
      if (!mo(d.definition)) {
        await Je(d);
        return;
      }
      await d.definition.runPrimary(ve());
    }, Re = (d, h = {}) => {
      const A = h.active ?? d.resolved.active, P = h.disabled ?? d.resolved.disabled, ue = h.presentation === "menu", Be = !ue && oe(d, h.iconOnly), pt = !!h.showCaret;
      return j("button", {
        key: d.definition.id,
        type: "button",
        class: [t.e(ue ? "menu-item" : "button"), h.class, A && "is-active", P && "is-disabled", u.value === d.definition.id && "is-open"],
        disabled: P,
        title: [Ee(d), h.shortcut].filter(Boolean).join(" · "),
        "aria-keyshortcuts": h.shortcutAriaLabel || void 0,
        "aria-label": Ee(d),
        "aria-haspopup": pt ? "menu" : void 0,
        "aria-expanded": pt ? u.value === d.definition.id : void 0,
        "aria-pressed": d.definition.kind === "toggle" ? A ? "true" : "false" : void 0,
        "data-item-id": d.definition.id,
        "data-kind": d.definition.kind,
        "data-icon-only": ue ? void 0 : Be ? "true" : "false",
        "data-has-caret": ue ? void 0 : pt ? "true" : "false",
        onMousedown: Ze,
        onClick: h.onClick
      }, [ue ? Fe(d, {
        label: h.label,
        value: h.value,
        showCaret: h.showCaret
      }) : ze(d, {
        label: h.label,
        iconOnly: Be,
        showCaret: h.showCaret,
        hideIcon: h.hideIcon
      })]);
    }, Ge = (d) => d === "menu" ? "right-start" : "bottom-start", tt = (d, h, A = {}) => {
      var P;
      return Ft(Qt, {
        key: d.definition.id,
        visible: u.value === d.definition.id,
        variant: "popover",
        trigger: "click",
        placement: Ge(A.presentation ?? "toolbar"),
        offset: 6,
        // ElPopover defaults to 150px; color grid needs ~256px+.
        width: "auto",
        popperClass: t.e("popover"),
        persistent: !1,
        disabled: !a.value,
        appendTo: (P = a.value) == null ? void 0 : P.target,
        "onUpdate:visible": (ue) => {
          de(d.definition.id, ue);
        }
      }, {
        default: () => Re(d, {
          label: A.label,
          value: A.value,
          iconOnly: A.iconOnly,
          hideIcon: A.hideIcon,
          presentation: A.presentation,
          showCaret: !0
        }),
        content: () => j("div", {
          class: t.e("menu"),
          onMousedown: Ze
        }, [h])
      });
    }, He = (d, h, A = {}) => j("button", {
      type: "button",
      class: [t.e("menu-item"), (A.active ?? !1) && "is-active", h.disabled && "is-disabled"],
      disabled: h.disabled,
      "data-option-id": h.id,
      onMousedown: Ze,
      onClick: A.onClick
    }, [j("span", {
      class: t.e("menu-item-label")
    }, [ee(h)])]), E = (d, h) => {
      if (d.definition.kind !== "custom")
        return null;
      if (La(d.definition.render)) {
        const A = d.definition.render;
        return j("div", {
          key: d.definition.id,
          class: t.e("custom"),
          "data-item-id": d.definition.id
        }, [A({
          editor: s.value,
          snapshot: O.value.state,
          item: d.definition
        })]);
      }
      return j("div", {
        key: d.definition.id,
        class: t.e("custom"),
        "data-item-id": d.definition.id
      }, [Ft(d.definition.render, {
        key: d.definition.id,
        editor: s.value
      }, {
        default: (A) => Re(d, {
          presentation: h,
          disabled: A == null ? void 0 : A.disabled,
          shortcut: A == null ? void 0 : A.shortcut,
          shortcutAriaLabel: A == null ? void 0 : A.shortcutAriaLabel,
          active: typeof (A == null ? void 0 : A.isActive) == "boolean" ? A.isActive : d.resolved.active,
          onClick: () => {
            if (typeof (A == null ? void 0 : A.onClick) == "function") {
              A.onClick();
              return;
            }
            Je(d);
          }
        })
      })]);
    }, I = (d, h = "toolbar") => {
      var A;
      if (d.definition.kind === "separator")
        return null;
      if (d.definition.kind === "spacer")
        return j("span", {
          key: d.definition.id,
          class: t.e("spacer"),
          "data-item-id": d.definition.id,
          "aria-hidden": "true"
        }, null);
      if (d.definition.kind === "custom")
        return E(d, h);
      if (fo(d.definition))
        return tt(d, j("div", {
          class: t.e("menu-list")
        }, [d.definition.options.map((P) => He(d, P, {
          active: P.id === d.resolved.value,
          onClick: () => {
            Qe(d, P.id);
          }
        }))]), {
          presentation: h
        });
      if (xn(d.definition)) {
        const P = d.definition.includeResetOption !== !1;
        return tt(
          d,
          j("div", {
            class: t.e("menu-list")
          }, [P ? j("button", {
            type: "button",
            class: [t.e("menu-item"), d.resolved.value == null && "is-active"],
            onMousedown: Ze,
            onClick: () => {
              W(d, null);
            }
          }, [j("span", {
            class: t.e("menu-item-label")
          }, [o("panel:default", "Default")])]) : null, d.definition.options.map((ue) => He(d, ue, {
            active: Rn(ue.value, d.resolved.value),
            onClick: () => {
              W(d, ue.value ?? null);
            }
          }))]),
          // The track shows the current value in place of the name; a menu
          // row keeps the name and trails the value.
          h === "menu" ? {
            presentation: h,
            value: d.resolved.value != null ? ne(d) : null
          } : {
            label: ne(d)
          }
        );
      }
      if (po(d.definition))
        return tt(d, j("div", {
          class: t.e("color-panel")
        }, [j("button", {
          type: "button",
          class: [t.e("color-clear"), d.resolved.value == null && "is-active"],
          onMousedown: Ze,
          onClick: () => {
            W(d, null);
          }
        }, [j("span", {
          class: t.e("menu-item-label")
        }, [o("panel:clear-color", "Clear color")])]), j("div", {
          class: t.e("color-grid")
        }, [d.definition.options.map((P) => j("button", {
          type: "button",
          class: [t.e("color-swatch"), Rn(P.value, d.resolved.value) && "is-active"],
          title: ee(P),
          "aria-label": ee(P),
          style: {
            backgroundColor: P.swatch
          },
          onMousedown: Ze,
          onClick: () => {
            W(d, P.value ?? null);
          }
        }, null))]), d.definition.allowCustomValue ? j("label", {
          class: t.e("color-picker")
        }, [j("span", {
          class: t.e("color-picker-label")
        }, [o("panel:custom", "Custom")]), j("input", {
          type: "color",
          value: typeof d.resolved.value == "string" ? d.resolved.value : "#000000",
          onMousedown: Ze,
          onInput: (P) => {
            W(d, P.target.value);
          }
        }, null)]) : null]), {
          presentation: h
        });
      if (mo(d.definition)) {
        const P = d.definition;
        return j("div", {
          key: P.id,
          class: [t.e("split-button"), d.resolved.active && "is-active", d.resolved.disabled && "is-disabled"]
        }, [Re(d, {
          presentation: h,
          label: P.primaryAction.label ?? Ee(d),
          onClick: () => {
            ye(d);
          }
        }), Ft(Qt, {
          visible: u.value === P.id,
          variant: "popover",
          trigger: "click",
          placement: Ge(h),
          offset: 6,
          width: "auto",
          popperClass: t.e("popover"),
          persistent: !1,
          disabled: !a.value,
          appendTo: (A = a.value) == null ? void 0 : A.target,
          "onUpdate:visible": (ue) => {
            de(P.id, ue);
          }
        }, {
          default: () => j("button", {
            type: "button",
            class: [t.e("split-caret"), d.resolved.disabled && "is-disabled"],
            "aria-label": `${Ee(d)} options`,
            disabled: d.resolved.disabled,
            onMousedown: Ze
          }, [j("span", {
            class: t.e("button-caret"),
            "aria-hidden": "true"
          }, [j(xe, {
            icon: h === "menu" ? "lucide:chevron-right" : "lucide:chevron-down"
          }, null)])]),
          content: () => j("div", {
            class: t.e("menu"),
            onMousedown: Ze
          }, [j("div", {
            class: t.e("menu-list")
          }, [P.options.map((ue) => He(d, ue, {
            onClick: () => {
              var Be;
              (Be = P.onOptionSelect) == null || Be.call(P, ue.id, ve()), _e();
            }
          }))])])
        })]);
      }
      return Re(d, {
        presentation: h,
        onClick: () => {
          Je(d), h === "menu" && (_.value = !1);
        }
      });
    }, H = (d) => w.value && d.some((h) => M.value.has(h.definition.id)), Y = S(() => K.value.filter((d) => d.some((h) => M.value.has(h.definition.id)))), fe = (d, h, A = {
      includeLeadingSeparator: !0
    }) => {
      const P = se(d, h), ue = A.includeLeadingSeparator !== !1;
      return j("div", {
        key: P,
        class: [t.e("group"), H(d) && "is-overflowed"],
        "data-group-index": h,
        "data-overflow-group": P
      }, [ue && h > 0 ? j("span", {
        class: t.e("separator"),
        "aria-hidden": "true"
      }, null) : null, d.map((Be) => I(Be))]);
    }, Ie = (d) => {
      const h = d.definition;
      return h.kind === "separator" || h.kind === "spacer" ? null : j("div", {
        key: `overflow-${h.id}`,
        class: t.e("overflow-entry"),
        "data-overflow-item-id": h.id
      }, [I(d, "menu")]);
    }, Ce = () => {
      var h;
      if (!w.value)
        return null;
      const d = Y.value.length === 0;
      return Ft(Qt, {
        visible: _.value,
        variant: "popover",
        trigger: "click",
        placement: "bottom-end",
        offset: 6,
        width: "auto",
        popperClass: t.e("popover"),
        persistent: !1,
        disabled: d || !a.value,
        appendTo: (h = a.value) == null ? void 0 : h.target,
        "onUpdate:visible": (A) => {
          _.value = A;
        }
      }, {
        default: () => j("button", {
          ref: y,
          type: "button",
          class: [t.e("button"), t.e("more-button"), d && "is-idle", _.value && "is-open"],
          "aria-hidden": d ? "true" : void 0,
          tabindex: d ? -1 : void 0,
          title: "More",
          "aria-label": o("panel:more", "More toolbar actions"),
          "aria-haspopup": "menu",
          "aria-expanded": _.value ? "true" : "false",
          "data-icon-only": "true",
          "data-has-caret": "false",
          onMousedown: Ze
        }, [j("span", {
          class: t.e("button-icon-shell"),
          "aria-hidden": "true"
        }, [j(xe, {
          icon: "lucide:ellipsis",
          class: t.e("button-icon")
        }, null)])]),
        content: () => j("div", {
          class: [t.e("menu"), t.e("overflow-panel")],
          role: "menu",
          onMousedown: Ze
        }, [Y.value.map((A, P) => j("div", {
          key: `overflow-group-${se(A, P)}`,
          class: t.e("overflow-section")
        }, [P > 0 ? j("div", {
          class: t.e("overflow-section-divider"),
          "aria-hidden": "true"
        }, null) : null, A.map((ue) => Ie(ue))]))])
      });
    };
    return () => {
      const d = s.value, h = O.value.items;
      if (!d || h.length === 0)
        return null;
      const A = K.value;
      if (A.length === 0)
        return null;
      const P = Object.fromEntries(Object.entries(n).filter(([ue]) => ue !== "class" && ue !== "style"));
      return w.value ? j("div", st({
        ref: p,
        class: [t.b(), n.class],
        style: n.style,
        "data-surface": e.surface,
        "data-overflow": "true"
      }, P), [j("div", {
        ref: m,
        class: t.e("track")
      }, [A.map((ue, Be) => fe(ue, Be))]), Ce()]) : j("div", st({
        class: [t.b(), n.class],
        style: n.style,
        "data-surface": e.surface
      }, P), [A.map((ue, Be) => fe(ue, Be))]);
    };
  }
}), vo = ["image", "iframe", "video", "imageGroup", "codeBlock", "horizontalRule"], Ba = (e) => {
  var o;
  if (!e || typeof e != "object") return !1;
  const t = (o = e.toJSON) == null ? void 0 : o.call(e);
  return (t == null ? void 0 : t.type) === "nodeRange";
}, Ca = Object.freeze({
  strategy: "fixed",
  placement: "top-start",
  offset: 8,
  flip: Object.freeze({
    fallbackPlacements: ["bottom-start"]
  }),
  shift: Object.freeze({
    padding: 8,
    crossAxis: !0
  })
}), za = ({
  state: e
}) => {
  var n, i;
  const {
    selection: t
  } = e;
  if (t.empty || Ba(t))
    return !1;
  if (t instanceof zn) {
    const s = t.node;
    if (s && vo.includes(s.type.name))
      return !1;
  }
  const o = (i = (n = t.$from) == null ? void 0 : n.node) == null ? void 0 : i.call(n, t.$from.depth);
  return !(o && vo.includes(o.type.name));
}, Ma = /* @__PURE__ */ Te({
  name: "TextEditorBubbleToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    },
    options: {
      type: Object,
      default: () => ({})
    },
    shouldShow: {
      type: Function,
      default: null
    }
  },
  setup(e) {
    const t = De("text-editor-bubble-menu"), o = $t(), n = yt("editor", null), i = S(() => e.editor ?? (n == null ? void 0 : n.value) ?? null), {
      binding: s
    } = bt(e.themeOwner), a = J(!1), l = Mn(a), r = () => {
      a.value = !0, typeof e.options.onShow == "function" && e.options.onShow();
    }, f = () => {
      a.value = !1, typeof e.options.onHide == "function" && e.options.onHide();
    };
    return () => {
      const c = i.value, u = s.value;
      if (!c || !u)
        return null;
      const p = Object.fromEntries(Object.entries(o).filter(([m]) => m !== "class" && m !== "style"));
      return (
        // TipTap removes/reparents its menu element. Keep a Vue-owned root so
        // toggling the toolbar (for example on readonly) has a stable anchor.
        j("div", {
          style: {
            display: "contents"
          }
        }, [j(ei, st({
          editor: c,
          shouldShow: e.shouldShow ?? za,
          options: {
            ...Ca,
            ...e.options,
            onShow: r,
            onHide: f
          },
          appendTo: () => u.target,
          class: [t.b(), o.class],
          style: {
            zIndex: l.value
          }
        }, p), {
          default: () => [j(mi, {
            themeOwner: e.themeOwner,
            editor: c,
            surface: "bubble",
            contributions: e.contributions,
            includeDefaultContribution: e.includeDefaultContribution,
            style: o.style
          }, null)]
        })])
      );
    };
  }
}), Da = (e) => typeof e == "object" && e !== null && !Array.isArray(e), go = (e) => typeof e == "string" || Da(e), Fa = kr({
  contentProfile: { type: String, values: ["full", "basic-rich-text"], default: "full" },
  contentLimits: { type: Ae(Object), default: void 0 },
  /**
   * @description Frozen Runtime-derived owner for every editor overlay and feedback surface.
   */
  themeOwner: {
    type: Ae(Object),
    default: void 0
  },
  /**
   * @description Editor content (deprecated HTML import bridge alias)
   */
  content: {
    type: String,
    default: null
  },
  /**
   * @description v-model binding value for explicit HTML import, Markdown, or JSON modes
   */
  modelValue: {
    type: Ae([String, Object]),
    default: ""
  },
  /**
   * @description Explicit input content type. Prefer `document` or `markdown`; `html` is import-only bridge mode.
   */
  contentType: {
    type: String,
    values: ["html", "markdown", "json", "document"],
    default: "html"
  },
  /**
   * @description Explicit output content type
   */
  outputType: {
    type: String,
    values: ["html", "markdown", "json", "document"],
    default: "html"
  },
  /**
   * @description Markdown export mode
   */
  markdownExportMode: {
    type: String,
    values: ["semantic"],
    default: "semantic"
  },
  /**
   * @description Canonical document envelope value (preferred persistence contract)
   */
  documentValue: {
    type: Ae(Object),
    default: null
  },
  /**
   * @description Placeholder text or function (supports Tiptap's node-based placeholder)
   * @example
   * // Static placeholder
   * placeholder="Write something..."
   * // Dynamic placeholder based on node type
   * :placeholder="({ node }) => node.type.name === 'heading' ? 'Enter title...' : 'Write something...'"
   */
  placeholder: {
    type: Ae([String, Function]),
    default: void 0
  },
  /**
   * @description Placeholder contract for structured block-level defaults (Notion-style headings, lists, etc.)
   */
  placeholderContract: {
    type: Ae(Object),
    default: null
  },
  /**
   * @description Custom class for editor content area
   */
  editorClass: {
    type: Ae([
      String,
      Array,
      Object
    ]),
    default: ""
  },
  /**
   * @description Effective typography contract override for root and block defaults
   */
  typography: {
    type: Ae(Object),
    default: null
  },
  /**
   * @description Whether the editor is editable
   */
  editable: {
    type: Boolean,
    default: !0
  },
  /**
   * @description Whether to autofocus on mount
   */
  autofocus: {
    type: Boolean,
    default: !1
  },
  /**
   * @description Selection bubble toolbar. Mounted by default; pass `false`
   * when the host composes its own bubble surface.
   */
  bubbleToolbar: {
    type: Ae([Boolean, Object]),
    default: !0
  },
  /**
   * @description Drag handle configuration
   */
  dragHandle: {
    type: Ae([Boolean, Object]),
    default: !1
  },
  /**
   * @description Additional TipTap extensions
   */
  extensions: {
    type: Ae(Array),
    default: () => []
  },
  /**
   * @description Stable block identity configuration
   */
  stableBlockIdentity: {
    type: Ae(Object),
    default: () => ({})
  },
  /**
   * @description Collaboration mode model emit strategy
   */
  collaborationEmit: {
    type: Ae(String),
    values: ["none", "html", "markdown", "json", "document", "delta"],
    default: "none"
  },
  /**
   * @description StarterKit configuration options
   */
  starterkitOptions: {
    type: Ae(Object),
    default: () => ({})
  },
  /**
   * @description Optional editor-only Pages layout engine config. Disabled unless an object is provided.
   */
  pagesLayout: {
    type: Ae([
      Boolean,
      Object
    ]),
    default: !1
  },
  /**
   * @description Optional Pages header/footer contract and command layer. Disabled unless an object is provided.
   */
  pagesHeaderFooter: {
    type: Ae([
      Boolean,
      Object
    ]),
    default: !1
  },
  /**
   * @description Mention configuration
   */
  mentions: {
    type: Ae([Array, Object]),
    default: null
  },
  /**
   * @description Tag suggestions
   */
  tags: {
    type: Ae(Array),
    default: () => []
  },
  /**
   * @description Suggestion runtime configuration for mention, tag, emoji, and slash triggers
   */
  suggestions: {
    type: Ae(Object),
    default: () => ({})
  },
  /**
   * @description Formal Slash Catalog Contribution/merge entries (e.g. platform Ask AI).
   */
  slashCatalogContributions: {
    type: Ae(Array),
    default: () => []
  },
  /**
   * @description Formal host contract for the file intake and asset platform.
   * Use this as the long-term integration boundary for classify/import/upload/
   * resolve/policy/openNew/task hooks.
   */
  filePlatform: {
    type: Ae(Object),
    default: null
  },
  /**
   * @description Host-provided bookmark navigation source for shareable bookmark navigation and deep-link recovery. Use `createBookmarkNavigationProvider({ getBookmarks })`.
   */
  bookmarkProvider: {
    type: Ae(Object),
    default: void 0
  },
  /**
   * @description Host-provided ephemeral navigation sources such as search hits, AI suggestions, or collaborator follow. These targets participate in controller navigation but never enter the shareable URL contract.
   */
  ephemeralProviders: {
    type: Ae(Array),
    default: void 0
  },
  /**
   * @description Host-owned code block preferences. These never enter document JSON; they only influence new code block defaults and local authoring UI ordering.
   */
  codeBlockPreferences: {
    type: Ae(Object),
    default: null
  }
}), Pa = {
  "content-issue": (e) => !0,
  /**
   * @description Emitted when content changes
   */
  change: (e) => go(e),
  /**
   * @description v-model update event
   */
  "update:modelValue": (e) => go(e),
  /**
   * @description Document envelope update event
   */
  "update:documentValue": (e) => nn(e),
  /**
   * @description Emitted when the document envelope changes
   */
  "document-change": (e) => nn(e),
  /**
   * @description Emitted when editor gains focus
   */
  focus: (e) => e instanceof FocusEvent,
  /**
   * @description Emitted when editor loses focus
   */
  blur: (e) => e instanceof FocusEvent,
  /**
   * @description Emitted on every editor transaction
   */
  transaction: (e) => !0,
  /**
   * @description Emitted when collaboration delta strategy is enabled
   */
  delta: (e) => Array.isArray(e == null ? void 0 : e.steps) && typeof (e == null ? void 0 : e.version) == "number"
}, Va = (e, t, o) => {
  switch (t) {
    case "none":
    case "delta":
      return;
    case "html":
    case "markdown":
    case "json":
    case "document":
      return Jo(e, {
        outputType: t,
        document: o
      });
  }
}, ja = Object.freeze([
  ".md",
  ".markdown",
  ".html",
  ".htm",
  ".json",
  ".txt"
]), At = (e, t, o) => ({
  intent: "reject",
  code: e,
  reason: t,
  message: o
}), $a = (e) => {
  const t = e.lastIndexOf(".");
  return t < 0 ? "" : e.slice(t).toLowerCase();
}, Ha = (e) => e.trim().toLowerCase() === "readme", Ua = (e) => {
  var t, o;
  return (o = (t = e.constraints) == null ? void 0 : t.importExtensions) != null && o.length ? e.constraints.importExtensions.map(
    (n) => n.toLowerCase()
  ) : [...ja];
}, Ka = (e, t) => {
  const o = $a(e.name);
  if (!t.includes(o))
    return Ha(e.name) || e.type === "text/markdown" ? "markdown" : e.type === "text/html" ? "html" : e.type === "application/json" || e.type === "text/json" ? "json" : e.type === "text/plain" ? "text" : null;
  switch (o) {
    case ".md":
    case ".markdown":
      return "markdown";
    case ".html":
    case ".htm":
      return "html";
    case ".json":
      return "json";
    case ".txt":
      return "text";
    default:
      return null;
  }
}, qa = (e) => e.type.startsWith("image/") ? "image" : e.type.startsWith("video/") ? "video" : "file", Ga = (e) => {
  var i;
  const t = (i = e.context) == null ? void 0 : i.remoteUrl;
  if (typeof t == "string" && /^https?:\/\//i.test(t))
    return t;
  const o = e.htmlContent;
  if (!o)
    return null;
  const n = o.match(/\b(?:src|href)=["'](https?:\/\/[^"']+)["']/i);
  return (n == null ? void 0 : n[1]) ?? null;
}, Wa = (e, t, o) => ({
  event: e,
  decision: t,
  handled: o
}), Ja = async ({
  event: e,
  filePlatform: t
}) => {
  var c, u, p, m, y, M;
  const o = Ga(e);
  if ((u = (c = e.constraints) == null ? void 0 : c.allowedSources) != null && u.length && !e.constraints.allowedSources.includes(e.source))
    return At(
      "source-not-allowed",
      "source-rejected",
      `File intake source "${e.source}" is not allowed by the current platform policy.`
    );
  const n = (p = e.constraints) != null && p.maxFileSizeBytes ? e.files.find(
    (_) => _.size > e.constraints.maxFileSizeBytes
  ) : null;
  if (n)
    return At(
      "file-too-large",
      "size-rejected",
      `File "${n.name}" exceeds the maximum allowed size.`
    );
  const i = await ((m = t == null ? void 0 : t.classify) == null ? void 0 : m.call(t, e));
  if (i)
    return i;
  if (e.files.length === 0)
    return o ? {
      intent: "embed-remote",
      url: o
    } : At(
      "empty-intake",
      "no-files",
      "The intake event did not contain files or a resolvable remote URL."
    );
  const s = Ua(e), a = e.files.map(
    (_) => Ka(_, s)
  ), l = a.filter(
    (_) => !!_
  );
  if (l.length > 0 && l.length !== e.files.length)
    return At(
      "mixed-intents-not-supported",
      "mixed-intents",
      "A single intake event cannot mix import-content files with attachment files."
    );
  if (l.length > 0)
    return e.files.length > 1 ? At(
      "multiple-import-files-not-supported",
      "multiple-import-files",
      "A single intake event cannot import more than one text file at a time."
    ) : {
      intent: "import-content",
      format: a[0] ?? void 0
    };
  const r = (M = (y = e.constraints) == null ? void 0 : y.allowedMimeTypes) != null && M.length ? e.files.find(
    (_) => {
      var T, k;
      return !!_.type && !((k = (T = e.constraints) == null ? void 0 : T.allowedMimeTypes) != null && k.includes(_.type));
    }
  ) : null;
  if (r)
    return At(
      "mime-not-allowed",
      "mime-rejected",
      `File "${r.name}" is not allowed by the current MIME policy.`
    );
  const f = Array.from(
    new Set(e.files.map((_) => qa(_)))
  );
  return {
    intent: "attach-asset",
    assetKind: f.length === 1 ? f[0] : void 0
  };
}, lt = (e, t, o) => Wa(e, t, o), Za = (e) => {
  var o;
  const t = (o = e.body.content) == null ? void 0 : o.content;
  return !Array.isArray(t) || t.length === 0;
}, Xa = (e) => e.source === "drop" || e.source === "paste", Ya = async ({
  currentDocument: e,
  event: t,
  file: o,
  filePlatform: n,
  format: i
}) => {
  var a;
  if (Za(e))
    return "replace-current";
  const s = await ((a = n == null ? void 0 : n.chooseImportDisposition) == null ? void 0 : a.call(n, {
    event: t,
    file: o,
    format: i,
    currentDocument: e
  }));
  return s || (Xa(t) ? "insert-at-selection" : "cancel");
};
function Qa(e, t = !1) {
  const o = e.length;
  let n = 0, i = "", s = 0, a = 16, l = 0, r = 0, f = 0, c = 0, u = 0;
  function p(g, V) {
    let U = 0, x = 0;
    for (; U < g; ) {
      let w = e.charCodeAt(n);
      if (w >= 48 && w <= 57)
        x = x * 16 + w - 48;
      else if (w >= 65 && w <= 70)
        x = x * 16 + w - 65 + 10;
      else if (w >= 97 && w <= 102)
        x = x * 16 + w - 97 + 10;
      else
        break;
      n++, U++;
    }
    return U < g && (x = -1), x;
  }
  function m(g) {
    n = g, i = "", s = 0, a = 16, u = 0;
  }
  function y() {
    let g = n;
    if (e.charCodeAt(n) === 48)
      n++;
    else
      for (n++; n < e.length && Et(e.charCodeAt(n)); )
        n++;
    if (n < e.length && e.charCodeAt(n) === 46)
      if (n++, n < e.length && Et(e.charCodeAt(n)))
        for (n++; n < e.length && Et(e.charCodeAt(n)); )
          n++;
      else
        return u = 3, e.substring(g, n);
    let V = n;
    if (n < e.length && (e.charCodeAt(n) === 69 || e.charCodeAt(n) === 101))
      if (n++, (n < e.length && e.charCodeAt(n) === 43 || e.charCodeAt(n) === 45) && n++, n < e.length && Et(e.charCodeAt(n))) {
        for (n++; n < e.length && Et(e.charCodeAt(n)); )
          n++;
        V = n;
      } else
        u = 3;
    return e.substring(g, V);
  }
  function M() {
    let g = "", V = n;
    for (; ; ) {
      if (n >= o) {
        g += e.substring(V, n), u = 2;
        break;
      }
      const U = e.charCodeAt(n);
      if (U === 34) {
        g += e.substring(V, n), n++;
        break;
      }
      if (U === 92) {
        if (g += e.substring(V, n), n++, n >= o) {
          u = 2;
          break;
        }
        switch (e.charCodeAt(n++)) {
          case 34:
            g += '"';
            break;
          case 92:
            g += "\\";
            break;
          case 47:
            g += "/";
            break;
          case 98:
            g += "\b";
            break;
          case 102:
            g += "\f";
            break;
          case 110:
            g += `
`;
            break;
          case 114:
            g += "\r";
            break;
          case 116:
            g += "	";
            break;
          case 117:
            const w = p(4);
            w >= 0 ? g += String.fromCharCode(w) : u = 4;
            break;
          default:
            u = 5;
        }
        V = n;
        continue;
      }
      if (U >= 0 && U <= 31)
        if (Pt(U)) {
          g += e.substring(V, n), u = 2;
          break;
        } else
          u = 6;
      n++;
    }
    return g;
  }
  function _() {
    if (i = "", u = 0, s = n, r = l, c = f, n >= o)
      return s = o, a = 17;
    let g = e.charCodeAt(n);
    if (Tn(g)) {
      do
        n++, i += String.fromCharCode(g), g = e.charCodeAt(n);
      while (Tn(g));
      return a = 15;
    }
    if (Pt(g))
      return n++, i += String.fromCharCode(g), g === 13 && e.charCodeAt(n) === 10 && (n++, i += `
`), l++, f = n, a = 14;
    switch (g) {
      // tokens: []{}:,
      case 123:
        return n++, a = 1;
      case 125:
        return n++, a = 2;
      case 91:
        return n++, a = 3;
      case 93:
        return n++, a = 4;
      case 58:
        return n++, a = 6;
      case 44:
        return n++, a = 5;
      // strings
      case 34:
        return n++, i = M(), a = 10;
      // comments
      case 47:
        const V = n - 1;
        if (e.charCodeAt(n + 1) === 47) {
          for (n += 2; n < o && !Pt(e.charCodeAt(n)); )
            n++;
          return i = e.substring(V, n), a = 12;
        }
        if (e.charCodeAt(n + 1) === 42) {
          n += 2;
          const U = o - 1;
          let x = !1;
          for (; n < U; ) {
            const w = e.charCodeAt(n);
            if (w === 42 && e.charCodeAt(n + 1) === 47) {
              n += 2, x = !0;
              break;
            }
            n++, Pt(w) && (w === 13 && e.charCodeAt(n) === 10 && n++, l++, f = n);
          }
          return x || (n++, u = 1), i = e.substring(V, n), a = 13;
        }
        return i += String.fromCharCode(g), n++, a = 16;
      // numbers
      case 45:
        if (i += String.fromCharCode(g), n++, n === o || !Et(e.charCodeAt(n)))
          return a = 16;
      // found a minus, followed by a number so
      // we fall through to proceed with scanning
      // numbers
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
        return i += y(), a = 11;
      // literals and unknown symbols
      default:
        for (; n < o && T(g); )
          n++, g = e.charCodeAt(n);
        if (s !== n) {
          switch (i = e.substring(s, n), i) {
            case "true":
              return a = 8;
            case "false":
              return a = 9;
            case "null":
              return a = 7;
          }
          return a = 16;
        }
        return i += String.fromCharCode(g), n++, a = 16;
    }
  }
  function T(g) {
    if (Tn(g) || Pt(g))
      return !1;
    switch (g) {
      case 125:
      case 93:
      case 123:
      case 91:
      case 34:
      case 58:
      case 44:
      case 47:
        return !1;
    }
    return !0;
  }
  function k() {
    let g;
    do
      g = _();
    while (g >= 12 && g <= 15);
    return g;
  }
  return {
    setPosition: m,
    getPosition: () => n,
    scan: t ? k : _,
    getToken: () => a,
    getTokenValue: () => i,
    getTokenOffset: () => s,
    getTokenLength: () => n - s,
    getTokenStartLine: () => r,
    getTokenStartCharacter: () => s - c,
    getTokenError: () => u
  };
}
function Tn(e) {
  return e === 32 || e === 9;
}
function Pt(e) {
  return e === 10 || e === 13;
}
function Et(e) {
  return e >= 48 && e <= 57;
}
var ho;
(function(e) {
  e[e.lineFeed = 10] = "lineFeed", e[e.carriageReturn = 13] = "carriageReturn", e[e.space = 32] = "space", e[e._0 = 48] = "_0", e[e._1 = 49] = "_1", e[e._2 = 50] = "_2", e[e._3 = 51] = "_3", e[e._4 = 52] = "_4", e[e._5 = 53] = "_5", e[e._6 = 54] = "_6", e[e._7 = 55] = "_7", e[e._8 = 56] = "_8", e[e._9 = 57] = "_9", e[e.a = 97] = "a", e[e.b = 98] = "b", e[e.c = 99] = "c", e[e.d = 100] = "d", e[e.e = 101] = "e", e[e.f = 102] = "f", e[e.g = 103] = "g", e[e.h = 104] = "h", e[e.i = 105] = "i", e[e.j = 106] = "j", e[e.k = 107] = "k", e[e.l = 108] = "l", e[e.m = 109] = "m", e[e.n = 110] = "n", e[e.o = 111] = "o", e[e.p = 112] = "p", e[e.q = 113] = "q", e[e.r = 114] = "r", e[e.s = 115] = "s", e[e.t = 116] = "t", e[e.u = 117] = "u", e[e.v = 118] = "v", e[e.w = 119] = "w", e[e.x = 120] = "x", e[e.y = 121] = "y", e[e.z = 122] = "z", e[e.A = 65] = "A", e[e.B = 66] = "B", e[e.C = 67] = "C", e[e.D = 68] = "D", e[e.E = 69] = "E", e[e.F = 70] = "F", e[e.G = 71] = "G", e[e.H = 72] = "H", e[e.I = 73] = "I", e[e.J = 74] = "J", e[e.K = 75] = "K", e[e.L = 76] = "L", e[e.M = 77] = "M", e[e.N = 78] = "N", e[e.O = 79] = "O", e[e.P = 80] = "P", e[e.Q = 81] = "Q", e[e.R = 82] = "R", e[e.S = 83] = "S", e[e.T = 84] = "T", e[e.U = 85] = "U", e[e.V = 86] = "V", e[e.W = 87] = "W", e[e.X = 88] = "X", e[e.Y = 89] = "Y", e[e.Z = 90] = "Z", e[e.asterisk = 42] = "asterisk", e[e.backslash = 92] = "backslash", e[e.closeBrace = 125] = "closeBrace", e[e.closeBracket = 93] = "closeBracket", e[e.colon = 58] = "colon", e[e.comma = 44] = "comma", e[e.dot = 46] = "dot", e[e.doubleQuote = 34] = "doubleQuote", e[e.minus = 45] = "minus", e[e.openBrace = 123] = "openBrace", e[e.openBracket = 91] = "openBracket", e[e.plus = 43] = "plus", e[e.slash = 47] = "slash", e[e.formFeed = 12] = "formFeed", e[e.tab = 9] = "tab";
})(ho || (ho = {}));
new Array(20).fill(0).map((e, t) => " ".repeat(t));
const St = 200;
new Array(St).fill(0).map((e, t) => `
` + " ".repeat(t)), new Array(St).fill(0).map((e, t) => "\r" + " ".repeat(t)), new Array(St).fill(0).map((e, t) => `\r
` + " ".repeat(t)), new Array(St).fill(0).map((e, t) => `
` + "	".repeat(t)), new Array(St).fill(0).map((e, t) => "\r" + "	".repeat(t)), new Array(St).fill(0).map((e, t) => `\r
` + "	".repeat(t));
var rn;
(function(e) {
  e.DEFAULT = {
    allowTrailingComma: !1
  };
})(rn || (rn = {}));
function el(e, t = [], o = rn.DEFAULT) {
  let n = null, i = [];
  const s = [];
  function a(r) {
    Array.isArray(i) ? i.push(r) : n !== null && (i[n] = r);
  }
  return tl(e, {
    onObjectBegin: () => {
      const r = {};
      a(r), s.push(i), i = r, n = null;
    },
    onObjectProperty: (r) => {
      n = r;
    },
    onObjectEnd: () => {
      i = s.pop();
    },
    onArrayBegin: () => {
      const r = [];
      a(r), s.push(i), i = r, n = null;
    },
    onArrayEnd: () => {
      i = s.pop();
    },
    onLiteralValue: a,
    onError: (r, f, c) => {
      t.push({ error: r, offset: f, length: c });
    }
  }, o), i[0];
}
function tl(e, t, o = rn.DEFAULT) {
  const n = Qa(e, !1), i = [];
  let s = 0;
  function a(C) {
    return C ? () => s === 0 && C(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter()) : () => !0;
  }
  function l(C) {
    return C ? (N) => s === 0 && C(N, n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter()) : () => !0;
  }
  function r(C) {
    return C ? (N) => s === 0 && C(N, n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter(), () => i.slice()) : () => !0;
  }
  function f(C) {
    return C ? () => {
      s > 0 ? s++ : C(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter(), () => i.slice()) === !1 && (s = 1);
    } : () => !0;
  }
  function c(C) {
    return C ? () => {
      s > 0 && s--, s === 0 && C(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter());
    } : () => !0;
  }
  const u = f(t.onObjectBegin), p = r(t.onObjectProperty), m = c(t.onObjectEnd), y = f(t.onArrayBegin), M = c(t.onArrayEnd), _ = r(t.onLiteralValue), T = l(t.onSeparator), k = a(t.onComment), g = l(t.onError), V = o && o.disallowComments, U = o && o.allowTrailingComma;
  function x() {
    for (; ; ) {
      const C = n.scan();
      switch (n.getTokenError()) {
        case 4:
          w(
            14
            /* ParseErrorCode.InvalidUnicode */
          );
          break;
        case 5:
          w(
            15
            /* ParseErrorCode.InvalidEscapeCharacter */
          );
          break;
        case 3:
          w(
            13
            /* ParseErrorCode.UnexpectedEndOfNumber */
          );
          break;
        case 1:
          V || w(
            11
            /* ParseErrorCode.UnexpectedEndOfComment */
          );
          break;
        case 2:
          w(
            12
            /* ParseErrorCode.UnexpectedEndOfString */
          );
          break;
        case 6:
          w(
            16
            /* ParseErrorCode.InvalidCharacter */
          );
          break;
      }
      switch (C) {
        case 12:
        case 13:
          V ? w(
            10
            /* ParseErrorCode.InvalidCommentToken */
          ) : k();
          break;
        case 16:
          w(
            1
            /* ParseErrorCode.InvalidSymbol */
          );
          break;
        case 15:
        case 14:
          break;
        default:
          return C;
      }
    }
  }
  function w(C, N = [], O = []) {
    if (g(C), N.length + O.length > 0) {
      let K = n.getToken();
      for (; K !== 17; ) {
        if (N.indexOf(K) !== -1) {
          x();
          break;
        } else if (O.indexOf(K) !== -1)
          break;
        K = x();
      }
    }
  }
  function R(C) {
    const N = n.getTokenValue();
    return C ? _(N) : (p(N), i.push(N)), x(), !0;
  }
  function X() {
    switch (n.getToken()) {
      case 11:
        const C = n.getTokenValue();
        let N = Number(C);
        isNaN(N) && (w(
          2
          /* ParseErrorCode.InvalidNumberFormat */
        ), N = 0), _(N);
        break;
      case 7:
        _(null);
        break;
      case 8:
        _(!0);
        break;
      case 9:
        _(!1);
        break;
      default:
        return !1;
    }
    return x(), !0;
  }
  function Z() {
    return n.getToken() !== 10 ? (w(3, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ]), !1) : (R(!1), n.getToken() === 6 ? (T(":"), x(), B() || w(4, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ])) : w(5, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ]), i.pop(), !0);
  }
  function ie() {
    u(), x();
    let C = !1;
    for (; n.getToken() !== 2 && n.getToken() !== 17; ) {
      if (n.getToken() === 5) {
        if (C || w(4, [], []), T(","), x(), n.getToken() === 2 && U)
          break;
      } else C && w(6, [], []);
      Z() || w(4, [], [
        2,
        5
        /* SyntaxKind.CommaToken */
      ]), C = !0;
    }
    return m(), n.getToken() !== 2 ? w(7, [
      2
      /* SyntaxKind.CloseBraceToken */
    ], []) : x(), !0;
  }
  function ce() {
    y(), x();
    let C = !0, N = !1;
    for (; n.getToken() !== 4 && n.getToken() !== 17; ) {
      if (n.getToken() === 5) {
        if (N || w(4, [], []), T(","), x(), n.getToken() === 4 && U)
          break;
      } else N && w(6, [], []);
      C ? (i.push(0), C = !1) : i[i.length - 1]++, B() || w(4, [], [
        4,
        5
        /* SyntaxKind.CommaToken */
      ]), N = !0;
    }
    return M(), C || i.pop(), n.getToken() !== 4 ? w(8, [
      4
      /* SyntaxKind.CloseBracketToken */
    ], []) : x(), !0;
  }
  function B() {
    switch (n.getToken()) {
      case 3:
        return ce();
      case 1:
        return ie();
      case 10:
        return R(!0);
      default:
        return X();
    }
  }
  return x(), n.getToken() === 17 ? o.allowEmptyContent ? !0 : (w(4, [], []), !1) : B() ? (n.getToken() !== 17 && w(9, [], []), !0) : (w(4, [], []), !1);
}
var bo;
(function(e) {
  e[e.None = 0] = "None", e[e.UnexpectedEndOfComment = 1] = "UnexpectedEndOfComment", e[e.UnexpectedEndOfString = 2] = "UnexpectedEndOfString", e[e.UnexpectedEndOfNumber = 3] = "UnexpectedEndOfNumber", e[e.InvalidUnicode = 4] = "InvalidUnicode", e[e.InvalidEscapeCharacter = 5] = "InvalidEscapeCharacter", e[e.InvalidCharacter = 6] = "InvalidCharacter";
})(bo || (bo = {}));
var yo;
(function(e) {
  e[e.OpenBraceToken = 1] = "OpenBraceToken", e[e.CloseBraceToken = 2] = "CloseBraceToken", e[e.OpenBracketToken = 3] = "OpenBracketToken", e[e.CloseBracketToken = 4] = "CloseBracketToken", e[e.CommaToken = 5] = "CommaToken", e[e.ColonToken = 6] = "ColonToken", e[e.NullKeyword = 7] = "NullKeyword", e[e.TrueKeyword = 8] = "TrueKeyword", e[e.FalseKeyword = 9] = "FalseKeyword", e[e.StringLiteral = 10] = "StringLiteral", e[e.NumericLiteral = 11] = "NumericLiteral", e[e.LineCommentTrivia = 12] = "LineCommentTrivia", e[e.BlockCommentTrivia = 13] = "BlockCommentTrivia", e[e.LineBreakTrivia = 14] = "LineBreakTrivia", e[e.Trivia = 15] = "Trivia", e[e.Unknown = 16] = "Unknown", e[e.EOF = 17] = "EOF";
})(yo || (yo = {}));
const ko = el;
var wo;
(function(e) {
  e[e.InvalidSymbol = 1] = "InvalidSymbol", e[e.InvalidNumberFormat = 2] = "InvalidNumberFormat", e[e.PropertyNameExpected = 3] = "PropertyNameExpected", e[e.ValueExpected = 4] = "ValueExpected", e[e.ColonExpected = 5] = "ColonExpected", e[e.CommaExpected = 6] = "CommaExpected", e[e.CloseBraceExpected = 7] = "CloseBraceExpected", e[e.CloseBracketExpected = 8] = "CloseBracketExpected", e[e.EndOfFileExpected = 9] = "EndOfFileExpected", e[e.InvalidCommentToken = 10] = "InvalidCommentToken", e[e.UnexpectedEndOfComment = 11] = "UnexpectedEndOfComment", e[e.UnexpectedEndOfString = 12] = "UnexpectedEndOfString", e[e.UnexpectedEndOfNumber = 13] = "UnexpectedEndOfNumber", e[e.InvalidUnicode = 14] = "InvalidUnicode", e[e.InvalidEscapeCharacter = 15] = "InvalidEscapeCharacter", e[e.InvalidCharacter = 16] = "InvalidCharacter";
})(wo || (wo = {}));
function xo(e) {
  switch (e) {
    case 1:
      return "InvalidSymbol";
    case 2:
      return "InvalidNumberFormat";
    case 3:
      return "PropertyNameExpected";
    case 4:
      return "ValueExpected";
    case 5:
      return "ColonExpected";
    case 6:
      return "CommaExpected";
    case 7:
      return "CloseBraceExpected";
    case 8:
      return "CloseBracketExpected";
    case 9:
      return "EndOfFileExpected";
    case 10:
      return "InvalidCommentToken";
    case 11:
      return "UnexpectedEndOfComment";
    case 12:
      return "UnexpectedEndOfString";
    case 13:
      return "UnexpectedEndOfNumber";
    case 14:
      return "InvalidUnicode";
    case 15:
      return "InvalidEscapeCharacter";
    case 16:
      return "InvalidCharacter";
  }
  return "<unknown ParseErrorCode>";
}
const To = (e) => e.map((t) => ({
  code: `json-parse/${xo(t.error)}`,
  message: xo(t.error),
  offset: t.offset,
  length: t.length
})), nl = async (e, t) => {
  const o = await e.text();
  if (t === "json") {
    const n = [], i = ko(o, n, {
      allowEmptyContent: !1,
      allowTrailingComma: !1,
      disallowComments: !0
    });
    if (n.length === 0)
      return {
        format: t,
        rawText: o,
        value: i,
        parsedValue: i,
        jsonParseMode: "json",
        jsonDiagnostics: []
      };
    const s = [], a = ko(o, s, {
      allowEmptyContent: !1,
      allowTrailingComma: !0,
      disallowComments: !1
    });
    return s.length === 0 ? {
      format: t,
      rawText: o,
      value: a,
      parsedValue: a,
      jsonParseMode: "jsonc",
      jsonDiagnostics: To(n)
    } : {
      format: t,
      rawText: o,
      value: o,
      jsonParseMode: "raw-text",
      jsonDiagnostics: To(s)
    };
  }
  return {
    format: t,
    rawText: o,
    value: o
  };
}, ol = (e) => typeof e == "object" && e !== null && !Array.isArray(e), il = (e) => ol(e) && typeof e.type == "string", sl = (e) => nn(e) || il(e), rl = async (e, t, o, n) => {
  const s = (o != null && o.resolveJsonImportMode && n ? await o.resolveJsonImportMode({
    event: n,
    file: e,
    rawText: t.rawText,
    parsedValue: t.parsedValue,
    parseMode: t.jsonParseMode ?? "raw-text",
    diagnostics: t.jsonDiagnostics ?? []
  }) : "auto") ?? "auto";
  if (s === "code-block")
    return t.rawText;
  if (s === "canonical-document") {
    if (!sl(t.parsedValue))
      throw new Error(
        'JSON import mode "canonical-document" requires a canonical document envelope or JSONContent payload.'
      );
    return t.parsedValue;
  }
  return t.parsedValue ?? t.rawText;
}, al = async (e, t, o, n) => {
  const i = await nl(e, t);
  switch (t) {
    case "markdown":
      return Ds(i.value, {
        importMode: "fresh-import",
        meta: {
          source: "import"
        }
      }).document;
    case "html":
      return Ms(
        o != null && o.sanitizeImportedHtml && n ? await o.sanitizeImportedHtml(i.value, {
          event: n,
          file: e
        }) : i.value,
        {
          importMode: "fresh-import",
          meta: {
            source: "import"
          }
        }
      ).document;
    case "json":
      return zs(
        await rl(e, i, o, n),
        {
          importMode: "fresh-import",
          meta: {
            source: "import"
          }
        }
      ).document;
    case "text":
      return Cs(i.value, {
        importMode: "fresh-import",
        meta: {
          source: "import"
        }
      }).document;
  }
}, ll = (e) => ({
  ...e,
  body: {
    ...e.body,
    content: sr(
      e.body.content,
      "file-intake"
    )
  }
}), cl = async ({
  applyImportedDocument: e,
  currentDocument: t,
  event: o,
  file: n,
  filePlatform: i,
  format: s,
  insertImportedDocument: a
}) => {
  const l = await Ya({
    currentDocument: t,
    event: o,
    file: n,
    filePlatform: i,
    format: s
  });
  if (l === "cancel")
    return {
      disposition: l,
      handled: !0
    };
  const r = ll(
    await al(n, s, i, o)
  );
  if (l === "replace-current")
    return e(r), {
      disposition: l,
      document: r,
      handled: !0
    };
  if (l === "insert-at-selection") {
    if (!a)
      throw new Error(
        'Text file import disposition "insert-at-selection" requires an insertion callback.'
      );
    return a(r, {
      event: o,
      file: n,
      format: s
    }), {
      disposition: l,
      document: r,
      handled: !0
    };
  }
  return l === "open-new" ? (await (i == null ? void 0 : i.openNewImportedDocument({
    event: o,
    file: n,
    format: s,
    document: r
  })), {
    disposition: l,
    document: r,
    handled: !0
  }) : {
    disposition: l,
    handled: !0
  };
}, ul = (e, t) => {
  var i, s;
  const o = (i = e.context) == null ? void 0 : i.preferredNodeKind;
  if (o === "image" || o === "video" || o === "attachment")
    return o;
  const n = (s = e.context) == null ? void 0 : s.nodeKind;
  if (n === "image" || n === "video" || n === "attachment")
    return n;
  if (t.intent === "attach-asset") {
    if (t.assetKind === "image")
      return "image";
    if (t.assetKind === "video")
      return "video";
    if (t.assetKind === "file")
      return "attachment";
  }
  return null;
}, dl = (e, t, o) => {
  const { event: n } = e, i = e.anchorPos ?? n.dropPos ?? null;
  return t.enqueue({
    anchorPos: i,
    event: n,
    preferredNodeKind: ul(n, o)
  });
}, fl = ({
  applyImportedDocument: e,
  assetPipelineRuntime: t,
  documentState: o,
  editor: n,
  filePlatformRuntime: i,
  getCurrentDocument: s,
  insertImportedDocument: a
}) => ({
  dispatch: async (l) => {
    const r = i.getFilePlatform(), f = l.event.htmlContent && (r != null && r.sanitizeImportedHtml) ? {
      ...l.event,
      htmlContent: await r.sanitizeImportedHtml(
        l.event.htmlContent,
        {
          event: l.event,
          file: l.event.files[0] ?? null
        }
      )
    } : l.event, c = await Ja({
      event: f,
      filePlatform: r
    });
    it("text-editor:file-intake", "intake classified", {
      source: f.source,
      dropPos: f.dropPos,
      selectionFrom: f.selectionFrom,
      selectionTo: f.selectionTo,
      files: f.files.map((m) => ({
        name: m.name,
        type: m.type,
        size: m.size
      })),
      decision: c
    });
    const u = n.value;
    if (c.intent === "reject")
      return lt(f, c, !0);
    if (c.intent === "import-content") {
      const m = f.files[0];
      if (!m)
        return lt(
          f,
          {
            intent: "reject",
            code: "missing-import-file",
            reason: "import-file-missing",
            message: "Import-content decisions require a concrete file payload."
          },
          !0
        );
      try {
        const y = await cl({
          applyImportedDocument: e,
          currentDocument: s(),
          event: f,
          file: m,
          filePlatform: r,
          format: c.format ?? "text",
          insertImportedDocument: a
        });
        return it("text-editor:file-intake", "text import executed", {
          source: f.source,
          fileName: m.name,
          format: c.format ?? "text",
          disposition: y.disposition,
          handled: y.handled
        }), lt(f, c, y.handled);
      } catch (y) {
        return it("text-editor:file-intake", "text import failed", {
          source: f.source,
          fileName: m.name,
          format: c.format ?? "text",
          error: y instanceof Error ? y.message : String(y)
        }), lt(
          f,
          {
            intent: "reject",
            code: "import-failed",
            reason: "import-error",
            message: y instanceof Error ? y.message : "The text file import pipeline failed."
          },
          !0
        );
      }
    }
    if (c.intent === "embed-remote")
      try {
        const m = await Zr({
          anchorPos: l.anchorPos ?? f.dropPos ?? null,
          documentState: o,
          editor: u,
          event: f,
          filePlatform: r,
          url: c.url ?? ""
        });
        return it("text-editor:file-intake", "remote embed executed", {
          source: f.source,
          url: c.url ?? "",
          handled: m.handled
        }), lt(f, c, m.handled);
      } catch (m) {
        const y = m instanceof _t ? m.code : "remote-embed-failed", M = m instanceof Error ? m.message : "The remote embed pipeline failed.";
        return i.emitDiagnostic({
          code: y,
          message: M,
          severity: "error",
          stage: "intake",
          intake: f,
          cause: m
        }), lt(
          f,
          {
            intent: "reject",
            code: y,
            reason: "remote-embed-error",
            message: M
          },
          !0
        );
      }
    if (!u || c.intent !== "attach-asset")
      return lt(
        f,
        {
          intent: "reject",
          code: "unsupported-intent",
          reason: "intent-not-supported",
          message: `The intake pipeline does not support intent "${String(
            c.intent
          )}".`
        },
        !0
      );
    const p = dl(
      {
        ...l,
        event: f
      },
      t,
      c
    );
    return lt(f, c, p);
  }
}), vi = /* @__PURE__ */ Te({
  name: "ZxTextEditor",
  inheritAttrs: !1,
  __name: "text-editor",
  props: Fa,
  emits: Pa,
  setup(e, { expose: t, emit: o }) {
    const n = e, i = Ut(), s = Yo(), a = o, l = Go(n.themeOwner);
    if (!l || l.state !== "active")
      throw new Error("EDITOR_THEME_OWNER_REQUIRED");
    An(ns, l);
    const r = De("text-editor"), f = De("code-block"), c = Ne(null), u = J(null), p = J(gt()), m = J(kn()), y = J(!1), M = S(() => n.filePlatform ?? null), _ = Ne(null), T = S(
      () => n.bubbleToolbar !== !1 && n.editable
    ), k = S(
      () => typeof n.bubbleToolbar == "object" && n.bubbleToolbar !== null ? n.bubbleToolbar : {}
    ), g = S(() => n.dragHandle ? n.dragHandle === !0 ? !0 : n.dragHandle.showPlus !== !1 : !1), V = S(() => {
      if (!(!n.dragHandle || n.dragHandle === !0))
        return n.dragHandle.onPlusClick;
    }), U = S(() => !n.dragHandle || n.dragHandle === !0 ? null : n.dragHandle.askAIBridge ?? null), x = $t(), w = S(() => q(x.class)), R = S(() => ft(x.style)), X = [
      "aria-label",
      "aria-labelledby",
      "aria-describedby",
      "aria-invalid",
      "aria-required"
    ], Z = S(() => Object.fromEntries(
      Object.entries(x).filter(
        ([b]) => b !== "class" && b !== "style" && !X.includes(b)
      )
    )), ie = S(
      () => Object.fromEntries(
        X.flatMap((b) => {
          const z = x[b];
          return z == null || z === !1 ? [] : [[b, String(z)]];
        })
      )
    ), ce = S(() => {
      const b = c.value ? Fs(c.value) : ni({
        override: n.typography
      });
      return Xo(b);
    }), B = S(
      () => os(n.extensions, "comment")
    ), C = (b, z) => {
      const $ = b.state.doc.resolve(z);
      let G = $.depth;
      for (; G > 0 && $.node(G).type.name !== "codeBlock"; ) G--;
      if (G === 0) return null;
      const te = $.node(G), re = $.before(G), ke = b.nodeDOM(re), Se = ke instanceof HTMLElement ? ke : null;
      return { node: te, from: re, dom: Se };
    }, N = (b, z, $) => {
      const G = f.b(), te = Array.from(
        b.dom.querySelectorAll(`.${G}`)
      );
      if (!te.length) return null;
      const re = 8, ke = 24;
      for (const Se of te) {
        const we = Se.getBoundingClientRect(), at = $ >= we.top && $ <= we.bottom, et = z >= we.left - ke && z <= we.right + ke;
        if (at && (z < we.left - 1 || z > we.right + 1) || $ > we.bottom && $ <= we.bottom + re && et)
          return Se;
      }
      return null;
    }, O = (b, z, $) => {
      var Se;
      const G = z + $, te = b.state.doc.nodeAt(G);
      if ((te == null ? void 0 : te.type.name) === "paragraph" && te.content.size === 0) {
        const we = b.state.tr.setSelection(
          ct.create(b.state.doc, G + 1)
        );
        return b.dispatch(we.scrollIntoView()), !0;
      }
      const re = b.state.schema.nodes.paragraph, ke = re == null ? void 0 : re.createAndFill();
      if (ke && re) {
        const we = b.state.doc.resolve(G), at = we.index();
        if (we.parent.canReplaceWith(at, at, re)) {
          const et = b.state.tr.insert(G, ke);
          return et.setSelection(ct.create(et.doc, G + 1)), b.dispatch(et.scrollIntoView()), !0;
        }
      }
      return (Se = c.value) == null || Se.chain().focus().setNodeSelection(z).createParagraphNear().run(), !0;
    }, K = (b, z) => {
      var ke;
      const $ = b.state.doc.resolve(z), G = $.nodeBefore;
      if ((G == null ? void 0 : G.type.name) === "paragraph" && G.content.size === 0) {
        const Se = b.state.tr.setSelection(
          ct.create(b.state.doc, z - 1)
        );
        return b.dispatch(Se.scrollIntoView()), !0;
      }
      const te = b.state.schema.nodes.paragraph, re = te == null ? void 0 : te.createAndFill();
      if (re && te) {
        const Se = $.index();
        if ($.parent.canReplaceWith(Se, Se, te)) {
          const we = b.state.tr.insert(z, re);
          return we.setSelection(ct.create(we.doc, z + 1)), b.dispatch(we.scrollIntoView()), !0;
        }
      }
      return (ke = c.value) == null || ke.chain().focus().setNodeSelection(z).createParagraphNear().run(), !0;
    }, se = (b) => {
      const z = b.state.doc;
      let $ = 0;
      for (let G = 0; G < z.childCount; G++) {
        const te = z.child(G);
        if (G === z.childCount - 1) return { node: te, from: $ };
        $ += te.nodeSize;
      }
      return null;
    }, ge = (b) => {
      var re, ke;
      const z = (re = c.value) == null ? void 0 : re.view;
      if (!z || b.button !== 0) return;
      const $ = b.target;
      if ($ && z.dom.contains($)) return;
      const G = z.dom.getBoundingClientRect();
      if (b.clientY <= G.bottom + 1) return;
      b.preventDefault();
      const te = se(z);
      if ((te == null ? void 0 : te.node.type.name) === "codeBlock") {
        O(z, te.from, te.node.nodeSize), z.focus();
        return;
      }
      (ke = c.value) == null || ke.chain().focus("end").run();
    }, le = (b) => {
      var z;
      return Array.from(((z = b.dataTransfer) == null ? void 0 : z.files) ?? []);
    }, pe = (b) => {
      var $;
      if (le(b).length > 0)
        return !0;
      const z = ($ = b.dataTransfer) == null ? void 0 : $.types;
      return !!(z && Array.from(z).includes("Files"));
    }, be = (b) => {
      nt.emitDiagnostic({
        code: "root-drop-intake-dispatch-failed",
        message: b instanceof Error ? b.message : "Failed to dispatch dropped files from the editor root.",
        severity: "error",
        stage: "intake",
        cause: b
      });
    }, ve = (b) => {
      var $;
      const z = ($ = c.value) == null ? void 0 : $.view.dom;
      return !!(z && b instanceof Node && z.contains(b));
    }, de = (b) => {
      pe(b) && (ve(b.target) || (b.preventDefault(), b.dataTransfer && (b.dataTransfer.dropEffect = "copy")));
    }, _e = (b) => {
      if (n.contentProfile === "basic-rich-text" && le(b).length) {
        b.preventDefault(), b.stopPropagation(), a("content-issue", "备注不支持图片或附件");
        return;
      }
      const z = le(b);
      z.length !== 0 && (ve(b.target) || (b.preventDefault(), Promise.resolve(
        nt.intakeFiles({
          source: "drop",
          files: z,
          dropPos: null,
          anchorPos: null
        })
      ).catch(($) => {
        be($);
      })));
    }, Ee = (b, z, $) => {
      var Yn, Qn, eo, to;
      const G = $.target;
      if (!G) return !1;
      const te = $.clientX, re = $.clientY, ke = f.b(), Se = f.e("line-numbers"), we = f.e("body"), at = f.e("pre"), et = f.e("code"), We = G.closest(`.${ke}`), Fi = G.closest(`.${Se}`);
      let Wt = C(b, z);
      if (!Wt && G === b.dom) {
        const je = N(b, te, re);
        if (je) {
          const Ue = b.posAtDOM(je, 0);
          Wt = C(b, Ue);
        }
      }
      if (We || Wt) {
        const je = Wt || (We ? C(b, z) : null);
        if (je) {
          const Ue = (Yn = je.dom || We) == null ? void 0 : Yn.getBoundingClientRect(), gn = Ue ? te < Ue.left - 2 && re >= Ue.top && re <= Ue.bottom : !1;
          if (Fi || gn)
            return K(b, je.from);
          const no = (Qn = We || je.dom) == null ? void 0 : Qn.querySelector(
            `.${we}`
          ), oo = (eo = We || je.dom) == null ? void 0 : eo.querySelector(
            `.${at}`
          ), io = (to = We || je.dom) == null ? void 0 : to.querySelector(
            `.${et}`
          );
          if (no && oo && io && no.contains(G) && oo.contains(G)) {
            const Zt = document.createRange();
            Zt.selectNodeContents(io);
            const zt = Array.from(Zt.getClientRects()).filter(
              (Mt) => Mt.width > 0 && Mt.height > 0
            );
            if (zt.length > 0) {
              const Mt = Math.max(...zt.map((ot) => ot.bottom)), $i = 1, hn = zt.filter(
                (ot) => Math.abs(ot.bottom - Mt) <= $i
              ), Hi = Math.max(...hn.map((ot) => ot.right)), Ui = Math.min(...hn.map((ot) => ot.top)), Ki = Math.max(...hn.map((ot) => ot.bottom)), qi = re >= Ui - 1 && re <= Ki + 1 && te > Hi + 6, Gi = re > Mt + 6;
              if (qi || Gi)
                return O(b, je.from, je.node.nodeSize);
            }
          }
          if (Ue) {
            const Zt = te > Ue.right + 2 && re >= Ue.top && re <= Ue.bottom, zt = re > Ue.bottom + 2;
            if (Zt || zt)
              return O(b, je.from, je.node.nodeSize);
          }
        }
      }
      const Jn = G.closest(
        "p, h1, h2, h3, h4, h5, h6, li, blockquote, td, th"
      );
      if (!Jn) return !1;
      const Jt = [], Pi = document.createTreeWalker(Jn, NodeFilter.SHOW_TEXT);
      let Zn;
      for (; Zn = Pi.nextNode(); )
        Jt.push(Zn);
      if (Jt.length === 0) return !1;
      const Xn = document.createRange(), Vi = Jt[Jt.length - 1];
      Xn.selectNodeContents(Vi);
      const ji = Xn.getBoundingClientRect();
      if (te > ji.right + 2) {
        const Ue = b.state.doc.resolve(z).end(), gn = b.state.tr.setSelection(
          ct.create(b.state.doc, Ue)
        );
        return b.dispatch(gn), !0;
      }
      return !1;
    }, ee = va({
      editor: c,
      rootRef: u,
      documentState: p,
      getBookmarkProvider: () => n.bookmarkProvider,
      getEphemeralProviders: () => n.ephemeralProviders
    }), ne = ee.navigationController, he = ee.scheduleNavigationRefresh, oe = ee.refreshNavigationRuntime, ze = ee.syncEditorNavigationBridge, Fe = ee.navigateToBlock, Je = ee.navigate, Qe = ee.cancelNavigation, W = ee.getNavigationSnapshot, ye = ee.getNavigationDebugSnapshot, Re = ee.listNavigationDescriptors, Ge = ee.syncNavigationFromLocation, tt = ee.createShareableFragment, He = ee.getBlockElement, E = S(() => ({
      attributes: {
        class: q([r.e("prose"), n.editorClass]),
        ...ie.value
      },
      handleClick: Ee
    })), I = _r({
      editor: c,
      documentState: p,
      annotationBridgeState: m,
      hasCommentExtension: B,
      isApplyingExternalContent: y,
      getMarkdownExportMode: () => n.markdownExportMode,
      getStableBlockIdentityOptions: () => {
        var b, z;
        return {
          types: (b = n.stableBlockIdentity) == null ? void 0 : b.types,
          generateId: (z = n.stableBlockIdentity) == null ? void 0 : z.generateId
        };
      }
    }), H = I.getCurrentDocument, Y = I.resolveHydratedState, fe = I.isHydratedStateSynced, Ie = I.getHTML, Ce = I.getMarkdown, d = I.getJSON, h = I.getDocument, A = I.getText, P = I.getExcerpt, ue = (b, z) => {
      n.contentProfile === "basic-rich-text" && Ye(b, n.contentLimits), I.setContent(b, z);
    }, Be = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      I.setHTML(b);
    }, pt = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      I.setMarkdown(b);
    }, Tt = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      I.setJSON(b);
    }, Nt = (b) => ue(b, { contentType: "document" }), Kt = I.getRuntimeStatus, fn = (b) => JSON.parse(
      JSON.stringify(
        Array.isArray(b.body.content.content) ? b.body.content.content : []
      )
    ), Gn = (b, z) => {
      const { doc: $ } = b.state, G = Math.max(0, Math.min(z, $.content.size)), te = $.resolve(G);
      for (let re = te.depth; re > 0; re -= 1)
        if (te.node(re).isBlock && te.depth >= re)
          return te.before(re);
      return G;
    }, pn = (b, z, $) => {
      if (typeof $.dropPos == "number") {
        const G = Tr(
          b.state.doc,
          $.dropPos,
          z
        ), te = G ?? Gn(b, $.dropPos);
        return it(
          "text-editor:file-import",
          "resolved drop insertion range",
          {
            requestedDropPos: $.dropPos,
            normalizedDropPos: G,
            insertionPos: te
          }
        ), {
          from: te,
          to: te
        };
      }
      return {
        from: $.selectionFrom ?? b.state.selection.from,
        to: $.selectionTo ?? b.state.selection.to
      };
    }, Lt = (b, z) => {
      var et;
      const $ = c.value;
      if (!$) {
        Nt(b);
        return;
      }
      const G = fn(b);
      if (G.length === 0)
        return;
      const te = G.map(
        (We) => $.schema.nodeFromJSON(We)
      ), re = new ii(si.fromArray(te), 0, 0), ke = H($), Se = gt({
        ...ke,
        assets: Fn(ke.assets, b.assets),
        annotations: ur(
          ke.annotations,
          b.annotations
        )
      });
      p.value = Se, m.value = kn(Se);
      const we = pn(
        $,
        re,
        z.event
      );
      it("text-editor:file-import", "applying imported content", {
        importedNodeCount: G.length,
        importedNodeTypes: G.map((We) => We.type),
        event: z.event,
        insertionRange: we
      });
      const at = $.state.tr.replaceRange(
        we.from,
        we.to,
        re
      );
      $.view.focus(), $.view.dispatch(at.scrollIntoView()), it("text-editor:file-import", "import transaction applied", {
        selectionFrom: $.state.selection.from,
        selectionTo: $.state.selection.to,
        topLevelNodeTypes: ((et = H($).body.content.content) == null ? void 0 : et.map(
          (We) => We.type
        )) ?? []
      });
    }, nt = Mr({
      editor: c,
      filePlatform: M,
      intakeDispatcher: _,
      getCurrentDocument: () => H()
    }), Bt = Gr({
      documentState: p,
      editor: c,
      filePlatformRuntime: nt
    });
    _.value = fl({
      applyImportedDocument: (b) => Nt(b),
      assetPipelineRuntime: Bt,
      documentState: p,
      editor: c,
      filePlatformRuntime: nt,
      getCurrentDocument: () => H(),
      insertImportedDocument: (b, z) => Lt(b, z)
    });
    const qt = (b) => {
      I.applyHydratedEditorState(b), oe();
    };
    Q(
      () => [
        n.content,
        n.modelValue,
        n.documentValue,
        n.contentType
      ],
      () => {
        var te, re;
        if (!c.value) return;
        const b = mt(
          "text-editor:external-sync",
          "props->editor sync watcher",
          {
            contentType: n.contentType,
            hasDocumentValue: !!n.documentValue
          }
        );
        if (n.contentProfile === "basic-rich-text") {
          if (JSON.stringify(n.documentValue) === JSON.stringify(I.getDocument())) {
            b == null || b.end({ applied: !1, sourceType: "document" });
            return;
          }
          try {
            Ye(n.documentValue, n.contentLimits);
          } catch (ke) {
            a("content-issue", String(ke)), b == null || b.end({ applied: !1 });
            return;
          }
        }
        const z = Y({
          content: n.content,
          modelValue: n.modelValue,
          documentValue: n.documentValue,
          contentType: n.contentType,
          hydrateAnnotations: B.value,
          stableBlockIdentity: {
            types: (te = n.stableBlockIdentity) == null ? void 0 : te.types,
            generateId: (re = n.stableBlockIdentity) == null ? void 0 : re.generateId
          }
        }), $ = mt(
          "text-editor:external-sync",
          "isHydratedStateSynced"
        ), G = fe(z);
        $ == null || $.end({
          synced: G,
          sourceType: z.sourceType
        }), G || (it(
          "text-editor:external-sync",
          "applying external hydrated state",
          {
            sourceType: z.sourceType
          }
        ), qt(z)), b == null || b.end({
          applied: !G,
          sourceType: z.sourceType
        });
      },
      { deep: !0 }
    ), Q(
      () => n.editable,
      (b) => {
        c.value && (c.value.setEditable(b, !1), c.value.view.dispatch(
          c.value.state.tr.setSelection(c.value.state.selection).setStoredMarks(c.value.state.storedMarks).setMeta("addToHistory", !1)
        ));
      }
    ), Q(
      E,
      (b) => {
        c.value && c.value.setOptions({ editorProps: b });
      },
      { deep: !0 }
    );
    const Gt = () => {
      const b = c.value;
      b && ["codeBlock", "slashCommands", "contentPaste"].forEach((z) => {
        const $ = b.extensionManager.extensions.find(
          (G) => G.name === z
        );
        $ != null && $.options && ($.options.codeBlockPreferences = n.codeBlockPreferences);
      });
    }, Ct = () => {
      const b = c.value;
      if (!b) return;
      const z = b.extensionManager.extensions.find(
        ($) => $.name === "slashCommands"
      );
      z != null && z.options && (z.options.catalogContributions = n.slashCatalogContributions ?? null);
    };
    Q(
      () => n.codeBlockPreferences,
      () => {
        Gt();
      },
      { deep: !0 }
    ), Q(
      () => n.slashCatalogContributions,
      () => {
        Ct();
      },
      { deep: !0 }
    );
    const mn = yt(pi, !1);
    Ht(() => {
      var z, $;
      n.contentProfile === "basic-rich-text" && (mn ? wa : Ye)(n.documentValue, n.contentLimits);
      const b = Y({
        content: n.content,
        modelValue: n.modelValue,
        documentValue: n.documentValue,
        contentType: n.contentType,
        hydrateAnnotations: B.value,
        stableBlockIdentity: {
          types: (z = n.stableBlockIdentity) == null ? void 0 : z.types,
          generateId: ($ = n.stableBlockIdentity) == null ? void 0 : $.generateId
        }
      });
      p.value = b.document, m.value = kn(
        b.document
      ), c.value = Ar(
        {
          content: b.content,
          editorProps: E.value,
          editable: n.editable,
          autofocus: n.autofocus,
          onUpdate: ({ editor: G }) => {
            it("text-editor:update", "editor onUpdate fired"), Li(G);
          },
          onTransaction: ({
            editor: G,
            transaction: te
          }) => {
            a("transaction", G), Bi(te), Ci(G, te), he();
          },
          onFocus: ({ event: G }) => {
            a("focus", G);
          },
          onBlur: ({ event: G }) => {
            a("blur", G);
          }
        },
        {
          contentProfile: n.contentProfile,
          contentLimits: n.contentLimits,
          onContentIssue: (G) => a("content-issue", G),
          pages: n.contentProfile === "basic-rich-text" ? !1 : void 0,
          dragHandle: n.contentProfile === "basic-rich-text" ? !1 : n.dragHandle,
          shortcutRuntime: i,
          shortcutParentOwner: s,
          extensions: n.extensions,
          getCurrentDocument: () => H(),
          mentions: n.mentions,
          placeholder: n.placeholder,
          placeholderContract: n.placeholderContract,
          stableBlockIdentity: n.stableBlockIdentity,
          starterkitOptions: n.starterkitOptions,
          suggestions: n.suggestions,
          editable: n.editable,
          pagesHeaderFooter: n.pagesHeaderFooter,
          pagesLayout: n.pagesLayout,
          tags: n.tags,
          typography: n.typography,
          assetPipelineRuntime: Bt,
          filePlatform: M.value,
          codeBlockPreferences: n.codeBlockPreferences,
          slashCatalogContributions: n.slashCatalogContributions,
          filePlatformRuntime: nt,
          themeOwner: l
        }
      ), ze(), oe(), Gt(), Ct();
    }), rt(() => {
      ee.destroy(), c.value && (c.value.destroy(), c.value = null);
    }), An(
      "editor",
      S(() => c.value)
    );
    const vn = S(() => n.extensions.some((b) => {
      const z = b == null ? void 0 : b.name;
      return z === "collaboration" || z === "collaborationCursor";
    }));
    let Wn = 0;
    const Li = (b) => {
      if (y.value) return;
      const z = mt(
        "text-editor:update",
        "handleContentUpdate",
        {
          outputType: n.outputType,
          contentType: n.contentType,
          isCollaboration: vn.value
        }
      ), $ = mt(
        "text-editor:update",
        "getCurrentDocument"
      ), G = H(b);
      $ == null || $.end({
        topLevelNodes: Array.isArray(G.body.content.content) ? G.body.content.content.length : 0
      });
      const te = mt(
        "text-editor:update",
        "exportEditorContentValue"
      ), re = I.exportEditorContentValue({
        editor: b,
        document: G,
        outputType: n.outputType
      });
      te == null || te.end({
        exportedType: typeof re
      });
      const ke = mt(
        "text-editor:update",
        "emit events"
      );
      if (a("change", re), a("update:documentValue", G), a("document-change", G), vn.value) {
        const we = Va(
          b,
          n.collaborationEmit,
          G
        );
        we !== void 0 && a("update:modelValue", we);
      } else
        a("update:modelValue", re);
      ke == null || ke.end();
      const Se = mt(
        "text-editor:navigation",
        "refreshNavigationRuntime"
      );
      oe(), Se == null || Se.end(), z == null || z.end({
        topLevelNodes: Array.isArray(G.body.content.content) ? G.body.content.content.length : 0
      });
    }, Bi = (b) => {
      const z = rr(
        b
      );
      if (!z)
        return;
      const $ = gt({
        ...p.value,
        meta: {
          ...p.value.meta,
          pages: z.pages
        }
      });
      p.value = $, a("update:documentValue", $), a("document-change", $);
    }, Ci = (b, z) => {
      if (vn.value && n.collaborationEmit === "delta" && z) {
        const $ = z;
        $.steps && $.steps.length > 0 && (Wn++, a("delta", {
          steps: $.steps,
          version: Wn
        }));
      }
    }, zi = () => {
      var b;
      (b = c.value) == null || b.chain().focus().run();
    }, Mi = () => {
      var b;
      (b = u.value) == null || b.blur();
    }, Di = oi;
    return t({
      editor: c,
      navigationController: ne,
      rootRef: u,
      focus: zi,
      blur: Mi,
      getHTML: Ie,
      getMarkdown: Ce,
      getJSON: d,
      getDocument: h,
      navigate: Je,
      cancelNavigation: Qe,
      getNavigationSnapshot: W,
      getNavigationDebugSnapshot: ye,
      listNavigationDescriptors: Re,
      syncNavigationFromLocation: Ge,
      createShareableFragment: tt,
      navigateToBlock: Fe,
      getBlockElement: He,
      getRuntimeStatus: Kt,
      getText: A,
      getExcerpt: P,
      setHTML: Be,
      setMarkdown: pt,
      setJSON: Tt,
      setDocument: Nt,
      setContent: ue,
      intakeFiles: async (b, z = {}) => {
        if (n.contentProfile === "basic-rich-text")
          throw a("content-issue", "备注不支持图片或附件"), new TypeError("basic-rich-text:resources-not-supported");
        return nt.intakeFiles({
          files: Array.from(b),
          source: z.source,
          htmlContent: z.htmlContent,
          dropPos: z.dropPos,
          anchorPos: z.anchorPos,
          context: z.context
        });
      },
      clearContent: () => {
        n.contentProfile === "basic-rich-text" && c.value ? (c.value.view.dispatch(
          Di.closeHistory(c.value.state.tr)
        ), c.value.commands.clearContent()) : Be("");
      },
      isEmpty: () => {
        var b;
        return ((b = c.value) == null ? void 0 : b.isEmpty) ?? !0;
      }
    }), (b, z) => c.value ? (L(), F("div", st({
      key: 0,
      ref_key: "rootRef",
      ref: u,
      class: [v(r).b(), w.value],
      style: R.value
    }, Z.value, {
      onDragoverCapture: de,
      onDropCapture: _e
    }), [
      b.dragHandle ? (L(), $e(Ea, {
        key: 0,
        editor: c.value,
        "show-plus": g.value,
        "on-plus-click": V.value,
        "ask-ai-bridge": U.value
      }, null, 8, ["editor", "show-plus", "on-plus-click", "ask-ai-bridge"])) : ae("", !0),
      Ve(b.$slots, "top", { editor: c.value }),
      Ve(b.$slots, "editor", { editor: c.value }, () => [
        j(v(xr), {
          editor: c.value,
          class: q([v(r).e("content"), ce.value.className]),
          style: ft(ce.value.style),
          onMousedown: ge
        }, null, 8, ["editor", "class", "style"])
      ]),
      T.value ? (L(), $e(v(Ma), {
        key: 1,
        editor: c.value,
        contributions: k.value.contributions,
        "should-show": k.value.shouldShow,
        options: k.value.options
      }, null, 8, ["editor", "contributions", "should-show", "options"])) : ae("", !0),
      Ve(b.$slots, "bottom", { editor: c.value })
    ], 16)) : ae("", !0);
  }
});
function rf() {
  const e = ls({
    uploading: !1,
    progress: 0,
    uploaded: 0,
    total: 0,
    error: null,
    result: null
  }), t = () => {
    e.uploading = !1, e.progress = 0, e.uploaded = 0, e.total = 0, e.error = null, e.result = null;
  }, o = S(() => e.uploading), n = S(() => e.progress), i = S(() => e.error), s = S(() => e.result);
  return {
    upload: (l, r) => pl(l, r, e, t),
    reset: t,
    state: e,
    isUploading: o,
    progress: n,
    error: i,
    result: s
  };
}
async function pl(e, t, o, n) {
  var s;
  if (!(t != null && t.endpoint))
    throw new Error("Upload endpoint is required");
  if (!e)
    throw new Error("File is required");
  n(), o.uploading = !0;
  let i = e;
  if ((s = t.optimize) != null && s.enabled && e.type.startsWith("image/"))
    try {
      i = await hl(e, t.optimize);
    } catch (a) {
      console.warn("Image optimization failed, using original file:", a);
    }
  return new Promise((a, l) => {
    const r = new XMLHttpRequest();
    r.upload.addEventListener("progress", (u) => {
      var p;
      u.lengthComputable && (o.uploaded = u.loaded, o.total = u.total, o.progress = Math.round(u.loaded / u.total * 100)), (p = t.onProgress) == null || p.call(t, u);
    }), r.upload.addEventListener("load", () => {
      o.progress = 100;
    }), r.addEventListener("error", () => {
      const u = new Error("Upload failed");
      o.error = u, o.uploading = !1, l(u);
    }), r.onreadystatechange = () => {
      if (r.readyState !== XMLHttpRequest.DONE) return;
      const u = ml(r.getAllResponseHeaders()), p = vl(r.responseText), m = {
        data: p,
        status: r.status,
        headers: u
      };
      if (r.status >= 200 && r.status < 300) {
        o.result = m, o.uploading = !1, a(m);
        return;
      }
      const y = gl(r.status, p);
      o.error = y, o.uploading = !1, l(y);
    };
    const f = t.method ?? "POST";
    if (r.open(f, t.endpoint, !0), r.withCredentials = !!t.withCredentials, t.headers)
      for (const [u, p] of Object.entries(t.headers))
        r.setRequestHeader(u, p);
    const c = new FormData();
    if (c.append(t.fieldName ?? "file", i, e.name), t.data)
      for (const [u, p] of Object.entries(t.data))
        c.append(u, p);
    r.send(c);
  });
}
function ml(e) {
  return e ? e.split(`\r
`).filter(Boolean).reduce((t, o) => {
    const n = o.indexOf(": ");
    if (n > 0) {
      const i = o.slice(0, n).trim().toLowerCase(), s = o.slice(n + 2).trim();
      i && (t[i] = s);
    }
    return t;
  }, {}) : {};
}
function vl(e) {
  try {
    return JSON.parse(e);
  } catch {
    return e;
  }
}
function gl(e, t) {
  if (t instanceof Error) return t;
  const o = (typeof t == "object" && t !== null && "message" in t ? String(t.message) : void 0) || (typeof t == "string" ? t : "Upload failed");
  return new Error(`${e || 0}: ${o}`);
}
async function hl(e, t) {
  const { maxWidth: o, maxHeight: n, quality: i = 0.8, outputFormat: s } = t;
  return new Promise((a, l) => {
    const r = new Image(), f = URL.createObjectURL(e);
    r.onload = () => {
      URL.revokeObjectURL(f);
      let { width: c, height: u } = r;
      o && c > o && (u = Math.round(u * o / c), c = o), n && u > n && (c = Math.round(c * n / u), u = n);
      const p = document.createElement("canvas");
      p.width = c, p.height = u;
      const m = p.getContext("2d");
      if (!m) {
        l(new Error("Failed to get canvas context"));
        return;
      }
      m.drawImage(r, 0, 0, c, u);
      const y = s || e.type || "image/jpeg";
      p.toBlob(
        (M) => {
          M ? a(M) : l(new Error("Failed to create blob"));
        },
        y,
        i
      );
    }, r.onerror = () => {
      URL.revokeObjectURL(f), l(new Error("Failed to load image"));
    }, r.src = f;
  });
}
const bl = (e) => ({
  requestId: "navigation-request-unavailable",
  status: "failed",
  target: e.target,
  phase: "failed",
  reason: "target-unavailable",
  settle: null
}), yl = (e = {}) => {
  const t = J(ro());
  let o = null;
  const n = () => {
    const u = v(e.controller);
    if (u)
      return u;
    const p = v(e.editor);
    return p ? typeof p.navigate == "function" && typeof p.getSnapshot == "function" && typeof p.subscribe == "function" ? p : p.navigationController ?? null : null;
  }, i = (u) => {
    if (o == null || o(), o = null, !u) {
      t.value = ro();
      return;
    }
    t.value = u.getSnapshot(), o = u.subscribe((p) => {
      t.value = p;
    });
  };
  Q(
    () => [v(e.controller), v(e.editor)],
    () => {
      i(n());
    },
    { immediate: !0 }
  ), kt(() => {
    o == null || o(), o = null;
  });
  const s = async (u) => {
    const p = n();
    return p ? p.navigate(u) : bl(u);
  }, a = (u, p) => s({
    ...p,
    source: "bookmark",
    target: {
      kind: "bookmark",
      bookmarkId: u
    }
  }), l = (u, p) => s({
    ...p,
    source: "annotation",
    target: {
      kind: "annotation",
      annotationId: u
    }
  }), r = (u, p) => s({
    ...p,
    source: "search",
    target: {
      kind: "search-hit",
      hitId: u
    }
  }), f = (u, p) => s({
    ...p,
    source: "ai",
    target: {
      kind: "ai-suggestion",
      suggestionId: u
    }
  }), c = (u, p) => s({
    ...p,
    source: "presence",
    target: {
      kind: "presence",
      presenceId: u
    }
  });
  return {
    snapshot: t,
    debug: S(() => Zo(t.value)),
    activeReadingHeadingId: S(
      () => t.value.activeReadingHeadingId
    ),
    async listDescriptors(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.listDescriptors(u)) ?? [];
    },
    async listBookmarkDescriptors() {
      var u;
      return ((u = n()) == null ? void 0 : u.listDescriptors({ kinds: ["bookmark"] })) ?? [];
    },
    navigate: s,
    navigateToBookmark: a,
    navigateToAnnotation: l,
    navigateToCommentThread: l,
    navigateToSearchHit: r,
    navigateToAiSuggestion: f,
    navigateToPresence: c,
    followCollaborator: c,
    cancelNavigation() {
      var u;
      (u = n()) == null || u.cancel();
    },
    async syncFromLocation(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.syncFromLocation(u)) ?? null;
    },
    createShareableFragment(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.createShareableFragment(u)) ?? null;
    }
  };
}, $n = (e) => {
  const t = e.originalLevel ?? e.level;
  return Number.isFinite(t) && t > 0 ? t : 1;
}, kl = (e, t = null, o = 0) => ({
  id: Rt(e),
  label: e.textContent,
  anchor: e,
  parentId: t,
  children: [],
  originalLevel: $n(e),
  depth: o,
  indexLabel: null,
  isActive: !!e.isActive,
  isScrolledOver: !!e.isScrolledOver,
  isExpanded: !0,
  isVisible: !0
}), Hn = (e) => e.map((t) => ({
  ...t,
  children: Hn(t.children)
})), Un = (e) => {
  const t = [], o = (n) => {
    for (const i of n)
      t.push(i), i.children.length > 0 && o(i.children);
  };
  return o(e), t;
}, wl = (e = []) => {
  var i;
  const t = [...e].sort((s, a) => s.pos !== a.pos ? s.pos - a.pos : s.itemIndex - a.itemIndex), o = [], n = [
    {
      level: 0,
      node: null
    }
  ];
  for (const s of t) {
    const a = $n(s);
    for (; n.length > 1 && n[n.length - 1].level >= a; )
      n.pop();
    const l = ((i = n[n.length - 1]) == null ? void 0 : i.node) ?? null, r = kl(
      s,
      (l == null ? void 0 : l.id) ?? null,
      l ? l.depth + 1 : 0
    );
    l ? l.children.push(r) : o.push(r), n.push({
      level: a,
      node: r
    });
  }
  return {
    tree: o,
    flat: Un(o)
  };
}, xl = (e, t = {}) => {
  const o = Hn(e), n = Un(o), i = t.showIndex ?? !1, s = (a, l = []) => {
    a.forEach((r, f) => {
      var p;
      const c = [...l, f + 1], u = i ? c.join(".") : null;
      r.indexLabel = ((p = t.indexStrategy) == null ? void 0 : p.call(t, {
        node: r,
        root: o,
        flat: n
      })) ?? u, r.children.length > 0 && s(r.children, c);
    });
  };
  return s(o), {
    tree: o,
    flat: n
  };
}, Tl = (e) => {
  if (typeof window > "u" || typeof document > "u" || e == null)
    return null;
  if (typeof e == "string")
    try {
      return document.querySelector(e);
    } catch {
      return null;
    }
  if (typeof e == "function")
    try {
      return e();
    } catch {
      return null;
    }
  return typeof HTMLElement < "u" && e instanceof HTMLElement ? e : null;
}, an = (e, t) => {
  for (const o of e) {
    if (o.id === t)
      return [o.id];
    const n = an(o.children, t);
    if (n.length > 0)
      return [o.id, ...n];
  }
  return [];
}, Il = (e = [], t = null) => _n(
  e.map((o) => ({
    id: Rt(o),
    dom: o.dom,
    pos: o.pos,
    order: o.itemIndex,
    isActive: o.isActive
  })),
  {
    scrollContainer: t
  }
), Al = (e, t) => {
  const o = e.originalLevel || $n(e.anchor);
  return (t.minLevel == null || o >= t.minLevel) && (t.maxLevel == null || o <= t.maxLevel);
}, Nn = (e, t, o = 0, n = null) => {
  const i = [];
  for (const s of e) {
    if (Al(s, t)) {
      const l = {
        ...s,
        parentId: n,
        depth: o,
        isVisible: !0,
        children: Nn(
          s.children,
          t,
          o + 1,
          s.id
        )
      };
      i.push(l);
      continue;
    }
    i.push(
      ...Nn(s.children, t, o, n)
    );
  }
  return i;
}, El = (e, t, o) => {
  if (!o)
    return null;
  const n = new Set(t.map((s) => s.id));
  if (n.has(o))
    return o;
  const i = an(e, o);
  for (let s = i.length - 1; s >= 0; s -= 1)
    if (n.has(i[s]))
      return i[s];
  return null;
}, Sl = (e, t = {}) => {
  const o = Hn(e), n = Nn(o, t), i = Un(n), s = new Set(t.expandedKeys ?? []), a = El(o, i, t.activeId), l = a ? i.findIndex((r) => r.id === a) : -1;
  return i.forEach((r, f) => {
    r.isActive = r.id === a, r.isScrolledOver = l >= 0 && f < l, r.isVisible = !0, r.isExpanded = r.children.length === 0 || s.has(r.id);
  }), {
    tree: n,
    flat: i
  };
}, _l = { DEV: !1 }, Io = (e) => Array.isArray(e) ? [...e] : [], Ol = (e) => e.filter((t) => t.children.length > 0).map((t) => t.id), Me = (e) => En(e) ? e.value : e, Ao = /* @__PURE__ */ new Set(), Rl = () => _l.DEV, Vt = (e) => {
  !Rl() || Ao.has(e) || (Ao.add(e), console.warn(`[useTextEditorToc] ${e}`));
}, gi = (e) => {
  var t;
  return (t = e == null ? void 0 : e.storage) == null ? void 0 : t.tableOfContents;
}, Nl = (e) => !!(e && typeof e.on == "function" && typeof e.off == "function"), Eo = (e) => {
  if (!e || typeof e != "object")
    return !1;
  const t = e;
  return typeof t.id == "string" && typeof t.pos == "number" && typeof t.textContent == "string" && typeof t.level == "number" && typeof t.itemIndex == "number" && typeof t.dom == "object" && t.dom !== null;
}, Ll = (e) => {
  const t = gi(e), o = Array.isArray(t == null ? void 0 : t.content) ? t.content.filter(Eo) : [];
  if (o.length > 0)
    return [...o];
  const n = Array.isArray(t == null ? void 0 : t.anchors) ? t.anchors.filter(Eo) : [];
  return n.length > 0 ? [...n] : [];
}, So = (e) => ["auto", "scroll", "overlay"].includes(e), hi = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return !1;
  const t = window.getComputedStyle(e);
  return (So(t.overflowY) || So(t.overflow)) && e.scrollHeight > e.clientHeight + 1;
}, Bl = (e) => {
  if (!e || typeof document > "u")
    return null;
  let t = e.parentElement;
  for (; t && !(t === document.body || t === document.documentElement); ) {
    if (hi(t))
      return t;
    const o = t.parentElement;
    t = o instanceof HTMLElement ? o : null;
  }
  return null;
}, _o = (e, t) => t && e && t.contains(e) && hi(t) ? t : Bl(e) ?? t, Cl = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return 16;
  const t = window.getComputedStyle(e), o = Number.parseFloat(t.scrollPaddingTop || "0") || 0, n = Number.parseFloat(t.paddingTop || "0") || 0;
  return o || n;
}, Oo = (e) => (e == null ? void 0 : e.navigationController) ?? null;
function zl(e = {}) {
  const t = e.editor !== void 0, o = Ne([]), n = J(null), i = J(
    Me(e.defaultExpandedKeys) === void 0 ? null : Io(Me(e.defaultExpandedKeys))
  ), s = S(
    () => Me(e.anchors) !== void 0
  ), a = S(
    () => Me(e.expandedKeys) !== void 0
  ), l = S(() => !!Me(e.editor)), r = S(
    () => Oo(Me(e.editor))
  ), f = yl({
    controller: r
  });
  Q(
    () => Me(e.defaultExpandedKeys),
    (B) => {
      a.value || (B === void 0 ? i.value = null : i.value = Io(B));
    },
    {
      deep: !0
    }
  );
  const c = (B) => {
    if (!B) {
      o.value = [], t || Vt(
        "Provide `anchors` or pass an editor instance with the TableOfContents extension enabled."
      );
      return;
    }
    if (!gi(B)) {
      o.value = [], Vt(
        "The editor is missing `storage.tableOfContents`. Enable the TableOfContents extension before using `useTextEditorToc`."
      );
      return;
    }
    Oo(B) || Vt(
      "The editor is missing `navigationController`. Use `ZxTextEditor` for platform-backed TOC navigation, or pass standalone `anchors` instead of relying on editor fallback behavior."
    ), o.value = Ll(B);
  };
  Q(
    () => [Me(e.editor), s.value],
    ([B, C], N, O) => {
      if (C) {
        o.value = [];
        return;
      }
      if (c(B), !B)
        return;
      if (!Nl(B)) {
        Vt(
          "The editor is missing `on/off` transaction hooks. TOC anchors will be read once but cannot live-refresh from editor transactions."
        );
        return;
      }
      const K = () => {
        c(B);
      };
      B.on("transaction", K), O(() => {
        B.off("transaction", K);
      });
    },
    {
      immediate: !0
    }
  );
  const u = S(() => {
    const B = Me(e.anchors);
    return B !== void 0 ? B : o.value;
  }), p = S(
    () => wl(u.value ?? [])
  ), m = S(
    () => Tl(Me(e.scrollContainer))
  ), y = S(
    () => {
      var B;
      return _o(
        ((B = u.value[0]) == null ? void 0 : B.dom) ?? null,
        m.value
      );
    }
  ), M = S(
    () => xl(p.value.tree, {
      showIndex: Me(e.showIndex) ?? !1,
      indexStrategy: Me(e.indexStrategy)
    })
  ), _ = S(
    () => Ol(M.value.flat)
  ), T = S(
    () => r.value ? f.activeReadingHeadingId.value : l.value ? null : n.value
  ), k = () => {
    if (l.value) {
      n.value = null;
      return;
    }
    n.value = Il(
      u.value,
      y.value
    );
  };
  Q(
    u,
    () => {
      l.value || k();
    },
    {
      immediate: !0,
      deep: !0
    }
  ), Q(
    () => [y.value, l.value],
    ([B, C], N, O) => {
      if (C || (k(), typeof window > "u"))
        return;
      const K = B ?? window;
      let se = 0;
      const ge = () => {
        se || (se = window.requestAnimationFrame(() => {
          se = 0, k();
        }));
      };
      K.addEventListener("scroll", ge, {
        passive: !0
      }), window.addEventListener("resize", ge), O(() => {
        se && window.cancelAnimationFrame(se), K.removeEventListener("scroll", ge), window.removeEventListener("resize", ge);
      });
    },
    {
      immediate: !0
    }
  );
  const g = S(() => {
    const C = Me(e.expandedKeys) ?? i.value ?? _.value, N = new Set(C);
    return (Me(e.autoExpandActivePath) ?? !0) && T.value && an(M.value.tree, T.value).forEach((O) => {
      N.add(O);
    }), [...N];
  }), V = S(
    () => Sl(M.value.tree, {
      activeId: T.value,
      expandedKeys: g.value,
      minLevel: Me(e.minLevel),
      maxLevel: Me(e.maxLevel)
    })
  ), U = S(() => V.value.tree), x = S(() => V.value.flat), w = S(() => g.value), R = S(
    () => x.value.filter((B) => B.isVisible).length === 0
  ), X = (B) => {
    a.value || (i.value = B);
  };
  return {
    tree: U,
    flat: x,
    activeId: T,
    expandedKeys: w,
    isEmpty: R,
    navigateTo: (B) => {
      var N, O;
      const C = x.value.find((K) => K.id === B);
      if (C) {
        if (r.value) {
          f.navigate({
            source: "outline",
            target: {
              kind: "heading",
              blockId: C.id
            },
            align: "start",
            history: "none"
          });
          return;
        }
        if (l.value) {
          Vt(
            "Editor-backed TOC navigation requires `navigationController`. Legacy block navigation fallback is intentionally disabled."
          );
          return;
        }
        if (n.value = C.id, !!C.anchor.dom)
          try {
            const K = _o(
              C.anchor.dom,
              y.value
            );
            if (K) {
              const se = K.getBoundingClientRect(), ge = C.anchor.dom.getBoundingClientRect(), le = Cl(K), pe = K.scrollTop + ge.top - se.top - le;
              K.scrollTo({
                top: Math.max(pe, 0),
                behavior: "smooth"
              });
              return;
            }
            (O = (N = C.anchor.dom).scrollIntoView) == null || O.call(N, {
              block: "start",
              behavior: "smooth"
            });
          } catch {
          }
      }
    },
    toggleExpanded: (B) => {
      if (a.value)
        return;
      const C = new Set(i.value ?? _.value);
      C.has(B) ? C.delete(B) : C.add(B), X([...C]);
    },
    expandPath: (B) => {
      if (a.value)
        return;
      const C = new Set(i.value ?? _.value);
      an(M.value.tree, B).forEach((N) => {
        C.add(N);
      }), X([...C]);
    }
  };
}
const Ml = {
  white: "#ffffff"
};
function Dl(e) {
  if (e === "transparent" || e === Ml.white) return !0;
  if (!e.startsWith("#")) return !1;
  const t = e.replace("#", ""), o = Number.parseInt(t.slice(0, 2), 16), n = Number.parseInt(t.slice(2, 4), 16), i = Number.parseInt(t.slice(4, 6), 16);
  return (0.299 * o + 0.587 * n + 0.114 * i) / 255 > 0.65;
}
const Fl = ["onClick"], bi = /* @__PURE__ */ Te({
  name: "ZxTextEditorFontColor",
  __name: "font-color",
  props: {
    editor: {
      type: null,
      required: !0
    },
    mode: {
      type: String,
      default: "both"
    }
  },
  setup(e) {
    const t = e, o = De("text-editor-font-color"), n = J(!1), i = J("text"), s = J(null), a = J(null), l = J(null), { binding: r } = bt();
    Q(
      () => t.mode,
      (x) => {
        x && x !== "both" && (i.value = x);
      },
      { immediate: !0 }
    );
    const f = S(() => t.mode === "both"), c = () => {
      if (!t.editor) return;
      const { from: x, to: w } = t.editor.state.selection;
      l.value = { from: x, to: w };
    };
    Q(n, (x) => {
      x && c();
    });
    const u = S(() => {
      var x;
      return (x = r.value) == null ? void 0 : x.target;
    }), p = S(() => i.value === "background" ? Ps : Vs), m = (x) => Dl(x), y = (x) => {
      const w = M();
      return w ? w.toLowerCase() === x.toLowerCase() : !1;
    }, M = () => {
      if (!t.editor) return null;
      if (i.value === "background") {
        const w = t.editor.getAttributes("namedHighlight");
        return _(w == null ? void 0 : w.color);
      }
      const x = t.editor.getAttributes("textStyle");
      return _(x == null ? void 0 : x.color);
    }, _ = (x) => js(
      x,
      i.value === "background" ? "highlight" : "text"
    ), T = S(() => {
      if (!t.editor) return !0;
      if (i.value === "background")
        return !t.editor.isActive("namedHighlight");
      const x = t.editor.getAttributes("textStyle");
      return !(x != null && x.color);
    }), k = (x) => {
      if (!t.editor) return;
      n.value = !1;
      const w = l.value || t.editor.state.selection;
      i.value === "background" && $s(x), requestAnimationFrame(() => {
        t.editor && Hs(t.editor, {
          mode: i.value === "background" ? "highlight" : "text",
          value: x,
          selection: w
        });
      });
    }, g = () => {
      if (!t.editor) return;
      n.value = !1;
      const x = l.value || t.editor.state.selection;
      requestAnimationFrame(() => {
        t.editor && Us(t.editor, {
          mode: i.value === "text" ? "text" : "highlight",
          selection: x
        });
      });
    }, V = async () => {
      var R;
      if (!("EyeDropper" in window)) {
        (R = a.value) == null || R.click();
        return;
      }
      const w = await new window.EyeDropper().open();
      w != null && w.sRGBHex && k(w.sRGBHex);
    }, U = (x) => {
      const w = x.target, R = w == null ? void 0 : w.value;
      R && k(R);
    };
    return (x, w) => (L(), $e(v(Qt), {
      visible: n.value,
      "onUpdate:visible": w[8] || (w[8] = (R) => n.value = R),
      variant: "popover",
      trigger: "click",
      "show-arrow": !1,
      placement: "bottom-start",
      width: "auto",
      teleported: !0,
      "append-to": u.value,
      disabled: !v(r),
      "popper-class": v(o).e("popper")
    }, {
      content: ht(() => [
        D("div", {
          class: q(v(o).b()),
          onMousedown: w[7] || (w[7] = Ke(() => {
          }, ["prevent"]))
        }, [
          f.value ? (L(), F("div", {
            key: 0,
            class: q(v(o).e("tabs"))
          }, [
            D("button", {
              class: q([v(o).e("tab"), { "is-active": i.value === "text" }]),
              type: "button",
              onMousedown: w[0] || (w[0] = Ke(() => {
              }, ["prevent"])),
              onClick: w[1] || (w[1] = (R) => i.value = "text")
            }, [
              j(v(xe), { icon: "lucide:type" }),
              w[9] || (w[9] = D("span", null, "文字颜色", -1))
            ], 34),
            D("button", {
              class: q([v(o).e("tab"), { "is-active": i.value === "background" }]),
              type: "button",
              onMousedown: w[2] || (w[2] = Ke(() => {
              }, ["prevent"])),
              onClick: w[3] || (w[3] = (R) => i.value = "background")
            }, [
              j(v(xe), { icon: "lucide:highlighter" }),
              w[10] || (w[10] = D("span", null, "背景颜色", -1))
            ], 34)
          ], 2)) : ae("", !0),
          D("div", {
            class: q(v(o).e("palette"))
          }, [
            D("button", {
              class: q([v(o).e("clear-option"), { "is-active": T.value }]),
              type: "button",
              onMousedown: w[4] || (w[4] = Ke(() => {
              }, ["prevent"])),
              onClick: g
            }, [
              D("span", {
                class: q([v(o).e("clear-swatch"), { "is-active": T.value }])
              }, [
                D("span", {
                  class: q(v(o).e("clear-line"))
                }, null, 2)
              ], 2),
              D("span", {
                class: q(v(o).e("clear-label"))
              }, "无", 2)
            ], 34),
            D("div", {
              class: q(v(o).e("grid"))
            }, [
              (L(!0), F(Le, null, Pe(p.value, (R, X) => (L(), F("button", {
                key: X,
                class: q([
                  v(o).e("swatch"),
                  {
                    "is-light": m(R),
                    "is-active": y(R)
                  }
                ]),
                style: ft({ backgroundColor: R }),
                type: "button",
                onMousedown: w[5] || (w[5] = Ke(() => {
                }, ["prevent"])),
                onClick: (Z) => k(R)
              }, [
                y(R) ? (L(), $e(v(xe), {
                  key: 0,
                  icon: "lucide:check",
                  class: q([v(o).e("check"), { "is-dark": m(R) }])
                }, null, 8, ["class"])) : ae("", !0)
              ], 46, Fl))), 128))
            ], 2),
            D("div", {
              class: q(v(o).e("custom-section"))
            }, [
              D("span", {
                class: q(v(o).e("custom-label"))
              }, "自定义", 2),
              D("div", {
                class: q(v(o).e("custom-actions"))
              }, [
                D("label", {
                  class: q(v(o).e("custom-btn"))
                }, [
                  j(v(xe), { icon: "lucide:plus-circle" }),
                  D("input", {
                    ref_key: "customColorInputRef",
                    ref: a,
                    class: q(v(o).e("custom-input")),
                    type: "color",
                    tabindex: "-1",
                    onInput: U
                  }, null, 34)
                ], 2),
                D("button", {
                  class: q(v(o).e("custom-btn")),
                  type: "button",
                  onMousedown: w[6] || (w[6] = Ke(() => {
                  }, ["prevent"])),
                  onClick: V
                }, [
                  j(v(xe), { icon: "lucide:pipette" })
                ], 34)
              ], 2)
            ], 2)
          ], 2)
        ], 34)
      ]),
      default: ht(() => [
        D("span", {
          ref_key: "referenceRef",
          ref: s,
          onMousedown: Ke(c, ["prevent"])
        }, [
          Ve(x.$slots, "default", wt(xt({ isActive: n.value })))
        ], 544)
      ]),
      _: 3
    }, 8, ["visible", "append-to", "disabled", "popper-class"]));
  }
}), af = /* @__PURE__ */ Te({
  name: "ZxTextEditorTextColor",
  __name: "text-color",
  props: {
    editor: {}
  },
  setup(e) {
    return (t, o) => (L(), $e(bi, {
      editor: e.editor,
      mode: "text"
    }, {
      default: ht((n) => [
        Ve(t.$slots, "default", wt(xt(n)))
      ]),
      _: 3
    }, 8, ["editor"]));
  }
}), lf = /* @__PURE__ */ Te({
  name: "ZxTextEditorHighlightColor",
  __name: "highlight-color",
  props: {
    editor: {}
  },
  setup(e) {
    return (t, o) => (L(), $e(bi, {
      editor: e.editor,
      mode: "background"
    }, {
      default: ht((n) => [
        Ve(t.$slots, "default", wt(xt(n)))
      ]),
      _: 3
    }, 8, ["editor"]));
  }
}), Pl = /* @__PURE__ */ Te({
  name: "ZxTextEditorInsertImage",
  __name: "insert-image",
  props: {
    editor: {}
  },
  setup(e) {
    const t = e, o = De("text-editor-insert-image"), n = J(null), i = J(!1), s = J([]), { binding: a } = bt(), l = () => {
      var c;
      (c = n.value) == null || c.click();
    }, r = (c) => {
      const u = c.target, p = u.files;
      p && p.length > 0 && t.editor && (p.length === 1 ? t.editor.chain().focus().uploadImage(p[0], "picker").run() : (s.value = Array.from(p), i.value = !0)), u && (u.value = "");
    }, f = () => {
      i.value = !1, s.value = [];
    };
    return (c, u) => (L(), F(Le, null, [
      Ve(c.$slots, "default", wt(xt({ onClick: l })), void 0, !0),
      D("input", {
        ref_key: "fileInputRef",
        ref: n,
        type: "file",
        class: q(v(o).e("file-input")),
        accept: "image/*",
        multiple: "",
        onChange: r
      }, null, 34),
      i.value && e.editor && v(a) ? (L(), $e(is, {
        key: 0,
        modelValue: i.value,
        "onUpdate:modelValue": u[0] || (u[0] = (p) => i.value = p),
        files: s.value,
        "onUpdate:files": u[1] || (u[1] = (p) => s.value = p),
        mode: "new",
        editor: e.editor,
        "portal-binding": v(a),
        onClose: f
      }, null, 8, ["modelValue", "files", "editor", "portal-binding"])) : ae("", !0)
    ], 64));
  }
}), Vl = (e, t) => {
  const o = e.__vccOpts || e;
  for (const [n, i] of t)
    o[n] = i;
  return o;
}, jl = /* @__PURE__ */ Vl(Pl, [["__scopeId", "data-v-3a55a987"]]), $l = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: jl
}, Symbol.toStringTag, { value: "Module" })), cf = /* @__PURE__ */ Te({
  name: "ZxTextEditorInsertVideo",
  __name: "insert-video",
  props: {
    editor: {}
  },
  setup(e) {
    const t = e, o = () => {
      t.editor && t.editor.chain().focus().selectAndUploadVideo().run();
    };
    return (n, i) => Ve(n.$slots, "default", wt(xt({ onClick: o })));
  }
}), uf = /* @__PURE__ */ Te({
  name: "ZxTextEditorInsertLink",
  __name: "insert-link",
  props: {
    editor: {},
    actionRef: {}
  },
  setup(e) {
    var f;
    const t = e, o = Ne(null);
    Q(
      () => t.editor,
      (c, u, p) => {
        p(
          Wo(c, (m) => {
            o.value = (m == null ? void 0 : m.editLink) ?? null;
          })
        );
      },
      { immediate: !0, flush: "sync" }
    );
    const n = S(() => t.actionRef ?? o.value), i = Ne((f = n.value) == null ? void 0 : f.getView()), s = Js(), a = S(() => {
      const c = i.value;
      if (!c) return;
      const u = s.formatMany(c.shortcuts, {
        platform: c.platform
      });
      return {
        ...c,
        shortcutText: u.label,
        shortcutAriaLabel: u.ariaLabel
      };
    });
    let l = () => {
    };
    Q(
      n,
      (c) => {
        l();
        const u = () => {
          i.value = c == null ? void 0 : c.getView();
        };
        l = (c == null ? void 0 : c.subscribe(u)) ?? (() => {
        }), u();
      },
      { immediate: !0 }
    ), kt(() => l());
    const r = () => {
      var c;
      return (c = n.value) == null ? void 0 : c.invoke();
    };
    return (c, u) => {
      var p, m, y;
      return Ve(c.$slots, "default", wt(xt({
        onClick: r,
        disabled: !((p = a.value) != null && p.enabled),
        shortcut: (m = a.value) == null ? void 0 : m.shortcutText,
        shortcutAriaLabel: (y = a.value) == null ? void 0 : y.shortcutAriaLabel
      })));
    };
  }
}), Hl = ["onClick", "onMouseover"], Ul = ["src", "alt"], df = /* @__PURE__ */ Te({
  name: "ZxTextEditorMentionList",
  __name: "mention-list",
  props: {
    items: {},
    command: { type: Function }
  },
  setup(e, { expose: t }) {
    const o = e, n = De("text-editor-mention-list"), i = J(0);
    Q(
      () => o.items,
      () => {
        i.value = 0;
      }
    );
    const s = () => {
      i.value = (i.value + o.items.length - 1) % o.items.length;
    }, a = () => {
      i.value = (i.value + 1) % o.items.length;
    }, l = () => {
      r(i.value);
    }, r = (c) => {
      const u = o.items[c];
      u && o.command({
        id: u.value || u.id,
        label: u.label
      });
    };
    return t({
      onKeyDown: ({ event: c }) => c.key === "ArrowUp" ? (s(), !0) : c.key === "ArrowDown" ? (a(), !0) : c.key === "Enter" ? (l(), !0) : !1
    }), (c, u) => e.items.length ? (L(), F("div", {
      key: 0,
      class: q(v(n).b())
    }, [
      D("div", {
        class: q(v(n).e("scroll"))
      }, [
        (L(!0), F(Le, null, Pe(e.items, (p, m) => (L(), F("button", {
          key: p.id || m,
          class: q([v(n).e("item"), v(n).is("selected", m === i.value)]),
          type: "button",
          onClick: (y) => r(m),
          onMouseover: (y) => i.value = m
        }, [
          p.avatar ? (L(), F("span", {
            key: 0,
            class: q(v(n).e("avatar"))
          }, [
            D("img", {
              src: p.avatar,
              alt: p.label
            }, null, 8, Ul)
          ], 2)) : ae("", !0),
          D("span", {
            class: q(v(n).e("label"))
          }, me(p.label), 3)
        ], 42, Hl))), 128))
      ], 2)
    ], 2)) : ae("", !0);
  }
}), Kl = ["aria-expanded", "aria-current"], ql = ["aria-label"], Gl = ["title"], Wl = /* @__PURE__ */ Te({
  name: "ZxTextEditorTocNode",
  __name: "toc-node",
  props: {
    node: {}
  },
  emits: ["navigate", "toggle"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = De("text-editor-toc"), s = Xe(o, "node"), a = S(() => s.value.children.length > 0), l = () => {
      n("navigate", s.value);
    }, r = () => {
      n("toggle", s.value);
    };
    return (f, c) => {
      const u = cs("TocNode", !0);
      return L(), F("div", {
        class: q([
          v(i).e("node"),
          v(i).is("active", s.value.isActive),
          v(i).is("scrolled", s.value.isScrolledOver)
        ]),
        role: "treeitem",
        "aria-expanded": a.value ? s.value.isExpanded ? "true" : "false" : void 0,
        "aria-current": s.value.isActive ? "location" : void 0
      }, [
        D("div", {
          class: q(v(i).e("row")),
          style: ft({ "--toc-depth": s.value.depth })
        }, [
          a.value ? (L(), F("button", {
            key: 0,
            type: "button",
            class: q([v(i).e("branch"), v(i).is("expanded", s.value.isExpanded)]),
            "aria-label": s.value.isExpanded ? "Collapse section" : "Expand section",
            onClick: Ke(r, ["stop"])
          }, [
            (L(), F("svg", {
              viewBox: "0 0 12 12",
              fill: "currentColor",
              class: q(v(i).e("branch-icon")),
              "aria-hidden": "true"
            }, [...c[2] || (c[2] = [
              D("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M5.84 7.787a.2.2 0 0 0 .32 0l2.6-3.467A.2.2 0 0 0 8.6 4H3.4a.2.2 0 0 0-.16.32z"
              }, null, -1)
            ])], 2))
          ], 10, ql)) : (L(), F("span", {
            key: 1,
            class: q(v(i).e("spacer")),
            "aria-hidden": "true"
          }, null, 2)),
          Ve(f.$slots, "item", {
            node: s.value,
            navigate: l,
            toggle: r
          }, () => [
            D("button", {
              type: "button",
              class: q(v(i).e("item")),
              title: s.value.label,
              onClick: l
            }, [
              s.value.indexLabel ? (L(), F("span", {
                key: 0,
                class: q(v(i).e("index"))
              }, me(s.value.indexLabel), 3)) : ae("", !0),
              D("span", {
                class: q(v(i).e("label"))
              }, me(s.value.label), 3)
            ], 10, Gl)
          ])
        ], 6),
        a.value && s.value.isExpanded ? (L(), F("div", {
          key: 0,
          class: q(v(i).e("children")),
          role: "group"
        }, [
          (L(!0), F(Le, null, Pe(s.value.children, (p) => (L(), $e(u, {
            key: p.id,
            node: p,
            onNavigate: c[0] || (c[0] = (m) => n("navigate", m)),
            onToggle: c[1] || (c[1] = (m) => n("toggle", m))
          }, {
            item: ht((m) => [
              Ve(f.$slots, "item", st({ ref_for: !0 }, m))
            ]),
            _: 3
          }, 8, ["node"]))), 128))
        ], 2)) : ae("", !0)
      ], 10, Kl);
    };
  }
}), ff = /* @__PURE__ */ Te({
  name: "ZxTextEditorToC",
  __name: "toc",
  props: {
    editor: {
      type: Object,
      default: null
    },
    anchors: {
      type: Array,
      default: void 0
    },
    scrollContainer: {
      type: [String, Object, Function],
      default: void 0
    },
    minLevel: {
      type: Number,
      default: void 0
    },
    maxLevel: {
      type: Number,
      default: void 0
    },
    showIndex: {
      type: Boolean,
      default: !1
    },
    indexStrategy: {
      type: Function,
      default: void 0
    },
    expandedKeys: {
      type: Array,
      default: void 0
    },
    defaultExpandedKeys: {
      type: Array,
      default: void 0
    },
    autoExpandActivePath: {
      type: Boolean,
      default: !0
    },
    emptyText: {
      type: String,
      default: "暂无标题"
    }
  },
  emits: ["update:expandedKeys", "item-click"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = De("text-editor-toc"), s = J(null), { activeId: a, tree: l, expandedKeys: r, isEmpty: f, navigateTo: c, toggleExpanded: u } = zl({
      editor: Xe(o, "editor"),
      anchors: Xe(o, "anchors"),
      scrollContainer: Xe(o, "scrollContainer"),
      minLevel: Xe(o, "minLevel"),
      maxLevel: Xe(o, "maxLevel"),
      showIndex: Xe(o, "showIndex"),
      indexStrategy: Xe(o, "indexStrategy"),
      expandedKeys: Xe(o, "expandedKeys"),
      defaultExpandedKeys: Xe(o, "defaultExpandedKeys"),
      autoExpandActivePath: Xe(o, "autoExpandActivePath")
    }), p = async () => {
      var g, V;
      await dt();
      const T = (g = s.value) == null ? void 0 : g.querySelector(
        '[aria-current="location"]'
      ), k = (T == null ? void 0 : T.querySelector(`.${i.e("item")}`)) ?? T;
      (V = k == null ? void 0 : k.scrollIntoView) == null || V.call(k, {
        block: "nearest",
        behavior: "smooth"
      });
    };
    Q(a, (T) => {
      T && p();
    });
    const m = S(() => r.value), y = (T) => {
      const k = new Set(m.value);
      return k.has(T) ? k.delete(T) : k.add(T), [...k];
    }, M = (T) => {
      if (T.children.length === 0)
        return;
      const k = y(T.id);
      n("update:expandedKeys", k), u(T.id);
    }, _ = (T) => {
      c(T.id), n("item-click", T);
    };
    return (T, k) => (L(), F("nav", {
      ref_key: "rootRef",
      ref: s,
      class: q(v(i).b()),
      "aria-label": "Table of contents"
    }, [
      D("div", {
        class: q(v(i).e("content"))
      }, [
        v(f) ? Ve(T.$slots, "empty", wt(xt({ emptyText: e.emptyText })), () => [
          D("div", {
            class: q(v(i).e("empty"))
          }, me(e.emptyText), 3)
        ], void 0, 0) : (L(), F("div", {
          key: 1,
          class: q(v(i).e("tree")),
          role: "tree"
        }, [
          (L(!0), F(Le, null, Pe(v(l), (g) => (L(), $e(Wl, {
            key: g.id,
            node: g,
            onNavigate: _,
            onToggle: M
          }, {
            item: ht((V) => [
              Ve(T.$slots, "item", st({ ref_for: !0 }, V))
            ]),
            _: 3
          }, 8, ["node"]))), 128))
        ], 2))
      ], 2)
    ], 2));
  }
}), yi = (e) => e, ki = yi({
  status: {
    idle: "Ready",
    composing: "Writing instructions",
    prepared: "Ready to generate",
    starting: "Starting generation",
    streaming: "Generating",
    "abort-requested": "Requesting stop",
    "awaiting-review": "Ready to review",
    error: "Generation failed",
    conflict: "Document changed",
    stopped: "Stopped",
    completed: "Completed",
    detached: "Task running in background"
  },
  writingResultOutcome: {
    "document-changed": "The document changed. Regenerate to use the current text.",
    "anchor-lost": "The text at the cursor changed. Place the cursor, then regenerate.",
    "output-truncated": "The response hit the length limit. Copy it or regenerate.",
    "incomplete-result": "The response is incomplete. Copy it or regenerate.",
    "empty-result": "The response is empty. Add a topic and regenerate.",
    "invalid-structure": "The response does not match the requested format. Regenerate.",
    "outline-depth-exceeded": "The outline exceeds the requested depth. Regenerate.",
    "idea-count-mismatch": "The number of ideas differs from the request. Regenerate.",
    "duplicate-ideas": "Some ideas repeat. Regenerate."
  },
  chrome: {
    accept: "Accept",
    reject: "Reject",
    close: "Close",
    followUpPlaceholder: "Add a follow-up…",
    followUpAria: "Add a follow-up",
    reviewAria: "Inline diff review",
    reviewActionsAria: "Inline diff review actions",
    acceptUnavailable: "Accept unavailable: {reason}",
    controlUnavailable: "{label}. Unavailable: {reason}",
    hintAccept: "Accept",
    hintReject: "Reject",
    hintStep: "Step",
    followUpResets: "A follow-up clears {n} staged choice(s).",
    liveDecided: "Paragraph {ordinal}: {state}. {pending} pending.",
    liveAllDecided: "Paragraph {ordinal}: {state}. All changes decided.",
    liveFocused: "Paragraph {ordinal} of {total}: {state}.",
    liveUndecided: "Paragraph {ordinal}: back to pending."
  },
  hunk: {
    keep: "Keep",
    restore: "Keep original",
    undo: "Undo",
    kept: "Kept",
    restored: "Original kept",
    pending: "Pending",
    willDelete: "This paragraph will be removed",
    added: "New paragraph",
    ariaReplace: "Paragraph {ordinal} of {total}: {state}",
    ariaInsert: "Paragraph {ordinal} of {total} (new paragraph): {state}",
    ariaDelete: "Paragraph {ordinal} of {total} (removal): {state}"
  },
  presentation: {
    replacement: {
      title: "Review suggested edit",
      description: "Compare the removed and added text, then choose an action."
    },
    deletion: {
      title: "Review deletion",
      description: "This suggestion removes the selected text."
    },
    "no-change": {
      title: "No changes proposed",
      description: "The candidate matches the selected text. Accept closes the review without changing document history."
    },
    degraded: {
      title: "Limited diff preview",
      description: "The full inline diff cannot be shown safely. Accept is unavailable; reject or close this review."
    },
    conflict: {
      title: "Document changed",
      description: "Accept is unavailable until the review is restarted on the latest document."
    },
    error: {
      title: "Review unavailable",
      description: "The suggestion could not be prepared. Reject or close this review."
    }
  },
  disabledReason: {
    "disposition-pending": "Another review action is in progress.",
    "presentation-unverified": "The suggestion could not be verified.",
    "presentation-unsupported": "This suggestion cannot be reviewed inline.",
    "reject-only": "This review is reject-only.",
    conflict: "The document changed after this review started.",
    "action-unavailable": "This action is not currently available."
  },
  busy: {
    accept: "Accepting suggestion…",
    reject: "Rejecting suggestion…",
    "add-follow-up": "Starting follow-up…",
    close: "Closing preview…"
  },
  skills: {
    "improve-writing": {
      label: "Improve writing",
      description: "Clarify and strengthen the selected text"
    },
    proofread: {
      label: "Proofread",
      description: "Fix grammar and spelling"
    },
    explain: {
      label: "Explain",
      description: "Explain the selected text"
    },
    reformat: {
      label: "Reformat",
      description: "Reformat the selected text"
    }
  },
  slash: {
    "continue-writing": {
      label: "Continue writing"
    },
    "draft-outline": {
      label: "Draft an outline"
    },
    "brainstorm-ideas": {
      label: "Brainstorm ideas"
    }
  },
  surface: {
    askAi: "Ask AI",
    editWithAi: "Edit with AI",
    askAiPlaceholder: "Ask AI to write anything…",
    skills: "Skills",
    skillsSettings: "Skills settings",
    suggestions: "Suggestions",
    stop: "Stop",
    generating: "Generating",
    stopping: "Stopping…",
    insertBelow: "Insert below",
    insert: "Insert",
    copy: "Copy",
    copied: "Copied",
    copyFailed: "Could not copy. Select the text and copy it manually.",
    discard: "Discard",
    reviewRefine: "Review Refine",
    result: "AI result",
    resultActionsAria: "AI result actions",
    reviewResult: "Review AI result",
    continueReview: "Continue Review",
    selectionMenuAria: "Ask AI selection menu",
    skillsListAria: "AI skills",
    contextPlanned: "Will use {n} context blocks",
    contextSubmitted: "Used {n} context blocks",
    contextPrefix: "{n} preceding blocks",
    contextSuffix: "{n} following blocks",
    contextOutline: "outline",
    contextDigest: "summary",
    contextOmitted: "{n} blocks omitted",
    contextFull: "complete authorized text",
    contextPartial: "partial text",
    contextSummarized: "summary coverage",
    contextPolicyExcluded: "{n} blocks excluded by policy",
    contextTokensEstimated: "about {estimated} input tokens",
    contextTokensActual: "{actual} input tokens (estimated {estimated})"
  },
  handoff: {
    "multi-block-selection": "Skills work on one paragraph at a time. Select text within a single paragraph.",
    "explicit-line-break": "Selections with a manual line break are not supported yet. Select text on one line.",
    "unsupported-node": "AI editing is not available for this block type yet.",
    "collapsed-selection": "Select some text first.",
    "task-open": "An AI task is already open. Finish or close it before starting another.",
    "capture-failed": "Could not read this selection. Select the text again and retry.",
    unavailable: "Ask AI could not start for this selection."
  },
  error: {
    generic: "Something went wrong with this AI task.",
    category: {
      transport: "The AI service could not be reached.",
      "provider-adapter": "The AI service returned an error.",
      validation: "This request could not be completed as written.",
      "resource-limit": "This request is larger than the AI service allows.",
      unsupported: "This request is not supported here.",
      "anchor-lost": "The text this task was working on is no longer in the document.",
      conflict: "The document changed while this task was open.",
      abort: "This task could not be stopped."
    },
    code: {
      "transport.network": "Could not connect to the AI service. Check the network, then retry.",
      "transport.provider-unavailable": "The AI service is temporarily unavailable. Retry in a moment.",
      "transport.rate-limited": "Too many requests in a short time. Wait a moment, then retry.",
      "transport.transport-failed": "The request to the AI service failed.",
      "transport.transport-disconnected": "The connection closed before the response finished.",
      "transport.timeout": "The AI service took too long to respond.",
      "provider-adapter.auth-failed": "The AI service rejected the credentials of this site. Contact the site administrator.",
      "provider-adapter.quota-exceeded": "The AI service quota has run out. Contact the site administrator.",
      "provider-adapter.request-rejected": "The AI service rejected this request.",
      "provider-adapter.empty-output": "The AI service returned an empty response.",
      "provider-adapter.protocol": "The AI service returned a response that could not be read.",
      "provider-adapter.internal": "The AI integration hit an internal error.",
      "provider-adapter.handoff-failure": "The response could not be prepared for review.",
      "resource-limit.context-overflow": "The request is too long for the model. Select less text, then try again.",
      "resource-limit.output-truncated": "The response reached the length limit before it finished.",
      "resource-limit.resource-limit": "The response exceeded the allowed size.",
      "validation.content-filtered": "The AI service declined this request. Rephrase it, then try again.",
      "abort.abort-unsupported": "This AI service cannot stop a running task."
    }
  },
  action: {
    submit: "Generate",
    stop: "Stop",
    retry: "Retry",
    restart: "Regenerate",
    supersede: "Replace request",
    "follow-up": "Follow up",
    reveal: "Reveal",
    "review-previous": "Previous change",
    "review-next": "Next change",
    "review-decide": "Decide",
    "review-accept-all": "Accept all",
    "review-reject-all": "Reject all",
    "review-commit": "Apply",
    "review-regenerate": "Regenerate suggestion",
    "review-refine": "Review Refine",
    "retry-review-refine": "Retry refinement",
    close: "Close",
    "edit-prompt": "Edit instructions",
    "reselect-target": "Reselect text",
    "narrow-scope": "Narrow the selection",
    "choose-supported-command": "Choose another command",
    "contact-host": "Contact support"
  },
  actionHint: {
    retry: "Re-sends the same request",
    restart: "Uses the current document",
    "follow-up": "Builds on the previous result",
    "retry-review-refine": "Re-sends the same refinement"
  }
}), Jl = yi({
  status: {
    idle: "就绪",
    composing: "编辑要求",
    prepared: "准备生成",
    starting: "正在启动生成",
    streaming: "正在生成",
    "abort-requested": "正在请求停止",
    "awaiting-review": "等待审阅",
    error: "生成失败",
    conflict: "正文已变化",
    stopped: "已停止",
    completed: "已完成",
    detached: "任务在后台继续"
  },
  writingResultOutcome: {
    "document-changed": "正文已变化，请重新生成以使用当前正文。",
    "anchor-lost": "光标处的内容已变化，请先放置光标再重新生成。",
    "output-truncated": "回复达到长度上限被截断，可复制内容或重新生成。",
    "incomplete-result": "回复尚未完成，可复制内容或重新生成。",
    "empty-result": "回复为空，请补充主题后重新生成。",
    "invalid-structure": "回复不符合所需格式，请重新生成。",
    "outline-depth-exceeded": "大纲层级超出要求，请重新生成。",
    "idea-count-mismatch": "想法数量与要求不符，请重新生成。",
    "duplicate-ideas": "部分想法重复，请重新生成。"
  },
  chrome: {
    accept: "接受",
    reject: "拒绝",
    close: "关闭",
    followUpPlaceholder: "补充追问…",
    followUpAria: "补充追问",
    reviewAria: "行内改写审阅",
    reviewActionsAria: "行内改写审阅操作",
    acceptUnavailable: "无法接受：{reason}",
    controlUnavailable: "{label}。不可用：{reason}",
    hintAccept: "接受",
    hintReject: "拒绝",
    hintStep: "逐段",
    followUpResets: "追问会清空 {n} 项裁决。",
    liveDecided: "第 {ordinal} 段：{state}，还剩 {pending} 段待定。",
    liveAllDecided: "第 {ordinal} 段：{state}，已全部裁决。",
    liveFocused: "第 {ordinal} 段，共 {total} 段：{state}。",
    liveUndecided: "第 {ordinal} 段：已撤回，回到待定。"
  },
  hunk: {
    keep: "采用",
    restore: "留原文",
    undo: "撤回",
    kept: "已采用",
    restored: "留原文",
    pending: "待定",
    willDelete: "此段将删除",
    added: "新增",
    ariaReplace: "第 {ordinal} 段，共 {total} 段：{state}",
    ariaInsert: "第 {ordinal} 段，共 {total} 段（新增段落）：{state}",
    ariaDelete: "第 {ordinal} 段，共 {total} 段（删除）：{state}"
  },
  presentation: {
    replacement: {
      title: "审阅建议改写",
      description: "对比删除与新增内容，然后选择操作。"
    },
    deletion: {
      title: "审阅删除建议",
      description: "这条建议会删除所选文字。"
    },
    "no-change": {
      title: "没有提出改动",
      description: "候选文本与选区相同。接受后会关闭审阅，且不改写文档历史。"
    },
    degraded: {
      title: "仅提供有限预览",
      description: "完整行内 diff 无法安全展示。无法接受；请拒绝或关闭本次审阅。"
    },
    conflict: {
      title: "文档已变化",
      description: "请先按最新文档重新发起审阅，然后才能接受。"
    },
    error: {
      title: "无法审阅",
      description: "建议未能准备完成。请拒绝或关闭本次审阅。"
    }
  },
  disabledReason: {
    "disposition-pending": "另一项审阅操作正在进行。",
    "presentation-unverified": "建议未能通过校验。",
    "presentation-unsupported": "这条建议无法在行内审阅。",
    "reject-only": "本次审阅只能拒绝。",
    conflict: "审阅开始后文档已变化。",
    "action-unavailable": "当前无法执行此操作。"
  },
  busy: {
    accept: "正在接受建议…",
    reject: "正在拒绝建议…",
    "add-follow-up": "正在开始追问…",
    close: "正在关闭预览…"
  },
  skills: {
    "improve-writing": {
      label: "改进写作",
      description: "让所选文字更清晰、更有力"
    },
    proofread: {
      label: "校对",
      description: "修正语法和拼写"
    },
    explain: {
      label: "解释",
      description: "解释所选文字"
    },
    reformat: {
      label: "重排格式",
      description: "重新整理所选文字的格式"
    }
  },
  slash: {
    "continue-writing": {
      label: "继续写"
    },
    "draft-outline": {
      label: "起草大纲"
    },
    "brainstorm-ideas": {
      label: "头脑风暴"
    }
  },
  surface: {
    askAi: "问 AI",
    editWithAi: "用 AI 编辑",
    askAiPlaceholder: "让 AI 写任何内容…",
    skills: "技能",
    skillsSettings: "技能设置",
    suggestions: "建议",
    stop: "停止",
    generating: "生成中",
    stopping: "正在停止…",
    insertBelow: "插入到下方",
    insert: "插入",
    copy: "复制",
    copied: "已复制",
    copyFailed: "复制失败，请手动选中文本复制。",
    discard: "舍弃",
    reviewRefine: "继续改写",
    result: "AI 结果",
    resultActionsAria: "AI 结果操作",
    reviewResult: "审阅 AI 结果",
    continueReview: "继续审阅",
    selectionMenuAria: "问 AI 选区菜单",
    skillsListAria: "AI 技能",
    contextPlanned: "将参考 {n} 段上下文",
    contextSubmitted: "已参考 {n} 段上下文",
    contextPrefix: "光标前 {n} 段",
    contextSuffix: "光标后 {n} 段",
    contextOutline: "大纲",
    contextDigest: "摘要",
    contextOmitted: "省略 {n} 段",
    contextFull: "完整授权正文",
    contextPartial: "部分正文",
    contextSummarized: "摘要覆盖",
    contextPolicyExcluded: "策略排除 {n} 段",
    contextTokensEstimated: "约 {estimated} 输入 token",
    contextTokensActual: "实际 {actual} 输入 token（预估 {estimated}）"
  },
  handoff: {
    "multi-block-selection": "技能一次只处理一个段落。请在同一段内选择文字。",
    "explicit-line-break": "暂不支持包含手动换行的选区。请选择同一行中的文字。",
    "unsupported-node": "这类块暂不支持 AI 编辑。",
    "collapsed-selection": "请先选中一段文字。",
    "task-open": "已有进行中的 AI 任务。请先完成或关闭后再开始新的任务。",
    "capture-failed": "无法读取这次选区。请重新选择文字后再试。",
    unavailable: "无法对这次选区启动问 AI。"
  },
  error: {
    generic: "本次 AI 任务出错了。",
    category: {
      transport: "无法连接 AI 服务。",
      "provider-adapter": "AI 服务返回了错误。",
      validation: "这条请求无法按当前写法完成。",
      "resource-limit": "这条请求超出了 AI 服务的处理上限。",
      unsupported: "此处不支持这条请求。",
      "anchor-lost": "本次任务处理的文字已不在文档中。",
      conflict: "任务进行期间文档已变化。",
      abort: "无法停止本次任务。"
    },
    code: {
      "transport.network": "无法连接 AI 服务。请检查网络后重试。",
      "transport.provider-unavailable": "AI 服务暂时不可用，请稍后重试。",
      "transport.rate-limited": "短时间内请求过多，请稍等后重试。",
      "transport.transport-failed": "发往 AI 服务的请求失败了。",
      "transport.transport-disconnected": "回复完成前连接已断开。",
      "transport.timeout": "AI 服务响应超时。",
      "provider-adapter.auth-failed": "AI 服务拒绝了本站的凭据，请联系站点管理员。",
      "provider-adapter.quota-exceeded": "AI 服务额度已用完，请联系站点管理员。",
      "provider-adapter.request-rejected": "AI 服务拒绝了这条请求。",
      "provider-adapter.empty-output": "AI 服务返回了空回复。",
      "provider-adapter.protocol": "AI 服务返回的内容无法解析。",
      "provider-adapter.internal": "AI 集成内部出错。",
      "provider-adapter.handoff-failure": "回复未能整理成可审阅的结果。",
      "resource-limit.context-overflow": "请求内容超出模型上限。请少选一些文字后再试。",
      "resource-limit.output-truncated": "回复达到长度上限，未能写完。",
      "resource-limit.resource-limit": "回复超出了允许的大小。",
      "validation.content-filtered": "AI 服务拒绝回答这条请求。请换个说法后再试。",
      "abort.abort-unsupported": "这个 AI 服务不支持中途停止。"
    }
  },
  action: {
    submit: "生成",
    stop: "停止",
    retry: "重试",
    restart: "重新生成",
    supersede: "替换请求",
    "follow-up": "追问",
    reveal: "显示任务",
    "review-previous": "上一处",
    "review-next": "下一处",
    "review-decide": "裁决",
    "review-accept-all": "全部接受",
    "review-reject-all": "全部拒绝",
    "review-commit": "应用",
    "review-regenerate": "重新生成建议",
    "review-refine": "继续改写",
    "retry-review-refine": "重试改写",
    close: "关闭",
    "edit-prompt": "修改要求",
    "reselect-target": "重新选择",
    "narrow-scope": "缩小范围",
    "choose-supported-command": "换个命令",
    "contact-host": "联系管理员"
  },
  actionHint: {
    retry: "重发同一请求",
    restart: "按当前正文生成",
    "follow-up": "基于上一次结果",
    "retry-review-refine": "重发同一改写"
  }
}), Zl = (e, t) => e.replace(
  /\{(\w+)\}/g,
  (o, n) => `${t[n] ?? `{${n}}`}`
), Xl = (e) => (e ?? "").toLowerCase().replace(/_/g, "-").startsWith("zh"), Yl = (e) => Xl(e) ? Jl : ki, Ql = (e) => xa.map((t) => {
  const o = e.skills[t.skillId];
  return o ? { ...t, label: o.label, description: o.description } : t;
}), ec = (e) => Ta.map((t) => {
  const o = e.slash[t.id];
  return o ? { ...t, label: o.label } : t;
}), Ro = (e, t = ki) => t.handoff[e.reason] ?? t.handoff.unavailable, Kn = () => {
  const { lang: e } = ms(), t = S(() => Yl(e.value)), o = S(
    () => Ql(t.value)
  ), n = S(
    () => ec(t.value)
  );
  return {
    lang: e,
    messages: t,
    defaultSkills: o,
    slashSuggestions: n,
    formatCopy: Zl
  };
};
let tc = 0;
const nc = (e = `inline-ai-focus-${++tc}`) => {
  let t = null;
  return {
    create: (o = 1500) => (t = {
      instanceId: e,
      expiresAt: Date.now() + Math.max(0, o),
      revoked: !1
    }, t),
    current: () => t,
    revoke: () => {
      t ? t = { ...t, revoked: !0 } : t = null;
    },
    isActive: (o = t) => !o || o !== t || o.revoked || o.instanceId !== e ? !1 : Date.now() <= o.expiresAt
  };
}, oc = (e) => e instanceof HTMLElement ? !!e.closest('input, textarea, [contenteditable="true"]') : !1, ic = (e) => {
  var i;
  const t = e.event.target, o = oc(t);
  e.claim(), (i = e.focusToken) == null || i.create(), o || e.event.preventDefault();
  const n = e.inputEl ?? (o && t instanceof HTMLElement ? t : null);
  n && typeof n.focus == "function" && n.focus({ preventScroll: !0 });
}, sc = (e) => {
  e.claim();
  const t = e.focusToken.create(), o = typeof document < "u" ? document.activeElement : null;
  return (e.raf ?? requestAnimationFrame)(async () => {
    var a;
    if (!e.focusToken.isActive(t) || (await ((a = e.afterGeometry) == null ? void 0 : a.call(e)), !e.focusToken.isActive(t))) return;
    const i = e.getInput();
    if (!i) return;
    const s = typeof document < "u" ? document.activeElement : null;
    if (s && s !== i && s !== o && !i.contains(s)) {
      const l = s === document.body || s === document.documentElement, r = !!s.closest("[data-inline-ai-focus-root]"), f = s.matches('[contenteditable="true"]');
      if (!l && !r && !f) {
        const c = s.closest(
          'input, textarea, button, select, [contenteditable="true"], [tabindex]'
        );
        if (c && !i.contains(c)) return;
      }
    }
    i.focus({ preventScroll: !0 });
  }), t;
}, rc = (e) => ti(e), In = (e) => e.kind === "geometry" || e.kind === "scroll" || e.kind === "visualViewport", No = (e) => e !== !1 && e !== null && e !== void 0, ac = (e) => {
  const t = async () => {
    await dt(), No(e.activationKey()) && e.input.value && sc({
      claim: e.claim,
      focusToken: e.focusToken,
      getInput: () => e.input.value
    });
  };
  return Q(
    [e.activationKey, e.input],
    ([o]) => {
      if (!No(o)) {
        e.focusToken.revoke();
        return;
      }
      e.input.value && t();
    },
    { flush: "post", immediate: !0 }
  ), rt(() => {
    e.focusToken.revoke();
  }), {
    requestFocus: t
  };
}, lc = {
  key: 0,
  class: "zx-inline-ai-surface__sr-only"
}, cc = ["value", "placeholder", "aria-label", "aria-disabled", "data-testid"], uc = ["disabled", "aria-disabled", "data-testid"], Ln = /* @__PURE__ */ Te({
  __name: "InlineAiPromptComposer",
  props: {
    modelValue: {},
    variant: {},
    activationKey: { type: [String, Number, Boolean, null] },
    submitEnabled: { type: Boolean },
    shortcut: {},
    inputAriaDisabled: { type: [Boolean, String] },
    placeholder: {},
    accessibleLabel: {}
  },
  emits: ["update:modelValue", "submit", "focus-intent"],
  setup(e, { expose: t, emit: o }) {
    const n = e, i = o, s = Ne(null), a = nc(), l = Ne(n.modelValue), { messages: r } = Kn(), f = S(() => n.variant === "slash"), c = S(() => n.variant === "selection"), u = S(() => !l.value.trim()), p = S(
      () => n.accessibleLabel ?? (f.value ? r.value.surface.askAi : r.value.surface.editWithAi)
    ), m = S(
      () => n.placeholder ?? (f.value ? r.value.surface.askAiPlaceholder : r.value.surface.editWithAi)
    ), y = S(
      () => c.value ? "inline-ai-edit-with-ai" : "inline-ai-surface-prompt"
    ), M = S(
      () => c.value ? "inline-ai-prompt-send" : "inline-ai-surface-send"
    ), _ = S(() => f.value || !u.value), T = S(
      () => c.value ? [
        "zx-inline-ai-prompt-composer",
        "zx-inline-ai-selection-menu__prompt-row"
      ] : [
        "zx-inline-ai-prompt-composer",
        "zx-inline-ai-surface__prompt-row",
        { "zx-inline-ai-surface__prompt-row--slash": f.value }
      ]
    ), k = S(
      () => c.value ? ["zx-inline-ai-prompt-composer__selection-label"] : ["zx-inline-ai-surface__prompt-label"]
    ), g = S(
      () => c.value ? [
        "zx-inline-ai-prompt-composer__control",
        "zx-inline-ai-selection-menu__prompt"
      ] : [
        "zx-inline-ai-prompt-composer__control",
        "zx-inline-ai-surface__prompt",
        { "zx-inline-ai-surface__prompt--slash": f.value }
      ]
    ), V = S(
      () => c.value ? ["zx-inline-ai-selection-menu__send"] : ["zx-inline-ai-surface__send", "zx-inline-ai-surface__hit"]
    ), U = () => {
      const B = s.value;
      if (!B) return;
      const C = getComputedStyle(B), N = Number.parseFloat(C.minHeight) || 0, O = Number.parseFloat(C.maxHeight) || Number.POSITIVE_INFINITY;
      B.style.height = "auto";
      const K = Math.min(
        Math.max(B.scrollHeight, N),
        O
      );
      B.style.height = `${K}px`, B.style.overflowY = B.scrollHeight > O ? "auto" : "hidden";
    };
    ac({
      activationKey: () => n.activationKey,
      claim: () => i("focus-intent"),
      focusToken: a,
      input: s
    }), Q(
      () => n.modelValue,
      (B) => {
        B !== l.value && (l.value = B);
      }
    ), Q([l, () => n.variant], () => {
      dt(U);
    }), Ht(() => {
      U();
    });
    const x = (B) => {
      const C = B.currentTarget;
      l.value = C.value, i("update:modelValue", C.value);
    }, w = () => {
      i("submit");
    }, R = () => {
      w();
    }, X = (B) => {
      B.key !== "Enter" || B.isComposing || B.keyCode === 229 || rc(B) || B.shiftKey || B.metaKey || B.ctrlKey || (B.preventDefault(), w());
    }, Z = (B) => {
      ic({
        event: B,
        claim: () => i("focus-intent"),
        inputEl: s.value,
        focusToken: a
      });
      const C = a.current();
      queueMicrotask(() => {
        a.current() === C && a.revoke();
      });
    }, ie = () => {
      if (a.isActive()) {
        a.revoke();
        return;
      }
      i("focus-intent");
    };
    return t({ focus: () => {
      var B;
      (B = s.value) == null || B.focus({ preventScroll: !0 });
    } }), (B, C) => (L(), F("div", {
      class: q(T.value)
    }, [
      D("label", {
        class: q(k.value)
      }, [
        c.value ? ae("", !0) : (L(), F("span", lc, me(p.value), 1)),
        D("textarea", {
          ref_key: "inputEl",
          ref: s,
          value: l.value,
          class: q(g.value),
          rows: "1",
          placeholder: m.value,
          "aria-label": p.value,
          "aria-disabled": e.inputAriaDisabled,
          "data-testid": y.value,
          "data-inline-ai-edit-with-ai": "",
          onInput: x,
          onPointerdown: Z,
          onFocus: ie,
          onKeydown: X
        }, null, 42, cc)
      ], 2),
      u.value && e.shortcut ? (L(), F("kbd", {
        key: 0,
        class: q(
          c.value ? "zx-inline-ai-selection-menu__shortcut" : "zx-inline-ai-surface__shortcut"
        ),
        "aria-hidden": "true"
      }, me(e.shortcut), 3)) : ae("", !0),
      _.value ? (L(), F("button", {
        key: 1,
        type: "button",
        class: q(V.value),
        disabled: c.value ? void 0 : u.value || n.submitEnabled === !1,
        "aria-disabled": c.value && n.submitEnabled === !1 ? "true" : void 0,
        "aria-label": "Send",
        "data-testid": M.value,
        onClick: R
      }, [
        j(v(xe), {
          icon: "lucide:arrow-up",
          "aria-hidden": "true"
        })
      ], 10, uc)) : ae("", !0)
    ], 2));
  }
}), dc = Object.freeze([
  { id: "paragraph", label: "Text", icon: "lucide:type" },
  { id: "heading-1", label: "Heading 1", icon: "lucide:heading-1" },
  { id: "heading-2", label: "Heading 2", icon: "lucide:heading-2" },
  { id: "heading-3", label: "Heading 3", icon: "lucide:heading-3" },
  { id: "heading-4", label: "Heading 4", icon: "lucide:heading-4" },
  { id: "bullet-list", label: "Bulleted list", icon: "lucide:list" },
  { id: "ordered-list", label: "Numbered list", icon: "lucide:list-ordered" },
  { id: "task-list", label: "To-do list", icon: "lucide:list-checks" },
  { id: "code-block", label: "Code", icon: "lucide:code" },
  { id: "blockquote", label: "Quote", icon: "lucide:quote" }
]), fc = Object.freeze([
  { id: "color", label: "Text color", glyph: "A" },
  { id: "bold", label: "Bold", glyph: "B" },
  { id: "italic", label: "Italic", glyph: "I" },
  { id: "underline", label: "Underline", glyph: "U" },
  { id: "clear", label: "Clear formatting", glyph: "Tx" },
  { id: "link", label: "Link", glyph: "a/" },
  { id: "strike", label: "Strikethrough", glyph: "S" },
  { id: "code", label: "Code", glyph: "</>" }
]), Oe = (e, t) => {
  var i;
  if (!(e != null && e.chain)) return !1;
  const o = e.chain().focus(), n = t(o);
  return ((i = n == null ? void 0 : n.run) == null ? void 0 : i.call(n)) ?? !1;
}, pc = (e) => e != null && e.isActive ? e.isActive("heading", { level: 1 }) ? "Heading 1" : e.isActive("heading", { level: 2 }) ? "Heading 2" : e.isActive("heading", { level: 3 }) ? "Heading 3" : e.isActive("heading", { level: 4 }) ? "Heading 4" : e.isActive("bulletList") ? "Bulleted list" : e.isActive("orderedList") ? "Numbered list" : e.isActive("taskList") ? "To-do list" : e.isActive("codeBlock") ? "Code" : e.isActive("blockquote") ? "Quote" : "Normal text" : "Normal text", mc = (e) => e != null && e.isActive ? e.isActive("heading", { level: 1 }) ? "heading-1" : e.isActive("heading", { level: 2 }) ? "heading-2" : e.isActive("heading", { level: 3 }) ? "heading-3" : e.isActive("heading", { level: 4 }) ? "heading-4" : e.isActive("bulletList") ? "bullet-list" : e.isActive("orderedList") ? "ordered-list" : e.isActive("taskList") ? "task-list" : e.isActive("codeBlock") ? "code-block" : e.isActive("blockquote") ? "blockquote" : "paragraph" : "paragraph", vc = (e, t) => {
  switch (t) {
    case "paragraph":
      return Oe(e, (o) => {
        var n;
        return (n = o.setParagraph) == null ? void 0 : n.call(o);
      });
    case "heading-1":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 1 });
      });
    case "heading-2":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 2 });
      });
    case "heading-3":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 3 });
      });
    case "heading-4":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 4 });
      });
    case "bullet-list":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleBulletList) == null ? void 0 : n.call(o);
      });
    case "ordered-list":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleOrderedList) == null ? void 0 : n.call(o);
      });
    case "task-list":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleTaskList) == null ? void 0 : n.call(o);
      });
    case "blockquote":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleBlockquote) == null ? void 0 : n.call(o);
      });
    case "code-block":
      return Oe(e, (o) => {
        var n;
        return (n = o.toggleCodeBlock) == null ? void 0 : n.call(o);
      });
    default:
      return !1;
  }
}, gc = (e, t) => !(e != null && e.isActive) || t === "clear" || t === "color" ? !1 : t === "link" ? e.isActive("link") : e.isActive(t), hc = "var(--zx-semantic-action-focus-ring)", bc = (e, t, o = () => typeof window < "u" ? window.prompt("Link URL", "https://") : null) => {
  var n, i, s, a;
  switch (t) {
    case "color": {
      const l = (i = (n = e == null ? void 0 : e.getAttributes) == null ? void 0 : n.call(e, "textStyle")) == null ? void 0 : i.color;
      return typeof l == "string" && l.length > 0 ? Oe(e, (r) => {
        var f;
        return (f = r.unsetColor) == null ? void 0 : f.call(r);
      }) : Oe(
        e,
        (r) => {
          var f;
          return (f = r.setColor) == null ? void 0 : f.call(r, hc);
        }
      );
    }
    case "bold":
      return Oe(e, (l) => {
        var r;
        return (r = l.toggleBold) == null ? void 0 : r.call(l);
      });
    case "italic":
      return Oe(e, (l) => {
        var r;
        return (r = l.toggleItalic) == null ? void 0 : r.call(l);
      });
    case "underline":
      return Oe(e, (l) => {
        var r;
        return (r = l.toggleUnderline) == null ? void 0 : r.call(l);
      });
    case "strike":
      return Oe(e, (l) => {
        var r;
        return (r = l.toggleStrike) == null ? void 0 : r.call(l);
      });
    case "code":
      return Oe(e, (l) => {
        var r;
        return (r = l.toggleCode) == null ? void 0 : r.call(l);
      });
    case "clear":
      return Oe(e, (l) => {
        var r;
        return (r = l.unsetAllMarks) == null ? void 0 : r.call(l);
      });
    case "link": {
      if ((s = e == null ? void 0 : e.isActive) != null && s.call(e, "link"))
        return Oe(
          e,
          (r) => {
            var f, c, u;
            return (u = (c = (f = r.extendMarkRange) == null ? void 0 : f.call(r, "link")) == null ? void 0 : c.unsetLink) == null ? void 0 : u.call(c);
          }
        );
      const l = (a = o()) == null ? void 0 : a.trim();
      return l ? Oe(
        e,
        (r) => {
          var f, c, u;
          return (u = (c = (f = r.extendMarkRange) == null ? void 0 : f.call(r, "link")) == null ? void 0 : c.setLink) == null ? void 0 : u.call(c, { href: l });
        }
      ) : !1;
    }
    default:
      return !1;
  }
}, yc = ["aria-label"], kc = ["aria-expanded", "aria-disabled"], wc = { class: "zx-inline-ai-selection-menu__turn-into-label" }, xc = ["aria-checked", "data-active", "aria-disabled", "onClick"], Tc = {
  class: "zx-inline-ai-selection-menu__turn-into-item-icon",
  "aria-hidden": "true"
}, Ic = { class: "zx-inline-ai-selection-menu__turn-into-item-label" }, Ac = {
  key: 1,
  class: "zx-inline-ai-selection-menu__check-spacer",
  "aria-hidden": "true"
}, Ec = {
  class: "zx-inline-ai-selection-menu__format",
  "data-testid": "inline-ai-format-grid",
  role: "toolbar",
  "aria-label": "Text formatting"
}, Sc = ["aria-label", "aria-pressed", "aria-disabled", "data-format", "onClick"], _c = { class: "zx-inline-ai-selection-menu__skills-header" }, Oc = { class: "zx-inline-ai-selection-menu__section-label" }, Rc = ["aria-label"], Nc = ["data-skill-id", "data-testid", "aria-disabled", "onClick"], Lc = ["data-reason", "title"], Bc = { class: "zx-inline-ai-selection-menu__notice-text" }, Cc = {
  key: 1,
  class: "zx-inline-ai-selection-menu__divider",
  "aria-hidden": "true"
}, zc = ["aria-disabled"], Mc = ["aria-disabled"], Dc = {
  class: "zx-ai-authoring-sr-only",
  "data-testid": "inline-ai-capability-reason",
  role: "status",
  "aria-live": "polite"
}, Fc = /* @__PURE__ */ Te({
  __name: "InlineAiSelectionMenu",
  props: {
    skills: {},
    editor: { default: null },
    disabled: { type: Boolean, default: !1 },
    capabilities: { default: null },
    autoFocusPrompt: { type: Boolean, default: !1 },
    notice: { default: null }
  },
  emits: ["skill-invoke", "edit-with-ai", "prompt-submit", "continue-review", "review-refine", "retain-selection", "prompt-draft"],
  setup(e, { emit: t }) {
    const o = t, n = J(!1), i = J(""), s = J(0), a = J(""), l = J(null);
    let r = null;
    const { messages: f, defaultSkills: c } = Kn(), u = S(() => e.skills ?? c.value), p = S(
      () => e.notice ? Ro(e.notice, f.value) : ""
    ), m = (ne, he) => {
      var ze;
      if (e.disabled)
        return { enabled: !1, reason: "authority-mismatch" };
      const oe = (ze = e.capabilities) == null ? void 0 : ze[ne];
      return oe || (he ? { enabled: !0 } : { enabled: !1, reason: "upstream-action-disabled" });
    }, y = S(() => m("format", !0)), M = S(() => m("startAi", !0)), _ = S(() => m("submit", !0)), T = S(() => m("continueReview", !1)), k = S(() => m("reviewRefine", !1)), g = S(
      () => e.capabilities !== null && (T.value.enabled || T.value.reason !== "no-open-task")
    ), V = S(
      () => e.capabilities !== null && (k.value.enabled || k.value.reason !== "no-open-task")
    ), U = S(() => ({
      editor: e.editor,
      revision: s.value
    })), x = S(() => pc(U.value.editor)), w = S(() => mc(U.value.editor)), { text: R } = cn({
      runtime: Ut(),
      bindingId: "textEditor.inlineEdit.open"
    }), X = fc, Z = dc, ie = () => {
      s.value += 1;
    }, ce = (ne) => {
      ne && (a.value = `authoring.capability.${ne}`);
    }, B = () => {
      r != null && (clearTimeout(r), r = null);
    }, C = () => {
      if (!y.value.enabled) {
        ce(y.value.reason);
        return;
      }
      B(), n.value = !0;
    }, N = () => {
      B(), r = setTimeout(() => {
        n.value = !1, r = null;
      }, 140);
    }, O = () => {
      B(), n.value = !1;
    };
    Q(
      () => e.editor,
      () => {
        s.value += 1, O();
      }
    ), Q(i, (ne) => {
      o("prompt-draft", ne);
    }), Q(
      () => e.notice,
      (ne) => {
        ne && (a.value = Ro(
          ne,
          f.value
        ));
      },
      { immediate: !0 }
    ), rt(() => {
      O();
    });
    const K = () => {
      if (!y.value.enabled) {
        ce(y.value.reason);
        return;
      }
      n.value ? O() : C();
    }, se = (ne) => {
      if (!y.value.enabled) {
        ce(y.value.reason);
        return;
      }
      vc(e.editor, ne), O(), ie();
    }, ge = (ne) => {
      if (!y.value.enabled) {
        ce(y.value.reason);
        return;
      }
      bc(e.editor, ne), ie();
    }, le = (ne) => gc(U.value.editor, ne), pe = (ne) => {
      if (!M.value.enabled) {
        ce(M.value.reason);
        return;
      }
      o("retain-selection"), o("skill-invoke", ne);
    }, be = () => {
      const ne = i.value.trim();
      if (!ne) {
        if (!M.value.enabled) {
          ce(M.value.reason);
          return;
        }
        o("edit-with-ai");
        return;
      }
      if (!_.value.enabled) {
        ce(_.value.reason);
        return;
      }
      o("prompt-submit", ne);
    }, ve = () => {
      if (!T.value.enabled) {
        ce(T.value.reason);
        return;
      }
      o("continue-review");
    }, de = () => {
      var he;
      const ne = i.value.trim();
      if (!ne) {
        ce("empty-prompt"), (he = l.value) == null || he.focus();
        return;
      }
      if (!k.value.enabled) {
        ce(k.value.reason);
        return;
      }
      o("review-refine", ne);
    }, _e = (ne) => {
      const he = ne.target;
      he != null && he.closest('input, textarea, [contenteditable="true"]') || ne.preventDefault();
    }, Ee = () => {
      o("retain-selection");
    }, ee = (ne) => ne ? void 0 : "true";
    return (ne, he) => (L(), F("div", {
      class: "zx-inline-ai-selection-menu",
      "data-testid": "inline-ai-selection-menu",
      "data-inline-ai-focus-root": "",
      role: "menu",
      "aria-label": v(f).surface.selectionMenuAria,
      onMousedown: _e
    }, [
      D("div", {
        class: "zx-inline-ai-selection-menu__turn-into",
        onMouseenter: C,
        onMouseleave: N
      }, [
        D("button", {
          type: "button",
          class: "zx-inline-ai-selection-menu__turn-into-trigger",
          "data-testid": "inline-ai-turn-into-trigger",
          "aria-haspopup": "menu",
          "aria-expanded": n.value,
          "aria-disabled": ee(y.value.enabled),
          onClick: K,
          onFocus: C
        }, [
          j(v(xe), {
            class: "zx-inline-ai-selection-menu__turn-into-icon",
            icon: "lucide:type",
            "aria-hidden": "true"
          }),
          D("span", wc, me(x.value), 1),
          j(v(xe), {
            class: "zx-inline-ai-selection-menu__chevron",
            icon: "lucide:chevron-right",
            "aria-hidden": "true"
          })
        ], 40, kc),
        n.value ? (L(), F("div", {
          key: 0,
          class: "zx-inline-ai-selection-menu__turn-into-panel",
          "data-testid": "inline-ai-turn-into-panel",
          role: "menu",
          "aria-label": "Turn into",
          onMouseenter: C,
          onMouseleave: N
        }, [
          (L(!0), F(Le, null, Pe(v(Z), (oe) => (L(), F("button", {
            key: oe.id,
            type: "button",
            class: "zx-inline-ai-selection-menu__turn-into-item",
            role: "menuitemradio",
            "aria-checked": w.value === oe.id,
            "data-active": w.value === oe.id ? "true" : "false",
            "aria-disabled": ee(y.value.enabled),
            onClick: (ze) => se(oe.id)
          }, [
            D("span", Tc, [
              j(v(xe), {
                icon: oe.icon
              }, null, 8, ["icon"])
            ]),
            D("span", Ic, me(oe.label), 1),
            w.value === oe.id ? (L(), $e(v(xe), {
              key: 0,
              class: "zx-inline-ai-selection-menu__check",
              icon: "lucide:check",
              "aria-hidden": "true"
            })) : (L(), F("span", Ac))
          ], 8, xc))), 128))
        ], 32)) : ae("", !0)
      ], 32),
      he[1] || (he[1] = D("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      D("div", Ec, [
        (L(!0), F(Le, null, Pe(v(X), (oe) => (L(), F("button", {
          key: oe.id,
          type: "button",
          class: q(["zx-inline-ai-selection-menu__format-btn", {
            "is-active": le(oe.id),
            "is-italic": oe.id === "italic",
            "is-underline": oe.id === "underline",
            "is-strike": oe.id === "strike"
          }]),
          "aria-label": oe.label,
          "aria-pressed": le(oe.id),
          "aria-disabled": ee(y.value.enabled),
          "data-format": oe.id,
          onClick: (ze) => ge(oe.id)
        }, me(oe.glyph), 11, Sc))), 128))
      ]),
      he[2] || (he[2] = D("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      D("div", _c, [
        D("span", Oc, me(v(f).surface.skills), 1),
        j(v(xe), {
          class: "zx-inline-ai-selection-menu__skills-icon",
          icon: "lucide:sliders-horizontal",
          "aria-hidden": "true",
          "data-testid": "inline-ai-skills-settings-icon"
        })
      ]),
      D("div", {
        class: "zx-inline-ai-selection-menu__skills",
        "data-testid": "inline-ai-skills-list",
        role: "group",
        "aria-label": v(f).surface.skillsListAria
      }, [
        (L(!0), F(Le, null, Pe(u.value, (oe) => (L(), F("button", {
          key: oe.skillId,
          type: "button",
          class: "zx-inline-ai-selection-menu__skill",
          role: "menuitem",
          "data-skill-id": oe.skillId,
          "data-testid": `inline-ai-skill-${oe.skillId}`,
          "aria-disabled": ee(M.value.enabled),
          onClick: (ze) => pe(oe)
        }, me(oe.label), 9, Nc))), 128))
      ], 8, Rc),
      e.notice ? (L(), F("p", {
        key: 0,
        class: "zx-inline-ai-selection-menu__notice",
        "data-testid": "inline-ai-selection-notice",
        "data-reason": e.notice.reason,
        title: e.notice.detail,
        role: "note"
      }, [
        j(v(xe), {
          class: "zx-inline-ai-selection-menu__notice-icon",
          icon: "lucide:info",
          "aria-hidden": "true"
        }),
        D("span", Bc, me(p.value), 1)
      ], 8, Lc)) : ae("", !0),
      g.value || V.value ? (L(), F("div", Cc)) : ae("", !0),
      g.value ? (L(), F("button", {
        key: 2,
        type: "button",
        class: "zx-inline-ai-selection-menu__skill",
        "data-testid": "inline-ai-continue-review",
        "aria-disabled": ee(T.value.enabled),
        onClick: ve
      }, me(v(f).surface.continueReview), 9, zc)) : ae("", !0),
      V.value ? (L(), F("button", {
        key: 3,
        type: "button",
        class: "zx-inline-ai-selection-menu__skill",
        "data-testid": "inline-ai-review-refine",
        "aria-disabled": ee(k.value.enabled),
        onClick: de
      }, me(v(f).surface.reviewRefine), 9, Mc)) : ae("", !0),
      he[3] || (he[3] = D("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      j(Ln, {
        ref_key: "promptComposerRef",
        ref: l,
        modelValue: i.value,
        "onUpdate:modelValue": he[0] || (he[0] = (oe) => i.value = oe),
        variant: "selection",
        "activation-key": e.autoFocusPrompt ? !0 : null,
        "submit-enabled": _.value.enabled,
        shortcut: v(R),
        "input-aria-disabled": ee(
          i.value.trim() ? _.value.enabled : M.value.enabled || _.value.enabled || _.value.reason === "empty-prompt"
        ),
        onSubmit: be,
        onFocusIntent: Ee
      }, null, 8, ["modelValue", "activation-key", "submit-enabled", "shortcut", "input-aria-disabled"]),
      D("div", Dc, me(a.value), 1)
    ], 40, yc));
  }
}), Pc = (e = globalThis.matchMedia) => {
  var t;
  try {
    return ((t = e == null ? void 0 : e("(prefers-reduced-motion: reduce)")) == null ? void 0 : t.matches) === !0;
  } catch {
    return !1;
  }
}, wi = (e) => {
  Pc() && (e.style.setProperty("transition", "none"), e.style.setProperty("animation", "none"), e.dataset.inlineAiReducedMotion = "true");
}, Vc = (e) => {
  const t = e.elements.floating;
  t.style.setProperty(
    "--inline-ai-available-width",
    `${Math.max(0, Math.floor(e.availableWidth))}px`
  ), t.style.setProperty(
    "--inline-ai-available-height",
    `${Math.max(0, Math.floor(e.availableHeight))}px`
  ), t.dataset.inlineAiViewportSource = globalThis.visualViewport ? "visualViewport" : "layoutViewport", wi(t);
}, xi = Object.freeze({
  fallbackPlacements: ["top-start"]
}), Ti = Object.freeze({
  padding: dn,
  // A retained target can move outside the viewport while its task remains
  // open. For bottom/top placement, crossAxis is the vertical axis: clamp the
  // recovery surface into the visible viewport instead of following the
  // off-screen document coordinate.
  crossAxis: !0
}), Ii = Object.freeze({
  padding: dn,
  apply: Vc
}), jc = (e) => ({
  left: e.left,
  top: e.top,
  width: e.width,
  height: e.height,
  right: e.left + e.width,
  bottom: e.top + e.height,
  x: e.left,
  y: e.top
}), Ai = (e) => ({
  getBoundingClientRect: () => {
    const t = e();
    if (!t)
      return new DOMRect(0, 0, 0, 0);
    const o = jc(t);
    return {
      ...o,
      toJSON: () => o
    };
  }
}), $c = () => [
  Zi(dn),
  Ko(xi),
  Xi(Ti),
  Yi(Ii)
], Hc = async (e) => {
  const t = e.getAnchor ?? (() => e.anchor);
  if (!t()) return {};
  const n = Ai(t), { x: i, y: s } = await Uo(n, e.floating, {
    strategy: "fixed",
    placement: "bottom-start",
    middleware: $c()
  });
  wi(e.floating);
  const a = globalThis.visualViewport;
  return e.floating.dataset.inlineAiViewportSource = a ? "visualViewport" : "layoutViewport", {
    position: "fixed",
    // Keep layout coordinates stable and move the overlay on the compositor.
    // Response shells can grow from compact Prompt chrome to a rich review;
    // changing left/top for every measured size would create avoidable CLS.
    left: "0px",
    top: "0px",
    transform: `translate3d(${Math.round(i)}px, ${Math.round(s)}px, 0)`
  };
}, Uc = (e) => {
  var u, p;
  const t = Ai(e.getAnchor);
  let o;
  const n = new Promise((m) => {
    o = m;
  });
  let i = !1;
  const s = () => Hc({
    getAnchor: e.getAnchor,
    floating: e.floating
  }).then((m) => {
    Object.keys(m).length > 0 && e.onStyle(m), i || (i = !0, o());
  });
  s();
  const a = Ji(t, e.floating, s, {
    ancestorScroll: !0,
    ancestorResize: !0,
    elementResize: !0,
    layoutShift: !0
  }), r = (e.windowLike ?? globalThis).visualViewport, f = () => {
    s();
  };
  (u = r == null ? void 0 : r.addEventListener) == null || u.call(r, "resize", f), (p = r == null ? void 0 : r.addEventListener) == null || p.call(r, "scroll", f), typeof window < "u" && window.addEventListener("resize", f);
  const c = (() => {
    var m, y;
    a(), (m = r == null ? void 0 : r.removeEventListener) == null || m.call(r, "resize", f), (y = r == null ? void 0 : r.removeEventListener) == null || y.call(r, "scroll", f), typeof window < "u" && window.removeEventListener("resize", f), i || (i = !0, o());
  });
  return Object.defineProperty(c, "ready", {
    value: n,
    enumerable: !0
  }), c;
}, Kc = (e) => ({
  position: "fixed",
  left: "0px",
  top: "0px",
  transform: `translate3d(${Math.round(e.left)}px, ${Math.round(
    e.top + e.height + dn
  )}px, 0)`
}), qc = (e) => {
  var o;
  if (!e || typeof e != "object") return !1;
  const t = (o = e.toJSON) == null ? void 0 : o.call(e);
  return (t == null ? void 0 : t.type) === "nodeRange";
}, Lo = /* @__PURE__ */ new Set([
  "image",
  "iframe",
  "video",
  "imageGroup",
  "codeBlock",
  "horizontalRule"
]), Gc = Object.freeze({
  strategy: "fixed",
  placement: "bottom-start",
  offset: 8,
  flip: xi,
  shift: Ti,
  size: Ii
}), Wc = (e = {}) => Object.freeze({
  ...e,
  ...Gc
}), Jc = (e) => Number.isFinite(e.top) && Number.isFinite(e.left) && e.height > 0 && // Allow zero-width caret rects at line ends; reject empty/invalid boxes.
(e.width > 0 || e.height >= 1), Zc = (e) => {
  const t = Array.from(e).filter(Jc);
  return t.length === 0 ? null : t[t.length - 1];
}, Bo = (e) => {
  const t = e.clientRects ? Zc(e.clientRects) : null;
  if (t)
    return new DOMRect(t.right, t.top, 0, Math.max(1, t.height));
  const o = Math.max(e.from, e.to), n = o > Math.min(e.from, e.to) ? o - 1 : o, i = e.coordsAtPos(n), s = i.right, a = i.top, l = Math.max(1, i.bottom - i.top);
  return new DOMRect(s, a, 0, l);
}, Xc = (e) => {
  if (typeof window > "u" || typeof document > "u")
    return [];
  const t = window.getSelection();
  if (!t || t.isCollapsed || t.rangeCount === 0)
    return [];
  const o = t.getRangeAt(0), n = e.dom;
  return n && !n.contains(o.commonAncestorContainer) && o.commonAncestorContainer !== n ? [] : Array.from(o.getClientRects());
}, Yc = (e, t) => {
  let o, n;
  return () => {
    var i;
    try {
      if (!e || e.isDestroyed) return null;
      const s = e.view;
      if (!((i = s == null ? void 0 : s.state) != null && i.selection) || typeof s.coordsAtPos != "function")
        return null;
      const a = s.coordsAtPos.bind(s), l = s.state.selection, r = (t == null ? void 0 : t()) ?? (l.from === l.to ? null : { from: l.from, to: l.to });
      if (!r || r.from === r.to) return null;
      const f = `${r.from}:${r.to}`;
      f !== o && (o = f, n = void 0);
      const c = Bo({
        from: r.from,
        to: r.to,
        coordsAtPos: a
      }), p = l.from === r.from && l.to === r.to ? Xc(s) : [], m = p.length > 0 ? Bo({
        from: r.from,
        to: r.to,
        coordsAtPos: a,
        clientRects: p
      }) : null;
      m && (n = {
        x: m.x - c.x,
        y: m.y - c.y,
        height: m.height - c.height
      });
      const y = m ?? (n ? new DOMRect(
        c.x + n.x,
        c.y + n.y,
        0,
        Math.max(1, c.height + n.height)
      ) : c);
      return {
        getBoundingClientRect: () => y,
        getClientRects: () => [y]
      };
    } catch {
      return null;
    }
  };
}, Qc = ({
  state: e
}) => {
  var n, i;
  const { selection: t } = e;
  if (t.empty || qc(t))
    return !1;
  if (t instanceof zn) {
    const s = t.node;
    if (s && Lo.has(s.type.name))
      return !1;
  }
  const o = (i = (n = t.$from) == null ? void 0 : n.node) == null ? void 0 : i.call(n, t.$from.depth);
  return !(o && Lo.has(o.type.name));
}, Ei = "inlineAiBubbleMenu", eu = 140, Co = (e) => e.suppress || e.pointerSelecting && !e.pointerSelectionSettled ? !1 : (e.shouldShow ?? Qc)(e.payload), tu = (e) => {
  var n, i;
  const t = (n = e.editor) == null ? void 0 : n.view;
  if (!((i = t == null ? void 0 : t.state) != null && i.tr) || typeof t.dispatch != "function") return;
  const o = e.pluginKey ?? Ei;
  t.dispatch(t.state.tr.setMeta(o, e.visible ? "show" : "hide"));
}, Si = /* @__PURE__ */ new WeakMap(), pf = () => {
  const e = Ne(
    null
  ), t = S(
    () => {
      var n;
      return ((n = e.value) == null ? void 0 : n.stage.value) ?? null;
    }
  ), o = {
    stage: t,
    active: S(() => t.value !== null),
    dismiss: () => {
      const n = e.value;
      return (n == null ? void 0 : n.stage.value) == null ? !1 : (n.dismiss(), !0);
    }
  };
  return Si.set(o, { participant: e }), Object.freeze(o);
}, nu = (e, t) => {
  const o = Si.get(e);
  if (!o)
    throw new TypeError(
      "[text-editor/authoring-ui] Invalid Inline AI Bubble Escape channel"
    );
  if (o.participant.value && o.participant.value !== t)
    throw new TypeError(
      "[text-editor/authoring-ui] Duplicate Inline AI Bubble Escape owner"
    );
  return o.participant.value = t, () => {
    o.participant.value === t && (o.participant.value = null);
  };
}, ou = Object.freeze([
  "multi-block-selection",
  "explicit-line-break",
  "unsupported-node",
  "collapsed-selection",
  "task-open",
  "capture-failed",
  "unavailable"
]), zo = (e) => typeof e == "string" && ou.includes(
  e
), iu = (e) => {
  if (typeof e == "string") {
    const t = e.trim();
    return zo(t) ? { reason: t } : { reason: "unavailable", ...t ? { detail: t } : {} };
  }
  if (e && typeof e == "object") {
    const { reason: t, detail: o } = e, n = zo(t), i = typeof o == "string" && o.trim() ? o.trim() : !n && typeof t == "string" && t.trim() ? t.trim() : void 0;
    return {
      reason: n ? t : "unavailable",
      ...i ? { detail: i } : {}
    };
  }
  return { reason: "unavailable" };
}, su = (e) => {
  let t = null;
  return {
    target: e.target,
    get outcome() {
      return t;
    },
    accept() {
      var o;
      return t !== null ? !1 : (t = "accepted", (o = e.onAccept) == null || o.call(e), !0);
    },
    reject(o) {
      var n;
      return t !== null ? !1 : (t = "rejected", ((n = e.onReject) == null ? void 0 : n.call(e, iu(o))) ?? !1);
    }
  };
}, ut = new Ho("inlineAiRetainedSelection"), ru = "zx-inline-ai-retained-selection", qn = (e, t, o) => {
  const n = Math.max(0, Math.min(t, o, e)), i = Math.max(0, Math.min(Math.max(t, o), e));
  return i <= n ? null : { from: n, to: i };
}, au = (e, t) => {
  if (!t) return vt.empty;
  const o = qn(e.content.size, t.from, t.to);
  return o ? vt.create(e, [
    Ys.inline(o.from, o.to, {
      class: ru
    })
  ]) : vt.empty;
}, lu = () => new $o({
  key: ut,
  state: {
    init: () => vt.empty,
    apply: (e, t, o, n) => {
      const i = e.getMeta(
        ut
      );
      return (i == null ? void 0 : i.kind) === "clear" ? vt.empty : (i == null ? void 0 : i.kind) === "set" ? au(n.doc, {
        from: i.from,
        to: i.to
      }) : !e.docChanged || t === vt.empty ? t : t.map(e.mapping, e.doc);
    }
  },
  props: {
    decorations(e) {
      return ut.getState(e);
    }
  }
}), cu = (e) => {
  const t = e.state;
  return ut.getState(t) !== void 0;
}, _i = (e) => !e || e.isDestroyed ? !1 : cu(e) ? !0 : typeof e.registerPlugin != "function" ? !1 : (e.registerPlugin(lu()), !0), Bn = (e, t) => {
  if (!e || e.isDestroyed || !e.view || !_i(e)) return !1;
  const { state: o, view: n } = e;
  let i;
  if (!t || t.from === t.to)
    i = o.tr.setMeta(ut, {
      kind: "clear"
    });
  else {
    const s = qn(o.doc.content.size, t.from, t.to);
    s ? i = o.tr.setMeta(ut, {
      kind: "set",
      from: s.from,
      to: s.to
    }) : i = o.tr.setMeta(ut, {
      kind: "clear"
    });
  }
  return n.dispatch(i), !0;
}, Mo = (e) => Bn(e, null), uu = (e) => {
  if (!(e != null && e.state)) return null;
  const t = ut.getState(
    e.state
  );
  if (!t || t === vt.empty) return null;
  let o = Number.POSITIVE_INFINITY, n = Number.NEGATIVE_INFINITY;
  for (const i of t.find())
    o = Math.min(o, i.from), n = Math.max(n, i.to);
  return !Number.isFinite(o) || !Number.isFinite(n) || n <= o ? null : qn(e.state.doc.content.size, o, n);
}, du = Object.freeze({ openCount: 0, active: null }), Do = (e) => ({
  anchor: e.anchor ?? e.from,
  head: e.head ?? e.to,
  from: e.from,
  to: e.to
}), Oi = (e) => ({
  anchor: e.anchor ?? e.from,
  head: e.head ?? e.to,
  from: e.from,
  to: e.to
}), fu = (e, t) => e.from === t.from && e.to === t.to, pu = (e) => e.active !== null && e.active.phase !== "dismissed", mu = (e, t) => {
  var o;
  switch (t.kind) {
    case "end":
      return e.active ? { openCount: e.openCount, active: null } : e;
    case "restore":
      return e.active || t.session.openId !== e.openCount ? e : {
        openCount: e.openCount,
        active: { ...t.session, phase: "active", owned: !1 }
      };
    case "dismiss": {
      if (!e.active || e.active.phase === "dismissed" && !t.range) return e;
      const n = t.range ? Do(t.range) : Oi(e.active);
      return {
        openCount: e.openCount,
        active: {
          ...e.active,
          ...n,
          phase: "dismissed",
          owned: !1
        }
      };
    }
    case "chrome-focus":
      return !e.active || e.active.phase === "dismissed" || e.active.owned ? e : {
        openCount: e.openCount,
        active: { ...e.active, owned: !0 }
      };
    case "selection-sync": {
      if ((o = e.active) != null && o.owned && e.active.phase !== "dismissed")
        return e;
      const { eligible: n, range: i } = t;
      if (!n || !i || i.from === i.to)
        return e.active ? { openCount: e.openCount, active: null } : e;
      if (e.active && fu(e.active, i)) return e;
      const s = e.openCount + 1, a = Do(i);
      return {
        openCount: s,
        active: {
          openId: s,
          ...a,
          phase: "active",
          owned: !1
        }
      };
    }
    default:
      return e;
  }
}, vu = (e) => e.active ? { from: e.active.from, to: e.active.to } : null, gu = (e) => e.active ? Oi(e.active) : null, hu = (e) => {
  var t;
  return ((t = e.active) == null ? void 0 : t.openId) ?? e.openCount;
}, mf = /* @__PURE__ */ Te({
  name: "InlineAiBubbleMenu",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    skills: {
      type: Array,
      default: void 0
    },
    disabled: {
      type: Boolean,
      default: !1
    },
    capabilities: {
      type: Object,
      default: null
    },
    /**
     * When true (e.g. product shell brewing/reviewing), hide the selection menu
     * so it does not stack under InlineAiSurface.
     */
    suppress: {
      type: Boolean,
      default: !1
    },
    /**
     * Optional per-editor state/action bridge for the catalog-owned Escape
     * adapter. The Bubble itself never registers a key listener.
     */
    escapeChannel: {
      type: Object,
      default: null
    },
    options: {
      type: Object,
      default: () => ({})
    },
    shouldShow: {
      type: Function,
      default: null
    },
    pluginKey: {
      type: [String, Object],
      default: Ei
    }
  },
  emits: {
    /**
     * `handoff` is the Bubble's receipt: hosts call `accept()` once their own
     * chrome takes over, or `reject(reason)` when the open fails closed so the
     * Bubble restores itself on the same selection with an inline notice.
     */
    "skill-invoke": (e, t, o) => !0,
    "edit-with-ai": (e, t) => !0,
    "prompt-submit": (e, t, o) => !0,
    "continue-review": () => !0,
    "review-refine": (e) => !0,
    "prompt-draft": (e) => !0
  },
  setup(e, {
    emit: t
  }) {
    const o = De("inline-ai-bubble-menu"), {
      defaultSkills: n
    } = Kn(), i = S(() => e.skills ?? n.value), s = $t(), a = yt("editor", null), l = S(() => e.editor ?? (a == null ? void 0 : a.value) ?? null), {
      binding: r
    } = bt(e.themeOwner), f = S(() => Wc(e.options)), c = J(du), u = S(() => vu(c.value)), p = S(() => gu(c.value)), m = S(() => pu(c.value)), y = Mn(m), M = S(() => {
      var E;
      return m.value ? "bubble" : ((E = c.value.active) == null ? void 0 : E.phase) === "dismissed" ? "selection" : null;
    }), _ = J(!1);
    let T = null, k = null, g = !1;
    const V = J(null), U = S(() => {
      const E = V.value, I = c.value.active;
      return !E || !I || I.openId !== E.openId ? null : E;
    }), x = J(!1), w = J(!1);
    let R;
    const X = (E) => {
      c.value = mu(c.value, E);
    };
    Q(
      () => {
        var E;
        return ((E = c.value.active) == null ? void 0 : E.owned) === !0 && u.value;
      },
      (E) => {
        var H;
        const I = l.value;
        E && ((H = e.capabilities) == null ? void 0 : H.startAi.enabled) !== !1 && (_.value = Bn(I, E));
      },
      // Pointer focus removes the browser's native selection immediately. Paint
      // the bookmarked range before that focus transfer can invalidate the live
      // selection capability used by the guard above.
      {
        flush: "sync"
      }
    );
    const Z = (E = l.value) => {
      _.value && (Mo(E), _.value = !1);
    }, ie = () => {
      if (typeof document > "u") return;
      const E = document.getSelection();
      !E || E.rangeCount === 0 || E.collapseToEnd();
    }, ce = () => {
      const E = l.value;
      if (!E) {
        X({
          kind: "selection-sync",
          eligible: !1,
          range: null
        });
        return;
      }
      const I = E.state, H = Co({
        payload: {
          editor: E,
          state: I
        },
        suppress: e.suppress,
        pointerSelecting: x.value,
        pointerSelectionSettled: w.value,
        shouldShow: e.shouldShow
      }), Y = I == null ? void 0 : I.selection;
      X({
        kind: "selection-sync",
        eligible: H,
        range: Y ? {
          anchor: Y.anchor,
          from: Y.from,
          head: Y.head,
          to: Y.to
        } : null
      });
    }, B = (E) => {
      var Y;
      const I = Co({
        payload: E,
        suppress: e.suppress,
        pointerSelecting: x.value,
        pointerSelectionSettled: w.value,
        shouldShow: e.shouldShow
      }), H = (Y = E.state) == null ? void 0 : Y.selection;
      return X({
        kind: "selection-sync",
        eligible: I,
        range: H ? {
          anchor: H.anchor,
          from: H.from,
          head: H.head,
          to: H.to
        } : null
      }), m.value;
    }, C = (E) => {
      tu({
        editor: l.value,
        pluginKey: e.pluginKey,
        visible: E
      });
    }, N = () => {
      R !== void 0 && (clearTimeout(R), R = void 0);
    }, O = () => {
      N(), x.value && (R = setTimeout(() => {
        R = void 0, x.value && (w.value = !0, ce(), C(m.value));
      }, eu));
    }, K = () => {
      x.value && (w.value = !1), ce(), x.value && (C(m.value), O());
    }, se = (E) => {
      var H, Y;
      const I = m.value;
      if (X({
        kind: "end"
      }), C(!1), E === "handoff") {
        _.value = !1;
        return;
      }
      if (Z(), I) {
        const fe = (H = l.value) == null ? void 0 : H.commands;
        (Y = fe == null ? void 0 : fe.focus) == null || Y.call(fe);
      }
    }, ge = (E, I) => {
      var Y, fe, Ie, Ce, d, h, A;
      let H = !1;
      if ((Y = E == null ? void 0 : E.state) != null && Y.doc && ((fe = E == null ? void 0 : E.state) != null && fe.tr) && (E != null && E.view))
        try {
          const P = ct.create(E.state.doc, I.anchor, I.head);
          E.view.dispatch(E.state.tr.setSelection(P)), H = !0;
        } catch {
        }
      H || (Ce = (Ie = E == null ? void 0 : E.commands) == null ? void 0 : Ie.setTextSelection) == null || Ce.call(Ie, I.anchor === I.head ? I.head : {
        from: I.from,
        to: I.to
      }), typeof ((d = E == null ? void 0 : E.view) == null ? void 0 : d.focus) == "function" ? E.view.focus() : (A = (h = E == null ? void 0 : E.commands) == null ? void 0 : h.focus) == null || A.call(h);
    }, le = () => {
      if (!m.value) return;
      const E = bn(l.value), I = p.value, H = uu(E), Y = I && H ? {
        anchor: I.anchor > I.head ? H.to : H.from,
        head: I.anchor > I.head ? H.from : H.to,
        from: H.from,
        to: H.to
      } : I;
      X({
        kind: "dismiss",
        range: Y ?? void 0
      }), C(!1), Y && ge(E, Y), Z();
    }, pe = () => {
      var H, Y, fe;
      if (M.value !== "selection") return;
      const E = bn(l.value), I = p.value;
      X({
        kind: "end"
      }), C(!1), Z(), I ? (ge(E, {
        anchor: I.head,
        head: I.head,
        from: I.head,
        to: I.head
      }), ie()) : typeof ((H = E == null ? void 0 : E.view) == null ? void 0 : H.focus) == "function" ? E.view.focus() : (fe = (Y = E == null ? void 0 : E.commands) == null ? void 0 : Y.focus) == null || fe.call(Y);
    }, be = {
      stage: M,
      dismiss: () => {
        M.value === "bubble" ? le() : pe();
      }
    };
    let ve;
    Q(() => e.escapeChannel, (E) => {
      ve == null || ve(), ve = E ? nu(E, be) : void 0;
    }, {
      immediate: !0
    }), Q(() => e.suppress, (E) => {
      if (E) {
        N(), w.value = !1, T = null, k = null, V.value = null, X({
          kind: "end"
        }), C(!1), _.value = !1;
        return;
      }
      ce(), C(m.value), Z();
    });
    const de = (E) => {
      var Y, fe;
      if (!m.value) return;
      const I = E.target;
      if (!I || I.closest(".zx-inline-ai-bubble-menu")) return;
      const H = (fe = (Y = l.value) == null ? void 0 : Y.view) == null ? void 0 : fe.dom;
      H != null && H.contains(I) || se("dismiss");
    }, _e = () => {
      var E;
      m.value && ((E = c.value.active) != null && E.owned) && se("dismiss");
    }, Ee = (E) => {
      var H, Y;
      if (E.button !== 0 || (H = c.value.active) != null && H.owned) return;
      const I = E.target;
      (Y = I == null ? void 0 : I.closest) != null && Y.call(I, ".zx-inline-ai-bubble-menu") || (x.value = !0, w.value = !1, N(), c.value.active && (X({
        kind: "end"
      }), C(!1)));
    }, ee = () => {
      x.value && (N(), x.value = !1, w.value = !1, ce(), C(m.value));
    }, ne = (E) => {
      var H;
      const I = (H = E == null ? void 0 : E.view) == null ? void 0 : H.dom;
      I == null || I.addEventListener("pointerdown", Ee);
    }, he = (E) => {
      var H;
      const I = (H = E == null ? void 0 : E.view) == null ? void 0 : H.dom;
      I == null || I.removeEventListener("pointerdown", Ee);
    }, oe = (E) => {
      var H, Y, fe, Ie;
      const I = E;
      I != null && I.state && (I != null && I.view) && _i(I), (H = I == null ? void 0 : I.off) == null || H.call(I, "focus", _e), (Y = I == null ? void 0 : I.on) == null || Y.call(I, "focus", _e), (fe = I == null ? void 0 : I.off) == null || fe.call(I, "selectionUpdate", K), (Ie = I == null ? void 0 : I.on) == null || Ie.call(I, "selectionUpdate", K), ne(E);
    }, ze = (E) => {
      var H, Y;
      const I = E;
      (H = I == null ? void 0 : I.off) == null || H.call(I, "focus", _e), (Y = I == null ? void 0 : I.off) == null || Y.call(I, "selectionUpdate", K), he(E);
    };
    Q(l, (E, I) => {
      I && I !== E && Z(I), ze(I ?? null), oe(E);
    }, {
      immediate: !0
    });
    const Fe = () => {
      In({
        kind: "scroll"
      }), In({
        kind: "visualViewport"
      }), In({
        kind: "geometry"
      });
    }, Je = () => {
      var I;
      const E = (I = r.value) == null ? void 0 : I.target.querySelector(".zx-inline-ai-bubble-menu");
      E instanceof HTMLElement && (E.dataset.inlineAiViewportSource = window.visualViewport ? "visualViewport" : "layoutViewport");
    };
    Ht(() => {
      var E, I;
      Je(), document.addEventListener("pointerdown", de, !0), window.addEventListener("pointerup", ee, !0), window.addEventListener("pointercancel", ee, !0), window.addEventListener("scroll", Fe, !0), (E = window.visualViewport) == null || E.addEventListener("resize", Fe), (I = window.visualViewport) == null || I.addEventListener("scroll", Fe), oe(l.value);
    }), rt(() => {
      var E, I;
      N(), ve == null || ve(), ve = void 0, document.removeEventListener("pointerdown", de, !0), window.removeEventListener("pointerup", ee, !0), window.removeEventListener("pointercancel", ee, !0), window.removeEventListener("scroll", Fe, !0), (E = window.visualViewport) == null || E.removeEventListener("resize", Fe), (I = window.visualViewport) == null || I.removeEventListener("scroll", Fe), ze(l.value), Z();
    });
    const Qe = (E) => {
      if (T !== E) return null;
      const I = k;
      return T = null, k = null, I;
    }, W = (E, I) => {
      var Ce;
      const H = Qe(E);
      if (!H) return !1;
      const Y = bn(l.value);
      Mo(Y), _.value = !1;
      const fe = c.value.active;
      if (fe && fe.openId !== H.openId) return !1;
      fe && (g = !0, X({
        kind: "end"
      }));
      const Ie = (Ce = Y == null ? void 0 : Y.state) == null ? void 0 : Ce.selection;
      return !Ie || Ie.from !== H.from || Ie.to !== H.to || (X({
        kind: "restore",
        session: H
      }), !m.value) ? (C(!1), !1) : (V.value = {
        ...I,
        openId: H.openId
      }, C(!0), !0);
    }, ye = (E) => {
      const I = u.value, H = c.value.active, Y = l.value;
      I && Bn(Y, I), V.value = null, g = !1, T = null, k = null;
      const fe = su({
        target: I,
        onAccept: () => {
          Qe(fe);
        },
        onReject: (Ce) => W(fe, Ce)
      });
      T = fe, k = H;
      const Ie = E(I, fe);
      return g ? (g = !1, Ie) : (_.value = !1, se("handoff"), Ie);
    }, Re = (E) => {
      ye((I, H) => t("skill-invoke", E, I, H));
    }, Ge = () => {
      ye((E, I) => t("edit-with-ai", E, I));
    }, tt = (E) => {
      ye((I, H) => t("prompt-submit", E, I, H));
    }, He = () => {
      X({
        kind: "chrome-focus"
      });
    };
    return () => {
      const E = l.value, I = r.value;
      if (!E || !I) return null;
      const H = Object.fromEntries(Object.entries(s).filter(([d]) => d !== "class" && d !== "style")), Y = Yc(E, () => u.value), fe = () => {
        t("continue-review");
      }, Ie = (d) => {
        se("handoff"), t("review-refine", d);
      }, Ce = (d) => {
        t("prompt-draft", d);
      };
      return j(ei, st({
        editor: E,
        pluginKey: e.pluginKey,
        shouldShow: B,
        options: f.value,
        getReferencedVirtualElement: Y,
        appendTo: () => I.target,
        class: [o.b(), "zx-inline-ai-bubble-menu", s.class],
        style: {
          zIndex: y.value
        }
      }, H), {
        default: () => [j(Fc, {
          key: hu(c.value),
          editor: E,
          skills: i.value,
          disabled: e.disabled,
          capabilities: e.capabilities,
          autoFocusPrompt: !1,
          notice: U.value,
          "onSkill-invoke": Re,
          "onEdit-with-ai": Ge,
          "onPrompt-submit": tt,
          "onContinue-review": fe,
          "onReview-refine": Ie,
          "onRetain-selection": He,
          "onPrompt-draft": Ce
        }, null)]
      });
    };
  }
}), vf = /* @__PURE__ */ Te({
  name: "TextEditorFloatingToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    },
    options: {
      type: Object,
      default: () => ({})
    }
  },
  setup(e) {
    const t = De("text-editor-floating-menu"), o = $t(), n = yt("editor", null), i = S(() => e.editor ?? (n == null ? void 0 : n.value) ?? null), {
      binding: s
    } = bt(e.themeOwner);
    return () => {
      const a = i.value, l = s.value;
      if (!a || !l)
        return null;
      const r = Object.fromEntries(Object.entries(o).filter(([f]) => f !== "class" && f !== "style"));
      return j(Xs, st({
        editor: a,
        appendTo: () => l.target,
        class: [t.b(), o.class]
      }, e.options, r), {
        default: () => [j(mi, {
          themeOwner: e.themeOwner,
          editor: a,
          surface: "floating",
          contributions: e.contributions,
          includeDefaultContribution: e.includeDefaultContribution,
          style: o.style
        }, null)]
      });
    };
  }
}), bu = ["value"], yu = ["value"], ku = ["value"], wu = ["value"], gf = /* @__PURE__ */ Te({
  name: "ZxTextEditorFontFamilySelector",
  __name: "font-family-selector",
  props: {
    fontSizes: { default: () => [...qs] },
    fontFamilies: { default: () => [...Ks] }
  },
  setup(e) {
    const t = De("text-editor-font-selector"), o = yt("editor"), n = S(() => o != null && o.value && o.value.getAttributes("textStyle").fontSize || ""), i = S(() => o != null && o.value && o.value.getAttributes("textStyle").fontFamily || ""), s = (r, ...f) => {
      var k, g, V, U;
      if (!(o != null && o.value)) return !1;
      const c = (g = (k = o.value).chain) == null ? void 0 : g.call(k), u = ((V = c == null ? void 0 : c.focus) == null ? void 0 : V.call(c)) ?? c, p = u, m = p == null ? void 0 : p[r];
      if (typeof m == "function") {
        const x = m.apply(u, f);
        return ((U = x == null ? void 0 : x.run) == null ? void 0 : U.call(x)) ?? !1;
      }
      const y = o.value.commands, M = y.focus;
      typeof M == "function" && M.call(y);
      const _ = y[r];
      if (typeof _ != "function")
        return !1;
      const T = _.apply(y, f);
      return typeof T == "boolean" ? T : !0;
    }, a = (r) => {
      const f = r.target.value;
      o != null && o.value && (f ? s("setFontSize", f) : s("unsetFontSize"));
    }, l = (r) => {
      const f = r.target.value;
      o != null && o.value && (f ? s("setFontFamily", f) : s("unsetFontFamily"));
    };
    return (r, f) => (L(), F("div", {
      class: q(v(t).b())
    }, [
      D("select", {
        class: q(v(t).e("size-select")),
        value: n.value,
        onChange: a
      }, [
        f[0] || (f[0] = D("option", { value: "" }, "默认", -1)),
        (L(!0), F(Le, null, Pe(e.fontSizes, (c) => (L(), F("option", {
          key: c,
          value: c
        }, me(c), 9, yu))), 128))
      ], 42, bu),
      D("select", {
        class: q(v(t).e("family-select")),
        value: i.value,
        onChange: l
      }, [
        f[1] || (f[1] = D("option", { value: "" }, "默认字体", -1)),
        (L(!0), F(Le, null, Pe(e.fontFamilies, (c) => (L(), F("option", {
          key: c.value,
          value: c.value
        }, me(c.label), 9, wu))), 128))
      ], 42, ku)
    ], 2));
  }
}), hf = /* @__PURE__ */ Te({
  name: "ZxTextEditorFloatingComments",
  __name: "floating-comments",
  props: {
    editor: {},
    threads: {},
    comments: {},
    activeAnnotationId: {},
    activeCommentId: {},
    currentUser: {},
    readonly: { type: Boolean }
  },
  emits: ["activate", "create", "edit", "delete", "resolve", "reply"],
  setup(e) {
    const t = De("text-editor-floating-comments");
    return (o, n) => (L(), F("div", {
      class: q(v(t).b())
    }, [
      Ve(o.$slots, "default", {}, () => [
        D("div", {
          class: q(v(t).e("placeholder"))
        }, " FloatingComments 组件需要由应用层提供实现 ", 2)
      ])
    ], 2));
  }
}), xu = ["value", "placeholder", "disabled", "onKeydown"], bf = /* @__PURE__ */ Te({
  name: "ZxTextEditorCommentEditor",
  __name: "comment-editor",
  props: {
    content: { default: "" },
    editable: { type: Boolean, default: !0 },
    placeholder: { default: "输入评论..." },
    showToolbar: { type: Boolean },
    autofocus: { type: Boolean }
  },
  emits: ["submit", "cancel", "update:content"],
  setup(e, { emit: t }) {
    const o = De("text-editor-comment-editor"), n = t, i = (l) => {
      const r = l.target.value;
      n("update:content", r);
    }, s = () => {
      n("submit", e.content);
    }, a = () => {
      n("cancel");
    };
    return (l, r) => (L(), F("div", {
      class: q(v(o).b())
    }, [
      Ve(l.$slots, "default", {}, () => [
        D("textarea", {
          class: q(v(o).e("textarea")),
          value: e.content,
          placeholder: e.placeholder,
          disabled: !e.editable,
          onInput: i,
          onKeydown: [
            so(Ke(s, ["ctrl"]), ["enter"]),
            so(a, ["escape"])
          ]
        }, null, 42, xu),
        D("div", {
          class: q(v(o).e("actions"))
        }, [
          D("button", {
            type: "button",
            class: q(v(o).e("cancel")),
            onClick: a
          }, " 取消 ", 2),
          D("button", {
            type: "button",
            class: q(v(o).e("submit")),
            onClick: s
          }, " 提交 ", 2)
        ], 2)
      ])
    ], 2));
  }
}), Tu = ["onClick", "onMouseenter"], yf = /* @__PURE__ */ Te({
  name: "ZxTextEditorEmbedList",
  __name: "embed-list",
  props: {
    items: {},
    query: {},
    command: { type: Function }
  },
  setup(e, { expose: t }) {
    const o = De("text-editor-embed-list"), n = e, i = J(0);
    Q(
      () => n.items,
      () => {
        i.value = 0;
      }
    );
    const s = (l) => {
      const r = n.items[l];
      r && n.command(r);
    };
    return t({ onKeyDown: (l) => l.key === "ArrowUp" ? (i.value = (i.value - 1 + n.items.length) % n.items.length, !0) : l.key === "ArrowDown" ? (i.value = (i.value + 1) % n.items.length, !0) : l.key === "Enter" ? (s(i.value), !0) : !1 }), (l, r) => (L(), F("div", {
      class: q(v(o).b())
    }, [
      e.items.length === 0 ? (L(), F("div", {
        key: 0,
        class: q(v(o).e("empty"))
      }, me(e.query ? "未找到匹配的文档" : "输入关键词搜索文档"), 3)) : ae("", !0),
      (L(!0), F(Le, null, Pe(e.items, (f, c) => (L(), F("button", {
        key: f.name,
        type: "button",
        class: q([v(o).e("item"), v(o).is("selected", c === i.value)]),
        onClick: (u) => s(c),
        onMouseenter: (u) => i.value = c
      }, [
        D("span", {
          class: q(v(o).e("icon"))
        }, "📄", 2),
        D("span", {
          class: q(v(o).e("title"))
        }, me(f.title), 3)
      ], 42, Tu))), 128))
    ], 2));
  }
}), Iu = (e) => {
  if (typeof e == "boolean") return e;
  if (typeof process < "u" && process.env.VITEST === "true")
    return !0;
  if (typeof window < "u" && typeof window.matchMedia == "function")
    try {
      return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    } catch {
      return !1;
    }
  return !1;
}, Au = () => typeof Intl < "u" && typeof Intl.Segmenter == "function" ? new Intl.Segmenter(void 0, { granularity: "word" }) : "word", Eu = (e) => {
  const t = Au();
  return t !== "word" ? Array.from(t.segment(e), ({ segment: o }) => o) : e.match(/\s+|[^\s]+/gu) ?? [];
}, Su = (e, t = {}) => {
  const o = J(""), n = J(!1), i = J(0);
  let s = "", a = 0, l = [], r = !1;
  const f = t.delayInMs === null ? 0 : Math.max(0, t.delayInMs ?? 10), c = typeof requestAnimationFrame == "function" ? requestAnimationFrame : (_) => setTimeout(() => _(Date.now()), 16), u = S(
    () => i.value === 0 && !n.value && o.value === qe(e)
  ), p = () => {
    a += 1, l = [], r = !1, i.value = 0, n.value = !1;
  }, m = (_) => {
    p(), s = _, o.value = _;
  }, y = (_) => {
    if (r || _ !== a || l.length === 0) return;
    r = !0, c(() => {
      if (_ !== a) return;
      r = !1;
      const k = l.shift();
      if (k !== void 0 && (o.value += k), i.value = l.length, l.length === 0) {
        n.value = !1, qe(e) || (s = "", o.value = "");
        return;
      }
      setTimeout(() => y(_), f);
    });
  }, M = (_) => {
    const T = Eu(_);
    if (T.length === 0) return;
    const k = a;
    l.push(...T), i.value = l.length, n.value = !0, y(k);
  };
  return Q(
    () => qe(e),
    (_) => {
      if (Iu(qe(t.snap))) {
        m(_);
        return;
      }
      if (!_) {
        if (i.value > 0 || n.value)
          return;
        p(), s = "", o.value = "";
        return;
      }
      _.startsWith(s) || (p(), s = "", o.value = "");
      const T = _.slice(s.length);
      T && (s = _, M(T));
    },
    { immediate: !0 }
  ), rt(() => {
    p();
  }), {
    displayedText: o,
    isRevealing: n,
    isCaughtUp: u
  };
}, _u = ["innerHTML"], Ou = /* @__PURE__ */ Te({
  name: "ZxTextEditorView",
  __name: "text-editor-view",
  props: {
    document: {},
    typography: { default: () => ({
      root: { fontSize: { cssValue: "1em", displayValue: "1em" } }
    }) }
  },
  setup(e) {
    const t = e, o = S(
      () => Xo(
        ni({ override: t.typography })
      )
    ), n = S(
      () => t.document ? Sn(t.document, { profile: "safe-html" }) : ""
    );
    return (i, s) => (L(), F("div", {
      class: q(["zx-text-editor-view", o.value.className]),
      style: ft(o.value.style)
    }, [
      n.value ? (L(), F("div", {
        key: 0,
        class: "ProseMirror zx-text-editor__prose",
        innerHTML: n.value
      }, null, 8, _u)) : ae("", !0)
    ], 6));
  }
}), Ru = { class: "zx-field-ai__context" }, Nu = { class: "zx-inline-ai-surface__status" }, Lu = ["disabled"], Bu = ["disabled"], Cu = ["checked", "disabled", "data-context-id", "onChange"], zu = {
  key: 1,
  "aria-label": "本次已提供的信息",
  "data-testid": "field-ai-receipt"
}, Mu = {
  key: 2,
  role: "status",
  "data-testid": "field-ai-notice"
}, Du = /* @__PURE__ */ Te({
  inheritAttrs: !1,
  __name: "FieldAIContext",
  props: {
    choices: {},
    selectedIds: {},
    receipt: {},
    notices: {},
    disabled: { type: Boolean },
    busy: { type: Boolean }
  },
  emits: ["update:selectedIds", "draft"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = {
      policy: "策略",
      budget: "预算",
      unavailable: "不可用",
      empty: "空值"
    }, s = (a, l) => {
      const r = l.target.checked;
      n(
        "update:selectedIds",
        r ? [...o.selectedIds, a] : o.selectedIds.filter((f) => f !== a)
      );
    };
    return (a, l) => (L(), F("div", Ru, [
      D("p", Nu, " AI 生成，采用前请核对。" + me(e.busy ? "生成中，预览尚未校验。" : ""), 1),
      l[2] || (l[2] = D("p", { class: "zx-inline-ai-surface__status" }, " 仅保护本次编辑中已知的个人信息；手输内容和重新加载的历史信息请自行核对。 ", -1)),
      D("button", {
        type: "button",
        disabled: e.disabled,
        "data-testid": "field-ai-draft-context",
        onClick: l[0] || (l[0] = (r) => n("draft"))
      }, " 根据表单信息起草 ", 8, Lu),
      e.choices.length ? (L(), F("fieldset", {
        key: 0,
        disabled: e.disabled
      }, [
        l[1] || (l[1] = D("legend", null, "补充上下文（可选）", -1)),
        (L(!0), F(Le, null, Pe(e.choices, (r) => (L(), F("label", {
          key: r.id
        }, [
          D("input", {
            type: "checkbox",
            checked: e.selectedIds.includes(r.id),
            disabled: r.disabled,
            "data-context-id": r.id,
            onChange: (f) => s(r.id, f)
          }, null, 40, Cu),
          Yt(" " + me(r.label), 1)
        ]))), 128))
      ], 8, Bu)) : ae("", !0),
      e.receipt ? (L(), F("ul", zu, [
        (L(!0), F(Le, null, Pe(e.receipt.included, (r) => (L(), F("li", {
          key: r.id
        }, me(r.label) + "：" + me(r.masked ? "已脱敏" : "已提供"), 1))), 128)),
        (L(!0), F(Le, null, Pe(e.receipt.withheld, (r) => (L(), F("li", {
          key: r.id
        }, me(r.label) + "：未提供（" + me(i[r.reason]) + "） ", 1))), 128))
      ])) : ae("", !0),
      e.notices.length ? (L(), F("p", Mu, " 部分信息未提供，可在上方选择或补充后重新生成。 ")) : ae("", !0)
    ]));
  }
}), Fu = ["id", "aria-busy"], Pu = { class: "zx-inline-ai-surface__slash-header" }, Vu = { class: "zx-inline-ai-surface__slash-title" }, ju = {
  key: 0,
  class: "zx-field-ai__scope"
}, $u = {
  key: 0,
  class: "zx-inline-ai-surface__error zx-field-ai__note",
  role: "alert"
}, Hu = { class: "zx-inline-ai-surface__slash-suggestion-list" }, Uu = ["disabled", "data-field-ai-suggestion", "onClick"], Ku = {
  key: 1,
  class: "zx-inline-ai-surface__result-footer"
}, qu = { class: "zx-inline-ai-surface__result-commands" }, Gu = {
  key: 1,
  class: "zx-inline-ai-surface__response"
}, Wu = {
  key: 0,
  class: "zx-inline-ai-surface__pondering",
  "data-testid": "field-ai-pondering"
}, Ju = { class: "zx-inline-ai-surface__pondering-lead" }, Zu = {
  class: "zx-inline-ai-surface__pondering-icon",
  "aria-hidden": "true"
}, Xu = {
  key: 1,
  class: "zx-inline-ai-surface__result"
}, Yu = { class: "zx-inline-ai-surface__result-body" }, Qu = {
  class: "zx-inline-ai-surface__avatar",
  "aria-hidden": "true"
}, ed = { class: "zx-inline-ai-surface__result-content" }, td = {
  key: 0,
  class: "zx-field-ai__candidate",
  "aria-label": "AI 候选内容",
  "data-testid": "field-ai-candidate"
}, nd = {
  key: 0,
  class: "zx-inline-ai-surface__status"
}, od = {
  key: 1,
  class: "zx-inline-ai-surface__preview zx-field-ai__stream",
  "data-testid": "field-ai-stream"
}, id = {
  key: 0,
  class: "zx-inline-ai-surface__caret",
  "aria-hidden": "true"
}, sd = {
  key: 2,
  class: "zx-inline-ai-surface__error",
  role: "alert"
}, rd = {
  key: 3,
  class: "zx-inline-ai-surface__status",
  role: "status"
}, ad = {
  key: 4,
  class: "zx-inline-ai-surface__status zx-field-ai__hint"
}, ld = {
  key: 0,
  class: "zx-inline-ai-surface__result-footer"
}, cd = { class: "zx-inline-ai-surface__result-icons" }, ud = {
  key: 1,
  class: "zx-inline-ai-surface__result-controls zx-field-ai__controls"
}, dd = {
  class: "zx-field-ai__control-row",
  role: "group",
  "aria-label": "候选操作"
}, fd = {
  key: 1,
  class: "zx-inline-ai-surface__follow-up zx-field-ai__follow-up",
  "data-testid": "field-ai-follow-up"
}, pd = { class: "zx-inline-ai-surface__result-commands" }, md = ["disabled", "aria-keyshortcuts"], vd = {
  class: "zx-inline-ai-surface__kbd",
  "aria-hidden": "true"
}, gd = /* @__PURE__ */ Te({
  __name: "FieldAIPopover",
  props: {
    controller: {},
    themeOwner: {},
    anchor: { type: Function }
  },
  emits: ["focusin", "focusout"],
  setup(e, { expose: t, emit: o }) {
    const n = e, i = o, {
      open: s,
      phase: a,
      instruction: l,
      scope: r,
      target: f,
      candidate: c,
      refinementPreview: u,
      stream: p,
      error: m,
      stale: y,
      submitted: M,
      empty: _,
      suggestions: T,
      busy: k,
      canAccept: g,
      available: V,
      selectedContextIds: U,
      contextChoices: x,
      receipt: w,
      notices: R,
      draftFromContext: X,
      start: Z,
      cancel: ie,
      stop: ce,
      generate: B,
      regenerate: C,
      accept: N
    } = n.controller, O = us(), K = `${O}-suggestions`, { binding: se } = bt(n.themeOwner), ge = Mn(() => s.value), le = J(), pe = J(""), be = S(() => M.value ? "response" : "composer"), ve = S(
      () => !!f.value && !y.value && !k.value && V.value
    ), de = S(
      () => s.value && be.value === "composer" ? "composer" : !1
    ), _e = S(
      () => r.value === "selection" ? "想怎么改所选文字？" : _.value ? "想写什么？例如：说明岗位职责、交接事项…" : "想怎么改？例如：更简洁、改成要点…"
    ), Ee = () => {
      ve.value && B();
    }, ee = () => {
      const h = pe.value.trim();
      !h || k.value || y.value || (pe.value = "", B(h));
    }, { displayedText: ne } = Su(
      () => c.value ? "" : p.value
    ), he = Ut(), { text: oe, aria: ze } = cn({
      runtime: he,
      bindingId: "textEditor.review.accept"
    }), Fe = typeof navigator < "u" && /Mac|iPhone|iPad|iPod/.test(navigator.platform ?? ""), Je = S(
      () => oe.value || (Fe ? "⌘ ⏎" : "Ctrl ⏎")
    ), Qe = S(
      () => ze.value || (Fe ? "Meta+Enter" : "Control+Enter")
    ), W = (h) => {
      if (!ti(h)) {
        if (h.key === "Escape") {
          h.preventDefault(), h.stopPropagation(), ie();
          return;
        }
        h.key === "Enter" && (h.metaKey || h.ctrlKey) && g.value && (h.preventDefault(), h.stopPropagation(), N());
      }
    }, ye = () => {
      var A;
      const h = document.activeElement;
      return !h || h === document.body || !!((A = le.value) != null && A.contains(h));
    }, Re = async () => {
      await dt();
      const h = le.value;
      if (!h || !ye()) return;
      (h.querySelector(
        '[data-field-ai-primary]:not(:disabled), [data-testid="field-ai-stop"]'
      ) ?? h).focus({ preventScroll: !0 });
    };
    Q(a, (h, A) => {
      s.value && h !== A && h !== "idle" && Re();
    });
    const Ge = (h) => {
      var P, ue;
      const A = h.target;
      A instanceof Node && ((P = le.value) != null && P.contains(A) || (ue = n.anchor()) != null && ue.contains(A) || be.value === "composer" && !l.value.trim() && !y.value && n.controller.close());
    };
    Q(
      s,
      (h) => {
        typeof document > "u" || (h ? document.addEventListener("pointerdown", Ge, !0) : (document.removeEventListener("pointerdown", Ge, !0), pe.value = ""));
      },
      { immediate: !0 }
    );
    const tt = ["position", "left", "top", "transform"];
    let He = {};
    const E = () => {
      const h = le.value;
      if (h)
        for (const A of tt) {
          const P = He[A];
          P ? h.style.setProperty(A, P) : h.style.removeProperty(A);
        }
    }, I = (h) => {
      He = h, E();
    };
    let H, Y;
    const fe = () => {
      const h = n.anchor();
      if (!h) return;
      const A = h.getBoundingClientRect();
      return {
        kind: "virtual-rect",
        left: A.left,
        top: A.top,
        width: A.width,
        height: A.height
      };
    }, Ie = () => {
      const h = le.value, A = fe();
      h && A && h.style.setProperty(
        "--field-ai-anchor-width",
        `${Math.round(A.width)}px`
      );
    }, Ce = () => {
      H == null || H(), H = void 0, Y == null || Y.disconnect(), Y = void 0;
    }, d = () => {
      Ce();
      const h = le.value, A = fe();
      if (!h || !A || !s.value) return;
      I(
        Object.keys(He).length ? He : Kc(A)
      ), Ie(), H = Uc({
        getAnchor: fe,
        floating: h,
        onStyle: (ue) => {
          I(ue), Ie();
        }
      });
      const P = n.anchor();
      P && typeof ResizeObserver < "u" && (Y = new ResizeObserver(Ie), Y.observe(P));
    };
    return Q(
      le,
      (h) => {
        h ? d() : (Ce(), He = {});
      },
      { flush: "post" }
    ), rt(() => {
      typeof document < "u" && document.removeEventListener("pointerdown", Ge, !0), Ce();
    }), t({ rootEl: le }), (h, A) => v(se) ? (L(), $e(ds, {
      key: 0,
      to: v(se).target
    }, [
      v(s) ? (L(), F("section", {
        key: 0,
        id: v(O),
        ref_key: "rootEl",
        ref: le,
        class: q([
          "zx-field-ai zx-inline-ai-surface zx-inline-ai-surface--anchored",
          be.value === "composer" ? "zx-inline-ai-surface--slash-composer" : "zx-inline-ai-surface--response"
        ]),
        style: ft({ zIndex: v(ge) }),
        role: "dialog",
        "aria-label": "AI 帮写",
        "aria-busy": v(k) || void 0,
        tabindex: "-1",
        "data-testid": "field-ai",
        onKeydown: W,
        onFocusin: A[12] || (A[12] = (P) => i("focusin", P)),
        onFocusout: A[13] || (A[13] = (P) => i("focusout", P))
      }, [
        j(Du, {
          "selected-ids": v(U),
          "onUpdate:selectedIds": A[0] || (A[0] = (P) => En(U) ? U.value = P : null),
          choices: v(x),
          receipt: v(w),
          notices: v(R),
          disabled: !v(V) || v(y),
          busy: v(k),
          onDraft: v(X)
        }, null, 8, ["selected-ids", "choices", "receipt", "notices", "disabled", "busy", "onDraft"]),
        be.value === "composer" ? (L(), F(Le, { key: 0 }, [
          D("header", Pu, [
            j(v(xe), {
              class: "zx-inline-ai-surface__slash-mark",
              icon: "lucide:sparkles",
              "aria-hidden": "true"
            }),
            D("span", Vu, [
              A[14] || (A[14] = Yt(" AI 帮写 ", -1)),
              v(r) === "selection" ? (L(), F("span", ju, " 所选文字 ")) : ae("", !0)
            ])
          ]),
          j(Ln, {
            modelValue: v(l),
            "onUpdate:modelValue": A[1] || (A[1] = (P) => En(l) ? l.value = P : null),
            variant: "slash",
            "activation-key": de.value,
            "submit-enabled": ve.value,
            placeholder: _e.value,
            "accessible-label": "AI 帮写指令",
            onSubmit: Ee
          }, null, 8, ["modelValue", "activation-key", "submit-enabled", "placeholder"]),
          v(m) ? (L(), F("p", $u, me(v(m)), 1)) : ae("", !0),
          fs(D("section", {
            class: "zx-inline-ai-surface__slash-suggestions",
            "aria-labelledby": K
          }, [
            D("span", {
              id: K,
              class: "zx-inline-ai-surface__slash-suggestions-label"
            }, " 试试 "),
            D("ul", Hu, [
              (L(!0), F(Le, null, Pe(v(T), (P) => (L(), F("li", {
                key: P.id
              }, [
                D("button", {
                  type: "button",
                  class: "zx-inline-ai-surface__slash-suggestion",
                  disabled: !ve.value,
                  "data-field-ai-suggestion": P.id,
                  onClick: (ue) => v(B)(P.instruction)
                }, [
                  j(v(xe), {
                    class: "zx-inline-ai-surface__slash-suggestion-icon",
                    icon: P.icon ?? "lucide:sparkles",
                    "aria-hidden": "true"
                  }, null, 8, ["icon"]),
                  D("span", null, me(P.label), 1)
                ], 8, Uu)
              ]))), 128))
            ])
          ], 512), [
            [ps, !v(l).trim() && !v(y)]
          ]),
          v(y) ? (L(), F("footer", Ku, [
            D("div", qu, [
              D("button", {
                type: "button",
                class: "zx-inline-ai-surface__command zx-inline-ai-surface__hit",
                "data-testid": "field-ai-discard",
                onClick: A[2] || (A[2] = //@ts-ignore
                (...P) => v(ie) && v(ie)(...P))
              }, " 关闭 "),
              D("button", {
                type: "button",
                class: "zx-inline-ai-surface__command zx-inline-ai-surface__command--primary zx-inline-ai-surface__hit",
                "data-testid": "field-ai-reload",
                "data-field-ai-primary": "",
                onClick: A[3] || (A[3] = (P) => v(Z)())
              }, " 重新读取原文 ")
            ])
          ])) : ae("", !0)
        ], 64)) : (L(), F("div", Gu, [
          v(k) && !v(ne) ? (L(), F("div", Wu, [
            D("span", Ju, [
              D("span", Zu, [
                j(v(xe), {
                  class: "zx-inline-ai-surface__pondering-orbit",
                  icon: "lucide:loader-circle"
                }),
                A[15] || (A[15] = D("span", { class: "zx-inline-ai-surface__pondering-spark" }, null, -1))
              ]),
              A[16] || (A[16] = D("span", { class: "zx-inline-ai-surface__pondering-text" }, [
                D("span", { class: "zx-inline-ai-surface__pondering-label" }, " 正在生成… ")
              ], -1)),
              A[17] || (A[17] = D("span", {
                class: "zx-inline-ai-surface__sr-only",
                role: "status",
                "aria-live": "polite"
              }, " 正在生成，原文保持不变 ", -1))
            ]),
            D("button", {
              type: "button",
              class: "zx-inline-ai-surface__stop zx-inline-ai-surface__hit",
              "aria-label": "停止生成",
              title: "停止生成",
              "data-testid": "field-ai-stop",
              onClick: A[4] || (A[4] = //@ts-ignore
              (...P) => v(ce) && v(ce)(...P))
            }, [...A[18] || (A[18] = [
              D("span", {
                class: "zx-inline-ai-surface__stop-glyph",
                "aria-hidden": "true"
              }, null, -1)
            ])])
          ])) : (L(), F("div", Xu, [
            D("div", Yu, [
              D("div", Qu, [
                j(v(xe), { icon: "lucide:sparkles" })
              ]),
              D("div", ed, [
                v(c) || v(u) ? (L(), F("div", td, [
                  j(Ou, {
                    document: v(c) ?? v(u)
                  }, null, 8, ["document"]),
                  v(c) ? ae("", !0) : (L(), F("p", nd, " 原候选仅供继续改写，不能直接采用。 "))
                ])) : v(ne) ? (L(), F("div", od, [
                  Yt(me(v(ne)), 1),
                  v(k) ? (L(), F("span", id)) : ae("", !0)
                ])) : ae("", !0),
                v(m) ? (L(), F("p", sd, me(v(m)), 1)) : v(a) === "stopped" ? (L(), F("p", rd, " 已停止，原文未改动。 ")) : v(c) ? (L(), F("p", ad, " 采用后替换" + me(v(r) === "selection" ? "所选文字" : "整段内容") + "，可撤销 ", 1)) : ae("", !0)
              ])
            ]),
            v(k) ? (L(), F("footer", ld, [
              D("div", cd, [
                D("button", {
                  type: "button",
                  class: "zx-inline-ai-surface__stop zx-inline-ai-surface__hit",
                  "aria-label": "停止生成",
                  title: "停止生成",
                  "data-testid": "field-ai-stop",
                  onClick: A[5] || (A[5] = //@ts-ignore
                  (...P) => v(ce) && v(ce)(...P))
                }, [...A[19] || (A[19] = [
                  D("span", {
                    class: "zx-inline-ai-surface__stop-glyph",
                    "aria-hidden": "true"
                  }, null, -1)
                ])])
              ])
            ])) : (L(), F("div", ud, [
              A[21] || (A[21] = D("hr", {
                class: "zx-field-ai__divider",
                "aria-hidden": "true"
              }, null, -1)),
              D("footer", dd, [
                v(c) && !v(y) ? (L(), F("button", {
                  key: 0,
                  type: "button",
                  class: "zx-inline-ai-surface__tool zx-inline-ai-surface__hit",
                  "aria-label": "重新生成",
                  title: "按同样的要求重新生成",
                  "data-testid": "field-ai-regenerate",
                  onClick: A[6] || (A[6] = //@ts-ignore
                  (...P) => v(C) && v(C)(...P))
                }, [
                  j(v(xe), {
                    icon: "lucide:refresh-cw",
                    "aria-hidden": "true"
                  })
                ])) : ae("", !0),
                (v(c) || v(u) || v(R).length) && !v(y) ? (L(), F("div", fd, [
                  j(Ln, {
                    modelValue: pe.value,
                    "onUpdate:modelValue": A[7] || (A[7] = (P) => pe.value = P),
                    variant: "surface",
                    "activation-key": !1,
                    placeholder: "继续修改，例如：再短一点",
                    "accessible-label": "继续修改候选",
                    "submit-enabled": !!pe.value.trim(),
                    onSubmit: ee
                  }, null, 8, ["modelValue", "submit-enabled"])
                ])) : ae("", !0),
                D("div", pd, [
                  D("button", {
                    type: "button",
                    class: "zx-inline-ai-surface__command zx-inline-ai-surface__hit",
                    "data-testid": "field-ai-discard",
                    onClick: A[8] || (A[8] = //@ts-ignore
                    (...P) => v(ie) && v(ie)(...P))
                  }, me(v(c) ? "舍弃" : "关闭"), 1),
                  v(y) ? (L(), F("button", {
                    key: 0,
                    type: "button",
                    class: "zx-inline-ai-surface__command zx-inline-ai-surface__command--primary zx-inline-ai-surface__hit",
                    "data-testid": "field-ai-reload",
                    "data-field-ai-primary": "",
                    onClick: A[9] || (A[9] = (P) => v(Z)())
                  }, " 重新读取原文 ")) : v(c) ? (L(), F("button", {
                    key: 1,
                    type: "button",
                    class: "zx-inline-ai-surface__command zx-inline-ai-surface__command--primary zx-inline-ai-surface__hit",
                    disabled: !v(g),
                    "aria-keyshortcuts": Qe.value,
                    "data-testid": "field-ai-accept",
                    "data-field-ai-primary": "",
                    onClick: A[10] || (A[10] = //@ts-ignore
                    (...P) => v(N) && v(N)(...P))
                  }, [
                    A[20] || (A[20] = Yt(" 采用 ", -1)),
                    D("kbd", vd, me(Je.value), 1)
                  ], 8, md)) : v(l).trim() ? (L(), F("button", {
                    key: 2,
                    type: "button",
                    class: "zx-inline-ai-surface__command zx-inline-ai-surface__command--primary zx-inline-ai-surface__hit",
                    "data-testid": "field-ai-retry",
                    "data-field-ai-primary": "",
                    onClick: A[11] || (A[11] = (P) => v(B)())
                  }, " 重试 ")) : ae("", !0)
                ])
              ])
            ]))
          ]))
        ]))
      ], 46, Fu)) : ae("", !0)
    ], 8, ["to"])) : ae("", !0);
  }
}), Ri = "ai.ask", hd = (e) => ({
  id: Ri,
  title: "Ask AI",
  description: "Write or revise with AI",
  icon: "lucide:sparkles",
  keywords: ["ai", "ask", "write", "ai 帮写", "帮写", "写"],
  aliases: ["ai"],
  shortcutBindingId: "textEditor.askAI.open",
  group: "ai",
  priority: -100,
  command: ({ editor: t, range: o }) => {
    t.chain().focus().deleteRange(o).run(), queueMicrotask(e);
  }
}), bd = (e) => Gs({
  id: "zx-field-ai",
  priority: -50,
  items: () => [
    {
      id: Ri,
      kind: "dropdown",
      surface: "bubble",
      priority: -50,
      label: "AI",
      icon: "lucide:sparkles",
      getState: () => ({ disabled: e.disabled() }),
      options: [
        ...e.suggestions().map((t) => ({
          id: `ai-${t.id}`,
          label: t.label,
          icon: t.icon
        })),
        { id: "ai-custom", label: "Ask AI…", icon: "lucide:pen-line" }
      ],
      onOptionSelect: (t) => {
        if (e.disabled()) return;
        const o = e.suggestions().find((n) => `ai-${n.id}` === t);
        e.open(o == null ? void 0 : o.instruction);
      }
    }
  ]
}), yd = Object.freeze([
  {
    id: "draft",
    label: "根据表单信息写一条备注",
    instruction: "根据提供的业务上下文，写一条简洁、准确的备注。",
    icon: "lucide:pen-line"
  },
  {
    id: "draft-points",
    label: "用要点列出关键信息",
    instruction: "根据提供的业务上下文，用要点列表写一条备注，每条一句话。",
    icon: "lucide:list"
  }
]), kd = Object.freeze([
  {
    id: "polish",
    label: "润色",
    instruction: "请润色表达，保留原意和事实，使文字清晰自然。",
    icon: "lucide:wand-sparkles"
  },
  {
    id: "concise",
    label: "精简",
    instruction: "请精简内容，保留关键事实和结论，去掉重复表述。",
    icon: "lucide:minimize-2"
  },
  {
    id: "points",
    label: "整理要点",
    instruction: "请保留原意，将内容整理成简洁清晰的要点列表。",
    icon: "lucide:list"
  }
]), Ni = (e, t) => {
  var o;
  return ((o = t == null ? void 0 : t.suggestions) == null ? void 0 : o.call(t, e)) ?? (e.empty && e.target === "document" ? yd : kd);
}, ln = (e) => ir("zx-text-editor-field-ai:v1", e.getJSON()), Cn = (e) => gt({
  body: { format: "json", content: e },
  annotations: [],
  assets: []
}), wd = (e, t) => {
  const { from: o, to: n, empty: i } = e.state.selection;
  return {
    fingerprint: ln(e),
    from: o,
    to: n,
    document: Ye(Cn(e.getJSON()), t),
    selection: i ? null : Ye(
      Cn(
        fr(
          e.state.doc.cut(o, n).toJSON()
        ).content
      ),
      t
    )
  };
}, Fo = (e, t, o, n, i) => {
  if (ln(e) !== t.fingerprint)
    throw new Error("原文已变化，请重新打开 AI 后生成");
  const s = Ye(n, i);
  if (!s) throw new Error("AI 没有返回可采用的内容，请重试");
  const a = si.fromArray(
    s.body.content.content.map(
      (r) => e.schema.nodeFromJSON(r)
    )
  ), l = e.state.tr;
  if (o === "selection") {
    if (t.from === t.to || !t.selection)
      throw new Error("所选文字已不可用，请重新选择");
    const r = s.body.content.content.every(
      (f) => f.type === "paragraph"
    );
    l.replaceRange(
      t.from,
      t.to,
      new ii(a, r ? 1 : 0, r ? 1 : 0)
    );
  } else
    l.replaceWith(0, l.doc.content.size, a);
  return ar(l, l.doc, {
    types: dr()
  }), Ye(Cn(l.doc.toJSON()), i), { candidate: s, transaction: l };
};
function xd(e) {
  const t = pr(), o = mr(), n = J("rewrite"), i = J([]), s = Ne(null);
  let a = 0;
  const l = S(
    () => t == null ? void 0 : t.definition.purposes[e.purpose() ?? ""]
  ), r = S(
    () => !!l.value && !!t && vr(t.status())
  ), f = S(
    () => {
      var p;
      return (((p = l.value) == null ? void 0 : p.selectableContextIds) ?? []).map((m) => {
        var M;
        const y = t.definition.items.find((_) => _.id === m);
        return {
          id: m,
          label: y.label,
          disabled: y.sensitivity === "personal" && ((M = t.status().policy) == null ? void 0 : M.personal) === "never"
        };
      });
    }
  );
  return Q(
    () => JSON.stringify([n.value, i.value]),
    () => {
      a++, e.invalidate("form");
    },
    { flush: "sync" }
  ), Q(
    () => t == null ? void 0 : t.stamp(),
    () => e.invalidate("form"),
    { flush: "sync" }
  ), Q(
    () => JSON.stringify([
      t == null ? void 0 : t.instanceKey(),
      e.purpose(),
      t == null ? void 0 : t.status()
    ]),
    (p, m) => {
      JSON.parse(p)[0] !== JSON.parse(m)[0] && o.reset(), e.invalidate("identity");
    },
    { flush: "sync" }
  ), kt(() => o.reset()), {
    available: r,
    action: n,
    selectedContextIds: i,
    choices: f,
    receipt: s,
    capture: async (p, m) => {
      if (!t || !e.purpose() || !r.value)
        throw new on("not-ready");
      const y = await gr(t, {
        purpose: e.purpose(),
        knownValues: o,
        signal: m,
        request: p,
        selection: () => ({
          action: i.value.length ? "include-context" : n.value,
          selectedContextIds: i.value,
          revision: a
        })
      });
      return s.value = y.receipt, y;
    },
    validateResult: (p, m) => {
      const y = () => {
        throw new on("invalid-output");
      };
      (!p || typeof p != "object" || Object.keys(p).sort().join(",") !== "document,meta,notices" || !Array.isArray(p.notices) || p.notices.length > 16 || !p.meta || Object.keys(p.meta).sort().join(",") !== "contextIds,model,promptVersion" || p.meta.promptVersion !== "text-field/v1" || typeof p.meta.model != "string" || !p.meta.model || [...p.meta.model].length > 128 || JSON.stringify(p.meta.contextIds) !== JSON.stringify(m) || p.document === null && !p.notices.length) && y();
      const M = new Set(
        t == null ? void 0 : t.definition.items.filter((_) => _.sensitivity !== "secret").map((_) => _.id)
      );
      for (const _ of p.notices)
        (!_ || Object.keys(_).sort().join(",") !== "code,contextIds" || _.code !== "information-unavailable" || !Array.isArray(_.contextIds) || _.contextIds.length > 16 || new Set(_.contextIds).size !== _.contextIds.length || _.contextIds.some((T) => !M.has(T))) && y();
      return p;
    }
  };
}
const Po = oi, Vo = (e) => JSON.parse(JSON.stringify(e));
function Td(e) {
  const t = J(!1), o = J(
    "idle"
  ), n = J(""), i = J("document"), s = Ne(null), a = Ne(null), l = J(""), r = J(""), f = J(!1), c = Ne([]), u = J(!1);
  let p = 0, m;
  const y = Ne(null), M = S(() => o.value === "generating"), _ = S(
    () => o.value === "ready" && !!a.value && !f.value && x.available.value && !e.disabled()
  ), T = S(() => {
    var O;
    return !((O = s.value) != null && O.document);
  }), k = S(
    () => Ni(
      { target: i.value, empty: T.value },
      e.adapter()
    )
  ), g = () => {
    p++, m == null || m.abort(), m = void 0;
  }, V = () => {
    const O = e.editor(), K = s.value;
    return !!O && !!K && ln(O) === K.fingerprint && O.state.selection.from === K.from && O.state.selection.to === K.to;
  }, U = () => {
    g(), f.value = !0, a.value = null, y.value = null, w = void 0, l.value = "", c.value = [], o.value = "error", r.value = "原文已变化，请重新打开 AI 后生成；当前原文已保留";
  }, x = xd({
    purpose: e.purpose,
    invalidate(O) {
      if (g(), O === "identity") {
        R();
        return;
      }
      if (t.value) {
        if (f.value || !V()) {
          U();
          return;
        }
        y.value = a.value ?? y.value, a.value = null, w = void 0, l.value = "", o.value = "idle", c.value = [], r.value = t.value && u.value ? "上下文已变化，旧候选仅供改写，请重新生成后采用" : "";
      }
    }
  });
  let w;
  const R = () => {
    g(), t.value = !1, a.value = null, l.value = "", o.value = "idle", r.value = "", s.value = null, u.value = !1, y.value = null, w = void 0, c.value = [], x.receipt.value = null;
  }, X = (O) => {
    s.value = wd(O, e.limits()), i.value = s.value.selection ? "selection" : "document";
  }, Z = (O) => {
    var se;
    const K = e.editor();
    if (!(!K || e.disabled() || !e.adapter() || !x.available.value)) {
      R(), t.value = !0, f.value = !1, n.value = "";
      try {
        X(K), x.selectedContextIds.value = [], x.action.value = (se = s.value) != null && se.document ? "rewrite" : "draft";
      } catch {
        r.value = "请先检查原文的格式和长度，再使用 AI", o.value = "error";
        return;
      }
      O != null && O.trim() && B(O);
    }
  }, ie = () => {
    g(), o.value = "stopped";
  }, ce = () => {
    var O;
    R(), e.disabled() || (O = e.editor()) == null || O.commands.focus();
  }, B = async (O = n.value) => {
    const K = e.editor(), se = e.adapter(), ge = s.value;
    if (!K || !se || !ge || e.disabled() || f.value || !O.trim() || !x.available.value)
      return;
    g();
    const le = p, pe = new AbortController();
    m = pe, n.value = O, u.value = !0;
    const be = a.value ?? y.value;
    y.value = be, a.value = null, l.value = "", r.value = "", c.value = [], o.value = "generating";
    const ve = () => le === p && t.value && !pe.signal.aborted && x.available.value && !e.disabled();
    try {
      const de = await x.capture(
        Vo({
          instruction: O.trim(),
          target: i.value,
          document: ge.document,
          selection: i.value === "selection" ? ge.selection : null,
          candidate: be ?? null
        }),
        pe.signal
      );
      if (!ve()) return;
      for (const ee of [
        de.request.document,
        de.request.selection,
        de.request.candidate
      ])
        ee !== null && Ye(ee, e.limits());
      const _e = await se.generate(
        {
          ...de.request,
          version: "ai-context/v1",
          requestId: hr(),
          captureId: de.captureId,
          manifestRevision: de.manifestRevision,
          policyRevision: de.policyRevision,
          scope: de.scope,
          purpose: de.purpose,
          action: de.action,
          selectedContextIds: de.selectedContextIds,
          profile: "basic-rich-text",
          context: de.items
        },
        {
          signal: pe.signal,
          onDelta: (ee) => {
            ve() && typeof ee == "string" && (l.value = (l.value + ee).slice(0, 1e5));
          }
        }
      );
      if (!ve()) return;
      if (de.assertCurrent(), x.validateResult(
        _e,
        de.items.map((ee) => ee.id)
      ), c.value = Vo(_e.notices), w = de, _e.document === null) {
        o.value = "ready", l.value = "";
        return;
      }
      const Ee = de.restore(_e.document);
      a.value = Fo(
        K,
        ge,
        i.value,
        Ee,
        e.limits()
      ).candidate, o.value = "ready";
    } catch (de) {
      if (!ve()) return;
      o.value = "error", r.value = de instanceof on && de.code === "placeholder-conflict" ? "内容包含保留占位符，请调整后再生成" : de instanceof on && de.code === "personal-blocked" ? "当前策略不允许发送内容中的已知个人信息，请调整内容后重试" : "AI 生成未完成，或结果不符合字段格式或长度限制，请调整要求后重试";
    } finally {
      le === p && (m = void 0);
    }
  }, C = () => {
    M.value || f.value || !n.value.trim() || (a.value = null, y.value = null, B(n.value));
  }, N = () => {
    const O = e.editor();
    if (!(!O || !s.value || !_.value))
      try {
        if (!w) throw new Error("missing AI capture");
        w.assertCurrent();
        const { transaction: K } = Fo(
          O,
          s.value,
          i.value,
          a.value,
          e.limits()
        ), se = K.doc;
        if (t.value = !1, O.view.dispatch(Po.closeHistory(K)), !O.state.doc.eq(se))
          throw new Error("内容未能应用，请重新生成");
        O.view.dispatch(
          Po.closeHistory(O.state.tr).setMeta("addToHistory", !1)
        ), R(), O.commands.focus();
      } catch (K) {
        t.value = !0, r.value = K instanceof Error ? K.message : "内容未能应用，请重试", o.value = "error";
      }
  };
  return Q(
    e.editor,
    (O, K, se) => {
      if (K && R(), !O) return;
      const ge = () => {
        const le = s.value;
        if (!t.value || !le) return;
        const pe = ln(O) === le.fingerprint;
        if (!u.value && o.value === "idle") {
          const { from: ve, to: de } = O.state.selection;
          if (pe && ve === le.from && de === le.to) return;
          try {
            X(O);
            return;
          } catch {
          }
        }
        const be = O.state.selection;
        pe && be.from === le.from && be.to === le.to || U();
      };
      O.on("transaction", ge), se(() => O.off("transaction", ge));
    },
    { immediate: !0 }
  ), Q(
    () => [e.disabled(), e.adapter()],
    () => {
      t.value && R();
    }
  ), Q(i, () => {
    g(), a.value = null, l.value = "", o.value = "idle", y.value = null;
  }), kt(g), {
    open: t,
    phase: o,
    instruction: n,
    scope: i,
    target: s,
    candidate: a,
    refinementPreview: S(
      () => a.value ? null : y.value
    ),
    stream: l,
    error: r,
    stale: f,
    submitted: u,
    empty: T,
    suggestions: k,
    busy: M,
    canAccept: _,
    available: x.available,
    selectedContextIds: x.selectedContextIds,
    contextChoices: x.choices,
    receipt: x.receipt,
    notices: c,
    draftFromContext: () => {
      x.selectedContextIds.value = [], x.action.value = "draft", B(n.value.trim() || "根据本次提供的信息起草");
    },
    start: Z,
    close: R,
    cancel: ce,
    stop: ie,
    generate: B,
    regenerate: C,
    accept: N
  };
}
const Id = ["title", "aria-label", "aria-expanded"], Ad = {
  key: 3,
  class: "zx-text-editor-field__message",
  role: "status"
}, kf = /* @__PURE__ */ Te({
  name: "ZxTextEditorField",
  inheritAttrs: !1,
  __name: "text-editor-field",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean },
    placeholder: {},
    id: {},
    contentLimits: {},
    ai: {},
    aiPurpose: {}
  },
  emits: ["update:modelValue", "focus", "blur", "edit-state"],
  setup(e, { expose: t, emit: o }) {
    const n = (W) => Object.fromEntries(
      Object.entries(W).filter(([ye]) => ye !== "class" && ye !== "style")
    );
    An(pi, !0);
    const i = e, s = o, a = {
      root: {
        fontSize: {
          cssValue: "var(--el-font-size-base, 14px)",
          displayValue: "14px"
        },
        fontFamily: { cssValue: "var(--el-font-family)", displayValue: "Default" }
      }
    }, l = Go(), r = Qs(), f = er(), c = tr(), u = Ne(l);
    let p = !1;
    Q(
      () => f.ok ? f.value.value : null,
      () => {
        var Re;
        if (l || !r.ok) return;
        const W = ss({
          nearestScope: f.ok ? f.value.value : null,
          nearestScopeAvailable: f.ok,
          app: c.ok ? c.value : null
        });
        if (!W) return;
        p && ((Re = u.value) == null || Re.dispose());
        const ye = rs(r.value, W);
        ye.ok && (u.value = ye.value, p = !0);
      },
      { immediate: !0 }
    );
    const m = J(), y = J(), M = J(), _ = () => {
      var W;
      return ((W = M.value) == null ? void 0 : W.rootEl) ?? null;
    }, T = (W) => {
      var ye, Re;
      return W instanceof Node && (!!((ye = y.value) != null && ye.contains(W)) || !!((Re = _()) != null && Re.contains(W)));
    };
    let k = !1;
    function g(W) {
      k || s("focus", W), k = !0;
    }
    async function V(W) {
      T(W.relatedTarget) || (await dt(), !T(document.activeElement) && (k = !1, R.value = "", s("blur", W)));
    }
    const U = (W) => {
      m.value = W ?? void 0;
    }, x = J(!1), w = J(""), R = J(""), X = S(() => {
      var W;
      return ((W = m.value) == null ? void 0 : W.editor) ?? null;
    }), Z = Td({
      editor: () => X.value,
      adapter: () => i.ai,
      disabled: () => !!i.disabled || !!i.readonly || x.value,
      limits: () => i.contentLimits,
      purpose: () => i.aiPurpose
    }), ie = S(
      () => !!i.ai && !i.disabled && !i.readonly && Z.available.value
    ), ce = () => {
      Z.open.value ? Z.cancel() : Z.start();
    }, B = hd(() => Z.start()), C = bd({
      suggestions: () => Ni({ target: "selection", empty: !1 }, i.ai),
      disabled: () => !ie.value || x.value,
      open: (W) => Z.start(W)
    }), N = S(
      () => i.ai ? { contributions: [C] } : !0
    ), O = S(() => i.ai ? [B] : []), K = Ut(), se = Qo({
      contributions: [Pn],
      kind: "textEditor.authoring",
      root: y,
      active: ie,
      focusRequired: !0
    }), ge = jt(ri, {
      owner: se,
      keyboardArgs: () => {
      },
      port: tn({
        getState: () => ({ enabled: ie.value && !x.value }),
        subscribe: (W) => Q([ie, x], W, { flush: "sync" }),
        run: () => Z.start()
      })
    }), le = jt(ai, {
      owner: se,
      keyboardArgs: () => {
      },
      port: tn({
        getState: () => ({ enabled: Z.open.value }),
        subscribe: (W) => Q(Z.open, W, { flush: "sync" }),
        run: () => Z.cancel()
      })
    });
    kt(() => {
      ge.dispose(), le.dispose();
    });
    const { text: pe } = cn({
      runtime: K,
      bindingId: "textEditor.askAI.open"
    }), be = S(
      () => pe.value ? `AI 帮写 (${pe.value})` : "AI 帮写"
    ), de = Ne({
      version: 2,
      body: {
        format: "json",
        content: {
          type: "doc",
          content: [
            {
              type: "paragraph",
              attrs: {
                textAlign: null,
                blockId: `blk_${crypto.randomUUID().replaceAll("-", "")}`
              }
            }
          ]
        }
      },
      annotations: [],
      assets: [],
      meta: { schemaVersion: "stable-block-identity/v2" }
    }), _e = S(() => i.modelValue ?? de.value), Ee = S(() => [
      ...x.value ? [{ severity: "error", message: "请完成输入法输入后再提交" }] : [],
      ...w.value ? [{ severity: "error", message: w.value }] : []
    ]), ee = () => s("edit-state", {
      pending: x.value || Z.open.value,
      blocking: Ee.value
    });
    let ne;
    function he(W) {
      if (i.disabled || i.readonly || x.value) return;
      let ye = W;
      try {
        ye = Ye(W, i.contentLimits), w.value = "", ye === null && (de.value = W);
      } catch (Ge) {
        w.value = String(Ge).includes("characters") ? "备注正文最多 5,000 个字符，当前输入已保留" : "备注文档超过资源或结构限制，当前输入已保留";
      }
      const Re = JSON.stringify(ye);
      Re !== JSON.stringify(i.modelValue) && (ne = Re, s("update:modelValue", ye)), ee();
    }
    function oe(W) {
      R.value = W.includes("basic-rich-text:link") ? "链接地址不受支持，请使用 http(s)、mailto 或 tel 链接" : W.includes("basic-rich-text:") ? "该格式不受支持，内容未改变" : W;
    }
    function ze() {
      x.value = !0, ee();
    }
    async function Fe() {
      x.value = !1, await dt(), m.value && he(m.value.getDocument()), ee();
    }
    function Je(W) {
      (W.isComposing || x.value || W.keyCode === 229) && W.key === "Enter" && W.stopPropagation();
    }
    Q(
      () => [i.disabled, i.readonly],
      () => ee()
    ), Q(
      () => i.modelValue,
      (W) => {
        if (!(ne !== void 0 && JSON.stringify(W) === ne)) {
          ne = void 0;
          try {
            Ye(W, i.contentLimits), w.value = "";
          } catch {
            w.value = "备注文档无法读取或超过限制";
          }
          ee();
        }
      },
      { immediate: !0 }
    ), Q([Z.open, Z.busy], ee), Ht(ee), rt(() => {
      var W;
      p && ((W = u.value) == null || W.dispose());
    });
    function Qe() {
      return Z.close(), x.value && m.value && (x.value = !1, he(m.value.getDocument())), null;
    }
    return t({
      focus: () => {
        var W;
        return (W = m.value) == null ? void 0 : W.focus();
      },
      validate: () => (ee(), !Ee.value.length && !Z.open.value),
      captureEdit: Qe
    }), (W, ye) => (L(), F("div", {
      ref_key: "fieldRoot",
      ref: y,
      class: q(["zx-text-editor-field", [
        q(W.$attrs.class),
        {
          "is-disabled": e.disabled,
          "has-ai": ie.value,
          "is-ai-open": v(Z).open.value
        }
      ]]),
      style: ft(ft(W.$attrs.style)),
      onCompositionstart: ze,
      onCompositionend: Fe,
      onKeydownCapture: Je,
      onFocusin: g,
      onFocusout: V
    }, [
      u.value ? (L(), $e(vi, st({
        key: 0,
        id: e.id,
        ref: U
      }, n(W.$attrs), {
        "theme-owner": u.value,
        "content-profile": "basic-rich-text",
        "bubble-toolbar": N.value,
        "slash-catalog-contributions": O.value,
        "content-limits": e.contentLimits,
        "document-value": _e.value,
        "content-type": "document",
        "output-type": "document",
        editable: !e.disabled && !e.readonly,
        typography: a,
        placeholder: e.placeholder ?? (ie.value ? "输入内容；按 / 或点 ✦ 使用 AI 帮写" : "输入内容；输入 / 插入列表，选中文字可设置格式"),
        "onUpdate:documentValue": he,
        onContentIssue: oe
      }), null, 16, ["id", "theme-owner", "bubble-toolbar", "slash-catalog-contributions", "content-limits", "document-value", "editable", "placeholder"])) : ae("", !0),
      ie.value ? (L(), F("button", {
        key: 1,
        type: "button",
        class: q(["zx-text-editor-field__ai", { "is-active": v(Z).open.value }]),
        title: be.value,
        "aria-label": be.value,
        "aria-haspopup": "dialog",
        "aria-expanded": v(Z).open.value,
        "data-testid": "field-ai-trigger",
        onMousedown: ye[0] || (ye[0] = Ke(() => {
        }, ["prevent"])),
        onClick: ce
      }, [
        j(v(xe), {
          icon: "lucide:sparkles",
          "aria-hidden": "true"
        })
      ], 42, Id)) : ae("", !0),
      e.ai ? (L(), $e(gd, {
        key: 2,
        ref_key: "popover",
        ref: M,
        controller: v(Z),
        "theme-owner": u.value,
        anchor: () => y.value,
        onFocusin: g,
        onFocusout: V
      }, null, 8, ["controller", "theme-owner", "anchor"])) : ae("", !0),
      R.value ? (L(), F("p", Ad, me(R.value), 1)) : ae("", !0)
    ], 38));
  }
}), wf = wr(vi), Ed = (e) => {
  const t = On(e.shellState);
  return t.kind === "close-presentation" ? ((e.handlers.closePresentation ?? e.handlers.closeIdle)(), { kind: "close-presentation" }) : t.kind === "dismiss-review-ui" ? (e.handlers.dismissReviewUi(), t) : (t.kind === "close-idle" && e.handlers.closeIdle(), t);
}, jo = (e, t) => Ws({
  getState: e,
  run: t,
  subscribe: (o) => Q(e, o, { flush: "sync" })
});
function xf(e) {
  const t = Qo({
    contributions: [Pn],
    kind: "textEditor.authoring",
    roots: () => [
      qe(e.root),
      ...e.roots ? qe(e.roots) : []
    ].filter((r) => !!r),
    active: e.active,
    focusRequired: !0
  }), o = () => {
    const r = qe(e.editorBindingId).trim();
    if (!r) throw new Error("editorBindingId must not be empty");
    return r;
  };
  let n = 0;
  const i = e.inlineEdit ? jt(br, {
    owner: t,
    keyboardArgs: () => {
    },
    port: jo(
      () => {
        const r = ao(
          e.inlineEdit.getRouteInput()
        );
        return {
          enabled: r.kind !== "closed",
          reason: r.kind === "closed" ? r.reason : void 0
        };
      },
      () => {
        const r = ao(
          e.inlineEdit.getRouteInput()
        );
        return r.kind === "closed" ? null : r.kind === "reveal" ? e.inlineEdit.owner.dispatch(r.actionId, r.binding).then((f) => {
          var c, u;
          return (u = (c = e.inlineEdit).onRevealReceipt) == null || u.call(c, f), f;
        }) : e.inlineEdit.owner.openInvocation({
          context: r.invocationContext,
          surface: {
            surface: "shortcut",
            invokerToken: `inline-edit-shortcut:${o()}`,
            capturedAtLogical: ++n
          }
        });
      }
    )
  }) : null, s = e.askAI ? jt(ri, {
    owner: t,
    keyboardArgs: () => {
    },
    port: {
      ...jo(
        e.askAI.getState,
        () => e.askAI.openInvocation({ surface: "shortcut" })
      ),
      subscribe: e.askAI.subscribe
    }
  }) : null, a = S(() => {
    var f;
    const r = qe(e.escape.shellState);
    return On(r).kind === "noop" && ((f = e.escape.selectionBubble) != null && f.active.value) ? "selection-bubble" : r;
  }), l = jt(ai, {
    owner: t,
    keyboardArgs: () => {
    },
    port: tn({
      getState: () => ({
        enabled: On(a.value).kind !== "noop",
        reason: "no-ai-surface"
      }),
      subscribe: (r) => Q(a, r, { flush: "sync" }),
      run: () => Ed({
        shellState: a.value,
        handlers: a.value === "selection-bubble" ? {
          ...e.escape.handlers,
          closeIdle: () => {
            var r;
            return (r = e.escape.selectionBubble) == null ? void 0 : r.dismiss();
          }
        } : e.escape.handlers
      })
    })
  });
  return kt(() => {
    i == null || i.dispose(), s == null || s.dispose(), l.dispose();
  }), {
    owner: t,
    inlineEdit: i ? yn(i, {
      args: void 0,
      bindingId: "textEditor.inlineEdit.open"
    }) : null,
    askAI: s ? yn(s, {
      args: void 0,
      bindingId: "textEditor.askAI.open"
    }) : null,
    escape: yn(l, {
      args: void 0,
      bindingId: "textEditor.inlineAi.escape"
    })
  };
}
function Tf(e) {
  const t = e.runtime ?? Ut(), o = Yo(), n = Ne(null), i = S(
    () => {
      var l, r;
      return qe(e.root) ?? ((r = (l = qe(e.editor)) == null ? void 0 : l.view) == null ? void 0 : r.dom) ?? null;
    }
  );
  let s = () => {
  };
  const a = Q(
    [() => qe(e.editor), i],
    ([l, r]) => {
      if (s(), s = () => {
      }, n.value = null, !l || !r) return;
      const f = qo(l);
      if (f) {
        if (f.runtime.runtimeId !== t.runtimeId)
          throw new Error("external-editor-shortcut-runtime-mismatch");
        s = Wo(l, (y) => {
          if (y && y.runtime.runtimeId !== t.runtimeId)
            throw new Error("external-editor-shortcut-runtime-mismatch");
          n.value = (y == null ? void 0 : y.editLink) ?? null;
        });
        return;
      }
      const c = t.createOwner({
        contributions: [Pn],
        kind: "textEditor.editor",
        parent: o,
        focusRequired: !0
      }), u = t.attachAction(yr, {
        owner: c,
        keyboardArgs: () => {
        },
        port: tn({
          getState: () => ({
            enabled: qe(e.active) !== !1 && !l.isDestroyed && l.isEditable !== !1 && typeof l.commands.openLinkEditor == "function",
            reason: "link-command-unavailable"
          }),
          subscribe: (y) => {
            var _, T;
            const M = Q(() => qe(e.active), y, {
              flush: "sync"
            });
            return (_ = l.on) == null || _.call(l, "transaction", y), (T = l.on) == null || T.call(l, "update", y), () => {
              var k, g;
              M(), (k = l.off) == null || k.call(l, "transaction", y), (g = l.off) == null || g.call(l, "update", y);
            };
          },
          run: () => {
            const y = l.commands.openLinkEditor;
            if (typeof y != "function")
              throw new Error("link-command-unavailable");
            return y.call(l.commands) === !0;
          }
        })
      }), p = Zs(t, c, { roots: [r] }), m = (y) => p.dispatch(y, "editor");
      r.addEventListener("keydown", m, !0), n.value = u.forArgs(void 0, {
        bindingId: "textEditor.link.edit"
      }), s = () => {
        r.removeEventListener("keydown", m, !0), p.dispose(), u.dispose(), c.dispose();
      };
    },
    { immediate: !0, flush: "sync" }
  );
  return kt(() => {
    a(), s();
  }), { action: n };
}
export {
  bi as A,
  af as B,
  lf as C,
  jl as D,
  cf as E,
  of as F,
  uf as G,
  df as H,
  Ea as I,
  ff as J,
  mi as K,
  Ma as L,
  mf as M,
  vf as N,
  gf as O,
  hf as P,
  bf as Q,
  ba as T,
  wf as Z,
  yf as _,
  Pa as a,
  ha as b,
  pf as c,
  rf as d,
  Ed as e,
  yl as f,
  zl as g,
  Tf as h,
  kf as i,
  Ou as j,
  kn as k,
  _r as l,
  va as m,
  Mr as n,
  Ot as o,
  Vr as p,
  Hr as q,
  wn as r,
  Gr as s,
  _t as t,
  xf as u,
  Zr as v,
  sf as w,
  ka as x,
  ya as y,
  Fa as z
};
//# sourceMappingURL=use-text-editor-command-keybindings-DEFth4pA.mjs.map
