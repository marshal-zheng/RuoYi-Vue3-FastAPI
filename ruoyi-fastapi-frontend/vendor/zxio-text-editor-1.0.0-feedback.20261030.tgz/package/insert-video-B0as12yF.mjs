import { E as f } from "./use-text-editor-command-keybindings-DEFth4pA.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-video-B0as12yF.mjs.map
