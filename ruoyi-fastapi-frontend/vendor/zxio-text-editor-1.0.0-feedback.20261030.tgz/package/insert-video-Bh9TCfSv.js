"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const e=require("./use-text-editor-command-keybindings-CliaqQa5.js");exports.default=e._sfc_main$6;
//# sourceMappingURL=insert-video-Bh9TCfSv.js.map
