import type { TooltipConfig } from './props';
declare var __VLS_40: {};
type __VLS_Slots = {} & {
    popoverContent?: (props: typeof __VLS_40) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
    readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
    readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
    readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | TooltipConfig) | (() => string | TooltipConfig) | (((new (...args: any[]) => string | TooltipConfig) | (() => string | TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    click: (ev: Event) => any;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly icon: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
    readonly name: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown, "", boolean>;
    readonly color: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<readonly [NumberConstructor, StringConstructor], unknown, unknown, "var(--zx-display-icon-default, 1rem)", boolean>;
    readonly hoverColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly className: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | TooltipConfig) | (() => string | TooltipConfig) | (((new (...args: any[]) => string | TooltipConfig) | (() => string | TooltipConfig)) | null)[], unknown, unknown, undefined, boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>> & Readonly<{
    onClick?: ((ev: Event) => any) | undefined;
}>, {
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | TooltipConfig) | (() => string | TooltipConfig) | (((new (...args: any[]) => string | TooltipConfig) | (() => string | TooltipConfig)) | null)[], unknown, unknown>;
    readonly className: string;
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
