# @zxio/http

通用 HTTP 请求库，基于 Axios 封装，支持插件化扩展、自定义通知、Token 管理等。

## 快速开始

### 基础使用

```typescript
import { createHttpClient } from '@zxio/http'

// 创建客户端
const http = createHttpClient({
  axiosConfig: {
    baseURL: '/api',
    timeout: 10000,
  },
})

// 发起请求
const data = await http.get({ url: '/users' })
const user = await http.post({ url: '/users', data: { name: 'John' } })
```

### 配置 Token

```typescript
const http = createHttpClient({
  axiosConfig: { baseURL: '/api' },
  tokenProvider: {
    getToken: () => localStorage.getItem('token') || '',
  },
})

// 请求会自动携带 Authorization header
const data = await http.get({ url: '/profile' })
```

### 自定义成功判定

```typescript
const http = createHttpClient({
  successCodes: [200, 0], // 支持多个成功码
  successResolver: ({ response }) => {
    const { code, data, msg } = response.data
    return {
      ok: code === 0,
      data,
      message: msg,
      code,
      raw: response.data,
    }
  },
})
```

### 集成 Provider scope 管理的反馈

```typescript
import { createHttpClient, createNotifier } from '@zxio/http'
import type { ThemeFeedback } from '@zxio/zxui'

export function createOwnedHttpClient(feedback: ThemeFeedback) {
  return createHttpClient({
    axiosConfig: { baseURL: '/api' },
    notifier: createNotifier({
      message(type, content) {
        return feedback.message({ type, message: content })
      },
      modal(type, { title, content }) {
        return feedback.confirm({ type, title, message: content })
      },
    }),
  })
}
```

由发起请求的 Provider scope 注入 `ThemeFeedback`，消息、确认框、目标节点和
`appContext` 因而共享同一个 owner；不得在 client 单例中捕获无上下文服务。

### 使用 Grid List 插件

```typescript
import { createHttpClient, createGridListPlugin } from '@zxio/http'

const http = createHttpClient({
  axiosConfig: { baseURL: '/api' },
  plugins: [createGridListPlugin()],
})

// 发送请求
await http.post({
  url: '/users',
  data: {
    pager: { page: 1, size: 20 },
    query: { name: 'John' },
  },
})

// 自动转换为
// { page: 1, size: 20, name: 'John' }

// 响应自动补充 pager
// { list: [...], total: 100 } → { list: [...], pager: { page: 1, size: 20, total: 100 } }
```

### 自定义插件

```typescript
const loggerPlugin = {
  name: 'logger',
  setup(client) {
    client.extendTransforms({
      async beforeRequest(config) {
        console.log('Request:', config.url)
        return config
      },
      async afterResponse(response) {
        console.log('Response:', response.status)
        return response
      },
    })
  },
}

const http = createHttpClient({
  plugins: [loggerPlugin],
})
```

### 响应处理顺序

响应按以下顺序处理：

1. 按注册顺序执行全部 `afterResponse`，包括创建后通过 `use` 或
   `extendTransforms` 注册的 hook。返回 `AxiosResponse` 替换当前响应；
   返回普通值（含 `null`、`false`、`0`、空字符串）替换 `response.data`；
   返回 `undefined`/`void` 则保留当前响应。返回数据不再提前结束管线。
2. 正常转换模式下，统一调用一次 `successResolver`，判定加工后的响应，
   处理成功通知或抛出业务错误。
3. 统一返回 resolver 的 `data`，只在最后解包。

`isReturnNativeResponse: true` 仍跳过业务成功判定与解包，返回包含加工后
`data` 的完整 Axios 响应；`isTransformResponse: false` 返回加工后的完整
响应体，同样跳过 resolver。两种模式均执行响应加工 hook，HTTP 传输错误
仍由 Axios 判定。

hook 应保留 resolver 所需的协议字段。Grid List 插件保留 `code/data`
等外层协议，在内层数据中补充列表与 pager，并保留业务附加的非枚举元数据。
它不会代替成功判定或提前解包。该修复改变了以前“返回普通值即终止”的行为；
需要自定义最终返回值时，通过 `successResolver` 明确返回 `data`。

### 参数语义

`params` 只负责 query，`data` 只负责 body，同名字段互不覆盖；不需要模式开关。

```typescript
await http.post({
  url: '/users',
  params: { tenant: 'team-a' },
  data: { nickname: null },
})
```

核心不删除 JSON null，也不把字符串 params 拼成路径段。URLSearchParams 查询与
表单体保留重复键及空字符串；普通 query 的 null/undefined 和请求体编码由 Axios
或调用方 serializer 决定。

`joinTime: true` 为 GET query 补充 `_t`，先复制 URLSearchParams，保留其他重复键。
`joinParamsToUrl: true` 在 token 注入后只将 query 经 Axios serializer 拼入 URL，
消费一次，不将 body 复制到 URL；baseURL 和自定义 paramsSerializer 正常生效。
内建 query token 注入也会先复制 URLSearchParams，不修改调用方实例。
分页插件和自定义 hook 仍按各自的公开契约加工请求。

### 文件上传

```typescript
const http = createHttpClient({ axiosConfig: { baseURL: '/api' } })

await http.upload(
  { url: '/upload' },
  {
    file: fileObject,
    name: 'avatar', // 自定义字段名
    data: { userId: 123 }, // 额外参数
  },
  { timeout: 120000 } // 可选：单次请求选项
)
```

`Content-Type` 交给 axios 与浏览器按 `FormData` 自动补全（含 multipart boundary），手写会让服务端解析失败。

### 请求选项

每个请求可覆盖全局配置：

```typescript
// 不显示成功提示
await http.post({ url: '/users', data }, { successMessageMode: 'none' })

// 错误使用弹窗
await http.get({ url: '/critical' }, { errorMessageMode: 'modal' })

// 不携带 token
await http.get({ url: '/public' }, { withToken: false })

// 自定义提示消息
await http.post(
  { url: '/users', data },
  {
    successNotice: { message: '创建成功！' },
    errorNotice: { message: '创建失败，请重试' },
  }
)
```

### 请求重试

自动重试默认关闭。显式配置 `retry` 后，默认仅重试 GET/HEAD/OPTIONS 的网络、超时和 5xx 传输失败；POST/PUT/PATCH/DELETE 不默认重放。业务确认写操作可安全重放后，才能用 `retryCondition` 显式选择。取消、准备失败和无法归类的本地异常不能被自定义条件放行。

重试只包住 Axios 传输；中间失败不执行 `onError`、失败通知或鉴权钩子。仅最终失败进入一次错误管线，业务 `onError` 增强并抛出同一个错误的行为继续保留。`afterResponse`、`successResolver` 在重试结束后执行，异常不会重发请求；普通异常按原身份抛出，明确的 `HttpError` 拒绝进入一次错误管线。鉴权和错误钩子的异常也按原身份透传。

退避等待响应请求 `signal`，取消后清理计时器和监听器，不发送下一次请求。`AbortError.reason` 保留取消原因，退避取消的 `cause` 保留最近的传输错误（其 `cause` 仍为原始 Axios 错误），`config` 保留该请求上下文。超时仍按每次传输计算。

失败自动重试，支持指数退避：

```typescript
import { createHttpClient, exponentialBackoff } from '@zxio/http'

const http = createHttpClient({
  retry: {
    count: 3, // 最多重试 3 次
    delay: exponentialBackoff, // 指数退避: 1s, 2s, 4s...
  },
})

// 单次请求禁用重试
await http.get({ url: '/api/data' }, { retry: false })
```

### 独立请求与显式取消

每次调用独立发送并完成，即使 URL 和参数相同，也不会自动取消另一次调用或共享结果。
取消由调用方通过 Axios 原生 `signal` 明确控制；同一个 controller 可用于调用方明确
拥有的一组请求，独立操作应使用不同 controller。

```typescript
const controller = new AbortController()
const pending = http.get({ url: '/users', signal: controller.signal })
controller.abort('leave-page')

try {
  await pending
} catch (error) {
  if (!isAbortError(error)) throw error
}
```

上例的 `isAbortError` 从 `@zxio/http` 导入。搜索等交互需要替换上一次请求时，由同一个
交互实例保存并取消自己的 controller。取消客户端等待不代表撤销服务端已经执行的写入。
显式并发插件仍负责队列上限、优先级与其自身请求的取消。

读取结果需要跨组件共享、缓存和失效管理时，可在应用查询层采用 TanStack Query 等
成熟方案，明确数据 key 和调用范围；HTTP 核心不管理查询缓存或业务提交锁。

### 破坏性变更迁移

- 删除 `deduplication`、`deduplicate`、`ignoreCancelToken` 与 `parameterMode`。
- 删除 `AxiosCanceler`、`getPendingKey`、`DedupManager`、`createDedupManager`、
  `defaultKeyGenerator` 以及仅服务于旧指纹/参数清理的工具导出。
- 普通请求默认独立；显式取消使用 `config.signal`，不再通过参数指纹替换请求。
- 路径直接写入 `url`，body 显式写入 `data`；删除 query 向 body 复制与 null 清理的旧路径。
- 同步更新调用、类型与示例，不保留 legacy 分支。

### 超时控制

超时优先级由高到低为：单次请求第二参数的 `timeout`、单次请求配置中的
`requestOptions.timeout`、单次 Axios 配置中的 `timeout`、客户端默认
`requestOptions.timeout`，最后使用客户端分类型超时。`0` 表示禁用超时。
普通请求的分类型默认值优先使用 `timeout.default`，然后回退到
`axiosConfig.timeout` 和内置的 10 秒；上传、下载保留独立的 60 秒默认值。

```typescript
// 单次 Axios 配置可直接覆盖下载默认超时。
await http.get({ url: '/export', responseType: 'blob', timeout: 120000 })
```

不同请求类型使用不同超时：

```typescript
const http = createHttpClient({
  timeout: {
    default: 10000, // 普通请求 10s
    upload: 60000, // 上传 60s
    download: 60000, // 下载 60s
  },
})
```

### 错误类型

`HttpError` 保留原始 `cause`、`response` 以及请求配置（`config` 与兼容的
`request` 指向同一配置）；重复调用 `createHttpError` 会返回已分类的原错误。
业务可在错误上附加领域信息，无需重新包装成普通 `Error`。

请求前置加工、token 获取/应用、URL 拼接及超时配置失败统一为
`RequestPreparationError`（`ERR_REQUEST_PREPARATION`）。`cause` 保留原始抛出值，
`config/request` 保留最后一次成功加工的请求配置，包含调用方的反馈及上下文选项。
该阶段位于自动重试之外，仅进入一次既有 `onError` 管线；调用方修正条件后可重新发起。
准备期间取消仍为 `AbortError`，保留原始取消原因。

`onError` 接收已规范化的 `HttpError`，返回值不恢复请求，抛错沿用既有的终止管线语义。
`createHttpError(error, fallbackConfig?)` 和 `resolveHttpError(error, fallbackConfig?)`
接受任意抛出值，仅在原错误缺少配置时使用备用配置；已有 `HttpError` 保持原实例。
无响应本身不代表网络错误：明确网络错误代码或 Axios transport 对象才是网络证据。
Axios 内部加工等无法可靠归属阶段的本地异常保留基础 `HttpError`，默认不自动重试。

二进制失败体可通过 `await resolveHttpError(error)` 解码为 `error.data`，
支持 Blob、ArrayBuffer 与视图中的 JSON/Problem Details，以及明确的 text/plain。
默认错误处理已调用此入口；自定义 onError 在需要规范错误时也应 await 它。
原始 `raw`、`response.data`、`response` 和 `cause` 保持原值，重复解析已解码的
HttpError 保持同一实例。读取前限制为 1 MiB；读取失败、格式无效或超过限额时
保留原错误，取消直接跳过。同步 `createHttpError` 的既有契约不变。
该入口只处理已知失败，不将合法 JSON/文本下载自动判为错误。

主动取消统一为 `AbortError`，`code` 为 `ERR_CANCELED`，可用
`isAbortError(error)` 判断。`reason` 保留外部 signal 的取消原因。默认客户端
不为取消发出失败通知或鉴权失败回调，业务反馈也应跳过取消。

普通请求直接使用调用方的 signal，不建立指纹登记。并发插件取消使用实际派发的
signal，结束时清理连接的监听；排队请求收到外部取消后立即拒绝，且不会反向取消
调用方的 controller。

细分错误类型，便于精确处理：

```typescript
import {
  RequestPreparationError,
  NetworkError,
  TimeoutError,
  ValidationError,
  ServerError,
} from '@zxio/http'

try {
  await http.get({ url: '/api/data' })
} catch (e) {
  if (e instanceof RequestPreparationError)
    console.log('请求准备失败:', e.cause)
  if (e instanceof NetworkError) console.log('网络不可用')
  if (e instanceof TimeoutError) console.log('请求超时')
  if (e instanceof ValidationError) console.log('参数错误:', e.status)
  if (e instanceof ServerError) console.log('服务器错误:', e.status)
}
```

### 并发控制

限制最大并发数，支持优先级：

```typescript
import { createHttpClient, createConcurrencyPlugin } from '@zxio/http'

const http = createHttpClient({
  plugins: [createConcurrencyPlugin({ maxConcurrent: 6 })],
})

// 高优先级请求优先执行
await http.get({ url: '/api/important' }, { priority: 10 })
```

### 类型安全 API

定义 API 端点，获得完整类型推导：

```typescript
import { createHttpClient, createTypedAPI } from '@zxio/http'

const api = createTypedAPI(http, {
  getUser: { method: 'GET', url: '/api/users/:id' },
  createUser: { method: 'POST', url: '/api/users' },
})

const user = await api.getUser({ id: 1 })
```

### 增强日志

结构化日志输出：

```typescript
import { createHttpClient, createEnhancedLogger } from '@zxio/http'

const http = createHttpClient({
  logger: createEnhancedLogger({
    enabled: true,
    level: 'debug',
    format: 'pretty', // pretty | json
  }),
})
```

## API

### createHttpClient(config)

创建 HTTP 客户端实例。

**参数：**

- `axiosConfig` - Axios 配置对象
- `tokenProvider` - Token 提供器
  - `getToken(): string | Promise<string>` - 获取 token
  - `applyToken?(config, token, options)` - 自定义 token 应用方式
  - `onAuthError?(error)` - 401 错误回调
- `notifier` - 通知适配器
  - `message(type, content)` - 消息通知
  - `modal(type, { title, content })` - 弹窗通知
- `successResolver` - 自定义成功判定
- `successCodes` - 成功状态码数组
- `requestOptions` - 默认请求选项
- `plugins` - 插件数组
- `logger` - 日志记录器

### 请求方法

- `http.get(config, options)` - GET 请求
- `http.post(config, options)` - POST 请求
- `http.put(config, options)` - PUT 请求
- `http.delete(config, options)` - DELETE 请求
- `http.upload(config, uploadOption, options)` - 文件上传
- `http.request(config, options)` - 通用请求

### 客户端实例

- `createHttpClient(config)` - 默认多例；`singleton: true` 时复用同一实例
- `resetHttpClientSingleton()` - 释放单例，使下一次创建重新读取配置

### 插件

- `createGridListPlugin(options)` - Grid List 数据转换插件
- `createConcurrencyPlugin(options)` - 并发控制插件；同一 client 只会接管一次，`teardown(client)` 可还原

## 类型定义

```typescript
interface HttpClientConfig {
  axiosConfig?: AxiosRequestConfig
  tokenProvider?: HttpTokenProvider
  notifier?: HttpNotifier
  successResolver?: SuccessResolver
  successCodes?: Array<string | number>
  requestOptions?: RequestOptions
  plugins?: HttpPlugin[]
  logger?: HttpClientLogger
}

interface RequestOptions {
  withToken?: boolean
  successMessageMode?: 'auto' | 'message' | 'modal' | 'none'
  errorMessageMode?: 'message' | 'modal' | 'none'
  showSuccessMessage?: boolean
  showErrorMessage?: boolean
  isTransformResponse?: boolean
  isReturnNativeResponse?: boolean
  joinParamsToUrl?: boolean
  joinTime?: boolean
  successNotice?: { title?: string; message?: string }
  errorNotice?: { title?: string; message?: string }
  context?: Record<string, unknown>
}
```

### 日志与通知异常隔离

日志、通知回调和通知订阅监听器属于旁路。同步抛错及返回 Promise 的拒绝分别隔离，
请求不等待它们完成；单个监听器失败不阻止其他监听器或 message/modal 通道。
异步回调应返回 Promise，不要用 `void` 脱离返回链，否则客户端无法接住其拒绝。
转换上下文中的日志／通知以及 `setNotifier` 也遵循此规则。

响应转换、`successResolver`、Token 准备和 `onAuthError` 仍参与请求语义，异常继续使
请求失败；`onError` 抛错仍终止错误管线。业务在转换钩子里调用提示时，应在业务反馈
边界隔离展示异常，不得吞掉整个转换钩子的错误。
