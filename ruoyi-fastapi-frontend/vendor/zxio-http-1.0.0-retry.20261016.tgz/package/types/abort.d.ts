import type { GenericAbortSignal } from 'axios';
export declare function createLinkedAbortController(signal?: GenericAbortSignal): {
    controller: AbortController;
    dispose: () => void;
};
