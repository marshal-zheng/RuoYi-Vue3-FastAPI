import type { BackendConfig, SuccessResolver } from './types.js';
export declare function getDefaultSuccessResolver(successCodes?: Array<string | number>, backendConfig?: BackendConfig): SuccessResolver;
