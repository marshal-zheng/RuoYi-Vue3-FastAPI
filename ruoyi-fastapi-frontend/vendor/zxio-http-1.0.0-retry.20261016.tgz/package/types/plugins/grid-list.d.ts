import type { HttpPlugin, HttpRequestConfig, ResolvedRequestOptions } from '../types.js';
export interface GridListPluginOptions {
    predicate?(config: HttpRequestConfig, options: ResolvedRequestOptions): boolean;
    requestPagerKey?: string;
    responsePagerKey?: string;
    pageField?: string;
    sizeField?: string;
    totalField?: string;
    listField?: string;
    resolveList?(payload: Record<string, unknown>): unknown[] | undefined;
    resolveTotal?(payload: Record<string, unknown>): number | undefined;
}
export declare function createGridListPlugin(options?: GridListPluginOptions): HttpPlugin;
