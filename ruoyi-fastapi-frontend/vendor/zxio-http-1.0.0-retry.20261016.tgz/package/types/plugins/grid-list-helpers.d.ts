import type { HttpRequestConfig, ResolvedRequestOptions } from '../types.js';
import type { GridListPluginOptions } from './grid-list.js';
export declare const DEFAULT_PAGE_FIELD = "page";
export declare const DEFAULT_SIZE_FIELD = "size";
export declare const DEFAULT_TOTAL_FIELD = "total";
export declare const DEFAULT_LIST_FIELD = "list";
export interface PagerPayload {
    payload: Record<string, unknown>;
    page: number;
    size: number;
}
export declare function extractPagerPayload(source: unknown, pagerKey: string, pageField: string, sizeField: string): PagerPayload | undefined;
export declare function resolveListField(payload: Record<string, unknown>, listField: string, resolver?: GridListPluginOptions['resolveList']): any[] | undefined;
export declare function resolveTotalField(payload: Record<string, unknown>, totalField: string, resolver?: GridListPluginOptions['resolveTotal']): number | undefined;
export declare function shouldHandle(config: HttpRequestConfig, options: ResolvedRequestOptions, predicate: GridListPluginOptions['predicate'] | undefined, requestPagerKey: string, pageField: string, sizeField: string): boolean;
