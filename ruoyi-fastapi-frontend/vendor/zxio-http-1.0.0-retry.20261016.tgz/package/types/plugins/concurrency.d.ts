import type { HttpClient, HttpPlugin, HttpRequestConfig } from '../types.js';
export interface ConcurrencyPluginOptions {
    /** 最大并发数，默认 6 */
    maxConcurrent?: number;
}
export interface QueuedRequest {
    id: string;
    priority: number;
    execute: () => Promise<unknown>;
    resolve: (value: unknown) => void;
    reject: (error: unknown) => void;
    abortController?: AbortController;
    config?: HttpRequestConfig;
    dispose?: () => void;
}
export declare class ConcurrencyPlugin implements HttpPlugin {
    readonly name = "concurrency";
    private queue;
    private running;
    private maxConcurrent;
    private readonly patchedState;
    private inFlightControllers;
    constructor(options?: ConcurrencyPluginOptions);
    setup(client: HttpClient): void;
    /**
     * 还原被接管的 request，并拒绝仍在排队的请求
     */
    teardown(client: HttpClient): void;
    /**
     * 将请求加入队列
     */
    private enqueueRequest;
    /**
     * 入队请求
     */
    enqueue(request: QueuedRequest): void;
    /**
     * 处理队列
     */
    processQueue(): void;
    /**
     * 取消排队中的请求
     */
    cancel(id: string): boolean;
    private cancelQueuedRequest;
    /**
     * 获取当前队列长度
     */
    getQueueLength(): number;
    /**
     * 获取当前运行中的请求数
     */
    getRunningCount(): number;
    /**
     * 清空队列
     */
    clearQueue(): void;
    /**
     * 使用外部传入的 context id，否则生成一个新的 id
     */
    private resolveRequestId;
}
/**
 * 创建并发控制插件
 */
export declare function createConcurrencyPlugin(options?: ConcurrencyPluginOptions): HttpPlugin;
