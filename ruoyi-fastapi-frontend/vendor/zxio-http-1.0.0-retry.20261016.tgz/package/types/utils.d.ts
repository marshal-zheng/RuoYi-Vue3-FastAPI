import type { RequestOptions, ResolvedRequestOptions } from './types.js';
export declare function isPlainObject(value: unknown): value is Record<string, unknown>;
export declare function deepMerge<T extends Record<string, unknown>>(target: T, ...sources: Array<Record<string, unknown> | undefined>): T;
export declare function joinTimestamp(join: boolean | undefined): {
    _t: number;
} | {
    _t?: undefined;
};
export declare function resolveRequestOptions(base?: RequestOptions, override?: RequestOptions, defaults?: {
    successCodes?: Array<string | number>;
}): ResolvedRequestOptions;
