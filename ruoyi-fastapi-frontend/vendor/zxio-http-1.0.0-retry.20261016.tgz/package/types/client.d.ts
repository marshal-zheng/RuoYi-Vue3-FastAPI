import { type AxiosInstance, type AxiosRequestConfig } from 'axios';
import type { HttpClient, HttpClientConfig, HttpNotifier, HttpPlugin, HttpRequestConfig, HttpTransformHook, RequestOptions, UploadFileOption } from './types.js';
export declare class HttpClientImpl implements HttpClient {
    readonly axiosInstance: AxiosInstance;
    readonly config: HttpClientConfig;
    private notifier;
    private readonly transforms;
    private readonly defaultResolver;
    private readonly logger?;
    private readonly timeoutManager;
    private readonly globalRetryConfig;
    constructor(config?: HttpClientConfig);
    setNotifier(notifier: HttpNotifier): void;
    extendTransforms(transform: HttpTransformHook): void;
    use(plugin: HttpPlugin): this;
    request<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    /**
     * 解析重试配置
     */
    private resolveRetryConfig;
    get<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    post<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    put<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    delete<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    upload<T = unknown>(config: AxiosRequestConfig, option: UploadFileOption, options?: RequestOptions): Promise<T>;
    private runAfterResponseHooks;
    private runErrorHooks;
    private getTransformContext;
    private applyToken;
    private resolveTokenDescriptor;
    private emitNotification;
    private log;
    private resolveLogger;
    private handleBeforeRequest;
    private finalizeResponse;
    private handleError;
}
export declare function createHttpClient(config?: HttpClientConfig): HttpClientImpl;
/**
 * 释放单例，使下一次 createHttpClient({ singleton: true }) 用新配置重建。
 */
export declare function resetHttpClientSingleton(): void;
