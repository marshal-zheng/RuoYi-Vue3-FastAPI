/** Invoke a side effect without changing the request or waiting for its completion. */
export declare function runObserver(observer: () => unknown): void;
