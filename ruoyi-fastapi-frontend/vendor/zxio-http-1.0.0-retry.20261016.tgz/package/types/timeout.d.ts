import type { HttpRequestConfig } from './types.js';
export interface TimeoutConfig {
    /** 默认超时时间（毫秒），默认 10000 */
    default?: number;
    /** 上传请求超时时间（毫秒），默认 60000 */
    upload?: number;
    /** 下载请求超时时间（毫秒），默认 60000 */
    download?: number;
}
export declare class TimeoutManager {
    private config;
    constructor(config?: TimeoutConfig | number);
    /**
     * 根据请求类型获取超时时间
     */
    getTimeout(config: HttpRequestConfig, requestTimeout?: number): number;
    /**
     * 判断是否为上传请求
     */
    isUploadRequest(config: HttpRequestConfig): boolean;
    /**
     * 判断是否为下载请求
     */
    isDownloadRequest(config: HttpRequestConfig): boolean;
    /**
     * 获取当前配置
     */
    getConfig(): Required<TimeoutConfig>;
}
/**
 * 创建超时管理器
 */
export declare function createTimeoutManager(config?: TimeoutConfig | number): TimeoutManager;
