import type { AxiosRequestConfig, AxiosResponse } from 'axios';
export interface HttpErrorPayload {
    status?: number;
    code?: string | number;
    message: string;
    data?: unknown;
    raw?: unknown;
    cause?: unknown;
}
export type HttpErrorName = 'HttpError' | 'RequestPreparationError' | 'NetworkError' | 'TimeoutError' | 'AbortError' | 'ValidationError' | 'ServerError';
/**
 * 基础 HTTP 错误类
 */
export declare class HttpError extends Error {
    readonly name: HttpErrorName;
    status?: number;
    code?: string | number;
    data?: unknown;
    raw?: unknown;
    response?: AxiosResponse;
    request?: AxiosRequestConfig;
    cause?: unknown;
    get config(): AxiosRequestConfig<any, any> | undefined;
    constructor(payload: HttpErrorPayload, response?: AxiosResponse, request?: AxiosRequestConfig);
    toJSON(): Record<string, unknown>;
}
/** The target request could not be prepared; no transport attempt was made. */
export declare class RequestPreparationError extends HttpError {
    readonly name: HttpErrorName;
    constructor(cause: unknown, request?: AxiosRequestConfig);
}
/**
 * 网络不可达错误
 */
export declare class NetworkError extends HttpError {
    readonly name: HttpErrorName;
    constructor(payload: HttpErrorPayload, response?: AxiosResponse, request?: AxiosRequestConfig);
}
/**
 * 请求超时错误
 */
export declare class TimeoutError extends HttpError {
    readonly name: HttpErrorName;
    constructor(payload: HttpErrorPayload, response?: AxiosResponse, request?: AxiosRequestConfig);
}
/**
 * 请求被取消错误
 */
export declare class AbortError extends HttpError {
    readonly name: HttpErrorName;
    readonly reason?: unknown;
    constructor(payload: HttpErrorPayload & {
        reason?: unknown;
    }, response?: AxiosResponse, request?: AxiosRequestConfig);
}
/**
 * 客户端验证错误 (4xx)
 */
export declare class ValidationError extends HttpError {
    readonly name: HttpErrorName;
    constructor(payload: HttpErrorPayload, response?: AxiosResponse, request?: AxiosRequestConfig);
}
/**
 * 服务端错误 (5xx)
 */
export declare class ServerError extends HttpError {
    readonly name: HttpErrorName;
    constructor(payload: HttpErrorPayload, response?: AxiosResponse, request?: AxiosRequestConfig);
}
/**
 * 根据 Axios 错误创建对应的 HttpError 子类
 */
export declare function isAbortError(error: unknown): boolean;
export declare function createHttpError(error: unknown, fallbackConfig?: AxiosRequestConfig): HttpError;
/** 解码二进制失败体；原始 cause、response 和 raw 保持不变。 */
export declare function resolveHttpError(error: unknown, fallbackConfig?: AxiosRequestConfig): Promise<HttpError>;
