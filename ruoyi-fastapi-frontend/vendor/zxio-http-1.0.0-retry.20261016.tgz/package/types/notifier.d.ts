import type { HttpNotifier } from './types.js';
export declare const noopNotifier: HttpNotifier;
export declare function createNotifier(overrides?: Partial<HttpNotifier>): HttpNotifier;
