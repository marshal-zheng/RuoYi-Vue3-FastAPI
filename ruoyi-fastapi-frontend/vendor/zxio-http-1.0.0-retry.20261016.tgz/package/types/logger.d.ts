import type { HttpClientLogger } from './types.js';
export type LogLevel = 'debug' | 'info' | 'warn' | 'error';
export type LogFormat = 'pretty' | 'json';
export interface LoggerConfig {
    /** 是否启用日志，默认 false */
    enabled?: boolean;
    /** 日志级别，默认 'info' */
    level?: LogLevel;
    /** 日志格式，默认 'pretty' */
    format?: LogFormat;
    /** 自定义日志输出函数 */
    output?: (level: LogLevel, message: string, meta?: Record<string, unknown>) => void;
}
export interface LogEntry {
    timestamp: string;
    level: LogLevel;
    event: string;
    url?: string;
    method?: string;
    status?: number;
    duration?: number;
    headers?: Record<string, string>;
    params?: Record<string, unknown>;
    data?: unknown;
    error?: unknown;
}
export declare class EnhancedLogger implements HttpClientLogger {
    private config;
    constructor(config?: LoggerConfig);
    debug(message: string, meta?: Record<string, unknown>): void;
    info(message: string, meta?: Record<string, unknown>): void;
    warn(message: string, meta?: Record<string, unknown>): void;
    error(message: string, meta?: Record<string, unknown>): void;
    /**
     * 核心日志方法
     */
    private log;
    /**
     * 判断是否应该输出该级别的日志
     */
    private shouldLog;
    /**
     * 默认日志输出
     */
    private defaultOutput;
    /**
     * 创建日志条目
     */
    private createEntry;
    /**
     * 格式化日志条目
     */
    private formatEntry;
    /**
     * Pretty 格式输出
     */
    private formatPretty;
    /**
     * 获取当前配置
     */
    getConfig(): Required<LoggerConfig>;
    /**
     * 更新配置
     */
    setConfig(config: Partial<LoggerConfig>): void;
    /**
     * 启用日志
     */
    enable(): void;
    /**
     * 禁用日志
     */
    disable(): void;
}
/**
 * 创建增强日志器
 */
export declare function createEnhancedLogger(config?: LoggerConfig): EnhancedLogger;
