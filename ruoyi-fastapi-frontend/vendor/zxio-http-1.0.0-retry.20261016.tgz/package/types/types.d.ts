import { HttpError, type HttpErrorPayload } from './errors.js';
import type { AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
import type { TimeoutConfig } from './timeout.js';
import type { RetryConfig } from './retry.js';
import type { LoggerConfig } from './logger.js';
export { HttpError, HttpErrorPayload };
export type Primitive = string | number | boolean | bigint | symbol | null | undefined;
/** Side effects: synchronous throws and returned promise rejections are isolated. */
export interface HttpClientLogger {
    debug?(message: string, meta?: Record<string, unknown>): void;
    info?(message: string, meta?: Record<string, unknown>): void;
    warn?(message: string, meta?: Record<string, unknown>): void;
    error?(message: string, meta?: Record<string, unknown>): void;
}
export type HttpNotificationLevel = 'success' | 'info' | 'warning' | 'error';
export type HttpNotificationChannel = 'message' | 'modal' | 'custom';
export interface HttpNotificationPayload {
    title?: string;
    content: string;
    details?: Record<string, unknown>;
}
export interface HttpNotificationEvent {
    level: HttpNotificationLevel;
    channel: HttpNotificationChannel;
    payload: HttpNotificationPayload;
    request?: {
        url?: string;
        method?: string;
        options?: ResolvedRequestOptions;
    };
    response?: AxiosResponse;
    error?: unknown;
}
export type HttpNotificationListener = (event: HttpNotificationEvent) => void;
/** Side effects are not awaited. Return asynchronous work so rejections can be isolated. */
export interface HttpNotifier {
    notify(event: HttpNotificationEvent): void;
    subscribe?(listener: HttpNotificationListener): () => void;
    message?(type: HttpNotificationLevel, content: string): void;
    modal?(type: Exclude<HttpNotificationLevel, 'success'>, options: {
        title?: string;
        content: string;
    }): void;
}
export interface HttpTokenProvider {
    getToken(): string | HttpTokenDescriptor | Promise<string | HttpTokenDescriptor>;
    resolveAuthorizationHeader?(token: string): string;
    applyToken?(config: HttpRequestConfig, token: HttpResolvedToken, options: ResolvedRequestOptions): void | Promise<void>;
    onAuthError?(error: HttpError): void | Promise<void>;
}
export interface HttpTokenDescriptor {
    value: string;
    header?: string;
    scheme?: string;
    headerName?: string;
    queryParam?: string;
}
export interface HttpResolvedToken {
    value: string;
    headerName: string;
    headerValue: string;
    queryParam?: string;
}
export interface SuccessResolverContext<T = unknown> {
    response: AxiosResponse<T>;
    options: ResolvedRequestOptions;
}
export interface SuccessResolverResult<T = unknown> {
    ok: boolean;
    data: T;
    message?: string;
    code?: string | number;
    raw?: unknown;
}
export type SuccessResolver<T = unknown> = (ctx: SuccessResolverContext) => SuccessResolverResult<T>;
export interface HttpTransformContext {
    client: HttpClient;
    axiosInstance: AxiosInstance;
    notifier: HttpNotifier;
    logger?: HttpClientLogger;
}
export interface HttpTransformHook {
    beforeRequest?(config: AxiosRequestConfig, options: ResolvedRequestOptions, context: HttpTransformContext): AxiosRequestConfig | Promise<AxiosRequestConfig>;
    /**
     * 按注册顺序加工响应。返回 AxiosResponse 替换响应，普通值替换 data，
     * undefined/void 保留当前响应；所有 hook 完成后统一成功判定与解包。
     * 加工时需保留 successResolver 所需的协议字段。
     */
    afterResponse?<T = unknown>(response: AxiosResponse<T>, options: ResolvedRequestOptions, context: HttpTransformContext): T | AxiosResponse<T> | void | Promise<T | AxiosResponse<T> | void>;
    /** Receives a normalized error, including preparation failures; throwing terminates the pipeline. */
    onError?(error: HttpError, options: ResolvedRequestOptions, context: HttpTransformContext): unknown | Promise<unknown>;
}
export interface HttpPlugin {
    name: string;
    setup(client: HttpClient): void;
}
export interface RequestNoticeOptions {
    mode?: 'message' | 'modal' | 'none';
    message?: string;
    title?: string;
}
export interface RequestOptions {
    joinParamsToUrl?: boolean;
    joinTime?: boolean;
    withToken?: boolean;
    isTransformResponse?: boolean;
    isReturnNativeResponse?: boolean;
    successMessageMode?: 'auto' | 'message' | 'modal' | 'none';
    showSuccessMessage?: boolean;
    errorMessageMode?: 'message' | 'modal' | 'none';
    showErrorMessage?: boolean;
    successResolver?: SuccessResolver;
    successCodes?: Array<string | number>;
    context?: Record<string, unknown>;
    successNotice?: RequestNoticeOptions;
    errorNotice?: RequestNoticeOptions;
    /** 单次请求的超时时间（毫秒） */
    timeout?: number;
    /** 单次请求的重试配置，false 禁用重试 */
    retry?: RetryConfig | false;
    /** 请求优先级（用于并发控制），数值越大优先级越高 */
    priority?: number;
}
export type ResolvedRequestOptions = Required<Pick<RequestOptions, 'joinParamsToUrl' | 'joinTime' | 'withToken' | 'isTransformResponse' | 'isReturnNativeResponse' | 'successMessageMode' | 'showSuccessMessage' | 'errorMessageMode' | 'showErrorMessage'>> & RequestOptions;
export interface HttpClientConfig {
    axiosConfig?: AxiosRequestConfig;
    requestOptions?: RequestOptions;
    notifier?: HttpNotifier;
    tokenProvider?: HttpTokenProvider;
    successResolver?: SuccessResolver;
    successCodes?: Array<string | number>;
    logger?: HttpClientLogger | LoggerConfig;
    transforms?: HttpTransformHook[];
    plugins?: HttpPlugin[];
    backendConfig?: BackendConfig;
    /** 超时配置 */
    timeout?: TimeoutConfig | number;
    /** 重试配置，false 禁用重试 */
    retry?: RetryConfig | false;
    /** 是否启用单例模式，默认 false（多例） */
    singleton?: boolean;
}
export interface BackendConfig {
    codeKey?: string;
    dataKey?: string;
    messageKey?: string;
    successCode?: string | number;
}
export interface UploadFileOption {
    data?: Record<string, unknown>;
    file: File | Blob | Array<File | Blob>;
    name?: string;
    filename?: string;
    isMultiple?: boolean;
}
export type HttpRequestConfig = AxiosRequestConfig & {
    requestOptions?: RequestOptions;
};
export interface HttpClient {
    readonly axiosInstance: AxiosInstance;
    readonly config: HttpClientConfig;
    request<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    get<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    post<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    put<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    delete<T = unknown>(config: HttpRequestConfig, options?: RequestOptions): Promise<T>;
    upload<T = unknown>(config: AxiosRequestConfig, option: UploadFileOption, options?: RequestOptions): Promise<T>;
    use(plugin: HttpPlugin): HttpClient;
    extendTransforms(transform: HttpTransformHook): void;
    setNotifier(notifier: HttpNotifier): void;
}
