import { HttpError } from './errors.js';
import type { AxiosRequestConfig } from 'axios';
export interface RetryConfig {
    /** 最大重试次数，默认 3 */
    count?: number;
    /** 重试延迟（毫秒）或延迟函数 */
    delay?: number | ((attempt: number, error: HttpError) => number);
    /** 传输失败的重试条件；可显式允许业务确认幂等的写请求，不能重试取消或准备失败 */
    retryCondition?: (error: HttpError) => boolean;
}
export interface RetryState {
    retries: number;
    lastError: HttpError | null;
}
/**
 * 默认仅重试 GET/HEAD/OPTIONS 的网络、超时或服务端失败；缺少上下文不自动重放。
 */
export declare function defaultRetryCondition(error: HttpError): boolean;
/**
 * 指数退避延迟函数
 */
export declare function exponentialBackoff(attempt: number, baseDelay?: number, maxDelay?: number): number;
export declare class RetryManager {
    private config;
    constructor(config?: RetryConfig);
    /**
     * 判断是否应该重试
     */
    shouldRetry(error: HttpError, state: RetryState): boolean;
    /**
     * 获取下次重试的延迟时间
     */
    getDelay(attempt: number, error: HttpError): number;
    /**
     * 执行带重试的请求
     */
    execute<T>(fn: () => Promise<T>, request?: AxiosRequestConfig): Promise<T>;
    /**
     * 获取当前配置
     */
    getConfig(): Required<RetryConfig>;
    private sleep;
}
/**
 * 创建重试管理器
 */
export declare function createRetryManager(config?: RetryConfig): RetryManager;
