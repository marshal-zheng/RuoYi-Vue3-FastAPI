export declare const ZxNotification: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    title: any;
    message: any;
    type: {
        type: import("vue").PropType<import("element-plus").NotificationType | undefined>;
        default: string;
    };
    appearance: any;
    icon: any;
    closeIcon: {
        type: import("vue").PropType<string | import("vue").Component>;
    };
    closeLabel: any;
    action: any;
    customStyle: any;
    showClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    dangerouslyUseHTMLString: any;
    announce: any;
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    close: () => true;
    click: (_event: MouseEvent) => true;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    title: any;
    message: any;
    type: {
        type: import("vue").PropType<import("element-plus").NotificationType | undefined>;
        default: string;
    };
    appearance: any;
    icon: any;
    closeIcon: {
        type: import("vue").PropType<string | import("vue").Component>;
    };
    closeLabel: any;
    action: any;
    customStyle: any;
    showClose: {
        type: BooleanConstructor;
        default: boolean;
    };
    dangerouslyUseHTMLString: any;
    announce: any;
}>> & Readonly<{
    onClick?: ((_event: MouseEvent) => any) | undefined;
    onClose?: (() => any) | undefined;
}>, {
    icon: any;
    message: any;
    title: any;
    type: import("element-plus").NotificationType | undefined;
    dangerouslyUseHTMLString: any;
    showClose: boolean;
    appearance: any;
    action: any;
    closeLabel: any;
    customStyle: any;
    announce: any;
}, import("vue").SlotsType<import("./src/types").ZxNotificationSlots>, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export default ZxNotification;
export type { ZxNotificationConfig, ZxNotificationOptions, ZxNotificationParams, ZxNotificationSlots, } from './src/types';
