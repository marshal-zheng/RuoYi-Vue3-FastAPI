declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly sources: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").IconSource[]) | (() => import("./props").IconSource[]) | {
        (): import("./props").IconSource[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").IconSource[]) | (() => import("./props").IconSource[]) | {
        (): import("./props").IconSource[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => string[], boolean>;
    readonly iconifyCollections: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | {
        (): string[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string[]) | (() => string[]) | {
        (): string[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    readonly customIcons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").IconMeta[]) | (() => import("./props").IconMeta[]) | {
        (): import("./props").IconMeta[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").IconMeta[]) | (() => import("./props").IconMeta[]) | {
        (): import("./props").IconMeta[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    readonly tabMode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "source" | "custom" | "category") | (() => import("./props").IconTabMode) | {
        (): import("./props").IconTabMode;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "source" | "custom" | "category") | (() => import("./props").IconTabMode) | {
        (): import("./props").IconTabMode;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "source", boolean>;
    readonly showTabs: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly categories: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").IconCategory[]) | (() => import("./props").IconCategory[]) | {
        (): import("./props").IconCategory[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").IconCategory[]) | (() => import("./props").IconCategory[]) | {
        (): import("./props").IconCategory[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    readonly columns: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
    readonly itemHeight: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 48, boolean>;
    readonly panelHeight: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 280, boolean>;
    readonly panelMode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
        (): "dialog" | "popover";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
        (): "dialog" | "popover";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "popover", boolean>;
    readonly popoverWidth: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 540, boolean>;
    readonly placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | {
        (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | {
        (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "bottom-start", boolean>;
    readonly showArrow: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly allowModeSwitch: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly searchable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly searchPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "header" | "panel") | (() => import("./props").IconSearchPlacement) | {
        (): import("./props").IconSearchPlacement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "header" | "panel") | (() => import("./props").IconSearchPlacement) | {
        (): import("./props").IconSearchPlacement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "panel", boolean>;
    readonly showRecent: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly showFooter: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly recentMax: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly recentScope: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import("./props").RecentScope) | {
        (): import("./props").RecentScope;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import("./props").RecentScope) | {
        (): import("./props").RecentScope;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "global", boolean>;
    readonly recentScopeKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly recentScopeResolver: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (icon: import("./props").IconMeta) => string) | (() => (icon: import("./props").IconMeta) => string) | {
        (): (icon: import("./props").IconMeta) => string;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (icon: import("./props").IconMeta) => string) | (() => (icon: import("./props").IconMeta) => string) | {
        (): (icon: import("./props").IconMeta) => string;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly recentSaveStrategy: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "select" | "close" | "confirm") | (() => import("./props").RecentSaveStrategy) | {
        (): import("./props").RecentSaveStrategy;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "select" | "close" | "confirm") | (() => import("./props").RecentSaveStrategy) | {
        (): import("./props").RecentSaveStrategy;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "select", boolean>;
    readonly confirmText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "OK", boolean>;
    readonly recentKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "zx-icon-select-recent", boolean>;
    readonly recentKeyPrefix: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly recentStorage: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").IconSelectStorage) | (() => import("./props").IconSelectStorage) | {
        (): import("./props").IconSelectStorage;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").IconSelectStorage) | (() => import("./props").IconSelectStorage) | {
        (): import("./props").IconSelectStorage;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly triggerMode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "icon" | "input") | (() => import("./props").TriggerMode) | {
        (): import("./props").TriggerMode;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "icon" | "input") | (() => import("./props").TriggerMode) | {
        (): import("./props").TriggerMode;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "input", boolean>;
    readonly triggerSize: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 36, boolean>;
    readonly clearable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly placeholder: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "点击选择图标", boolean>;
}>, {
    /** 打开面板 */
    open: () => void;
    /** 关闭面板 */
    close: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: string) => void;
    change: (value: string) => void;
    clear: () => void;
    confirm: () => void;
    "recent-change": (icons: string[], _scopeKey: string) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly sources: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").IconSource[]) | (() => import("./props").IconSource[]) | {
        (): import("./props").IconSource[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").IconSource[]) | (() => import("./props").IconSource[]) | {
        (): import("./props").IconSource[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => string[], boolean>;
    readonly iconifyCollections: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | {
        (): string[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string[]) | (() => string[]) | {
        (): string[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    readonly customIcons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").IconMeta[]) | (() => import("./props").IconMeta[]) | {
        (): import("./props").IconMeta[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").IconMeta[]) | (() => import("./props").IconMeta[]) | {
        (): import("./props").IconMeta[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    readonly tabMode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "source" | "custom" | "category") | (() => import("./props").IconTabMode) | {
        (): import("./props").IconTabMode;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "source" | "custom" | "category") | (() => import("./props").IconTabMode) | {
        (): import("./props").IconTabMode;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "source", boolean>;
    readonly showTabs: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly categories: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").IconCategory[]) | (() => import("./props").IconCategory[]) | {
        (): import("./props").IconCategory[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").IconCategory[]) | (() => import("./props").IconCategory[]) | {
        (): import("./props").IconCategory[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    readonly columns: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 6, boolean>;
    readonly itemHeight: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 48, boolean>;
    readonly panelHeight: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 280, boolean>;
    readonly panelMode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
        (): "dialog" | "popover";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
        (): "dialog" | "popover";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "popover", boolean>;
    readonly popoverWidth: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 540, boolean>;
    readonly placement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | {
        (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | {
        (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "bottom-start", boolean>;
    readonly showArrow: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly allowModeSwitch: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly searchable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly searchPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "header" | "panel") | (() => import("./props").IconSearchPlacement) | {
        (): import("./props").IconSearchPlacement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "header" | "panel") | (() => import("./props").IconSearchPlacement) | {
        (): import("./props").IconSearchPlacement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "panel", boolean>;
    readonly showRecent: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly showFooter: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly recentMax: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly recentScope: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import("./props").RecentScope) | {
        (): import("./props").RecentScope;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import("./props").RecentScope) | {
        (): import("./props").RecentScope;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "global", boolean>;
    readonly recentScopeKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly recentScopeResolver: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (icon: import("./props").IconMeta) => string) | (() => (icon: import("./props").IconMeta) => string) | {
        (): (icon: import("./props").IconMeta) => string;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (icon: import("./props").IconMeta) => string) | (() => (icon: import("./props").IconMeta) => string) | {
        (): (icon: import("./props").IconMeta) => string;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly recentSaveStrategy: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "select" | "close" | "confirm") | (() => import("./props").RecentSaveStrategy) | {
        (): import("./props").RecentSaveStrategy;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "select" | "close" | "confirm") | (() => import("./props").RecentSaveStrategy) | {
        (): import("./props").RecentSaveStrategy;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "select", boolean>;
    readonly confirmText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "OK", boolean>;
    readonly recentKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "zx-icon-select-recent", boolean>;
    readonly recentKeyPrefix: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly recentStorage: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./props").IconSelectStorage) | (() => import("./props").IconSelectStorage) | {
        (): import("./props").IconSelectStorage;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./props").IconSelectStorage) | (() => import("./props").IconSelectStorage) | {
        (): import("./props").IconSelectStorage;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly triggerMode: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "icon" | "input") | (() => import("./props").TriggerMode) | {
        (): import("./props").TriggerMode;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "icon" | "input") | (() => import("./props").TriggerMode) | {
        (): import("./props").TriggerMode;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "input", boolean>;
    readonly triggerSize: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 36, boolean>;
    readonly clearable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly disabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly placeholder: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "点击选择图标", boolean>;
}>> & Readonly<{
    "onUpdate:modelValue"?: ((value: string) => any) | undefined;
    onChange?: ((value: string) => any) | undefined;
    onClear?: (() => any) | undefined;
    onConfirm?: (() => any) | undefined;
    "onRecent-change"?: ((icons: string[], _scopeKey: string) => any) | undefined;
}>, {
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly columns: number;
    readonly placeholder: string;
    readonly modelValue: string;
    readonly clearable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly placement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | {
        (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | (() => "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end") | {
        (): "left" | "right" | "top" | "bottom" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "left-start" | "left-end" | "right-start" | "right-end";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly showArrow: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFooter: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmText: string;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly sources: import("./props").IconSource[];
    readonly iconifyCollections: string[];
    readonly customIcons: import("./props").IconMeta[];
    readonly tabMode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "source" | "custom" | "category") | (() => import("./props").IconTabMode) | {
        (): import("./props").IconTabMode;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "source" | "custom" | "category") | (() => import("./props").IconTabMode) | {
        (): import("./props").IconTabMode;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly showTabs: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly categories: import("./props").IconCategory[];
    readonly itemHeight: number;
    readonly panelHeight: number;
    readonly panelMode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
        (): "dialog" | "popover";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "dialog" | "popover") | (() => "dialog" | "popover") | {
        (): "dialog" | "popover";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly popoverWidth: number;
    readonly allowModeSwitch: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly searchPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "header" | "panel") | (() => import("./props").IconSearchPlacement) | {
        (): import("./props").IconSearchPlacement;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "header" | "panel") | (() => import("./props").IconSearchPlacement) | {
        (): import("./props").IconSearchPlacement;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly showRecent: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly recentMax: number;
    readonly recentScope: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import("./props").RecentScope) | {
        (): import("./props").RecentScope;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "source" | "global" | "custom" | "category") | (() => import("./props").RecentScope) | {
        (): import("./props").RecentScope;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly recentScopeKey: string;
    readonly recentScopeResolver: (icon: import("./props").IconMeta) => string;
    readonly recentSaveStrategy: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "select" | "close" | "confirm") | (() => import("./props").RecentSaveStrategy) | {
        (): import("./props").RecentSaveStrategy;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "select" | "close" | "confirm") | (() => import("./props").RecentSaveStrategy) | {
        (): import("./props").RecentSaveStrategy;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly recentKey: string;
    readonly recentKeyPrefix: string;
    readonly recentStorage: import("./props").IconSelectStorage;
    readonly triggerMode: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "icon" | "input") | (() => import("./props").TriggerMode) | {
        (): import("./props").TriggerMode;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "icon" | "input") | (() => import("./props").TriggerMode) | {
        (): import("./props").TriggerMode;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly triggerSize: number;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
