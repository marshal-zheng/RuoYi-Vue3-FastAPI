import { nextTick } from 'vue';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "default" | "large", unknown, "", boolean>;
    readonly shape: import("@zxio/shared").EpPropFinalized<StringConstructor, "" | "circle" | "round", unknown, "", boolean>;
    readonly activeClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "v-button--active", boolean>;
    readonly flat: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly vertical: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly rowGap: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly defaultFirstChecked: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly round: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>, {
    rootRef: import("vue").Ref<({
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly size?: import("element-plus").ButtonProps["size"];
            readonly type?: import("element-plus").ButtonProps["type"];
            readonly direction?: ("horizontal" | "vertical") | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: string, ...args: any[]) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
        direction: "horizontal" | "vertical";
    }> & Omit<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, "type" | "direction"> & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | undefined, ({
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly size?: import("element-plus").ButtonProps["size"];
            readonly type?: import("element-plus").ButtonProps["type"];
            readonly direction?: ("horizontal" | "vertical") | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: string, ...args: any[]) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
        direction: "horizontal" | "vertical";
    }> & Omit<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, "type" | "direction"> & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | undefined>;
    classes: import("vue").ComputedRef<(string | {
        [x: string]: "" | import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        'el-button-group': boolean;
    })[]>;
    groupStyle: import("vue").ComputedRef<{
        flexDirection: string;
        gap: string | undefined;
        alignItems: string;
    } | {
        flexDirection?: undefined;
        gap?: undefined;
        alignItems?: undefined;
    }>;
    groupSize: import("vue").ComputedRef<"small" | "large" | undefined>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    'update:modelValue': (value: string | number) => boolean;
    input: (value: string | number) => boolean;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly size: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "default" | "large", unknown, "", boolean>;
    readonly shape: import("@zxio/shared").EpPropFinalized<StringConstructor, "" | "circle" | "round", unknown, "", boolean>;
    readonly activeClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "v-button--active", boolean>;
    readonly flat: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly vertical: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly rowGap: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly defaultFirstChecked: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly round: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>> & Readonly<{
    onInput?: ((value: string | number) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string | number) => any) | undefined;
}>, {
    readonly flat: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "default" | "large", unknown>;
    readonly vertical: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly enabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly round: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => string | number) | {
        (): string | number;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly rowGap: number;
    readonly shape: import("@zxio/shared").EpPropMergeType<StringConstructor, "" | "circle" | "round", unknown>;
    readonly activeClass: string;
    readonly defaultFirstChecked: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {
    ElButtonGroup: import("element-plus/es/utils/vue/typescript.mjs").SFCWithInstall<__ZXUI_WithSlots<{
        new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, import("vue").PublicProps, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }, false, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, {
            type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
            direction: "horizontal" | "vertical";
        }>;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("element-plus/es/components/button/src/button-group.mjs").ButtonGroupProps> & Readonly<{}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
        type: "" | "default" | "text" | "info" | "primary" | "success" | "warning" | "danger";
        direction: "horizontal" | "vertical";
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
        $slots: {
            default?: (props: {}) => any;
        };
    }>>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
