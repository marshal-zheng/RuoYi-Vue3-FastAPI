import type { CSSProperties } from 'vue';
declare const _default: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly column: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly vAlignContent: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<StringConstructor, "center" | "top" | "bottom", unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly hAlignContent: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<StringConstructor, "left" | "center" | "right", unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly marginLeft: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly marginTop: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly marginRight: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly marginBottom: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly grow: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | boolean) | (() => number | boolean) | {
            (): number | boolean;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => number | boolean) | (() => number | boolean) | {
            (): number | boolean;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly shrink: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => number | boolean) | (() => number | boolean) | {
        (): number | boolean;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => number | boolean) | (() => number | boolean) | {
        (): number | boolean;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly basis: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly wrap: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly height: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly width: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
}>, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    flexStyle: import("vue").ComputedRef<CSSProperties>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly column: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly vAlignContent: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<StringConstructor, "center" | "top" | "bottom", unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly hAlignContent: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<StringConstructor, "left" | "center" | "right", unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly marginLeft: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly marginTop: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly marginRight: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly marginBottom: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly grow: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | boolean) | (() => number | boolean) | {
            (): number | boolean;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => number | boolean) | (() => number | boolean) | {
            (): number | boolean;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly shrink: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => number | boolean) | (() => number | boolean) | {
        (): number | boolean;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => number | boolean) | (() => number | boolean) | {
        (): number | boolean;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly basis: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly wrap: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly height: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly width: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | number) | (() => string | number) | {
            (): string | number;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
}>> & Readonly<{}>, {
    readonly column: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly wrap: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly shrink: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | boolean) | (() => number | boolean) | {
        (): number | boolean;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => number | boolean) | (() => number | boolean) | {
        (): number | boolean;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
