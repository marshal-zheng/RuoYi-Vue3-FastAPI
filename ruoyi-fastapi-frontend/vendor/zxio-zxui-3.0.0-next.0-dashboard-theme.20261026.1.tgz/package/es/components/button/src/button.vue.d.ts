declare const _default: __ZXUI_WithSlots<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
            (): Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
            (): Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        success: () => void;
        error: (error: Error) => void;
        startLoading: () => void;
        endLoading: () => void;
    }, import("vue").PublicProps, {
        readonly debounce: number;
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
            (): Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
            (): Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, {
        readonly debounce: number;
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
            (): string | Record<string, any>;
            new (): any;
            readonly prototype: any;
        }) | null)[], unknown, unknown>;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
        (): string | Record<string, any>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
        (): string | Record<string, any>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "", boolean>;
    readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
        (): Record<string, any>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
        (): Record<string, any>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
}>> & Readonly<{
    onSuccess?: (() => any) | undefined;
    onError?: ((error: Error) => any) | undefined;
    onStartLoading?: (() => any) | undefined;
    onEndLoading?: (() => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    success: () => void;
    error: (error: Error) => void;
    startLoading: () => void;
    endLoading: () => void;
}, string, {
    readonly debounce: number;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
        (): string | Record<string, any>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | {
        (): string | Record<string, any>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, {
    $slots: {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    } & {
        'tooltip-content'?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    };
}>;
export default _default;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
