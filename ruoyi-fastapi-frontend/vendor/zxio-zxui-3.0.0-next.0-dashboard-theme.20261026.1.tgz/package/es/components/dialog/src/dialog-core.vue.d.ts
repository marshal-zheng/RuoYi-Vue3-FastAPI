import type { FooterButtonConfig } from './constants';
import type { DialogSlots } from './slots';
import type { ThemeRequiredPortalTarget } from '../../theme-provider';
type __VLS_Slots = DialogSlots;
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly width: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly height: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
    readonly showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly fullscreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("./locale").DialogMessages>) | (() => Partial<import("./locale").DialogMessages>) | {
        (): Partial<import("./locale").DialogMessages>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<import("./locale").DialogMessages>) | (() => Partial<import("./locale").DialogMessages>) | {
        (): Partial<import("./locale").DialogMessages>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./constants").DialogDirtyGuard) | (() => boolean | import("./constants").DialogDirtyGuard) | {
        (): boolean | import("./constants").DialogDirtyGuard;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("./constants").DialogDirtyGuard) | (() => boolean | import("./constants").DialogDirtyGuard) | {
        (): boolean | import("./constants").DialogDirtyGuard;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, false, boolean>;
    readonly beforeClose: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./constants").DialogBeforeClose) | (() => import("./constants").DialogBeforeClose) | {
        (): import("./constants").DialogBeforeClose;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogBeforeClose) | (() => import("./constants").DialogBeforeClose) | {
        (): import("./constants").DialogBeforeClose;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly onConfirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | (() => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | {
        (): import("./constants").DialogConfirm | import("./constants").DialogConfirm[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | (() => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | {
        (): import("./constants").DialogConfirm | import("./constants").DialogConfirm[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | {
        (): string[][];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string[][]) | (() => string[][]) | {
        (): string[][];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./constants").DialogDescriptionItem[]) | (() => import("./constants").DialogDescriptionItem[]) | {
        (): import("./constants").DialogDescriptionItem[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogDescriptionItem[]) | (() => import("./constants").DialogDescriptionItem[]) | {
        (): import("./constants").DialogDescriptionItem[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    readonly dialogSize: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown, "small", boolean>;
    readonly footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "spin", boolean>;
    readonly loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly okText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly cancelText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly saveContinueText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly dialogStyle: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
        (): import("vue").CSSProperties;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
        (): import("vue").CSSProperties;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    readonly modalClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./constants").DialogConfirm) | (() => import("./constants").DialogConfirm) | {
        (): import("./constants").DialogConfirm;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogConfirm) | (() => import("./constants").DialogConfirm) | {
        (): import("./constants").DialogConfirm;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
        (): Record<string, any>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
        (): Record<string, any>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 24, boolean>;
    readonly draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | {
        (): ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | {
        (): ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly prevText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly nextText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly submitText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[]) | {
        (): FooterButtonConfig[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[]) | {
        (): FooterButtonConfig[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
        (): "left" | "center" | "right";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
        (): "left" | "center" | "right";
        new (): any;
        readonly prototype: any;
    }) | null)[], "left" | "center" | "right", unknown, "right", boolean>;
    readonly beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | {
        (): import("../../config-provider").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | {
        (): import("../../config-provider").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | {
        (): import("../../config-provider").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | {
        (): import("../../config-provider").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    }) | null)[], "none" | "auto", unknown, undefined, boolean>;
}>, {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => import("@zxio/keybindings/vue").ActionAdmission<void>;
    isFullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    isDirty: boolean;
    isSubmitting: boolean;
    currentStep: number;
    isFirstStep: boolean;
    isLastStep: boolean;
    resetSubmitting: () => void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (val: boolean) => void;
    cancel: () => void;
    prev: (params: import("@zxio/constants/form-modal").StepEventParams) => void;
    next: (params: import("@zxio/constants/form-modal").StepEventParams) => void;
    continue: () => void;
    close: () => void;
    back: () => void;
    open: () => void;
    confirm: (_result?: any) => void;
    closed: () => void;
    saveStart: (_done: () => void, _fail: (error?: any) => void) => void;
    saveSuccess: (_data?: any) => void;
    saveError: (_error: any) => void;
    buttonClick: (_buttonKey: string) => void;
    "update:currentStep": (val: number) => void;
    "update:current-step": (val: number) => void;
    "update:fullscreen": (_value: boolean) => void;
    "fullscreen-change": (_value: boolean) => void;
    opened: () => void;
    openAutoFocus: () => void;
    closeAutoFocus: () => void;
    "before-close": (_reason: "cancel" | "close") => void;
    "dirty-change": (_value: boolean) => void;
    "confirm-error": (_error?: any) => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly modelValue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly title: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly width: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly height: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, "", boolean>;
    readonly showClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly modal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly destroyOnClose: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly fullscreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly showFullScreen: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly subtitle: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly showBack: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly divider: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, undefined, boolean>;
    readonly locale: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("./locale").DialogMessages>) | (() => Partial<import("./locale").DialogMessages>) | {
        (): Partial<import("./locale").DialogMessages>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Partial<import("./locale").DialogMessages>) | (() => Partial<import("./locale").DialogMessages>) | {
        (): Partial<import("./locale").DialogMessages>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly okLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./constants").DialogDirtyGuard) | (() => boolean | import("./constants").DialogDirtyGuard) | {
        (): boolean | import("./constants").DialogDirtyGuard;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("./constants").DialogDirtyGuard) | (() => boolean | import("./constants").DialogDirtyGuard) | {
        (): boolean | import("./constants").DialogDirtyGuard;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, false, boolean>;
    readonly beforeClose: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./constants").DialogBeforeClose) | (() => import("./constants").DialogBeforeClose) | {
        (): import("./constants").DialogBeforeClose;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogBeforeClose) | (() => import("./constants").DialogBeforeClose) | {
        (): import("./constants").DialogBeforeClose;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly onConfirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | (() => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | {
        (): import("./constants").DialogConfirm | import("./constants").DialogConfirm[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | (() => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | {
        (): import("./constants").DialogConfirm | import("./constants").DialogConfirm[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly stepFields: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string[][]) | (() => string[][]) | {
        (): string[][];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string[][]) | (() => string[][]) | {
        (): string[][];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly validateStep: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (step: number) => boolean | Promise<boolean>) | (() => (step: number) => boolean | Promise<boolean>) | {
        (): (step: number) => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly titleTag: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly titleTagColor: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly descriptions: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./constants").DialogDescriptionItem[]) | (() => import("./constants").DialogDescriptionItem[]) | {
        (): import("./constants").DialogDescriptionItem[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogDescriptionItem[]) | (() => import("./constants").DialogDescriptionItem[]) | {
        (): import("./constants").DialogDescriptionItem[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => never[], boolean>;
    readonly dialogSize: import("@zxio/shared").EpPropFinalized<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown, "small", boolean>;
    readonly footer: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly showCancel: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly showContinue: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly noTitle: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly showSkeleton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly loading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly loadingType: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, "spin", boolean>;
    readonly loadingText: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly loadingBackground: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly okText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly cancelText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly saveContinueText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly okDisabled: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly dialogStyle: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
        (): import("vue").CSSProperties;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("vue").CSSProperties) | (() => import("vue").CSSProperties) | {
        (): import("vue").CSSProperties;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, () => {}, boolean>;
    readonly modalClass: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly handleBeforeCancel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly confirm: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => import("./constants").DialogConfirm) | (() => import("./constants").DialogConfirm) | {
        (): import("./constants").DialogConfirm;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogConfirm) | (() => import("./constants").DialogConfirm) | {
        (): import("./constants").DialogConfirm;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly formRef: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly formModel: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
        (): Record<string, any>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | {
        (): Record<string, any>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, null, boolean>;
    readonly autoResetForm: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly preValidate: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly autoScrollToError: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly scrollErrorOffset: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 24, boolean>;
    readonly draggable: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly appendTo: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | {
        (): ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => HTMLElement | Document | ShadowRoot | (() => HTMLElement | ShadowRoot | Document | null)) | (() => ThemeRequiredPortalTarget) | {
        (): ThemeRequiredPortalTarget;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly enableSteps: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly currentStep: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly totalSteps: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 1, boolean>;
    readonly prevText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly nextText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly submitText: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, ObjectConstructor], unknown, unknown, "", boolean>;
    readonly buttons: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[]) | {
        (): FooterButtonConfig[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => FooterButtonConfig[]) | (() => FooterButtonConfig[]) | {
        (): FooterButtonConfig[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly buttonAlign: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
        (): "left" | "center" | "right";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
        (): "left" | "center" | "right";
        new (): any;
        readonly prototype: any;
    }) | null)[], "left" | "center" | "right", unknown, "right", boolean>;
    readonly beforeSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => boolean | Promise<boolean>) | (() => () => boolean | Promise<boolean>) | {
        (): () => boolean | Promise<boolean>;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly afterSave: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => (success: boolean) => void) | (() => (success: boolean) => void) | {
        (): (success: boolean) => void;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly paddingInline: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | {
        (): import("../../config-provider").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | {
        (): import("../../config-provider").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly headerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly bodyPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly footerPadding: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown, undefined, boolean>;
    readonly bodyScroll: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | {
        (): import("../../config-provider").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | {
        (): import("../../config-provider").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    }) | null)[], "none" | "auto", unknown, undefined, boolean>;
}>> & Readonly<{
    "onUpdate:modelValue"?: ((val: boolean) => any) | undefined;
    onCancel?: (() => any) | undefined;
    onPrev?: ((params: import("@zxio/constants/form-modal").StepEventParams) => any) | undefined;
    onNext?: ((params: import("@zxio/constants/form-modal").StepEventParams) => any) | undefined;
    onContinue?: (() => any) | undefined;
    onClose?: (() => any) | undefined;
    onBack?: (() => any) | undefined;
    onOpen?: (() => any) | undefined;
    onConfirm?: ((_result?: any) => any) | undefined;
    onClosed?: (() => any) | undefined;
    onSaveStart?: ((_done: () => void, _fail: (error?: any) => void) => any) | undefined;
    onSaveSuccess?: ((_data?: any) => any) | undefined;
    onSaveError?: ((_error: any) => any) | undefined;
    onButtonClick?: ((_buttonKey: string) => any) | undefined;
    "onUpdate:currentStep"?: ((val: number) => any) | undefined;
    "onUpdate:current-step"?: ((val: number) => any) | undefined;
    "onUpdate:fullscreen"?: ((_value: boolean) => any) | undefined;
    "onFullscreen-change"?: ((_value: boolean) => any) | undefined;
    onOpened?: (() => any) | undefined;
    onOpenAutoFocus?: (() => any) | undefined;
    onCloseAutoFocus?: (() => any) | undefined;
    "onBefore-close"?: ((_reason: "cancel" | "close") => any) | undefined;
    "onDirty-change"?: ((_value: boolean) => any) | undefined;
    "onConfirm-error"?: ((_error?: any) => any) | undefined;
}>, {
    readonly footer: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly title: string;
    readonly loading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounce: number;
    readonly modal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly throttle: number;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly appendTo: ThemeRequiredPortalTarget;
    readonly locale: Partial<import("./locale").DialogMessages>;
    readonly divider: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly bodyPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly footerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly headerPadding: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number | import("../../config-provider").ZxOverlayInsets) | (() => import("../../config-provider").ZxOverlayPadding) | {
        (): import("../../config-provider").ZxOverlayPadding;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly beforeClose: import("./constants").DialogBeforeClose;
    readonly modalClass: string;
    readonly draggable: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnClickModal: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly closeOnPressEscape: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirm: import("./constants").DialogConfirm;
    readonly paddingInline: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | {
        (): import("../../config-provider").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => string | number) | (() => import("../../config-provider").ZxOverlayLength) | {
        (): import("../../config-provider").ZxOverlayLength;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly cancelText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly enableSteps: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly currentStep: number;
    readonly totalSteps: number;
    readonly prevText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly nextText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly submitText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly buttons: FooterButtonConfig[];
    readonly buttonAlign: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
        (): "left" | "center" | "right";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "left" | "center" | "right") | (() => "left" | "center" | "right") | {
        (): "left" | "center" | "right";
        new (): any;
        readonly prototype: any;
    }) | null)[], "left" | "center" | "right", unknown>;
    readonly beforeSave: () => boolean | Promise<boolean>;
    readonly afterSave: (success: boolean) => void;
    readonly formRef: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => {
        $: import("vue").ComponentInternalInstance;
        $data: {};
        $props: {
            readonly model?: Record<string, any> | undefined;
            readonly rules?: import("element-plus").FormRules | undefined;
            readonly labelPosition?: ("left" | "right" | "top") | undefined;
            readonly requireAsteriskPosition?: ("left" | "right") | undefined;
            readonly labelWidth?: (string | number) | undefined;
            readonly labelSuffix?: string | undefined;
            readonly inline?: boolean | undefined;
            readonly inlineMessage?: boolean | undefined;
            readonly statusIcon?: boolean | undefined;
            readonly showMessage?: boolean | undefined;
            readonly validateOnRuleChange?: boolean | undefined;
            readonly hideRequiredAsterisk?: boolean | undefined;
            readonly scrollToError?: boolean | undefined;
            readonly scrollIntoViewOptions?: (ScrollIntoViewOptions | boolean) | undefined;
            readonly size?: import("element-plus").ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        } & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps;
        $attrs: import("vue").Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import("vue").Slot<any> | undefined;
        }>;
        $root: import("vue").ComponentPublicInstance | null;
        $parent: import("vue").ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: "validate", prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        $el: any;
        $options: import("vue").ComponentOptionsBase<Readonly<import("element-plus").FormProps> & Readonly<{
            onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
        }>, {
            validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
            resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
            scrollToField: (prop: import("element-plus").FormItemProp) => void;
            getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
            fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
            setInitialValues: (initModel: Record<string, any>) => void;
        }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
            validate: (prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => void;
        }, string, {
            labelWidth: string | number;
            labelPosition: "left" | "right" | "top";
            requireAsteriskPosition: "left" | "right";
            labelSuffix: string;
            showMessage: boolean;
            validateOnRuleChange: boolean;
            scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
        }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            renderTriggered?: ((e: import("vue").DebuggerEvent) => void) | ((e: import("vue").DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import("vue").ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import("vue").nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import("@vue/reactivity").OnCleanup]) => any : (...args: [any, any, import("@vue/reactivity").OnCleanup]) => any, options?: import("vue").WatchOptions): import("vue").WatchStopHandle;
    } & Readonly<{
        labelWidth: string | number;
        labelPosition: "left" | "right" | "top";
        requireAsteriskPosition: "left" | "right";
        labelSuffix: string;
        showMessage: boolean;
        validateOnRuleChange: boolean;
        scrollIntoViewOptions: ScrollIntoViewOptions | boolean;
    }> & Omit<Readonly<import("element-plus").FormProps> & Readonly<{
        onValidate?: ((prop: import("element-plus").FormItemProp, isValid: boolean, message: string) => any) | undefined;
    }>, "validate" | "clearValidate" | "resetFields" | "validateField" | "labelPosition" | "requireAsteriskPosition" | "labelWidth" | "labelSuffix" | "showMessage" | "validateOnRuleChange" | "scrollIntoViewOptions" | "scrollToField" | "getField" | "fields" | "setInitialValues"> & {
        validate: (callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        validateField: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>, callback?: import("element-plus").FormValidateCallback) => import("element-plus").FormValidationResult;
        resetFields: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        clearValidate: (props?: import("element-plus/es/utils/typescript.mjs").Arrayable<import("element-plus").FormItemProp>) => void;
        scrollToField: (prop: import("element-plus").FormItemProp) => void;
        getField: (prop: import("element-plus").FormItemProp) => import("element-plus").FormItemContext | undefined;
        fields: import("vue").Reactive<import("element-plus").FormItemContext[]>;
        setInitialValues: (initModel: Record<string, any>) => void;
    } & {} & import("vue").ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | (() => import("element-plus").FormInstance | null) | {
        (): import("element-plus").FormInstance | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly preventRepeatSubmit: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingText: string;
    readonly fullscreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly destroyOnClose: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showFullScreen: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fullscreenShortcut: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly subtitle: string;
    readonly showBack: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly okLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly confirmOnDirty: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./constants").DialogDirtyGuard) | (() => boolean | import("./constants").DialogDirtyGuard) | {
        (): boolean | import("./constants").DialogDirtyGuard;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => boolean | import("./constants").DialogDirtyGuard) | (() => boolean | import("./constants").DialogDirtyGuard) | {
        (): boolean | import("./constants").DialogDirtyGuard;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly onConfirm: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | (() => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | {
        (): import("./constants").DialogConfirm | import("./constants").DialogConfirm[];
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | (() => import("./constants").DialogConfirm | import("./constants").DialogConfirm[]) | {
        (): import("./constants").DialogConfirm | import("./constants").DialogConfirm[];
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly stepFields: string[][];
    readonly validateStep: (step: number) => boolean | Promise<boolean>;
    readonly titleTag: string;
    readonly titleTagColor: string;
    readonly descriptions: import("./constants").DialogDescriptionItem[];
    readonly dialogSize: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "large" | "sm" | "md" | "lg" | "xl", unknown>;
    readonly showCancel: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showContinue: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly noTitle: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showSkeleton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadingType: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "spin" | "skeleton") | (() => "spin" | "skeleton") | {
        (): "spin" | "skeleton";
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly loadingBackground: string;
    readonly okText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly saveContinueText: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, ObjectConstructor], unknown, unknown>;
    readonly okDisabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly dialogStyle: import("vue").CSSProperties;
    readonly handleBeforeCancel: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => () => unknown) | (() => (() => unknown) | null) | {
        (): (() => unknown) | null;
        new (): any;
        readonly prototype: any;
    }) | null)[], unknown, unknown>;
    readonly formModel: Record<string, any>;
    readonly autoResetForm: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly preValidate: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly autoScrollToError: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly scrollErrorOffset: number;
    readonly bodyScroll: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | {
        (): import("../../config-provider").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    } | (((new (...args: any[]) => "none" | "auto") | (() => import("../../config-provider").ZxOverlayBodyScroll) | {
        (): import("../../config-provider").ZxOverlayBodyScroll;
        new (): any;
        readonly prototype: any;
    }) | null)[], "none" | "auto", unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = __ZXUI_WithSlots<T, {
        $slots: S;
    }>;

type __ZXUI_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & S };
