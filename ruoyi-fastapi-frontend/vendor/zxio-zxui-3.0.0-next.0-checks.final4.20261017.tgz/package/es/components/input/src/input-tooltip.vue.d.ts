type __VLS_Slots = {
    default(): unknown;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    focused: BooleanConstructor;
    tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("./props").InputTooltipConfig) | (() => string | import("./props").InputTooltipConfig) | (((new (...args: any[]) => string | import("./props").InputTooltipConfig) | (() => string | import("./props").InputTooltipConfig)) | null)[], unknown, unknown, "", boolean>;
    tooltipPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown, "right", boolean>;
    tooltipTrigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("./props").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("./props").InputTooltipTrigger)) | null)[], unknown, unknown, "hover", boolean>;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    focused: BooleanConstructor;
    tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | import("./props").InputTooltipConfig) | (() => string | import("./props").InputTooltipConfig) | (((new (...args: any[]) => string | import("./props").InputTooltipConfig) | (() => string | import("./props").InputTooltipConfig)) | null)[], unknown, unknown, "", boolean>;
    tooltipPlacement: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown, "right", boolean>;
    tooltipTrigger: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("./props").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("./props").InputTooltipTrigger)) | null)[], unknown, unknown, "hover", boolean>;
}>> & Readonly<{}>, {
    tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("./props").InputTooltipConfig) | (() => string | import("./props").InputTooltipConfig) | (((new (...args: any[]) => string | import("./props").InputTooltipConfig) | (() => string | import("./props").InputTooltipConfig)) | null)[], unknown, unknown>;
    focused: boolean;
    tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown>;
    tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("./props").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("./props").InputTooltipTrigger)) | null)[], unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & {
    $slots: S;
} };
