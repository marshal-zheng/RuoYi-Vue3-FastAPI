import type { GridListRequestState } from './props';
import type { GridListLoadOptions } from './use-grid-request';
declare function clearTableSelection(): void;
declare var __VLS_1: {
    query: Record<string, any> | {};
    data: {
        [x: string]: any;
        pager: {
            page: number;
            size: number;
            total: number;
        };
        query: Record<string, any>;
        list: any[];
        loading: boolean;
        error: unknown;
        lastLoadTime: number | null;
        silent: boolean;
    } | {
        readonly query: {};
        readonly list: readonly any[];
        readonly pager: {
            readonly page: number;
            readonly size: number;
            readonly total: number;
        } | null;
        readonly loading: boolean;
        readonly error: {} | null;
        readonly lastLoadTime: null;
        readonly silent: boolean;
    };
    mode: import("@zxio/shared").EpPropMergeType<StringConstructor, "request" | "controlled", unknown>;
    status: GridListRequestState;
    loading: boolean;
    refresh: (options?: GridListLoadOptions) => Promise<void> | undefined;
    updateState: (key: string, value: unknown) => void;
    updateMultiState: (value: any) => void;
}, __VLS_3: {
    loading: boolean;
    refreshing: boolean;
    error: unknown;
    paused: boolean;
    hasData: boolean;
    retry: () => void;
}, __VLS_5: {
    loading: boolean;
    refreshing: boolean;
    error: unknown;
    paused: boolean;
    hasData: boolean;
    retry: () => void;
}, __VLS_15: {
    grid: {
        [x: string]: any;
        pager: {
            page: number;
            size: number;
            total: number;
        };
        query: Record<string, any>;
        list: any[];
        loading: boolean;
        error: unknown;
        lastLoadTime: number | null;
        silent: boolean;
    } | {
        readonly query: {};
        readonly list: readonly any[];
        readonly pager: {
            readonly page: number;
            readonly size: number;
            readonly total: number;
        } | null;
        readonly loading: boolean;
        readonly error: {} | null;
        readonly lastLoadTime: null;
        readonly silent: boolean;
    };
    mode: import("@zxio/shared").EpPropMergeType<StringConstructor, "request" | "controlled", unknown>;
    status: GridListRequestState;
    loading: boolean;
    refresh: (options?: GridListLoadOptions) => Promise<void> | undefined;
    updateState: (key: string, value: unknown) => void;
    updateMultiState: (value: any) => void;
    hasData: boolean;
    isEmpty: boolean;
    emptySlot: import("vue").Slot<any> | undefined;
    renderEmpty: () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>;
}, __VLS_17: {
    refresh: (options?: GridListLoadOptions) => Promise<void> | undefined;
    error: null;
    isError: boolean;
}, __VLS_22: {}, __VLS_32: {
    pager: {
        page: number;
        size: number;
        total: number;
    } | {
        readonly page: number;
        readonly size: number;
        readonly total: number;
    };
};
type __VLS_Slots = {} & {
    form?: (props: typeof __VLS_1) => any;
} & {
    error?: (props: typeof __VLS_3) => any;
} & {
    status?: (props: typeof __VLS_5) => any;
} & {
    table?: (props: typeof __VLS_15) => any;
} & {
    empty?: (props: typeof __VLS_17) => any;
} & {
    emptyImage?: (props: typeof __VLS_22) => any;
} & {
    pagination?: (props: typeof __VLS_32) => any;
};
declare const __VLS_component: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    readonly mode: import("@zxio/shared").EpPropFinalized<StringConstructor, "request" | "controlled", unknown, "request", boolean>;
    readonly loadData: {
        readonly type: import("vue").PropType<Function>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly rows: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => readonly any[]) | (() => readonly any[]) | (((new (...args: any[]) => readonly any[]) | (() => readonly any[])) | null)[], unknown, unknown, undefined, boolean>;
    readonly pagination: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | (((new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null)) | null)[], unknown, unknown, undefined, boolean>;
    readonly status: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Readonly<import("./props").GridListStatus>) | (() => Readonly<import("./props").GridListStatus>) | (((new (...args: any[]) => Readonly<import("./props").GridListStatus>) | (() => Readonly<import("./props").GridListStatus>)) | null)[], unknown, unknown, undefined, boolean>;
    readonly initialState: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("./props").GridListState<Record<string, any>, any>>) | (() => Partial<import("./props").GridListState<Record<string, any>, any>>) | (((new (...args: any[]) => Partial<import("./props").GridListState<Record<string, any>, any>>) | (() => Partial<import("./props").GridListState<Record<string, any>, any>>)) | null)[], unknown, unknown, () => {}, boolean>;
    readonly showPagination: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly pageSizes: import("@zxio/shared").EpPropFinalized<ArrayConstructor, unknown, unknown, () => number[], boolean>;
    readonly paginationLayout: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "total, sizes, prev, pager, next, jumper", boolean>;
    readonly small: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly paginationBackground: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly loadOnMounted: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly queryTransform: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, (q: any) => any, boolean>;
    readonly paramsTransform: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, (p: any) => any, boolean>;
    readonly autoRefresh: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | (((new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig)) | null)[], unknown, unknown, false, boolean>;
    readonly clearSelectionOnLoad: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly syncUrlState: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly urlStateKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "_state", boolean>;
    readonly pageFrom0: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly debounceDelay: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 300, boolean>;
    readonly defaultPageSize: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly emptyDescription: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly emptyImage: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly emptyImageSize: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly showRefreshButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly showTableBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly fill: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>, {
    loadData: (params?: Record<string, unknown>, options?: GridListLoadOptions) => Promise<void> | undefined;
    refresh: (options?: GridListLoadOptions) => Promise<void> | undefined;
    mode: import("@zxio/shared").EpPropMergeType<StringConstructor, "request" | "controlled", unknown>;
    state: import("vue").ComputedRef<{
        readonly [x: string]: any;
        readonly pager: {
            readonly page: number;
            readonly size: number;
            readonly total: number;
        };
        readonly query: {
            readonly [x: string]: any;
        };
        readonly list: readonly any[];
        readonly loading: boolean;
        readonly error: Readonly<unknown>;
        readonly lastLoadTime: number | null;
        readonly silent: boolean;
    } | {
        readonly query: {};
        readonly list: readonly any[];
        readonly pager: {
            readonly page: number;
            readonly size: number;
            readonly total: number;
        } | null;
        readonly loading: boolean;
        readonly error: {} | null;
        readonly lastLoadTime: null;
        readonly silent: boolean;
    }>;
    updateState: (key: string, value: unknown) => void;
    updateMultiState: (value: any) => void;
    clearTableSelection: typeof clearTableSelection;
    getStateSnapshot: () => import("./props").GridListStateSnapshot;
    renderTableEmpty: () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: any) => void;
    "page-change": (_page: import("./props").GridListPageChange) => void;
    refresh: () => void;
    beforeLoad: (params: any) => void;
    dataLoaded: (data: any) => void;
    loadError: (error: any) => void;
    stateChange: (state: import("./props").GridListStateSnapshot) => void;
    selectionCleared: () => void;
}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    readonly mode: import("@zxio/shared").EpPropFinalized<StringConstructor, "request" | "controlled", unknown, "request", boolean>;
    readonly loadData: {
        readonly type: import("vue").PropType<Function>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly rows: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => readonly any[]) | (() => readonly any[]) | (((new (...args: any[]) => readonly any[]) | (() => readonly any[])) | null)[], unknown, unknown, undefined, boolean>;
    readonly pagination: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | (((new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null)) | null)[], unknown, unknown, undefined, boolean>;
    readonly status: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Readonly<import("./props").GridListStatus>) | (() => Readonly<import("./props").GridListStatus>) | (((new (...args: any[]) => Readonly<import("./props").GridListStatus>) | (() => Readonly<import("./props").GridListStatus>)) | null)[], unknown, unknown, undefined, boolean>;
    readonly initialState: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Partial<import("./props").GridListState<Record<string, any>, any>>) | (() => Partial<import("./props").GridListState<Record<string, any>, any>>) | (((new (...args: any[]) => Partial<import("./props").GridListState<Record<string, any>, any>>) | (() => Partial<import("./props").GridListState<Record<string, any>, any>>)) | null)[], unknown, unknown, () => {}, boolean>;
    readonly showPagination: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly pageSizes: import("@zxio/shared").EpPropFinalized<ArrayConstructor, unknown, unknown, () => number[], boolean>;
    readonly paginationLayout: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "total, sizes, prev, pager, next, jumper", boolean>;
    readonly small: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly paginationBackground: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly loadOnMounted: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly queryTransform: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, (q: any) => any, boolean>;
    readonly paramsTransform: import("@zxio/shared").EpPropFinalized<FunctionConstructor, unknown, unknown, (p: any) => any, boolean>;
    readonly autoRefresh: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | (((new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig)) | null)[], unknown, unknown, false, boolean>;
    readonly clearSelectionOnLoad: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly syncUrlState: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly urlStateKey: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "_state", boolean>;
    readonly pageFrom0: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly debounceDelay: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 300, boolean>;
    readonly defaultPageSize: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 10, boolean>;
    readonly emptyDescription: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, undefined, boolean>;
    readonly emptyImage: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly emptyImageSize: import("@zxio/shared").EpPropFinalized<readonly [StringConstructor, NumberConstructor], unknown, unknown, undefined, boolean>;
    readonly showRefreshButton: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly showTableBorder: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
    readonly fill: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, false, boolean>;
}>> & Readonly<{
    "onUpdate:modelValue"?: ((value: any) => any) | undefined;
    "onPage-change"?: ((_page: import("./props").GridListPageChange) => any) | undefined;
    onRefresh?: (() => any) | undefined;
    onBeforeLoad?: ((params: any) => any) | undefined;
    onDataLoaded?: ((data: any) => any) | undefined;
    onLoadError?: ((error: any) => any) | undefined;
    onStateChange?: ((state: import("./props").GridListStateSnapshot) => any) | undefined;
    onSelectionCleared?: (() => any) | undefined;
}>, {
    readonly small: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fill: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly mode: import("@zxio/shared").EpPropMergeType<StringConstructor, "request" | "controlled", unknown>;
    readonly status: Readonly<import("./props").GridListStatus>;
    readonly rows: readonly any[];
    readonly pagination: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null) | (((new (...args: any[]) => Readonly<import("./props").GridListPagerState>) | (() => Readonly<import("./props").GridListPagerState> | null)) | null)[], unknown, unknown>;
    readonly initialState: Partial<import("./props").GridListState<Record<string, any>, any>>;
    readonly showPagination: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly pageSizes: unknown[];
    readonly paginationLayout: string;
    readonly paginationBackground: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadOnMounted: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly queryTransform: Function;
    readonly paramsTransform: Function;
    readonly autoRefresh: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | (((new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig)) | null)[], unknown, unknown>;
    readonly clearSelectionOnLoad: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly syncUrlState: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly urlStateKey: string;
    readonly pageFrom0: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounceDelay: number;
    readonly defaultPageSize: number;
    readonly emptyDescription: string;
    readonly emptyImage: string;
    readonly emptyImageSize: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly showRefreshButton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showTableBorder: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & {
    $slots: S;
} };
