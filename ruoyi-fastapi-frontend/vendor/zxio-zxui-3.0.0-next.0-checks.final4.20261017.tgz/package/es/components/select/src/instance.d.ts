import type Select from './select.vue';
export type ZxSelectInstance = InstanceType<typeof Select>;
