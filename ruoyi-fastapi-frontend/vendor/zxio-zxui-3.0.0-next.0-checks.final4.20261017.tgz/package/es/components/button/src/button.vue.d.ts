declare const _default: Omit<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        success: () => void;
        error: (error: Error) => void;
        startLoading: () => void;
        endLoading: () => void;
    }, import("vue").PublicProps, {
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
        readonly debounce: number;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, {
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
        readonly debounce: number;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
    readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
}>> & Readonly<{
    onSuccess?: (() => any) | undefined;
    onError?: ((error: Error) => any) | undefined;
    onStartLoading?: (() => any) | undefined;
    onEndLoading?: (() => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    success: () => void;
    error: (error: Error) => void;
    startLoading: () => void;
    endLoading: () => void;
}, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        success: () => void;
        error: (error: Error) => void;
        startLoading: () => void;
        endLoading: () => void;
    }, import("vue").PublicProps, {
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
        readonly debounce: number;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, {
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
        readonly debounce: number;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
    readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
}>> & Readonly<{
    onSuccess?: (() => any) | undefined;
    onError?: ((error: Error) => any) | undefined;
    onStartLoading?: (() => any) | undefined;
    onEndLoading?: (() => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    success: () => void;
    error: (error: Error) => void;
    startLoading: () => void;
    endLoading: () => void;
}, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        success: () => void;
        error: (error: Error) => void;
        startLoading: () => void;
        endLoading: () => void;
    }, import("vue").PublicProps, {
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
        readonly debounce: number;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, {
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
        readonly debounce: number;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
    readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
}>> & Readonly<{
    onSuccess?: (() => any) | undefined;
    onError?: ((error: Error) => any) | undefined;
    onStartLoading?: (() => any) | undefined;
    onEndLoading?: (() => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    success: () => void;
    error: (error: Error) => void;
    startLoading: () => void;
    endLoading: () => void;
}, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): import("vue").CreateComponentPublicInstanceWithMixins<Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
        success: () => void;
        error: (error: Error) => void;
        startLoading: () => void;
        endLoading: () => void;
    }, import("vue").PublicProps, {
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
        readonly debounce: number;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }, true, {}, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, {}, any, import("vue").ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<import("vue").ExtractPropTypes<{
        readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
        readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
        readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
    }>> & Readonly<{
        onSuccess?: (() => any) | undefined;
        onError?: ((error: Error) => any) | undefined;
        onStartLoading?: (() => any) | undefined;
        onEndLoading?: (() => any) | undefined;
    }>, {}, {}, {}, {}, {
        readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
        readonly debounce: number;
        readonly throttle: number;
        readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconRight: string;
        readonly iconRightProps: Record<string, any>;
    }>;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly debounce: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly throttle: import("@zxio/shared").EpPropFinalized<NumberConstructor, unknown, unknown, 0, boolean>;
    readonly enableLoading: import("@zxio/shared").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    readonly tooltip: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown, "", boolean>;
    readonly iconRight: import("@zxio/shared").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly iconRightProps: import("@zxio/shared").EpPropFinalized<(new (...args: any[]) => Record<string, any>) | (() => Record<string, any>) | (((new (...args: any[]) => Record<string, any>) | (() => Record<string, any>)) | null)[], unknown, unknown, () => {}, boolean>;
}>> & Readonly<{
    onSuccess?: (() => any) | undefined;
    onError?: ((error: Error) => any) | undefined;
    onStartLoading?: (() => any) | undefined;
    onEndLoading?: (() => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    success: () => void;
    error: (error: Error) => void;
    startLoading: () => void;
    endLoading: () => void;
}, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    } & {
        'tooltip-content'?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    };
} };
export default _default;
