import type { PreparedThemeComposition } from './composition-contract';
import type { ThemeRuntimeResult } from './result';
import type { ZxDisplayProfile, ZxDisplayScale } from '@zxio/tokens/display';
export interface PreparedThemeLayoutChange {
    enterBusy(): void;
    /** Called after the matching CSS transaction enters the DOM. */
    commit(): Promise<ThemeRuntimeResult<void>>;
    /** Called after the CSS transaction rolls back. Keeps busy content hidden until restored. */
    rollback(): Promise<ThemeRuntimeResult<void>>;
    /** Publishes prepared geometry after the scope is ready. */
    finalize(): void;
}
export interface ThemeLayoutPort {
    prepare(input: {
        readonly scopeId: string;
        readonly root: HTMLElement;
        readonly themeId: string;
        readonly variantKey: string;
        readonly composition: PreparedThemeComposition | null;
        readonly display?: Readonly<{
            readonly profile: ZxDisplayProfile;
            readonly scale: ZxDisplayScale;
        }>;
        readonly effectiveRevision: number;
        readonly signal: AbortSignal;
    }): Promise<ThemeRuntimeResult<PreparedThemeLayoutChange>>;
}
