"use strict";
const vueQuery = require("@tanstack/vue-query");
async function invalidateQueryGroups(client, filters) {
  if (filters.length === 0) return;
  const union = {
    predicate: (query) => filters.some((filter) => vueQuery.matchQuery(filter, query))
  };
  await client.cancelQueries(union);
  await client.invalidateQueries({ ...union, refetchType: "active" });
}
exports.invalidateQueryGroups = invalidateQueryGroups;
