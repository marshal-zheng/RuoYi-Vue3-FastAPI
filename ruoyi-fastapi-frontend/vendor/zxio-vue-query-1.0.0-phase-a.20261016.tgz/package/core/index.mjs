import { i } from "../invalidation-CZqmzH40.mjs";
export {
  i as invalidateQueryGroups
};
