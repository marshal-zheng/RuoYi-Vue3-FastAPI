"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const invalidation = require("../invalidation-JOph8Ttl.js");
exports.invalidateQueryGroups = invalidation.invalidateQueryGroups;
