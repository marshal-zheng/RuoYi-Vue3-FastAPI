import { matchQuery } from "@tanstack/vue-query";
async function invalidateQueryGroups(client, filters) {
  if (filters.length === 0) return;
  const union = {
    predicate: (query) => filters.some((filter) => matchQuery(filter, query))
  };
  await client.cancelQueries(union);
  await client.invalidateQueries({ ...union, refetchType: "active" });
}
export {
  invalidateQueryGroups as i
};
