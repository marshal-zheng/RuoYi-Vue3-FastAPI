import { getCurrentInstance, ref, computed, toValue, unref, onActivated, onDeactivated, nextTick } from "vue";
import { useQueryClient, useQuery, isCancelledError, skipToken } from "@tanstack/vue-query";
const EMPTY_OPTIONS = Object.freeze([]);
function useQuerySelect(options, config = {}) {
  if (!getCurrentInstance()) {
    throw new Error("useQuerySelect must be called synchronously inside setup().");
  }
  const client = config.queryClient ?? useQueryClient();
  const activated = ref(true);
  const active = computed(() => activated.value && toValue(config.active ?? true));
  const currentOptions = computed(() => unref(toValue(options)));
  const gatedOptions = computed(() => active.value ? currentOptions.value : { ...currentOptions.value, enabled: false });
  const query = useQuery(gatedOptions, client);
  const execute = async (onlyStale) => {
    await nextTick();
    if (!active.value || unref(currentOptions.value.queryFn) === skipToken || !query.isEnabled.value) return;
    if (onlyStale && !query.isStale.value) return;
    await query.refetch({ cancelRefetch: false, throwOnError: true });
  };
  const ensureFresh = () => execute(true);
  const refresh = () => execute(false);
  const fromEvent = (action) => {
    void action().catch(() => {
    });
  };
  onActivated(() => {
    const wasDeactivated = !activated.value;
    activated.value = true;
    if (wasDeactivated) fromEvent(ensureFresh);
  });
  onDeactivated(() => {
    activated.value = false;
  });
  const selectProps = computed(() => ({
    options: query.data.value ?? EMPTY_OPTIONS,
    loading: query.isLoading.value,
    refreshing: query.isFetching.value && query.data.value !== void 0,
    error: isCancelledError(query.error.value) ? null : query.error.value,
    paused: query.fetchStatus.value === "paused"
  }));
  return {
    query,
    selectProps,
    selectEvents: {
      "visible-change": (visible) => {
        if (visible) fromEvent(ensureFresh);
      },
      retry: () => fromEvent(refresh)
    },
    ensureFresh,
    refresh
  };
}
export {
  useQuerySelect
};
