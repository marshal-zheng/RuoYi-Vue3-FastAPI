# @zxio/theme-rocket-moss

Ink is a deep moss-green Theme v4 package. Khaki is the glow seed. The
package id remains `rocket-moss`.

Run `pnpm -C packages/theme-rocket-moss build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
