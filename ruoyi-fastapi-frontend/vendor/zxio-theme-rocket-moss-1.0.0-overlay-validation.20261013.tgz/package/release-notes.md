# Release notes

## 1.0.0

- Add the Ink Theme v4 package with 162 deterministic variants. The package
  id remains `rocket-moss`.
- Anchor chrome to a deep moss green. Khaki is the glow material at 0.55
  intensity. Light paper is khaki-tinted; dark canvas stays in the moss
  family at a darker depth.
