import Component from './src/list-group-header.vue';
export default Component;
