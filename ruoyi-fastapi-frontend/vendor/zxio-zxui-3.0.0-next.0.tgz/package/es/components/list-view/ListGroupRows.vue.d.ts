import Component from './src/list-group-rows.vue';
export default Component;
