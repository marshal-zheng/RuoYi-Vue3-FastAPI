import Component from './src/list-groups.vue';
export default Component;
