import Component from './src/list-header-item.vue';
export default Component;
