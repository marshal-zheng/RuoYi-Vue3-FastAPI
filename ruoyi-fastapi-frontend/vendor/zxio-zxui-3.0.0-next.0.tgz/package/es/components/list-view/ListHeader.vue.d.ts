import Component from './src/list-header.vue';
export default Component;
