# @zxio/dashboard

`@zxio/dashboard` 的根入口提供 dashboard foundation schema、validation、migration 和 import/export。Vue renderer、grid runtime、panel chrome 和样式通过独立 subpath 暴露，不会从 schema-only 入口产生样式副作用或布局依赖。

## Runtime Surface

- `@zxio/dashboard/runtime` 导出 `ZxDashboardRenderer`、`ZxDashboardGrid`、`ZxDashboardPanelChrome`、runtime context、panel action 类型和 layout adapter helpers。
- `@zxio/dashboard/widget` 导出独立 widget registry、resolver adapter、widget context、glob manifest adapter、validation 和 migration helper；只在显式导入时进入依赖图。
- `@zxio/dashboard/designer` 导出 `ZxDashboardDesigner`、designer context hooks、panel 创建 helper、palette helper、designer event/issue 类型；只在显式导入时进入依赖图。
- `@zxio/dashboard/style` 与 `@zxio/dashboard/style/css` 导出 dashboard runtime 基础样式；只在需要 renderer/grid runtime 时导入。
- `@zxio/vue-grid-layout` 是 runtime 默认 grid 实现的 optional peer dependency。只使用 schema/validation/migration/import-export 的消费者不需要安装或加载它。
- 使用 `ZxDashboardRenderer`、`ZxDashboardGrid` 或 dashboard runtime style 的宿主应安装并去重 `@zxio/vue-grid-layout` 和 `vue`。Layout / edit 模式下的复制粘贴走 dashboard 自己的 `panels` 协议：库负责选中与几何，runtime 再 clone `DashboardPanel`。
- 宿主应用应保持 Vue 单例去重，确保 `vue`、`@vue/runtime-core` 和使用 dashboard runtime 的应用代码解析到同一份 Vue runtime。

本包不包含内置 widgets、远程插件市场、sandbox、数据源编排、权限、发布流、版本历史或业务审批。Designer 只负责本地 authoring protocol、受控 `panels` 请求、save/export request 和 validation diagnostics。

Runtime 示例见 `docs/examples/dashboard/runtime-renderer.vue`。示例只使用 `ZxDashboardRenderer`、`v-model:panels`、`#panel`、`#empty` 和 `#unresolved`，不引入 designer palette、edit drawer、widget registry 或内置 chart/table/text widgets。短期迁移旧内容加载器时，应在宿主 slot 中包装，不能把 `AsyncLoadComp`、组件路径解析或 `import.meta.glob` 放入 runtime core。

## 架构与归属

归属决策记录见 `docs/plans/2026-10-14-dashboard-ownership-decision.md`（2026-10-14 已确认）：

- `@zxio/dashboard` 是业务唯一的 dashboard API：document schema、widget registry、panel chrome、designer、locale 与主题接入都由本包提供；业务代码不直接 import `@zxio/vue-grid-layout`。
- `@zxio/vue-grid-layout` 是内部布局引擎。adapter（`src/runtime/grid/*`）只消费它的根入口/`./core`、`./editor`、`./command-platform`、`./responsive`、`./ui`（headless 模型）、`./worker`、`./theme` 与 `./style.css`；其 `./dashboard`、`./widget-registry`、`./dashboard-editor-shell`、`./persistence` 对 ZXUI 消费者视为内部/实验入口，不作为业务 API。
- 历史与文档级命令归本包（mirror 策略）：几何命令（select/move/resize/align/distribute/tidy/drop add）经引擎执行；`delete`、`duplicate`、`undo`、`redo`、`lock`、`hide` 由本包翻译为受控 `panels` 变更，`v-model:panels` 始终是唯一事实源，引擎 persistence 保持关闭。
- Token 层：引擎自带 ZXUI theme-consumer 扩展包（`themeBundle`，contract 4.0.0，`--vgl-*` → `--zx-semantic-*`），本包不重复桥接；dashboard 专属的 `--vgl-*`（引导线、占位、handle、焦点/选中、动效）在 `.zx-dashboard-grid` 作用域由 `--zx-dashboard-*` 派生，不用 `!important`。
- Authoring UI（toolbar、palette、inspector/drawer、context menu、diagnostics）归本包 designer：light DOM、跟随 ZXUI 主题与 locale；引擎 editor-kit 只以 headless 模型形式被消费。

## Widget Runtime Surface

Widget runtime 通过 registry + resolver adapter 接入 renderer，不给 `ZxDashboardRenderer` 增加 `registry` prop：

```ts
import { ZxDashboardRenderer } from '@zxio/dashboard/runtime'
import {
  createDashboardPanelContentResolver,
  createDashboardRegistry,
} from '@zxio/dashboard/widget'

const registry = createDashboardRegistry()

registry.register({
  name: 'risk-score',
  title: 'Risk Score',
  version: '1.0.0',
  group: 'Business',
  order: 10,
  component: () => import('./RiskScoreWidget.vue'),
  defaultGrid: { w: 6, h: 4 },
  defaultPanel: {
    title: 'Risk Score',
    params: { threshold: 80 },
  },
})

const resolvePanelContent = createDashboardPanelContentResolver(registry, {
  onWidgetEvent(event) {
    console.info(event.event, event.panelId)
  },
})
```

`createGlobWidgets()` 只接受显式 manifest，不从路径、文件名或 `.vue` 名称推断 widget key：

```ts
registry.use(
  createGlobWidgets(
    import.meta.glob('./widgets/**/*.widget.ts', { eager: true })
  )
)
```

`defaultGrid`、`defaultPanel`、`minGrid` / `maxGrid`（`{ w?, h? }` 列/行约束，variant 可按轴覆盖）、`lockable`（默认 `true`，`false` 时 designer 不提供 lock / unlock）、`group`、`order`、`hidden`、`palette` 和 icon metadata 是 registry metadata。`validateDashboardWidgets()` 对超出 `minGrid` / `maxGrid` 的 `gridPos` 报 `grid_below_min` / `grid_above_max`；`resolveDashboardWidgetGridConstraints()` 与 `clampDashboardGridSize()` 供宿主在自定义放置时复用同一套约束。Widget runtime 本身不渲染 palette 或 edit drawer；正式 authoring 能力由独立 `@zxio/dashboard/designer` 入口消费这些 metadata。内置 text/table/chart widgets、`@zxio/chart` 和业务评估 adapter 仍必须留在后续 specs 或业务插件中。

Widget runtime 示例见 `docs/examples/dashboard/widget-runtime.vue`。示例展示 `createDashboardRegistry()`、`registry.register()`、异步 widget、`createDashboardPanelContentResolver(registry)`、`@widget-event`、`@panel-action` 和 `@panel-update-request` 的组合方式。

## Designer Authoring Surface

Designer 是独立 authoring 入口，不从根入口或 widget runtime 入口导出：

```ts
import { ZxDashboardDesigner } from '@zxio/dashboard/designer'
import '@zxio/dashboard/style'
```

`ZxDashboardDesigner` 复用 `ZxDashboardRenderer` 与 `createDashboardPanelContentResolver(registry)`，根据 registry metadata 生成 palette 和新 panel。它不会持有持久化事实源：新增、删除、复制、patch、layout change 会同时 emit granular request/event 与 `update:panels`，最终界面仍由 host 是否回传 props 决定。Designer 样式不通过 `@zxio/dashboard/designer` 产生副作用，仍只由 `@zxio/dashboard/style` / `@zxio/dashboard/style/css` 统一加载。

放置与拖放规则：

- Palette 点击或没有坐标的新增按 first-fit 放置（`findDashboardDesignerFreeSlot()`：从第 0 行起逐行扫描第一个不重叠的空位，没有空位才新开一行），尺寸由 `gridPos` → variant/definition `defaultGrid` → `defaultPanelSize` 决定，再经 `minGrid` / `maxGrid` 与 `grid.columns`（默认 24）钳制（`resolveDashboardDesignerPanelSize()`）。
- Palette 拖拽写入 typed MIME `DASHBOARD_DESIGNER_DRAG_MIME`（= runtime 的 `DASHBOARD_PANEL_DRAG_MIME`，`application/x-zx-dashboard-designer-panel`）以及 `application/json` / `text/plain` 回退；grid 在 drop 时按同一顺序读取。`dragover` 阶段浏览器不暴露数据，designer 用 `beginDashboardDesignerDrag()` 记住的本页 drag（或 `dataTransfer.types` 上的 typed MIME）解析 widget，占位尺寸同样走约束钳制；无法识别的 drag 直接拒绝。宿主自定义拖拽源可调用 `beginDashboardDesignerDrag(dataTransfer, { widget, variant })` / `endDashboardDesignerDrag()`。
- 内置 `lock` / `unlock` / `hide` / `show` 由 designer 翻译成 `panel-patch-request`，写入 `panel.metadata.layout`（见下文「Layout constraints」）；`v-model:panels` 仍是唯一事实源。

历史、脏状态与键盘：

- Designer 持有文档级 undo/redo 历史（`createDashboardDesignerHistory()`，默认 `historyLimit` 100 步），记录的是 panels 快照而不是 grid 引擎的几何事务：标题/params patch、删除、复制、布局变更都进同一条历史。一次拖拽或 resize 内的多次 layout 回写合并为一步；删除/粘贴后引擎的压实回写（300ms settle window 内）并入上一步；文档刚加载时引擎的首次压实只移动干净基线，不会把文档标脏。
- 脏状态 = 当前 panels 与上次保存快照的值比较，通过 `v-model:dirty` 暴露；工具栏显示「有未保存的更改」与「放弃更改」。宿主保存成功后调用实例方法 `markSaved(panels?)`（或 context 的 `markSaved`），切换文档（`document.uid` 变化）时历史自动 `resetHistory()`。`history-change` 事件在 push / undo / redo / discard / saved / reset 时上报 `canUndo` / `canRedo` / `dirty`；undo / redo / discard 同时作为 `designer-event` 上报并携带 `panels` / `previousPanels`。
- 快捷键（`DASHBOARD_DESIGNER_KEYMAP`，macOS 显示为 Cmd）：`Mod+Z` undo、`Mod+Shift+Z` / `Mod+Y` redo、`Mod+S` 触发 `save-request`、`Delete` / `Backspace` 删除选中面板、`Mod+D` 复制、`Esc` 取消选择。undo/redo/save 在 designer 根节点 capture 阶段抢先处理，grid 引擎自己的几何历史不会与文档历史竞争；焦点在 grid 内时 `Delete` / `Mod+D` 由引擎按多选处理并通过 `editor-command-request` 回到 designer；文本输入控件（`input` / `textarea` / `select` / `contenteditable` / `role=textbox|combobox|searchbox`）内的按键不受影响。内置 `duplicate` / `remove` action 的 `shortcut` 会显示在面板菜单里。

示例边界：

- `docs/examples/dashboard/widget-runtime.vue`: 纯 registry + resolver runtime 示例，不包含 palette/drag add/drawer。
- `docs/examples/dashboard/host-composition.vue`: 宿主手写 authoring UI，不 import `@zxio/dashboard/designer`。组件库浮层通过宿主叶子导入 `@zxio/zxui/floating-panel` 完成；`@zxio/dashboard` 与 `@zxio/zxui` 互不依赖。
- `docs/examples/dashboard/designer-dogfood.vue`: 使用 `ZxDashboardDesigner` 的 canonical dogfood workbench。

## DashboardDocument v1

合法 document 必须是 JSON-only 数据，以 `schemaVersion` 和 `panels` 作为根协议：

```json
{
  "schemaVersion": 1,
  "uid": "risk-dashboard",
  "title": "风险看板",
  "pluginVersions": {
    "chart": "1.0.0",
    "risk-score": "2.1.0"
  },
  "references": [
    {
      "id": "risk-query",
      "type": "query",
      "name": "风险查询",
      "target": "query:risk-score"
    }
  ],
  "panels": [
    {
      "id": "panel-risk-score",
      "widget": "risk-score",
      "title": "风险评分",
      "gridPos": { "x": 0, "y": 0, "w": 6, "h": 4 },
      "params": { "threshold": 80 },
      "references": ["risk-query"]
    }
  ]
}
```

规则：

- `schemaVersion` 是正整数，从 `1` 起步，是 document-level migration 的唯一权威版本。
- `panel.id` 必须是非空字符串；legacy 数字 id 只能通过 migration adapter 字符串化。
- `panel.widget` 必须是非空稳定 widget key，禁止路径、URL、`.vue` 文件名、`import(...)`、`import.meta.glob` 和 Vite glob key。
- `panel.references` 只能引用 document-level `references[].id`，外部资源不可复制到 `params`、`data` 或 `metadata` 里充当隐式引用。
- `params` 保存业务配置，`data` 保存渲染数据或快照，`metadata` 保存宿主/插件扩展信息。

禁止把下面内容作为通用 dashboard document 保存：

```json
{
  "widget": "./components/EChartsWidget.vue",
  "setData": "runtime callback",
  "updateGridPos": "runtime callback",
  "metadata": {
    "data": "{\"legacy\":\"stringified business data\"}"
  }
}
```

## Chrome variants

`ZxDashboardRenderer` 与 `ZxDashboardPanelChrome` 通过 `chromeVariant`、
`headerMode`、`hoverElevation`、`focusable`、`selected` 与 panel state 等
可选 prop 控制 panel chrome 的视觉与交互形态。所有字段都是**追加式**的：
未设置时 runtime 沿用旧默认（与历史 schema、事件、slot 完全兼容）。

- `chromeVariant?: 'silent' | 'card'`
  默认 `'silent'`。`'silent'` 把 panel 画成 ZXUI `panel` 表面角色（零阴影、
  主题 `panel-edge` 描边、`radius-control` 圆角）；`'card'` 画成 `card`
  表面角色（主题 `card-depth` 投影、`radius-surface` 圆角）。panel chrome 根
  节点同时写入 `data-zx-surface="panel" | "card"`，renderer / designer 根
  节点写入 `data-zx-surface="canvas"`。未识别值会降级到 `'silent'` 并 emit
  `runtime-issue { code: 'unknown_chrome_variant' }`。
- `selected?: boolean`（panel-chrome）/ `selectedPanelId?: string`（renderer）
  选中态：chrome 根节点加 `is-selected` class、`data-selected="true"` 与
  `aria-current="true"`，描边与 1px 外环切换到主题 accent。`ZxDashboardDesigner`
  会自动把当前选中 panel 传给 renderer。
- `#panel-icon="{ panel, mode }"`（renderer）/ `#icon`（panel-chrome）
  标题前的 16px 图标插槽。`headerMode="minimal"` 时 description 折叠为标题
  右侧的 ⓘ 提示（`title` + `aria-label`），标题本身也带 `title` 以便截断时
  悬停查看全文。header actions 默认在 hover / focus-within / 选中时浮现，
  无 hover 能力的指针设备常驻。
- `panelChrome.headerMode? / panel-chrome 的 headerMode? = 'always' | 'minimal' | 'hover'`
  - `'always'`: 与历史 `showHeader: true` 等价，header 常驻；
  - `'minimal'`: 仅渲染标题，隐藏 description 与 actions；
  - `'hover'`: 默认隐藏 header，hover/focus-within 时浮起，离开 200ms
    后自动收起（CSS 由全局动画 token 驱动）。
  - 当 `headerMode` 与旧 `showHeader` 同时显式提供时，runtime 优先采用
    `headerMode` 并 emit `runtime-issue { code: 'header_mode_conflict' }`。
- `panelChrome.hoverElevation?: boolean`
  默认 `true`。设为 `false` 时 hover 不再切换 box-shadow / border-color，
  对应 chrome 上添加 `is-elevation-disabled` class。
- `focusable?: boolean`
  panel-chrome 根 `<article>` 的 `tabindex` 控制；默认 `true` → `tabindex="0"`。
- `panelChrome.panelState? / panelChrome.getPanelState?`
  传入 `'idle' | 'loading' | 'streaming' | 'error' | 'warn'` 字符串或
  `{ state, label }`，runtime 通过 context 的 `resolvePanelState`
  分发给每个 panel-chrome；非 idle 状态会渲染右上角圆点指示器与 sr-only 文本。

布局编辑 affordance 跟随 runtime mode 与 grid capability：`view` 与 `readonly`
会关闭 drag/resize/drop 并隐藏 resize handle；`layout` 与 `edit` 会在可缩放的
grid item 上显示 resize handle，并在 hover / focus / drag / resize 时增强反馈。
header actions 的可见模式由每个 action 自己的 `visibleIn` 决定（见下文
"Panel actions"），未声明时沿用旧行为：只在 `edit` 显示。

## Panel actions

`panelChrome.actions` / panel-chrome 的 `actions` 接受
`DashboardPanelActionDefinition[]`：

```ts
interface DashboardPanelActionDefinition {
  type: string
  label?: string // 未设置时内置类型取 locale.actions[type]
  icon?: Component // 内置类型自带 16px 线框 SVG
  placement?: 'inline' | 'menu' // 默认 inline；menu 折叠到「更多」按钮
  visibleIn?: DashboardRuntimeMode[] // 默认 ['edit']
  group?: string // 菜单内相邻不同 group 之间插入分隔线
  shortcut?: string // 仅展示（kbd），不绑定键位
  disabled?: boolean
  hidden?: boolean
  danger?: boolean
}
```

内置类型通过 `createDashboardPanelAction(type, overrides?)` 生成；直接写
`{ type: 'refresh' }` 也会被 `normalizeDashboardPanelAction` 补齐默认值：

| type        | placement | visibleIn              | 说明                                            |
| ----------- | --------- | ---------------------- | ----------------------------------------------- |
| `maximize`  | inline    | view / layout / edit   | renderer 内部接管，最大化时原位切换为 `restore` |
| `restore`   | inline    | view / layout / edit   | 还原                                            |
| `refresh`   | inline    | view / layout / edit   | 交给宿主                                        |
| `inspect`   | inline    | edit                   | designer 用它选中面板并打开编辑抽屉             |
| `duplicate` | menu      | edit                   | designer 内置；renderer 下交给宿主              |
| `lock` / `unlock` | menu | edit                   | designer 内置：写 `metadata.layout.locked`，锁定时原位切换为 `unlock`；renderer 下交给宿主 |
| `hide` / `show` | menu  | edit                   | designer 内置：写 `metadata.layout.hidden`，隐藏时原位切换为 `show`；renderer 下交给宿主 |
| `remove`    | menu      | edit                   | `danger`，designer 内置；renderer 下交给宿主    |

- 内置图标按钮 24px，`aria-label` / `title` 取 locale；有 `label` 的宿主
  action 仍渲染文字按钮。actions 容器为 `role="group"`。
- 「更多」按钮使用 HTML Popover API（top layer，不受 grid item 的
  `transform` / `overflow: hidden` 裁切），菜单为 `role="menu"` 且带
  `data-zx-surface="overlay"`，颜色来自主题 overlay 表面角色；无 Popover API
  的环境退化为绝对定位。支持 ArrowUp/Down、Home/End、Esc、Tab 与外部点击关闭。
- `maximize` / `restore`：renderer 新增 `maximizedPanelId?: string | null`
  （受控，`v-model:maximized-panel-id`）与 `maximize-change` 事件；未受控时
  内部维护。最大化时 grid 被 `.zx-dashboard__maximized` 容器替换，高度由
  `--zx-dashboard-maximized-height` / `-min-height`（默认 100% / 480px）决定，
  Esc 还原。`panel-action` 仍会照常 emit。
- `ZxDashboardDesigner` 自动在宿主 actions 后追加内置 `maximize`，edit 模式再
  追加 `inspect` / `duplicate` / `lock` / `hide` / `remove`；宿主声明了同名
  `type` 时以宿主为准。widget `lockable: false` 时不出现 lock / unlock。
- `panelChrome.getPanelActions?(panel, actions)` 可按面板裁剪或追加 action；
  designer 先调用宿主的 hook，再做 lockable 过滤。

## Layout constraints

面板级布局状态存放在 `panel.metadata.layout`（`DashboardPanelLayoutMetadata`），
随文档一起持久化，不新增 `gridPos` 字段：

```ts
interface DashboardPanelLayoutMetadata {
  locked?: boolean // 引擎 static：不可拖动 / 缩放；chrome 加 is-locked
  hidden?: boolean // view / layout 模式不渲染；edit 模式降透明显示，可 show
  minW?: number // 面板自己的尺寸约束（与 widget minGrid / maxGrid 取更严者）
  minH?: number
  maxW?: number
  maxH?: number
}
```

- `readDashboardPanelLayoutMetadata()` / `patchDashboardPanelLayoutMetadata()` /
  `isDashboardPanelLocked()` / `isDashboardPanelHidden()` 从 runtime 入口导出；
  patch 会保留 `metadata` 其余键，`undefined` 删除字段。
- `ZxDashboardGrid` 把 `metadata.layout` 翻译为引擎 item options（`minW` /
  `minH` / `maxW` / `maxH` / `static`），再合并 `grid.getItemOptions?(panel)`
  （宿主可补 `isDraggable` / `isResizable` 或覆盖约束）。designer 额外把 widget
  `minGrid` / `maxGrid` 合进去。引擎在拖拽 / 缩放时执行这些边界；单测只锁
  传给引擎的 props，引擎行为未在 happy-dom 中验证。
- renderer 在 view / layout 模式过滤 `hidden` 面板，但引擎回写 `panels` 时会
  把隐藏面板合并回文档，不会丢失。
- `grid.direction`（`'auto' | 'ltr' | 'rtl'`，默认 `auto` 跟随容器书写方向）与
  `grid.dragActivationDelay`（默认 `{ touch: 300, coarse: 300 }`，鼠标 / 笔立即
  响应）透传给引擎。

## Locale

dashboard 自带文案（工具条、面板操作、运行时 issue 消息、widget 加载态等）
全部走 `@zxio/dashboard/locale`，默认 `en`：

```ts
import { provideDashboardLocale } from '@zxio/dashboard/locale'

// 1) 宿主在上层统一注入：'zh-CN' | 'en' | DashboardLocale | 部分覆盖
provideDashboardLocale('zh-CN')
provideDashboardLocale({ lang: 'zh-CN', actions: { remove: '移除' } })

// 2) 或者直接给组件传 prop
// <ZxDashboardRenderer locale="zh-CN" />
// <ZxDashboardDesigner :locale="{ lang: 'en', toolbar: { save: 'Publish' } }" />
```

`useDashboardLocale()` 返回只读 `Ref<DashboardLocale>`，宿主自定义 slot 或
widget 可以复用同一份文案；`defineDashboardLocale()` 用于声明完整的新语言。
runtime issue 的 `code` 不受语言影响，`message` 会按当前 locale 生成。

CSS 公共面（host 可在自有作用域上覆盖）。"来源"列是 `--zx-semantic-*` 语义
token 名（省略前缀），`<role>` 在 silent 下是 `panel`、card 下是 `card`：

| Token                                                        | 来源（ZXUI 语义 token）                                         | 用途                           |
| ------------------------------------------------------------ | --------------------------------------------------------------- | ------------------------------ |
| `--zx-dashboard-bg`                                          | `surface-canvas-fill`                                           | renderer / designer 画布背景   |
| `--zx-dashboard-text-color`                                  | `surface-canvas-on-text`                                        | 画布继承文字色                 |
| `--zx-dashboard-panel-bg`                                    | `surface-<role>-fill`                                           | panel 背景                     |
| `--zx-dashboard-panel-highlight`                             | `surface-<role>-highlight`                                      | panel 背景高光（background-image） |
| `--zx-dashboard-panel-edge`                                  | `surface-<role>-edge`                                           | panel 描边（border 简写）      |
| `--zx-dashboard-panel-header-bg`                             | = `--zx-dashboard-panel-bg`                                     | header 背景                    |
| `--zx-dashboard-panel-title-color`                           | `surface-<role>-on-text`                                        | 标题 / 继承文字色              |
| `--zx-dashboard-panel-description-color`                     | `surface-<role>-on-text-secondary`                              | 描述 / 辅助文字色              |
| `--zx-dashboard-panel-radius`                                | silent: `radius-control` / card: `radius-surface`               | panel 圆角                     |
| `--zx-dashboard-panel-border-color`                          | `border-subtle`                                                 | 描边回退色、designer 面板描边  |
| `--zx-dashboard-panel-border-color-hover`                    | `border-strong`                                                 | hover 描边                     |
| `--zx-dashboard-panel-selected-color`                        | `accent-base`                                                   | 选中态描边 / 外环 / 激活控件   |
| `--zx-dashboard-panel-shadow`                                | `surface-<role>-depth`                                          | 默认 shadow                    |
| `--zx-dashboard-panel-shadow-hover`                          | silent: = shadow / card: `elevation-overlay-shadow`             | hover shadow                   |
| `--zx-dashboard-panel-shadow-selected`                       | 1px accent 外环 + `surface-<role>-depth`                        | 选中态 shadow                  |
| `--zx-dashboard-panel-header-height`                         | silent 40px / card 44px                                         | header 高度                    |
| `--zx-dashboard-panel-header-divider-color`                  | `border-subtle`                                                 | header 分隔线                  |
| `--zx-dashboard-panel-action-bg` / `-hover`                  | transparent / `fill-hover`                                      | header 图标按钮                |
| `--zx-dashboard-control-bg`                                  | `surface-field-fill`                                            | designer 工具条 / 面板控件背景 |
| `--zx-dashboard-focus-ring-color`                            | `action-focus-ring`                                             | focus ring                     |
| `--zx-dashboard-placeholder-bg`                              | `fill-selected`                                                 | 拖拽占位填充                   |
| `--zx-dashboard-placeholder-border-color`                    | `accent-base`                                                   | 拖拽占位描边                   |
| `--zx-dashboard-grid-guideline-color`                        | `border-subtle`                                                 | 编辑态网格线                   |
| `--zx-dashboard-guide-color` / `-active`                     | `accent-base`                                                   | 对齐 / 吸附指示线              |
| `--zx-dashboard-guide-color-predict`                         | `action-focus-ring`                                             | 预测对齐线                     |
| `--zx-dashboard-grid-dotgrid-color`                          | `border-subtle`                                                 | card 常驻 dot grid 颜色        |
| `--zx-dashboard-grid-dotgrid-enabled`                        | 0 / 1                                                           | card 常驻 dot grid 开关        |
| `--zx-dashboard-resize-handle-color` / `-active`             | = panel description color（`surface-<role>-on-text-secondary`）/ `accent-base` | resize handle           |
| `--zx-dashboard-resize-handle-{size,opacity}`                | 18px / 0.85                                                     | resize handle                  |
| `--zx-dashboard-anim-duration-fast`                          | `motion-duration-fast`（`:root` 回退 160ms）                    | 全局动画 (panel hover、handle) |
| `--zx-dashboard-anim-duration-base`                          | `motion-duration`（`:root` 回退 200ms）                         | 全局动画 (布局过渡)            |
| `--zx-dashboard-anim-easing`                                 | `cubic-bezier(0.2, 0, 0, 1)`                                    | 全局动画 easing                |
| `--zx-dashboard-status-color-{loading,streaming,error,warn}` | `accent-base` / `status-success` / `status-danger` / `status-warning` | 状态徽章配色             |

dashboard 内置 `prefers-reduced-motion: reduce` 的全局降级规则，host 不需要
重复声明。亮 / 暗与密度、对比度、圆角、动效轴统一由最近的 ZXUI 主题 Provider
（`data-zx-theme` / `data-zx-variant`）决定：dashboard 不再自带 `[data-theme]`
或 `prefers-color-scheme` 分支，也没有 `--zx-dashboard-*-dark` 二次 token；
表中每个 token 的内置回退都是亮色字面量，只在宿主完全没有加载 ZXUI 主题时
生效。`@zxio/vue-grid-layout/style.css` 的规则全部位于 `@layer vgl.*`，因此
dashboard 对 placeholder / resize handle 的覆盖不需要 `!important`。详见
`docs/zh-CN/component/dashboard.md` 的"主题与 Chrome"章节。

## Contract Fixtures

后续 dashboard runtime、widget registry、designer 和内置 widget specs 必须复用 `src/fixtures` 中的 v1 fixtures 作为 contract，不得重新定义不兼容 document 格式：

- `empty.json`
- `single-panel.json`
- `multi-panel-references.json`
- `unknown-widget.json`
- `legacy-gridcom-v0.json`
- `invalid-import-like-widget.json`
- `invalid-document.json`

本包的 `__tests__` 同时作为 schema、validation、import/export、migration、legacy adapter 和 package boundary gate。
