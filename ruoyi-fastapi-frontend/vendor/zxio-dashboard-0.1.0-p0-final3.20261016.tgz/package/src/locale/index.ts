import { computed, inject, provide, shallowRef, toValue } from 'vue'
import { en } from './en'
import { zhCn } from './zh-cn'

import type { InjectionKey, MaybeRefOrGetter, Ref } from 'vue'
import type {
  DashboardLocale,
  DashboardLocaleOverride,
  DashboardLocaleSection,
  DashboardLocaleSource,
} from './types'

export { en as dashboardLocaleEn, zhCn as dashboardLocaleZhCn }
export type {
  DashboardLocale,
  DashboardLocaleOverride,
  DashboardLocaleSection,
  DashboardLocaleSource,
} from './types'

export const dashboardLocaleKey: InjectionKey<Ref<DashboardLocale>> = Symbol(
  'zx-dashboard-locale'
)

const SECTION_KEYS = Object.keys(en).filter(
  (key) => key !== 'lang'
) as DashboardLocaleSection[]

const defaultLocale = shallowRef<DashboardLocale>(en)

export function defineDashboardLocale(
  locale: DashboardLocale
): DashboardLocale {
  return locale
}

export function isDashboardChineseLang(lang: string | undefined): boolean {
  return (lang ?? '').toLowerCase().replace(/_/g, '-').startsWith('zh')
}

function baseLocaleFor(lang: string | undefined): DashboardLocale {
  return isDashboardChineseLang(lang) ? zhCn : en
}

export function resolveDashboardLocale(
  source?: DashboardLocaleSource
): DashboardLocale {
  if (!source) return en
  if (typeof source === 'string') return baseLocaleFor(source)

  const override = source as DashboardLocaleOverride
  const base = baseLocaleFor(override.lang)
  const resolved: Record<string, unknown> = {
    ...base,
    lang: override.lang ?? base.lang,
  }

  for (const key of SECTION_KEYS) {
    const section = override[key]
    if (section && typeof section === 'object') {
      resolved[key] = { ...base[key], ...section }
    }
  }

  return resolved as DashboardLocale
}

export function provideDashboardLocale(
  source: MaybeRefOrGetter<DashboardLocaleSource>
): Ref<DashboardLocale> {
  const locale = computed(() => resolveDashboardLocale(toValue(source)))
  provide(dashboardLocaleKey, locale)
  return locale
}

export function useDashboardLocale(): Ref<DashboardLocale> {
  return inject(dashboardLocaleKey, null) ?? defaultLocale
}

export function formatDashboardCopy(
  template: string,
  vars: Record<string, string | number | undefined> = {}
): string {
  return template.replace(/\{(\w+)\}/g, (_, key: string) => {
    const value = vars[key]
    return value === undefined ? `{${key}}` : String(value)
  })
}

export function formatDashboardIssueMessage(
  locale: DashboardLocale,
  code: string,
  vars: Record<string, string | number | undefined> = {}
): string | undefined {
  const template = (locale.issues as Record<string, string | undefined>)[code]
  return template === undefined
    ? undefined
    : formatDashboardCopy(template, vars)
}
