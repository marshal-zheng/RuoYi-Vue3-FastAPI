import type { en } from './en'

export type DashboardLocale = typeof en

export type DashboardLocaleSection = Exclude<keyof DashboardLocale, 'lang'>

export type DashboardLocaleOverride = {
  lang?: string
} & {
  [K in DashboardLocaleSection]?: Partial<DashboardLocale[K]>
}

export type DashboardLocaleSource =
  | string
  | DashboardLocale
  | DashboardLocaleOverride
  | null
  | undefined
