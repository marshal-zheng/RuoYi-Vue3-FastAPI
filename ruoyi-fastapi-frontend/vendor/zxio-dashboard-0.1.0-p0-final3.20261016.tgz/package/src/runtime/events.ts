import type {
  DashboardRuntimeEventSource,
  DashboardRuntimeIssue,
  DashboardRuntimeMode,
} from './types'

export const DASHBOARD_RUNTIME_EVENT_ORDER = [
  'update:panels',
  'layout-change',
  'runtime-issue',
] as const

export function createDashboardRuntimeIssue(
  issue: DashboardRuntimeIssue
): DashboardRuntimeIssue {
  return issue
}

export function createDashboardRuntimeBaseEvent(input: {
  type: string
  mode: DashboardRuntimeMode
  source: DashboardRuntimeEventSource
  nativeEvent?: Event
}) {
  return input
}
