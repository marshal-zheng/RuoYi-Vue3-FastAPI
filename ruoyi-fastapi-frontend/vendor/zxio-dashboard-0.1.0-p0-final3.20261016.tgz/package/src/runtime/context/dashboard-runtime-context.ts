import { inject, provide } from 'vue'
import { dashboardRuntimeContextKey } from './symbols'

import type { DashboardRuntimeContext } from '../types'

export function provideDashboardRuntimeContext(
  context: DashboardRuntimeContext
): DashboardRuntimeContext {
  provide(dashboardRuntimeContextKey, context)
  return context
}

export function useDashboardRuntimeContext(): DashboardRuntimeContext | null {
  return inject(dashboardRuntimeContextKey, null)
}

export function useRequiredDashboardRuntimeContext(): DashboardRuntimeContext {
  const context = useDashboardRuntimeContext()

  if (!context) {
    throw new Error(
      '[dashboard] Missing DashboardRuntimeContext. Mount this component under ZxDashboardRenderer or call provideDashboardRuntimeContext().'
    )
  }

  return context
}
