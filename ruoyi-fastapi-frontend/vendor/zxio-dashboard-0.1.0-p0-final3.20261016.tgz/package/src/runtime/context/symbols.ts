import type { InjectionKey } from 'vue'
import type { DashboardRuntimeContext } from '../types'

export const dashboardRuntimeContextKey: InjectionKey<DashboardRuntimeContext> =
  Symbol('DashboardRuntimeContext')
