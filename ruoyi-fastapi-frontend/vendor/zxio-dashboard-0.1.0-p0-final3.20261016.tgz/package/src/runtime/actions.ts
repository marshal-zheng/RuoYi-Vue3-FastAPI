import { h } from 'vue'

import type { FunctionalComponent } from 'vue'
import type {
  DashboardPanelActionDefinition,
  DashboardRuntimeMode,
} from './types'

export type DashboardBuiltinPanelActionType =
  | 'maximize'
  | 'restore'
  | 'refresh'
  | 'inspect'
  | 'duplicate'
  | 'remove'
  | 'lock'
  | 'unlock'
  | 'hide'
  | 'show'

const ALL_MODES: readonly DashboardRuntimeMode[] = ['view', 'layout', 'edit']
const EDIT_ONLY: readonly DashboardRuntimeMode[] = ['edit']

/** A 16px stroke icon in the dashboard's own style (`aria-hidden`, `currentColor`). */
export function createDashboardIcon(
  name: string,
  paths: string[]
): FunctionalComponent {
  const icon: FunctionalComponent = () =>
    h(
      'svg',
      {
        viewBox: '0 0 16 16',
        fill: 'none',
        stroke: 'currentColor',
        'stroke-width': 1.5,
        'stroke-linecap': 'round',
        'stroke-linejoin': 'round',
        'aria-hidden': 'true',
        focusable: 'false',
      },
      paths.map((d) => h('path', { d }))
    )
  icon.displayName = `ZxDashboardIcon${name}`
  return icon
}

const createIcon = createDashboardIcon

export const DASHBOARD_PANEL_ACTION_ICONS = {
  maximize: createIcon('Maximize', [
    'M9.5 2.5h4v4',
    'M13.5 2.5 9 7',
    'M6.5 13.5h-4v-4',
    'M2.5 13.5 7 9',
  ]),
  restore: createIcon('Restore', [
    'M13.5 6.5h-4v-4',
    'M9.5 6.5 14 2',
    'M2.5 9.5h4v4',
    'M6.5 9.5 2 14',
  ]),
  refresh: createIcon('Refresh', ['M13 8a5 5 0 1 1-1.5-3.6', 'M13 2.5v3h-3']),
  inspect: createIcon('Inspect', ['M11.5 2.5l2 2-8 8H3.5v-2z', 'M10 4l2 2']),
  duplicate: createIcon('Duplicate', ['M6 6h7v7H6z', 'M10 6V3H3v7h3']),
  remove: createIcon('Remove', [
    'M3 4.5h10',
    'M6.5 4.5V3h3v1.5',
    'M4.5 4.5l.6 8.5h5.8l.6-8.5',
    'M6.75 7v4',
    'M9.25 7v4',
  ]),
  lock: createIcon('Lock', ['M4 7h8v6.5H4z', 'M5.5 7V5a2.5 2.5 0 0 1 5 0v2']),
  unlock: createIcon('Unlock', [
    'M4 7h8v6.5H4z',
    'M5.5 7V5a2.5 2.5 0 0 1 4.8-1',
  ]),
  hide: createIcon('Hide', [
    'M2 2l12 12',
    'M6.3 6.3A2 2 0 0 0 9.7 9.7',
    'M3.6 5.6C2.6 6.5 2 8 2 8s2.2 4 6 4c1.1 0 2-.3 2.8-.7',
    'M7 4.1C7.3 4 7.7 4 8 4c3.8 0 6 4 6 4s-.6 1.2-1.7 2.2',
  ]),
  show: createIcon('Show', [
    'M2 8s2.2-4 6-4 6 4 6 4-2.2 4-6 4-6-4-6-4z',
    'M10 8a2 2 0 1 1-4 0 2 2 0 0 1 4 0z',
  ]),
  more: createIcon('More', ['M3.25 8h.01', 'M8 8h.01', 'M12.75 8h.01']),
} satisfies Record<
  DashboardBuiltinPanelActionType | 'more',
  FunctionalComponent
>

export const DASHBOARD_BUILTIN_PANEL_ACTIONS: Readonly<
  Record<DashboardBuiltinPanelActionType, DashboardPanelActionDefinition>
> = {
  maximize: {
    type: 'maximize',
    icon: DASHBOARD_PANEL_ACTION_ICONS.maximize,
    placement: 'inline',
    visibleIn: ALL_MODES,
    group: 'view',
  },
  restore: {
    type: 'restore',
    icon: DASHBOARD_PANEL_ACTION_ICONS.restore,
    placement: 'inline',
    visibleIn: ALL_MODES,
    group: 'view',
  },
  refresh: {
    type: 'refresh',
    icon: DASHBOARD_PANEL_ACTION_ICONS.refresh,
    placement: 'inline',
    visibleIn: ALL_MODES,
    group: 'view',
  },
  inspect: {
    type: 'inspect',
    icon: DASHBOARD_PANEL_ACTION_ICONS.inspect,
    placement: 'inline',
    visibleIn: EDIT_ONLY,
    group: 'edit',
  },
  duplicate: {
    type: 'duplicate',
    icon: DASHBOARD_PANEL_ACTION_ICONS.duplicate,
    placement: 'menu',
    visibleIn: EDIT_ONLY,
    group: 'edit',
    shortcut: 'Mod+D',
  },
  lock: {
    type: 'lock',
    icon: DASHBOARD_PANEL_ACTION_ICONS.lock,
    placement: 'menu',
    visibleIn: EDIT_ONLY,
    group: 'state',
  },
  unlock: {
    type: 'unlock',
    icon: DASHBOARD_PANEL_ACTION_ICONS.unlock,
    placement: 'menu',
    visibleIn: EDIT_ONLY,
    group: 'state',
  },
  hide: {
    type: 'hide',
    icon: DASHBOARD_PANEL_ACTION_ICONS.hide,
    placement: 'menu',
    visibleIn: EDIT_ONLY,
    group: 'state',
  },
  show: {
    type: 'show',
    icon: DASHBOARD_PANEL_ACTION_ICONS.show,
    placement: 'menu',
    visibleIn: EDIT_ONLY,
    group: 'state',
  },
  remove: {
    type: 'remove',
    icon: DASHBOARD_PANEL_ACTION_ICONS.remove,
    placement: 'menu',
    visibleIn: EDIT_ONLY,
    danger: true,
    group: 'danger',
    shortcut: 'Delete',
  },
}

export function isDashboardBuiltinPanelActionType(
  type: string
): type is DashboardBuiltinPanelActionType {
  return Object.prototype.hasOwnProperty.call(
    DASHBOARD_BUILTIN_PANEL_ACTIONS,
    type
  )
}

function withDefinedFields(
  base: DashboardPanelActionDefinition,
  overrides: Partial<DashboardPanelActionDefinition>
): DashboardPanelActionDefinition {
  const merged: DashboardPanelActionDefinition = { ...base }
  for (const [key, value] of Object.entries(overrides)) {
    if (value !== undefined) {
      ;(merged as unknown as Record<string, unknown>)[key] = value
    }
  }
  return merged
}

export function createDashboardPanelAction(
  type: DashboardBuiltinPanelActionType,
  overrides: Partial<Omit<DashboardPanelActionDefinition, 'type'>> = {}
): DashboardPanelActionDefinition {
  return withDefinedFields(DASHBOARD_BUILTIN_PANEL_ACTIONS[type], overrides)
}

/**
 * Fills a host-authored action with the built-in defaults of its `type`
 * (icon, placement, visibleIn, group, danger). Host fields that are set win;
 * unknown types pass through untouched.
 */
export function normalizeDashboardPanelAction(
  action: DashboardPanelActionDefinition
): DashboardPanelActionDefinition {
  if (!isDashboardBuiltinPanelActionType(action.type)) return action
  return withDefinedFields(DASHBOARD_BUILTIN_PANEL_ACTIONS[action.type], action)
}

export function isDashboardPanelActionVisible(
  action: DashboardPanelActionDefinition,
  mode: DashboardRuntimeMode
): boolean {
  if (action.hidden) return false
  return (action.visibleIn ?? EDIT_ONLY).includes(mode)
}

/** Normalizes built-in defaults, then keeps the actions visible in `mode`. */
export function resolveDashboardPanelActions(
  actions: readonly DashboardPanelActionDefinition[],
  mode: DashboardRuntimeMode
): DashboardPanelActionDefinition[] {
  return actions
    .map(normalizeDashboardPanelAction)
    .filter((action) => isDashboardPanelActionVisible(action, mode))
}

export function splitDashboardPanelActions(
  actions: readonly DashboardPanelActionDefinition[]
): {
  inline: DashboardPanelActionDefinition[]
  menu: DashboardPanelActionDefinition[]
} {
  const inline: DashboardPanelActionDefinition[] = []
  const menu: DashboardPanelActionDefinition[] = []
  for (const action of actions) {
    if (action.placement === 'menu') menu.push(action)
    else inline.push(action)
  }
  return { inline, menu }
}
