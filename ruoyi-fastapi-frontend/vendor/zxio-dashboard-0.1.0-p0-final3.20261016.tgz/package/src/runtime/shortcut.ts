/**
 * Display helpers for keyboard shortcuts written in the canonical
 * `Mod+Shift+Z` form. `Mod` is Cmd on Apple platforms and Ctrl elsewhere.
 */

export function isApplePlatform(): boolean {
  if (typeof navigator === 'undefined') return false
  const probe =
    (navigator as { userAgentData?: { platform?: string } }).userAgentData
      ?.platform ||
    navigator.platform ||
    navigator.userAgent ||
    ''
  return /mac|iphone|ipad|ipod/i.test(probe)
}

const KEY_LABELS: Readonly<Record<string, string>> = {
  Escape: 'Esc',
  ArrowUp: '↑',
  ArrowDown: '↓',
  ArrowLeft: '←',
  ArrowRight: '→',
}

export function parseDashboardShortcut(shortcut: string): string[] {
  return shortcut
    .split('+')
    .map((token) => token.trim())
    .filter((token) => token.length > 0)
}

/** `Mod+Z` → `Cmd+Z` on Apple platforms, `Ctrl+Z` elsewhere. */
export function formatDashboardShortcut(
  shortcut: string,
  options: { apple?: boolean } = {}
): string {
  const apple = options.apple ?? isApplePlatform()
  return parseDashboardShortcut(shortcut)
    .map((token) => {
      switch (token) {
        case 'Mod':
          return apple ? 'Cmd' : 'Ctrl'
        case 'Meta':
          return apple ? 'Cmd' : 'Win'
        case 'Control':
          return 'Ctrl'
        default:
          return (
            KEY_LABELS[token] ??
            (token.length === 1 ? token.toUpperCase() : token)
          )
      }
    })
    .join('+')
}

/** `aria-keyshortcuts` value: `Mod+Z` → `Meta+Z` on Apple platforms, `Control+Z` elsewhere. */
export function formatDashboardAriaKeyShortcuts(
  shortcuts: string | readonly string[],
  options: { apple?: boolean } = {}
): string {
  const apple = options.apple ?? isApplePlatform()
  const list = typeof shortcuts === 'string' ? [shortcuts] : shortcuts
  return list
    .map((shortcut) =>
      parseDashboardShortcut(shortcut)
        .map((token) => {
          if (token === 'Mod') return apple ? 'Meta' : 'Control'
          if (token === 'Ctrl') return 'Control'
          if (token === 'Cmd') return 'Meta'
          return token.length === 1 ? token.toUpperCase() : token
        })
        .join('+')
    )
    .join(' ')
}
