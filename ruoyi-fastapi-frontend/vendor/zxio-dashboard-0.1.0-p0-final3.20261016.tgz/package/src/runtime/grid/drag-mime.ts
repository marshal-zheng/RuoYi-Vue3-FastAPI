/** Typed drag payload the designer palette and host drag sources set. */
export const DASHBOARD_PANEL_DRAG_MIME =
  'application/x-zx-dashboard-designer-panel'

/** MIME types read on drop, most specific first. */
export const DASHBOARD_PANEL_DROP_MIME_TYPES = [
  DASHBOARD_PANEL_DRAG_MIME,
  'application/json',
  'text/plain',
] as const

/**
 * Reads the first non-empty payload in {@link DASHBOARD_PANEL_DROP_MIME_TYPES}
 * order. Browsers withhold the data during `dragover` (protected mode), so
 * callers that only need to accept a drag should check `types` instead.
 */
export function readDashboardDropPayload(
  dataTransfer: DataTransfer | null | undefined
): string | undefined {
  if (!dataTransfer || typeof dataTransfer.getData !== 'function') {
    return undefined
  }

  for (const type of DASHBOARD_PANEL_DROP_MIME_TYPES) {
    let value: unknown
    try {
      value = dataTransfer.getData(type)
    } catch {
      value = undefined
    }
    if (typeof value === 'string' && value.length > 0) return value
  }

  return undefined
}

/** MIME types present on a drag; readable during `dragover` unlike the data. */
export function readDashboardDropTypes(
  dataTransfer: DataTransfer | null | undefined
): readonly string[] {
  const types = dataTransfer?.types
  if (!types) return []
  return Array.from(types as ArrayLike<string>, (type) => String(type))
}

export function hasDashboardPanelDragType(
  types: readonly string[] | undefined
): boolean {
  if (!types) return false
  return types.some((type) => type.toLowerCase() === DASHBOARD_PANEL_DRAG_MIME)
}
