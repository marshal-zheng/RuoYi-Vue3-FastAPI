import { cloneDashboardJson } from '../../schema'

import type { DashboardPanel } from '../../schema'
import type {
  DashboardEditorHostCommand,
  DashboardGridLayoutItem,
} from '../types'

/**
 * Editor commands whose only effect is selection or geometry. The host adopts
 * their result through `layout-change`, so the engine and `panels` stay equal.
 */
const DASHBOARD_EDITOR_GEOMETRY_COMMANDS = new Set([
  'select',
  'clearSelection',
  'copy',
  'move',
  'resize',
  'align',
  'distribute',
  'tidy',
])

/**
 * Editor commands the host answers itself. The engine's own run is cancelled
 * (its geometry history and persistence never see them) and the grid reports
 * an `editor-command-request` carrying the engine's target ids.
 */
const DASHBOARD_EDITOR_HOST_COMMANDS: ReadonlySet<string> =
  new Set<DashboardEditorHostCommand>([
    'delete',
    'undo',
    'redo',
    'save',
    'discard',
  ])

export function isDashboardEditorHostCommand(
  commandType: string
): commandType is DashboardEditorHostCommand {
  return DASHBOARD_EDITOR_HOST_COMMANDS.has(commandType)
}

export type DashboardGridEditorCommandResolution = {
  /** `request`: the host runs the command on its own model (see `editor-command-request`). */
  status: 'allow' | 'cancel' | 'block' | 'request'
  panels?: DashboardPanel[]
}

/** Builds the title of a cloned panel from the source title. */
export type DashboardCopyTitleFormatter = (title: string) => string

const defaultCopyTitle: DashboardCopyTitleFormatter = (title) => `${title} Copy`

/**
 * Maps one library editor command onto the dashboard model. Removal, history
 * and persistence commands become host requests (the host owns panels and
 * document history); anything else that would change the engine without a
 * matching `panels` change (hide, lock, reset, section commands) is blocked.
 */
export function resolveDashboardGridEditorCommand(input: {
  panels: readonly DashboardPanel[]
  /** Panel ids held by this grid's own editor clipboard. */
  clipboardSourceIds: readonly string[]
  commandType: string
  commandSource?: string
  targetIds: readonly string[]
  payload?: unknown
  layoutPatches?: readonly unknown[]
  formatCopyTitle?: DashboardCopyTitleFormatter
}): DashboardGridEditorCommandResolution {
  if (DASHBOARD_EDITOR_GEOMETRY_COMMANDS.has(input.commandType)) {
    return { status: 'allow' }
  }

  if (isDashboardEditorHostCommand(input.commandType)) {
    return { status: 'request' }
  }

  // Drops reach the host as `panel-add-request`; the library only commits the
  // placeholder geometry, which the grid resyncs from `panels` afterwards.
  if (input.commandType === 'add') {
    return { status: input.commandSource === 'drop' ? 'allow' : 'block' }
  }

  if (input.commandType !== 'paste' && input.commandType !== 'duplicate') {
    return { status: 'block' }
  }

  if (input.commandType === 'paste' && input.clipboardSourceIds.length === 0) {
    return { status: 'block' }
  }

  const addedItems = readDashboardEditorAddedLayoutItems(input.layoutPatches)
  if (addedItems.length === 0) return { status: 'allow' }

  const payloadSourceIds = readDashboardEditorClipboardSourceIds(
    input.payload
  ).filter((id) => input.clipboardSourceIds.includes(id))
  const sourceIds =
    input.commandType === 'duplicate'
      ? input.targetIds
      : payloadSourceIds.length > 0
      ? payloadSourceIds
      : input.clipboardSourceIds

  const cloned = applyDashboardEditorClipboardCommand({
    panels: input.panels,
    commandType: input.commandType,
    targetIds: input.targetIds,
    sourceIds,
    addedItems,
    formatCopyTitle: input.formatCopyTitle,
  })

  if (!cloned) return { status: 'cancel' }

  return {
    status: 'cancel',
    panels: cloned.panels,
  }
}

export function applyDashboardEditorClipboardCommand(input: {
  panels: readonly DashboardPanel[]
  commandType: string
  targetIds?: readonly string[]
  sourceIds?: readonly string[]
  addedItems?: readonly Pick<
    DashboardGridLayoutItem,
    'i' | 'x' | 'y' | 'w' | 'h'
  >[]
  formatCopyTitle?: DashboardCopyTitleFormatter
}): { panels: DashboardPanel[] } | null {
  if (input.commandType !== 'paste' && input.commandType !== 'duplicate') {
    return null
  }

  const addedItems = input.addedItems ?? []
  if (addedItems.length === 0) return null
  const formatCopyTitle = input.formatCopyTitle ?? defaultCopyTitle

  const sourceIds =
    input.commandType === 'duplicate'
      ? input.targetIds ?? input.sourceIds ?? []
      : input.sourceIds?.length
      ? input.sourceIds
      : input.targetIds ?? []

  const usedIds = new Set(input.panels.map((panel) => panel.id))
  const cloned: DashboardPanel[] = []

  addedItems.forEach((item, index) => {
    const sourceId = sourceIds[index]
    const source = sourceId
      ? input.panels.find((panel) => panel.id === sourceId)
      : undefined
    if (!source) return

    const id = nextUniqueDashboardPanelId(item.i, usedIds)
    usedIds.add(id)
    cloned.push({
      ...cloneDashboardJson(source),
      id,
      title: source.title ? formatCopyTitle(source.title) : undefined,
      gridPos: {
        x: item.x,
        y: item.y,
        w: item.w,
        h: item.h,
      },
    })
  })

  if (cloned.length === 0) return null
  return { panels: [...input.panels, ...cloned] }
}

export function adoptUnknownDashboardLayoutItems(input: {
  panels: readonly DashboardPanel[]
  layout: readonly DashboardGridLayoutItem[]
  sourceIds: readonly string[]
  ignoreIds?: ReadonlySet<string>
  formatCopyTitle?: DashboardCopyTitleFormatter
}): { panels: DashboardPanel[] } | null {
  const knownIds = new Set(input.panels.map((panel) => panel.id))
  const addedItems = input.layout.filter(
    (item) => !knownIds.has(item.i) && !input.ignoreIds?.has(item.i)
  )
  if (addedItems.length === 0) return null

  return applyDashboardEditorClipboardCommand({
    panels: input.panels,
    commandType: 'paste',
    sourceIds: input.sourceIds,
    addedItems,
    formatCopyTitle: input.formatCopyTitle,
  })
}

export type DashboardEditorClipboard = {
  /** Instance-scoped clipboard adapter handed to the grid editor. */
  adapter: {
    read: () => unknown
    write: (payload: unknown) => void
    hasContent: () => boolean
    subscribe: (listener: () => void) => () => void
    clear: () => void
  }
  /** Panel ids of the items this grid copied last. */
  sourceIds: () => string[]
}

/**
 * The library's internal clipboard is shared by every grid on the page, so a
 * paste in one dashboard could clone whatever ids another dashboard copied.
 * Each dashboard grid keeps its own clipboard instead, and its payload names
 * the source panels for paste.
 */
export function createDashboardEditorClipboard(): DashboardEditorClipboard {
  let payload: unknown = null
  const listeners = new Set<() => void>()
  const notify = () => listeners.forEach((listener) => listener())

  return {
    adapter: {
      read: () => (payload === null ? null : cloneDashboardJson(payload)),
      write: (next) => {
        payload = cloneDashboardJson(next)
        notify()
      },
      hasContent: () =>
        readDashboardEditorClipboardSourceIds(payload).length > 0,
      subscribe: (listener) => {
        listeners.add(listener)
        return () => {
          listeners.delete(listener)
        }
      },
      clear: () => {
        payload = null
        notify()
      },
    },
    sourceIds: () => readDashboardEditorClipboardSourceIds(payload),
  }
}

export function readDashboardEditorAddedLayoutItems(
  layoutPatches: readonly unknown[] | undefined
): DashboardGridLayoutItem[] {
  if (!layoutPatches) return []

  return layoutPatches.flatMap((patch) => {
    const item = readAddedLayoutItem(patch)
    return item ? [item] : []
  })
}

export function readDashboardEditorClipboardSourceIds(
  payload: unknown
): string[] {
  if (!payload || typeof payload !== 'object') return []

  const record = payload as Record<string, unknown>
  const resolved = record.resolvedClipboardPayload
  const items =
    resolved && typeof resolved === 'object'
      ? (resolved as { items?: unknown }).items
      : record.items

  if (!Array.isArray(items)) return []

  return items.flatMap((item) => {
    if (!item || typeof item !== 'object') return []
    const id = (item as { i?: unknown }).i
    return typeof id === 'string' && id.length > 0 ? [id] : []
  })
}

function readAddedLayoutItem(
  patch: unknown
): DashboardGridLayoutItem | undefined {
  if (!patch || typeof patch !== 'object') return undefined

  const candidate = patch as { type?: unknown; item?: unknown }
  if (
    candidate.type !== 'add' ||
    !candidate.item ||
    typeof candidate.item !== 'object'
  ) {
    return undefined
  }

  const item = candidate.item as Record<string, unknown>
  if (typeof item.i !== 'string' || item.i.length === 0) return undefined
  if (
    !Number.isInteger(item.x) ||
    !Number.isInteger(item.y) ||
    !Number.isInteger(item.w) ||
    !Number.isInteger(item.h)
  ) {
    return undefined
  }

  return {
    i: item.i,
    x: item.x as number,
    y: item.y as number,
    w: item.w as number,
    h: item.h as number,
  }
}

function nextUniqueDashboardPanelId(
  preferred: string,
  used: Set<string>
): string {
  if (!used.has(preferred)) return preferred

  let index = 2
  let candidate = `${preferred}-${index}`
  while (used.has(candidate)) {
    index += 1
    candidate = `${preferred}-${index}`
  }
  return candidate
}
