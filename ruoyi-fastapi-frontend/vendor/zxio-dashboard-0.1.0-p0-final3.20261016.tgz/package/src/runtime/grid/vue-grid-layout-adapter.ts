import { WidthProvider } from '@zxio/vue-grid-layout'
import { EditorGridLayout } from '@zxio/vue-grid-layout/editor'

import type { Component } from 'vue'
import type { GridInteractionEventPayload } from '@zxio/vue-grid-layout'
import type { GridEditorProp } from '@zxio/vue-grid-layout/editor'
import type { DashboardGridLayoutItem } from '../types'
import type { DashboardEditorClipboard } from './editor-clipboard'

export const DefaultDashboardGridLayout = WidthProvider(
  EditorGridLayout
) as Component

/** Elements whose key events the grid engine must leave alone (matched on the event target). */
export const DASHBOARD_GRID_IGNORED_KEY_TARGETS = [
  'input',
  'textarea',
  'select',
  '[contenteditable]:not([contenteditable="false"])',
  '[role="textbox"]',
  '[role="combobox"]',
  '[role="searchbox"]',
].join(', ')

/**
 * The library reads `editor` once at setup, so the grid must remount whenever
 * `enabled` changes; view / readonly grids get no editor (and no guides).
 */
export function createDashboardGridEditor(options: {
  enabled: boolean
  columns: number
  compactType: 'vertical' | 'horizontal' | null
  beforeCommand?: GridEditorProp['beforeCommand']
  clipboard?: DashboardEditorClipboard['adapter']
}): false | GridEditorProp {
  if (!options.enabled) return false

  return {
    defaultMode: 'edit',
    persistence: false,
    // The opaque payload is owned by the library; the dashboard only reads ids.
    clipboard: options.clipboard as GridEditorProp['clipboard'],
    input: {
      pasteMode: 'immediate',
      // Text inputs inside widgets keep their own Delete / Backspace / undo
      // keys; the engine only reads keys aimed at the grid itself.
      ignoredTargets: [
        (target: unknown) =>
          typeof (target as Element | null)?.closest === 'function' &&
          (target as Element).closest(DASHBOARD_GRID_IGNORED_KEY_TARGETS) !==
            null,
      ],
    },
    layoutEngineOptions: {
      cols: options.columns,
      compactType: options.compactType,
      allowOverlap: false,
      preventCollision: false,
    },
    guides: {
      enabled: true,
      snap: true,
      cols: options.columns,
      compactType: options.compactType,
      showGrid: 'interaction',
      // R6.AC1: interactions show grid guides only, no extra size labels.
      showSpacingLabels: false,
    },
    beforeCommand: options.beforeCommand,
  }
}

export function readGridInteraction(payload: unknown): {
  item?: DashboardGridLayoutItem
  event?: Event
} {
  if (!isGridInteractionPayload(payload)) return {}

  const item = payload.item
  if (!item || typeof item.i !== 'string') {
    return { event: payload.event }
  }

  return {
    item: item as DashboardGridLayoutItem,
    event: payload.event,
  }
}

function isGridInteractionPayload(
  value: unknown
): value is GridInteractionEventPayload {
  if (!value || typeof value !== 'object') return false
  const payload = value as Partial<GridInteractionEventPayload>
  return typeof payload.kind === 'string' && typeof payload.phase === 'string'
}
