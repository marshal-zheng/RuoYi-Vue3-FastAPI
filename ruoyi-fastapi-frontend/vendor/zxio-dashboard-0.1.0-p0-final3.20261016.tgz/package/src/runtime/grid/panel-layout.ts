import { isDashboardPlainObject } from '../../schema'

import type { DashboardJsonObject, DashboardPanel } from '../../schema'
import type {
  DashboardGridItemOptions,
  DashboardPanelLayoutMetadata,
} from '../types'

/** `panel.metadata` key that carries {@link DashboardPanelLayoutMetadata}. */
export const DASHBOARD_PANEL_LAYOUT_METADATA_KEY = 'layout'

/** Reads the layout state of a panel; malformed fields are ignored. */
export function readDashboardPanelLayoutMetadata(
  panel: Pick<DashboardPanel, 'metadata'>
): DashboardPanelLayoutMetadata {
  const raw = panel.metadata?.[DASHBOARD_PANEL_LAYOUT_METADATA_KEY]
  if (!isDashboardPlainObject(raw)) return {}

  const layout: DashboardPanelLayoutMetadata = {}
  if (typeof raw.locked === 'boolean') layout.locked = raw.locked
  if (typeof raw.hidden === 'boolean') layout.hidden = raw.hidden
  for (const key of ['minW', 'minH', 'maxW', 'maxH'] as const) {
    const value = raw[key]
    if (typeof value === 'number' && Number.isInteger(value) && value > 0) {
      layout[key] = value
    }
  }
  return layout
}

export function isDashboardPanelLocked(
  panel: Pick<DashboardPanel, 'metadata'>
): boolean {
  return readDashboardPanelLayoutMetadata(panel).locked === true
}

export function isDashboardPanelHidden(
  panel: Pick<DashboardPanel, 'metadata'>
): boolean {
  return readDashboardPanelLayoutMetadata(panel).hidden === true
}

/**
 * Returns the `metadata` object to patch a panel with: the existing metadata
 * and layout entries are kept, `patch` fields win, and `undefined` removes a
 * field so the result stays JSON-clean.
 */
export function patchDashboardPanelLayoutMetadata(
  panel: Pick<DashboardPanel, 'metadata'>,
  patch: DashboardPanelLayoutMetadata
): DashboardJsonObject {
  const metadata = panel.metadata ?? {}
  const current = metadata[DASHBOARD_PANEL_LAYOUT_METADATA_KEY]
  const layout: DashboardJsonObject = isDashboardPlainObject(current)
    ? { ...current }
    : {}

  for (const [key, value] of Object.entries(patch)) {
    if (value === undefined) delete layout[key]
    else layout[key] = value
  }

  return {
    ...metadata,
    [DASHBOARD_PANEL_LAYOUT_METADATA_KEY]: layout,
  }
}

/** Engine item options a panel carries in its own metadata. */
export function resolveDashboardGridItemOptions(
  panel: Pick<DashboardPanel, 'metadata'>
): DashboardGridItemOptions {
  const layout = readDashboardPanelLayoutMetadata(panel)
  const options: DashboardGridItemOptions = {}

  if (layout.minW !== undefined) options.minW = layout.minW
  if (layout.minH !== undefined) options.minH = layout.minH
  if (layout.maxW !== undefined) options.maxW = layout.maxW
  if (layout.maxH !== undefined) options.maxH = layout.maxH
  if (layout.locked) options.static = true

  return options
}

/** Drops `undefined` fields so they never shadow engine defaults. */
export function compactDashboardGridItemOptions(
  options: DashboardGridItemOptions
): DashboardGridItemOptions {
  const compact: DashboardGridItemOptions = {}
  for (const [key, value] of Object.entries(options)) {
    if (value !== undefined) {
      ;(compact as Record<string, unknown>)[key] = value
    }
  }
  return compact
}
