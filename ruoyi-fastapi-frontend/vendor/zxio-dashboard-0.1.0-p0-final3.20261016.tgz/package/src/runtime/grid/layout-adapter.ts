import type { DashboardGridPosition, DashboardPanel } from '../../schema'
import type {
  DashboardApplyLayoutOptions,
  DashboardBuildLayoutOptions,
  DashboardGridLayoutItem,
  DashboardLayoutChange,
  DashboardRuntimeIssue,
} from '../types'

export function buildDashboardGridLayout(
  panels: readonly DashboardPanel[],
  options: DashboardBuildLayoutOptions = {}
): DashboardGridLayoutItem[] {
  return panels.map((panel) => {
    const itemOptions = options.getItemOptions?.(panel) ?? {}

    return {
      i: panel.id,
      x: panel.gridPos.x,
      y: panel.gridPos.y,
      w: panel.gridPos.w,
      h: panel.gridPos.h,
      ...itemOptions,
    }
  })
}

export function applyDashboardGridLayout(
  panels: readonly DashboardPanel[],
  layout: readonly DashboardGridLayoutItem[],
  options: DashboardApplyLayoutOptions = {}
): {
  panels: DashboardPanel[]
  changes: DashboardLayoutChange[]
  issues: DashboardRuntimeIssue[]
} {
  const issues: DashboardRuntimeIssue[] = []
  const changes: DashboardLayoutChange[] = []
  const layoutByPanelId = new Map<
    string,
    { item: DashboardGridLayoutItem; index: number }
  >()
  const panelIds = new Set(panels.map((panel) => panel.id))

  layout.forEach((item, index) => {
    if (layoutByPanelId.has(item.i)) {
      issues.push({
        severity: 'warn',
        code: 'duplicate_layout_item',
        message: `Duplicate layout item for panel "${item.i}" was ignored.`,
        panelId: item.i,
        path: `/layout/${index}`,
      })
      return
    }

    if (!panelIds.has(item.i)) {
      issues.push({
        severity: 'warn',
        code: 'unknown_layout_panel',
        message: `Layout item references unknown panel "${item.i}".`,
        panelId: item.i,
        path: `/layout/${index}`,
      })
      return
    }

    layoutByPanelId.set(item.i, { item, index })
  })

  const nextPanels = panels.map((panel, index) => {
    const layoutEntry = layoutByPanelId.get(panel.id)

    if (!layoutEntry) {
      if (options.keepMissingPanels !== false) {
        issues.push({
          severity: 'warn',
          code: 'missing_layout_item',
          message: `Missing layout item for panel "${panel.id}".`,
          panelId: panel.id,
          path: `/panels/${index}`,
        })
      }
      return panel
    }

    const nextGridPos = normalizeDashboardGridPosition(layoutEntry.item)

    if (!nextGridPos) {
      issues.push({
        severity: 'error',
        code: 'invalid_layout_item',
        message: `Invalid layout item for panel "${panel.id}".`,
        panelId: panel.id,
        path: `/layout/${layoutEntry.index}`,
      })
      return panel
    }

    if (isSameGridPosition(panel.gridPos, nextGridPos)) {
      return panel
    }

    changes.push({
      panelId: panel.id,
      before: { ...panel.gridPos },
      after: nextGridPos,
    })

    return {
      ...panel,
      gridPos: nextGridPos,
    }
  })

  return {
    panels: nextPanels,
    changes,
    issues,
  }
}

export function sortPanelsByGridPosition(
  panels: readonly DashboardPanel[]
): DashboardPanel[] {
  return [...panels].sort((a, b) => {
    const byY = a.gridPos.y - b.gridPos.y
    if (byY !== 0) return byY

    const byX = a.gridPos.x - b.gridPos.x
    if (byX !== 0) return byX

    return a.id.localeCompare(b.id)
  })
}

function normalizeDashboardGridPosition(
  item: DashboardGridLayoutItem
): DashboardGridPosition | null {
  const next = {
    x: item.x,
    y: item.y,
    w: item.w,
    h: item.h,
  }

  if (
    !isNonNegativeInteger(next.x) ||
    !isNonNegativeInteger(next.y) ||
    !isPositiveInteger(next.w) ||
    !isPositiveInteger(next.h)
  ) {
    return null
  }

  return next
}

function isSameGridPosition(
  a: DashboardGridPosition,
  b: DashboardGridPosition
): boolean {
  return a.x === b.x && a.y === b.y && a.w === b.w && a.h === b.h
}

function isNonNegativeInteger(value: number): boolean {
  return Number.isInteger(value) && value >= 0
}

function isPositiveInteger(value: number): boolean {
  return Number.isInteger(value) && value > 0
}
