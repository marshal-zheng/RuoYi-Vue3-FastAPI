import type { DashboardRuntimeMode } from './types'

export interface DashboardRuntimeModeInput {
  mode?: DashboardRuntimeMode
  editable?: boolean
  layoutOnlyMode?: boolean
}

export function resolveDashboardRuntimeMode(
  input: DashboardRuntimeModeInput = {}
): DashboardRuntimeMode {
  const legacyMode = resolveLegacyDashboardRuntimeMode(input)

  if (input.mode) {
    if (
      legacyMode !== undefined &&
      legacyMode !== input.mode &&
      process.env.NODE_ENV !== 'production'
    ) {
      // eslint-disable-next-line no-console -- legacy prop conflicts are development diagnostics
      console.warn(
        '[ZxDashboard] The explicit mode prop takes precedence over legacy editable/layoutOnlyMode props.'
      )
    }
    return input.mode
  }

  return legacyMode ?? 'view'
}

function resolveLegacyDashboardRuntimeMode(
  input: DashboardRuntimeModeInput
): DashboardRuntimeMode | undefined {
  if (input.layoutOnlyMode === true) return 'layout'
  if (input.editable === true) return 'edit'
  return undefined
}
