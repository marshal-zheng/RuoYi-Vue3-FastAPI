import type {
  DashboardPanelRuntimeState,
  DashboardPanelStateInfo,
  DashboardPanelStateInput,
} from './types'

const dashboardPanelRuntimeStates = new Set<DashboardPanelRuntimeState>([
  'idle',
  'loading',
  'streaming',
  'error',
  'warn',
])

export function normalizeDashboardPanelState(
  input: DashboardPanelStateInput | undefined
): DashboardPanelStateInfo | undefined {
  if (input === undefined || input === null) return undefined

  if (typeof input === 'string') {
    if (!dashboardPanelRuntimeStates.has(input)) return undefined
    return { state: input, label: input }
  }

  if (
    typeof input === 'object' &&
    typeof input.state === 'string' &&
    dashboardPanelRuntimeStates.has(input.state)
  ) {
    return { state: input.state, label: input.label ?? input.state }
  }

  return undefined
}
