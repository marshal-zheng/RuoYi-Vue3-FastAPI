import {
  DASHBOARD_SCHEMA_VERSION,
  cloneDashboardJson,
  isDashboardImportLikeWidgetKey,
  isDashboardPlainObject,
  validateDashboardGridPositionInput,
} from '../schema'
import {
  hasBlockingDashboardIssues,
  validateDashboardDocument,
} from '../validation'

import type {
  DashboardDocument,
  DashboardGridPosition,
  DashboardJsonObject,
  DashboardJsonValue,
} from '../schema'
import type { DashboardImportResult } from '../import-export'
import type { DashboardSchemaIssue } from '../validation'
import type { DashboardLegacyGridComMigrationOptions } from './types'

const runtimeFieldNames = new Set([
  'setData',
  'updateGridPos',
  'component',
  'componentPath',
  'importPath',
  'path',
  'editor',
  'preview',
  'callbacks',
  'modules',
  'glob',
  'alias',
])

export function migrateLegacyGridComSnapshot(
  input: unknown,
  options: DashboardLegacyGridComMigrationOptions = {}
): DashboardImportResult {
  const currentSchemaVersion =
    options.currentSchemaVersion ?? DASHBOARD_SCHEMA_VERSION
  const issues: DashboardSchemaIssue[] = []
  const sourcePanels = readLegacyPanels(input, issues)

  if (!sourcePanels) {
    return { issues }
  }

  const usedIds = new Set<string>()
  const panels: DashboardDocument['panels'] = []

  sourcePanels.forEach((legacyPanel, index) => {
    const panelPath = `/panels/${index}`

    if (!isDashboardPlainObject(legacyPanel)) {
      issues.push({
        severity: 'error',
        code: 'legacy_gridcom_invalid_snapshot',
        message: 'Legacy GridCom panel must be a plain object.',
        path: panelPath,
      })
      return
    }

    const id = normalizeLegacyPanelId(
      legacyPanel.id,
      usedIds,
      panelPath,
      issues
    )
    const widget = normalizeLegacyWidget(legacyPanel, panelPath, issues)
    const gridPos = normalizeLegacyGridPosition(
      legacyPanel,
      index,
      options,
      issues
    )

    if (!id || !widget || !gridPos) return

    const metadata = buildLegacyMetadata(legacyPanel, panelPath, issues)
    const migratedPanel: DashboardDocument['panels'][number] = {
      id,
      widget,
      gridPos,
    }

    if (typeof legacyPanel.title === 'string')
      migratedPanel.title = legacyPanel.title
    if (typeof legacyPanel.description === 'string') {
      migratedPanel.description = legacyPanel.description
    }
    if (isDashboardPlainObject(legacyPanel.params)) {
      migratedPanel.params = cloneDashboardJson(
        legacyPanel.params as DashboardJsonObject
      )
    }

    const data = normalizeLegacyPanelData(
      legacyPanel,
      panelPath,
      metadata,
      issues
    )
    if (data !== undefined) migratedPanel.data = data
    if (Object.keys(metadata).length > 0) migratedPanel.metadata = metadata

    panels.push(migratedPanel)
  })

  const document: DashboardDocument = {
    schemaVersion: currentSchemaVersion as typeof DASHBOARD_SCHEMA_VERSION,
    panels,
  }

  if (isDashboardPlainObject(input)) {
    if (typeof input.uid === 'string') document.uid = input.uid
    if (typeof input.title === 'string') document.title = input.title
    if (typeof input.description === 'string') {
      document.description = input.description
    }
    if (isDashboardPlainObject(input.pluginVersions)) {
      document.pluginVersions = cloneDashboardJson(
        input.pluginVersions as DashboardJsonObject
      ) as Record<string, string>
    }
    if (Array.isArray(input.references)) {
      document.references = cloneDashboardJson(
        input.references
      ) as DashboardDocument['references']
    }
  }

  if (hasBlockingDashboardIssues(issues)) {
    return { issues }
  }

  const validation = validateDashboardDocument(document, {
    phase: 'import',
    currentSchemaVersion,
    knownWidgets: options.knownWidgets,
  })
  issues.push(...validation.issues)

  if (hasBlockingDashboardIssues(issues)) {
    return { issues }
  }

  return {
    document,
    issues,
  }
}

function readLegacyPanels(
  input: unknown,
  issues: DashboardSchemaIssue[]
): unknown[] | undefined {
  if (Array.isArray(input)) return input
  if (isDashboardPlainObject(input) && Array.isArray(input.panels)) {
    return input.panels
  }

  issues.push({
    severity: 'error',
    code: 'legacy_gridcom_invalid_snapshot',
    message:
      'Legacy GridCom snapshot must be an array or an object with panels.',
    path: '/panels',
  })
  return undefined
}

function normalizeLegacyPanelId(
  rawId: unknown,
  usedIds: Set<string>,
  path: string,
  issues: DashboardSchemaIssue[]
): string | undefined {
  if (
    !(
      typeof rawId === 'string' ||
      (typeof rawId === 'number' && Number.isFinite(rawId))
    ) ||
    String(rawId).trim().length === 0
  ) {
    issues.push({
      severity: 'error',
      code: 'invalid_panel_id',
      message: 'Legacy panel id must be a string or finite number.',
      path: `${path}/id`,
    })
    return undefined
  }

  const baseId = String(rawId).trim()
  let id = baseId
  let suffix = 2
  while (usedIds.has(id)) {
    id = `${baseId}-${suffix}`
    suffix += 1
  }
  usedIds.add(id)

  if (id !== baseId) {
    issues.push({
      severity: 'warn',
      code: 'legacy_gridcom_id_rewritten',
      message: `Legacy panel id "${baseId}" was rewritten to "${id}" to keep ids unique.`,
      path: `${path}/id`,
    })
  }

  return id
}

function normalizeLegacyWidget(
  panel: Record<string, unknown>,
  path: string,
  issues: DashboardSchemaIssue[]
): string | undefined {
  const widget = typeof panel.widget === 'string' ? panel.widget.trim() : ''
  if (widget && !isDashboardImportLikeWidgetKey(widget)) return widget

  if (widget) {
    issues.push({
      severity: 'error',
      code: 'import_like_widget',
      message:
        'Legacy widget cannot be a path, URL, glob, or import expression.',
      path: `${path}/widget`,
    })
    return undefined
  }

  const type = typeof panel.type === 'string' ? panel.type.trim() : ''
  if (type && !isDashboardImportLikeWidgetKey(type)) {
    issues.push({
      severity: 'warn',
      code: 'legacy_gridcom_widget_from_type',
      message: `Legacy panel type "${type}" was migrated to panel.widget.`,
      path: `${path}/type`,
      migratable: true,
    })
    return type
  }

  issues.push({
    severity: 'error',
    code: 'missing_widget',
    message: 'Legacy panel must provide a safe widget or type value.',
    path: `${path}/widget`,
  })
  return undefined
}

function normalizeLegacyGridPosition(
  panel: Record<string, unknown>,
  index: number,
  options: DashboardLegacyGridComMigrationOptions,
  issues: DashboardSchemaIssue[]
): DashboardGridPosition | undefined {
  const path = `/panels/${index}/gridPos`

  if (isDashboardPlainObject(panel.gridPos)) {
    const gridPos = {
      x: panel.gridPos.x,
      y: panel.gridPos.y,
      w: panel.gridPos.w,
      h: panel.gridPos.h,
    }
    const result = validateDashboardGridPositionInput(gridPos, path)
    issues.push(...result.issues)
    return result.value
  }

  if (options.defaultGridPosition) {
    const fallback =
      typeof options.defaultGridPosition === 'function'
        ? options.defaultGridPosition(panel, index)
        : options.defaultGridPosition
    const result = validateDashboardGridPositionInput(fallback, path)
    issues.push(...result.issues)
    if (result.value) {
      issues.push({
        severity: 'warn',
        code: 'legacy_gridcom_default_grid_used',
        message:
          'Legacy panel was migrated with an explicit default grid position.',
        path,
        migratable: true,
      })
    }
    return result.value
  }

  issues.push({
    severity: 'error',
    code: 'invalid_grid_position',
    message:
      'Legacy panel gridPos is required unless a default grid strategy is provided.',
    path,
  })
  return undefined
}

function normalizeLegacyPanelData(
  panel: Record<string, unknown>,
  path: string,
  metadata: DashboardJsonObject,
  issues: DashboardSchemaIssue[]
): DashboardJsonValue | undefined {
  const legacyMetadata = isDashboardPlainObject(panel.metadata)
    ? panel.metadata
    : undefined
  const metadataData = legacyMetadata?.data

  if (typeof metadataData === 'string') {
    if (!metadataData.trim()) return undefined
    try {
      issues.push({
        severity: 'warn',
        code: 'legacy_gridcom_metadata_data_migrated',
        message: 'Legacy metadata.data JSON string was migrated to panel.data.',
        path: `${path}/metadata/data`,
        migratable: true,
      })
      return JSON.parse(metadataData) as DashboardJsonValue
    } catch {
      const legacyGridCom = ensureLegacyGridComMetadata(metadata)
      legacyGridCom.metadataData = metadataData
      issues.push({
        severity: 'warn',
        code: 'legacy_gridcom_metadata_data_unparsed',
        message:
          'Legacy metadata.data was preserved because it is not valid JSON.',
        path: `${path}/metadata/data`,
      })
      return undefined
    }
  }

  if (panel.data !== undefined) {
    return cloneDashboardJson(panel.data as DashboardJsonValue)
  }

  return undefined
}

function buildLegacyMetadata(
  panel: Record<string, unknown>,
  path: string,
  issues: DashboardSchemaIssue[]
): DashboardJsonObject {
  const metadata: DashboardJsonObject = {}
  const legacyGridCom = ensureLegacyGridComMetadata(metadata)

  if (typeof panel.color === 'string') legacyGridCom.color = panel.color
  if (typeof panel.transparentBackground === 'boolean') {
    legacyGridCom.transparentBackground = panel.transparentBackground
  }
  if (typeof panel.type === 'string') legacyGridCom.type = panel.type

  const droppedFields: string[] = []
  for (const key of Object.keys(panel)) {
    if (runtimeFieldNames.has(key) || typeof panel[key] === 'function') {
      droppedFields.push(key)
      issues.push({
        severity: 'warn',
        code: 'legacy_gridcom_runtime_field_stripped',
        message: `Legacy runtime field "${key}" was stripped during migration.`,
        path: `${path}/${key}`,
      })
    }
  }

  if (droppedFields.length > 0) {
    legacyGridCom.droppedRuntimeFields = droppedFields
  }

  if (Object.keys(legacyGridCom).length === 0) {
    delete metadata.legacyGridCom
  }

  return metadata
}

function ensureLegacyGridComMetadata(
  metadata: DashboardJsonObject
): DashboardJsonObject {
  if (!isDashboardPlainObject(metadata.legacyGridCom)) {
    metadata.legacyGridCom = {}
  }
  return metadata.legacyGridCom
}
