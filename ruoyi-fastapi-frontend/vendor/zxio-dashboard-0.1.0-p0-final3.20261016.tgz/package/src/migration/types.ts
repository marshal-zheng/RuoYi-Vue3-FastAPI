import type {
  DashboardDocument,
  DashboardGridPosition,
  DashboardJsonObject,
  DashboardPanel,
} from '../schema'
import type { DashboardSchemaIssue } from '../validation'

export interface DashboardMigrationContext {
  currentSchemaVersion: number
  addWarning(issue: DashboardSchemaIssue): void
  addBlockingIssue(issue: DashboardSchemaIssue): void
}

export interface DashboardMigrationStep {
  fromVersion: number
  toVersion: number
  summary: string
  migrate: (
    document: DashboardJsonObject,
    context: DashboardMigrationContext
  ) => DashboardJsonObject
}

export interface DashboardWidgetMigrationContext {
  widget: string
  fromVersion?: string
  toVersion?: string
  documentSchemaVersion: number
}

export interface DashboardWidgetMigrator {
  widget: string
  targetVersion?: string
  migratePanel: (
    panel: DashboardPanel,
    context: DashboardWidgetMigrationContext
  ) => DashboardPanel
}

export interface DashboardMigrationOptions {
  currentSchemaVersion?: number
  steps?: DashboardMigrationStep[]
  widgetMigrators?: Record<string, DashboardWidgetMigrator>
  knownWidgets?: Iterable<string>
}

export interface DashboardMigrationReport {
  fromSchemaVersion: number
  toSchemaVersion: number
  finalSchemaVersion: number
  steps: Array<{
    fromVersion: number
    toVersion: number
    summary: string
  }>
  widgetMigrations: Array<{
    panelId: string
    widget: string
    fromVersion?: string
    toVersion?: string
    changed: boolean
  }>
  warnings: DashboardSchemaIssue[]
  blockingIssues: DashboardSchemaIssue[]
}

export interface DashboardMigrationResult {
  document?: DashboardDocument
  report: DashboardMigrationReport
  issues: DashboardSchemaIssue[]
}

export interface DashboardLegacyGridComMigrationOptions
  extends DashboardMigrationOptions {
  defaultGridPosition?:
    | DashboardGridPosition
    | ((panel: Record<string, unknown>, index: number) => DashboardGridPosition)
}
