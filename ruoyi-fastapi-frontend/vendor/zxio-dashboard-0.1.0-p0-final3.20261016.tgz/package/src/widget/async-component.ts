import {
  type Component,
  type SetupContext,
  type VNodeChild,
  defineComponent,
  h,
  onBeforeUnmount,
  ref,
  shallowRef,
} from 'vue'
import { useDashboardLocale } from '../locale'
import { createAsyncComponentLoadFailedIssue } from './issues'

import type {
  DashboardWidgetComponent,
  DashboardWidgetRegistryIssue,
} from './types'

export interface DashboardWidgetAsyncComponentOptions {
  widget: string
  variant?: string
  loadingComponent?: Component
  errorComponent?: Component
  delay?: number
  timeout?: number
  onIssue?: (issue: DashboardWidgetRegistryIssue) => void
}

export function resolveDashboardWidgetComponent(
  component: DashboardWidgetComponent,
  options: DashboardWidgetAsyncComponentOptions
): Component {
  if (typeof component !== 'function' || isVueFunctionComponent(component)) {
    return component as Component
  }

  return createDashboardWidgetFunctionBridge(component, options)
}

function createDashboardWidgetFunctionBridge(
  component: DashboardWidgetComponent,
  options: DashboardWidgetAsyncComponentOptions
): Component {
  const LoadingComponent =
    options.loadingComponent ?? DashboardWidgetAsyncLoadingFallback
  const ErrorComponent =
    options.errorComponent ?? DashboardWidgetAsyncErrorFallback

  return defineComponent({
    name: 'DashboardWidgetFunctionBridge',
    inheritAttrs: false,
    setup(_props, setupContext) {
      const loadedComponent = shallowRef<Component>()
      const loadingVisible = ref(false)
      const failed = ref(false)
      let asyncLoadStarted = false
      let loadingDelayTimer: ReturnType<typeof globalThis.setTimeout> | null =
        null

      function clearLoadingDelayTimer(): void {
        if (loadingDelayTimer === null) return
        globalThis.clearTimeout(loadingDelayTimer)
        loadingDelayTimer = null
      }

      function showLoadingFallback(): void {
        clearLoadingDelayTimer()
        const delay = options.delay ?? 0
        if (delay > 0) {
          loadingDelayTimer = globalThis.setTimeout(() => {
            loadingVisible.value = true
            loadingDelayTimer = null
          }, delay)
          return
        }
        loadingVisible.value = true
      }

      function reportLoadFailure(error: unknown): void {
        clearLoadingDelayTimer()
        options.onIssue?.(
          createAsyncComponentLoadFailedIssue(options.widget, error, {
            variant: options.variant,
          })
        )
        failed.value = true
        loadingVisible.value = false
      }

      function startAsyncLoad(
        result: Promise<DashboardWidgetComponentModule>
      ): void {
        asyncLoadStarted = true
        showLoadingFallback()

        withTimeout(result, options)
          .then((module) => {
            clearLoadingDelayTimer()
            loadedComponent.value = resolveComponentModule(module)
            loadingVisible.value = false
          })
          .catch(reportLoadFailure)
      }

      onBeforeUnmount(() => {
        clearLoadingDelayTimer()
      })

      return () => {
        if (loadedComponent.value) {
          return h(loadedComponent.value, setupContext.attrs)
        }
        if (failed.value) return h(ErrorComponent)
        if (asyncLoadStarted) {
          return loadingVisible.value ? h(LoadingComponent) : null
        }

        try {
          const result = invokeWidgetFunction(component, setupContext)
          if (isPromiseLike(result)) {
            startAsyncLoad(result)
            return loadingVisible.value ? h(LoadingComponent) : null
          }

          return result
        } catch (error) {
          reportLoadFailure(error)
          return h(ErrorComponent)
        }
      }
    },
  })
}

function resolveComponentModule(
  module: DashboardWidgetComponentModule
): Component {
  return isComponentModuleWithDefault(module) ? module.default : module
}

function withTimeout(
  promise: Promise<DashboardWidgetComponentModule>,
  options: DashboardWidgetAsyncComponentOptions
): Promise<DashboardWidgetComponentModule> {
  if (options.timeout === undefined) return promise

  return Promise.race([
    promise,
    new Promise<never>((_resolve, reject) => {
      globalThis.setTimeout(() => {
        reject(
          new Error(
            `Async component timed out after ${String(options.timeout)}ms.`
          )
        )
      }, options.timeout)
    }),
  ])
}

type DashboardWidgetComponentModule =
  | Component
  | {
      default: Component
    }

function invokeWidgetFunction(
  component: DashboardWidgetComponent,
  context: SetupContext
): VNodeChild | Promise<DashboardWidgetComponentModule> {
  return (
    component as (
      props: SetupContext['attrs'],
      context: SetupContext
    ) => VNodeChild | Promise<DashboardWidgetComponentModule>
  )(context.attrs, context)
}

interface DashboardWidgetFunctionLike {
  readonly length: number
  readonly props?: unknown
  readonly emits?: unknown
  readonly inheritAttrs?: unknown
  readonly __vccOpts?: unknown
}

function isVueFunctionComponent(
  component: DashboardWidgetFunctionLike
): boolean {
  return (
    component.length > 0 ||
    'props' in component ||
    'emits' in component ||
    'inheritAttrs' in component ||
    '__vccOpts' in component
  )
}

function isPromiseLike(
  value: unknown
): value is Promise<DashboardWidgetComponentModule> {
  return (
    (typeof value === 'object' || typeof value === 'function') &&
    value !== null &&
    typeof (value as Promise<unknown>).then === 'function'
  )
}

function isComponentModuleWithDefault(
  value: unknown
): value is { default: Component } {
  return typeof value === 'object' && value !== null && 'default' in value
}

const DashboardWidgetAsyncLoadingFallback = {
  name: 'DashboardWidgetAsyncLoadingFallback',
  setup() {
    const locale = useDashboardLocale()
    return () =>
      h(
        'div',
        { class: 'zx-dashboard-widget__loading', role: 'status' },
        locale.value.widget.loading
      )
  },
}

const DashboardWidgetAsyncErrorFallback = {
  name: 'DashboardWidgetAsyncErrorFallback',
  setup() {
    const locale = useDashboardLocale()
    return () =>
      h(
        'div',
        {
          class: 'zx-dashboard-widget__error',
          'data-dashboard-widget-error': 'async_component_load_failed',
        },
        locale.value.widget.loadError
      )
  },
}
