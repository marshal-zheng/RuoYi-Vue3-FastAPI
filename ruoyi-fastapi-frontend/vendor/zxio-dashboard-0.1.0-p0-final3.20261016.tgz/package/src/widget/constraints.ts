import type { DashboardGridPosition } from '../schema'
import type {
  DashboardWidgetDefinition,
  DashboardWidgetGridConstraint,
  DashboardWidgetVariantDefinition,
} from './types'

export interface DashboardWidgetGridConstraints {
  min: DashboardWidgetGridConstraint
  max: DashboardWidgetGridConstraint
}

export type DashboardGridSize = Pick<DashboardGridPosition, 'w' | 'h'>

/**
 * Effective size bounds of a panel: the variant overrides the definition per
 * axis, and an axis neither declares stays unconstrained.
 */
export function resolveDashboardWidgetGridConstraints(
  definition?: Pick<DashboardWidgetDefinition, 'minGrid' | 'maxGrid'>,
  variant?: Pick<DashboardWidgetVariantDefinition, 'minGrid' | 'maxGrid'>
): DashboardWidgetGridConstraints {
  return {
    min: mergeConstraint(definition?.minGrid, variant?.minGrid),
    max: mergeConstraint(definition?.maxGrid, variant?.maxGrid),
  }
}

/**
 * Clamps a size into the widget bounds (the minimum wins over the maximum)
 * and, when `columns` is given, into the grid width.
 */
export function clampDashboardGridSize(
  size: DashboardGridSize,
  constraints: DashboardWidgetGridConstraints,
  options: { columns?: number } = {}
): DashboardGridSize {
  let w = size.w
  let h = size.h

  if (constraints.max.w !== undefined) w = Math.min(w, constraints.max.w)
  if (constraints.min.w !== undefined) w = Math.max(w, constraints.min.w)
  if (constraints.max.h !== undefined) h = Math.min(h, constraints.max.h)
  if (constraints.min.h !== undefined) h = Math.max(h, constraints.min.h)
  if (options.columns !== undefined && options.columns > 0) {
    w = Math.min(w, options.columns)
  }

  return { w, h }
}

function mergeConstraint(
  base: DashboardWidgetGridConstraint | undefined,
  override: DashboardWidgetGridConstraint | undefined
): DashboardWidgetGridConstraint {
  const merged: DashboardWidgetGridConstraint = {}
  for (const source of [base, override]) {
    if (!source) continue
    if (typeof source.w === 'number') merged.w = source.w
    if (typeof source.h === 'number') merged.h = source.h
  }
  return merged
}
