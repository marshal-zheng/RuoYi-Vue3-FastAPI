import {
  cloneDashboardJson,
  collectDashboardJsonIssues,
  isDashboardImportLikeWidgetKey,
  isDashboardPlainObject,
  joinDashboardJsonPointer,
} from '../schema'

import type { DashboardGridPosition } from '../schema'
import type {
  DashboardWidgetDefaultPanel,
  DashboardWidgetDefinition,
  DashboardWidgetRegistryIssue,
  DashboardWidgetSourceMetadata,
  DashboardWidgetVariantDefinition,
} from './types'

export interface DashboardWidgetDefinitionNormalizationResult {
  definition?: DashboardWidgetDefinition
  issues: DashboardWidgetRegistryIssue[]
}

const allowedDefaultPanelFields = new Set([
  'variant',
  'title',
  'description',
  'params',
  'data',
  'metadata',
  'references',
])

export function createDashboardWidgetRegistryIssue(
  issue: DashboardWidgetRegistryIssue
): DashboardWidgetRegistryIssue {
  return issue
}

export function createInvalidWidgetDefinitionIssue(
  message: string,
  options: Partial<DashboardWidgetRegistryIssue> = {}
): DashboardWidgetRegistryIssue {
  return {
    severity: 'error',
    code: 'invalid_widget_definition',
    message,
    ...options,
  }
}

export function createDuplicateWidgetIssue(
  widget: string
): DashboardWidgetRegistryIssue {
  return {
    severity: 'error',
    code: 'duplicate_widget',
    message: `Widget "${widget}" is already registered.`,
    widget,
    suggestion: 'Pass { override: true } to replace the existing definition.',
  }
}

export function createDuplicatePluginIssue(
  plugin: string
): DashboardWidgetRegistryIssue {
  return {
    severity: 'warn',
    code: 'duplicate_plugin',
    message: `Widget plugin "${plugin}" is already installed.`,
    plugin,
  }
}

export function createUnresolvedWidgetIssue(
  widget: string,
  options: Partial<DashboardWidgetRegistryIssue> = {}
): DashboardWidgetRegistryIssue {
  return {
    severity: 'warn',
    code: 'unresolved_widget',
    message: `Widget "${widget}" is not registered in this dashboard registry.`,
    widget,
    ...options,
  }
}

export function createUnresolvedWidgetVariantIssue(
  widget: string,
  variant: string,
  options: Partial<DashboardWidgetRegistryIssue> = {}
): DashboardWidgetRegistryIssue {
  return {
    severity: 'warn',
    code: 'unresolved_widget_variant',
    message: `Widget "${widget}" does not define variant "${variant}".`,
    widget,
    variant,
    ...options,
  }
}

export function createInvalidGlobWidgetModuleIssue(
  path: string,
  message: string,
  options: Partial<DashboardWidgetRegistryIssue> = {}
): DashboardWidgetRegistryIssue {
  return {
    severity: 'error',
    code: 'invalid_glob_widget_module',
    message,
    path,
    ...options,
  }
}

export function createAsyncComponentLoadFailedIssue(
  widget: string,
  error: unknown,
  options: Partial<DashboardWidgetRegistryIssue> = {}
): DashboardWidgetRegistryIssue {
  return {
    severity: 'error',
    code: 'async_component_load_failed',
    message:
      error instanceof Error
        ? error.message
        : `Async component loader for widget "${widget}" failed.`,
    widget,
    ...options,
  }
}

export function validateDashboardWidgetKey(
  value: unknown,
  path: string,
  label = 'Widget name'
): DashboardWidgetRegistryIssue[] {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return [
      createInvalidWidgetDefinitionIssue(
        `${label} must be a non-empty string.`,
        { path }
      ),
    ]
  }

  if (isDashboardImportLikeWidgetKey(value)) {
    return [
      createInvalidWidgetDefinitionIssue(
        `${label} must be a stable widget key, not a path, URL, glob, or import expression.`,
        {
          widget: value,
          path,
          suggestion: 'Use a stable key such as "chart" or "risk-score".',
        }
      ),
    ]
  }

  return []
}

export function normalizeDashboardWidgetDefinition(
  input: DashboardWidgetDefinition,
  source?: DashboardWidgetSourceMetadata
): DashboardWidgetDefinitionNormalizationResult {
  const issues: DashboardWidgetRegistryIssue[] = []

  if (!isDashboardPlainObject(input)) {
    return {
      issues: [
        createInvalidWidgetDefinitionIssue(
          'Widget definition must be a plain object.',
          { path: '' }
        ),
      ],
    }
  }

  issues.push(...validateDashboardWidgetKey(input.name, '/name'))

  if (typeof input.title !== 'string' || input.title.trim().length === 0) {
    issues.push(
      createInvalidWidgetDefinitionIssue(
        'Widget definition title must be a non-empty string.',
        { widget: input.name, path: '/title' }
      )
    )
  }

  if (!isDashboardWidgetComponent(input.component)) {
    issues.push(
      createInvalidWidgetDefinitionIssue(
        'Widget definition component must be a Vue component or async component loader.',
        { widget: input.name, path: '/component' }
      )
    )
  }

  issues.push(
    ...validateDefinitionMetadata(input),
    ...validateDefaultGrid(input.defaultGrid, '/defaultGrid', input.name),
    ...validateGridConstraints(input, '', input.name),
    ...validateDefaultPanel(input.defaultPanel, '/defaultPanel', input.name),
    ...validateVariants(input.variants, input.name, input)
  )

  if (issues.some((issue) => issue.severity === 'error')) {
    return { issues }
  }

  try {
    return {
      definition: cloneDashboardWidgetDefinition(input, source),
      issues,
    }
  } catch (error) {
    return {
      issues: [
        createInvalidWidgetDefinitionIssue(
          error instanceof Error
            ? error.message
            : 'Widget definition could not be normalized.',
          { widget: input.name, path: '' }
        ),
      ],
    }
  }
}

export function cloneDashboardWidgetDefinition(
  definition: DashboardWidgetDefinition,
  source?: DashboardWidgetSourceMetadata
): DashboardWidgetDefinition {
  return {
    ...definition,
    tags: Array.isArray(definition.tags) ? [...definition.tags] : undefined,
    defaultGrid: cloneDefaultGrid(definition.defaultGrid),
    minGrid: cloneDefaultGrid(definition.minGrid),
    maxGrid: cloneDefaultGrid(definition.maxGrid),
    defaultPanel: cloneDefaultPanel(definition.defaultPanel),
    variants: definition.variants?.map(cloneDashboardWidgetVariantDefinition),
    source: source
      ? { ...source }
      : definition.source
      ? { ...definition.source }
      : undefined,
  }
}

export function cloneDashboardWidgetVariantDefinition(
  variant: DashboardWidgetVariantDefinition
): DashboardWidgetVariantDefinition {
  return {
    ...variant,
    defaultGrid: cloneDefaultGrid(variant.defaultGrid),
    minGrid: cloneDefaultGrid(variant.minGrid),
    maxGrid: cloneDefaultGrid(variant.maxGrid),
    defaultPanel: cloneDefaultPanel(variant.defaultPanel),
  }
}

function validateDefinitionMetadata(
  definition: DashboardWidgetDefinition
): DashboardWidgetRegistryIssue[] {
  const widget = definition.name

  return [
    ...validateOptionalString(
      definition.version,
      '/version',
      'version',
      widget
    ),
    ...validateOptionalString(definition.group, '/group', 'group', widget),
    ...validateOptionalString(
      definition.description,
      '/description',
      'description',
      widget
    ),
    ...validateTags(definition.tags, '/tags', widget),
    ...validateOptionalNumber(definition.order, '/order', 'order', widget),
    ...validateOptionalBoolean(definition.hidden, '/hidden', 'hidden', widget),
    ...validateOptionalBoolean(
      definition.palette,
      '/palette',
      'palette',
      widget
    ),
    ...validateOptionalComponent(
      definition.editor,
      '/editor',
      'editor',
      widget
    ),
    ...validateOptionalComponent(
      definition.preview,
      '/preview',
      'preview',
      widget
    ),
    ...validateOptionalFunction(
      definition.resolveProps,
      '/resolveProps',
      'resolveProps',
      widget
    ),
    ...validateOptionalFunction(
      definition.validate,
      '/validate',
      'validate',
      widget
    ),
    ...validateOptionalFunction(
      definition.migrate,
      '/migrate',
      'migrate',
      widget
    ),
  ]
}

function validateVariantMetadata(
  variant: Record<string, unknown>,
  path: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  return [
    ...validateOptionalString(variant.title, `${path}/title`, 'title', widget),
    ...validateOptionalString(
      variant.description,
      `${path}/description`,
      'description',
      widget
    ),
    ...validateOptionalNumber(variant.order, `${path}/order`, 'order', widget),
    ...validateOptionalComponent(
      variant.component,
      `${path}/component`,
      'component',
      widget
    ),
    ...validateOptionalComponent(
      variant.editor,
      `${path}/editor`,
      'editor',
      widget
    ),
    ...validateOptionalComponent(
      variant.preview,
      `${path}/preview`,
      'preview',
      widget
    ),
    ...validateOptionalFunction(
      variant.resolveProps,
      `${path}/resolveProps`,
      'resolveProps',
      widget
    ),
    ...validateOptionalFunction(
      variant.validate,
      `${path}/validate`,
      'validate',
      widget
    ),
    ...validateOptionalFunction(
      variant.migrate,
      `${path}/migrate`,
      'migrate',
      widget
    ),
  ]
}

function validateOptionalString(
  value: unknown,
  path: string,
  label: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (value === undefined) return []
  return typeof value === 'string'
    ? []
    : [
        createInvalidWidgetDefinitionIssue(
          `Widget ${label} must be a string when provided.`,
          { widget, path }
        ),
      ]
}

function validateOptionalNumber(
  value: unknown,
  path: string,
  label: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (value === undefined) return []
  return typeof value === 'number' && Number.isFinite(value)
    ? []
    : [
        createInvalidWidgetDefinitionIssue(
          `Widget ${label} must be a finite number when provided.`,
          { widget, path }
        ),
      ]
}

function validateOptionalBoolean(
  value: unknown,
  path: string,
  label: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (value === undefined) return []
  return typeof value === 'boolean'
    ? []
    : [
        createInvalidWidgetDefinitionIssue(
          `Widget ${label} must be a boolean when provided.`,
          { widget, path }
        ),
      ]
}

function validateOptionalComponent(
  value: unknown,
  path: string,
  label: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (value === undefined) return []
  return isDashboardWidgetComponent(value)
    ? []
    : [
        createInvalidWidgetDefinitionIssue(
          `Widget ${label} must be a Vue component or async component loader when provided.`,
          { widget, path }
        ),
      ]
}

function validateOptionalFunction(
  value: unknown,
  path: string,
  label: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (value === undefined) return []
  return typeof value === 'function'
    ? []
    : [
        createInvalidWidgetDefinitionIssue(
          `Widget ${label} must be a function when provided.`,
          { widget, path }
        ),
      ]
}

function validateTags(
  tags: unknown,
  path: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (tags === undefined) return []
  if (!Array.isArray(tags)) {
    return [
      createInvalidWidgetDefinitionIssue(
        'Widget tags must be an array of strings when provided.',
        { widget, path }
      ),
    ]
  }

  return tags.flatMap((tag, index) =>
    typeof tag === 'string'
      ? []
      : [
          createInvalidWidgetDefinitionIssue(
            'Widget tags must only contain strings.',
            { widget, path: joinDashboardJsonPointer(path, index) }
          ),
        ]
  )
}

function validateDefaultGrid(
  value: unknown,
  path: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (value === undefined) return []
  if (!isDashboardPlainObject(value)) {
    return [
      createInvalidWidgetDefinitionIssue(
        'defaultGrid must be a plain object when provided.',
        { widget, path }
      ),
    ]
  }

  const issues: DashboardWidgetRegistryIssue[] = []
  const allowed = new Set(['x', 'y', 'w', 'h'])
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) {
      issues.push(
        createInvalidWidgetDefinitionIssue(
          `defaultGrid cannot include "${key}".`,
          { widget, path: joinDashboardJsonPointer(path, key) }
        )
      )
    }
  }

  for (const [key, fieldValue] of Object.entries(value)) {
    if (
      fieldValue !== undefined &&
      (typeof fieldValue !== 'number' ||
        !Number.isInteger(fieldValue) ||
        (key === 'x' || key === 'y' ? fieldValue < 0 : fieldValue <= 0))
    ) {
      issues.push(
        createInvalidWidgetDefinitionIssue(
          `defaultGrid.${key} must be a valid grid integer.`,
          { widget, path: joinDashboardJsonPointer(path, key) }
        )
      )
    }
  }

  return issues
}

function validateDefaultPanel(
  value: unknown,
  path: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (value === undefined) return []
  if (!isDashboardPlainObject(value)) {
    return [
      createInvalidWidgetDefinitionIssue(
        'defaultPanel must be a plain JSON object when provided.',
        { widget, path }
      ),
    ]
  }

  const issues: DashboardWidgetRegistryIssue[] = []

  for (const key of Object.keys(value)) {
    if (!allowedDefaultPanelFields.has(key)) {
      issues.push(
        createInvalidWidgetDefinitionIssue(
          `defaultPanel cannot include protected or unknown field "${key}".`,
          { widget, path: joinDashboardJsonPointer(path, key) }
        )
      )
    }
  }

  issues.push(
    ...collectDashboardJsonIssues(value, path, { phase: 'authoring' }).map(
      (issue) =>
        createInvalidWidgetDefinitionIssue(issue.message, {
          widget,
          path: issue.path,
          suggestion: issue.suggestion,
        })
    )
  )

  return issues
}

function validateVariants(
  variants: unknown,
  widget?: string,
  definition?: { minGrid?: unknown; maxGrid?: unknown }
): DashboardWidgetRegistryIssue[] {
  if (variants === undefined) return []
  if (!Array.isArray(variants)) {
    return [
      createInvalidWidgetDefinitionIssue(
        'variants must be an array when provided.',
        { widget, path: '/variants' }
      ),
    ]
  }

  const issues: DashboardWidgetRegistryIssue[] = []
  const names = new Set<string>()

  variants.forEach((variant, index) => {
    const path = `/variants/${index}`
    if (!isDashboardPlainObject(variant)) {
      issues.push(
        createInvalidWidgetDefinitionIssue(
          'Widget variant must be a plain object.',
          { widget, path }
        )
      )
      return
    }

    issues.push(
      ...validateDashboardWidgetKey(
        variant.name,
        `${path}/name`,
        'Widget variant name'
      )
    )

    if (typeof variant.name === 'string') {
      if (names.has(variant.name)) {
        issues.push(
          createInvalidWidgetDefinitionIssue(
            `Widget variant "${variant.name}" is already defined.`,
            { widget, variant: variant.name, path: `${path}/name` }
          )
        )
      }
      names.add(variant.name)
    }

    const constraintIssues = validateGridConstraints(variant, path, widget)
    issues.push(
      ...validateVariantMetadata(variant, path, widget),
      ...validateDefaultGrid(
        variant.defaultGrid,
        `${path}/defaultGrid`,
        widget
      ),
      ...constraintIssues,
      ...(constraintIssues.length === 0
        ? validateGridConstraints(
            {
              minGrid: {
                ...(isDashboardPlainObject(definition?.minGrid)
                  ? definition.minGrid
                  : {}),
                ...(isDashboardPlainObject(variant.minGrid)
                  ? variant.minGrid
                  : {}),
              },
              maxGrid: {
                ...(isDashboardPlainObject(definition?.maxGrid)
                  ? definition.maxGrid
                  : {}),
                ...(isDashboardPlainObject(variant.maxGrid)
                  ? variant.maxGrid
                  : {}),
              },
            },
            path,
            widget
          )
        : []),
      ...validateDefaultPanel(
        variant.defaultPanel,
        `${path}/defaultPanel`,
        widget
      )
    )
  })

  return issues
}

/**
 * `minGrid` / `maxGrid` / `lockable` of a definition or variant: size bounds
 * are `{ w?, h? }` positive integers and a minimum may not exceed its maximum.
 */
function validateGridConstraints(
  input: { minGrid?: unknown; maxGrid?: unknown; lockable?: unknown },
  path: string,
  widget?: string
): DashboardWidgetRegistryIssue[] {
  const issues = [
    ...validateGridConstraint(
      input.minGrid,
      `${path}/minGrid`,
      'minGrid',
      widget
    ),
    ...validateGridConstraint(
      input.maxGrid,
      `${path}/maxGrid`,
      'maxGrid',
      widget
    ),
  ]

  if (input.lockable !== undefined && typeof input.lockable !== 'boolean') {
    issues.push(
      createInvalidWidgetDefinitionIssue(
        'lockable must be a boolean when provided.',
        { widget, path: `${path}/lockable` }
      )
    )
  }

  if (
    issues.length === 0 &&
    isDashboardPlainObject(input.minGrid) &&
    isDashboardPlainObject(input.maxGrid)
  ) {
    for (const key of ['w', 'h'] as const) {
      const min = input.minGrid[key]
      const max = input.maxGrid[key]
      if (typeof min === 'number' && typeof max === 'number' && min > max) {
        issues.push(
          createInvalidWidgetDefinitionIssue(
            `minGrid.${key} cannot exceed maxGrid.${key}.`,
            { widget, path: `${path}/minGrid/${key}` }
          )
        )
      }
    }
  }

  return issues
}

function validateGridConstraint(
  value: unknown,
  path: string,
  label: 'minGrid' | 'maxGrid',
  widget?: string
): DashboardWidgetRegistryIssue[] {
  if (value === undefined) return []
  if (!isDashboardPlainObject(value)) {
    return [
      createInvalidWidgetDefinitionIssue(
        `${label} must be a plain object when provided.`,
        { widget, path }
      ),
    ]
  }

  const issues: DashboardWidgetRegistryIssue[] = []

  for (const [key, fieldValue] of Object.entries(value)) {
    if (key !== 'w' && key !== 'h') {
      issues.push(
        createInvalidWidgetDefinitionIssue(
          `${label} cannot include "${key}".`,
          {
            widget,
            path: joinDashboardJsonPointer(path, key),
          }
        )
      )
      continue
    }

    if (
      fieldValue !== undefined &&
      (typeof fieldValue !== 'number' ||
        !Number.isInteger(fieldValue) ||
        fieldValue <= 0)
    ) {
      issues.push(
        createInvalidWidgetDefinitionIssue(
          `${label}.${key} must be a positive grid integer.`,
          { widget, path: joinDashboardJsonPointer(path, key) }
        )
      )
    }
  }

  return issues
}

function cloneDefaultGrid<T extends Partial<DashboardGridPosition>>(
  value: T | undefined
): T | undefined {
  return value ? { ...value } : undefined
}

function cloneDefaultPanel(
  value: DashboardWidgetDefaultPanel | undefined
): DashboardWidgetDefaultPanel | undefined {
  return value === undefined ? undefined : cloneDashboardJson(value)
}

function isDashboardWidgetComponent(value: unknown): boolean {
  return (
    typeof value === 'function' || (typeof value === 'object' && value !== null)
  )
}
