import { isDashboardPlainObject, joinDashboardJsonPointer } from '../schema'
import { resolveDashboardWidgetGridConstraints } from './constraints'

import type { DashboardDocument, DashboardPanel } from '../schema'
import type {
  DashboardWidgetDefinition,
  DashboardWidgetIssue,
  DashboardWidgetRegistry,
  DashboardWidgetRegistryIssue,
  DashboardWidgetValidationContext,
  DashboardWidgetValidationOptions,
  DashboardWidgetValidationResult,
  DashboardWidgetVariantDefinition,
} from './types'

export function validateDashboardWidgets(
  input: DashboardDocument | DashboardPanel[],
  registry: DashboardWidgetRegistry,
  options: DashboardWidgetValidationOptions = {}
): DashboardWidgetValidationResult {
  const document = Array.isArray(input)
    ? options.document
    : (input as DashboardDocument)
  const panels = Array.isArray(input) ? input : input.panels
  const issues: DashboardWidgetIssue[] = []

  panels.forEach((panel, index) => {
    const panelPath = joinDashboardJsonPointer('/panels', index)
    const resolved = registry.resolve(panel)

    if (!resolved.ok || !resolved.definition) {
      issues.push(
        ...resolved.issues.map((issue) =>
          toWidgetIssue(issue, panel, `${panelPath}/widget`)
        )
      )
      return
    }

    issues.push(
      ...validateGridConstraints(
        panel,
        panelPath,
        resolved.definition,
        resolved.variant
      )
    )

    const validate = resolved.validate
    if (!validate) return

    const context: DashboardWidgetValidationContext = {
      definition: resolved.definition,
      variant: resolved.variant,
      registry,
      document,
      panelIndex: index,
      pluginVersion: readPluginVersion(document, panel.widget),
    }

    try {
      issues.push(
        ...validate(panel, context).map((issue) =>
          normalizeWidgetIssue(issue, panel, panelPath)
        )
      )
    } catch (error) {
      issues.push({
        severity: 'error',
        code: 'invalid_widget_validation',
        message:
          error instanceof Error
            ? error.message
            : `Widget "${panel.widget}" validation failed.`,
        panelId: panel.id,
        widget: panel.widget,
        variant: panel.variant,
        path: panelPath,
      })
    }
  })

  return {
    valid: !issues.some((issue) => issue.severity === 'error'),
    issues,
  }
}

/** `gridPos` must stay inside the widget's `minGrid` / `maxGrid` bounds. */
function validateGridConstraints(
  panel: DashboardPanel,
  panelPath: string,
  definition: DashboardWidgetDefinition,
  variant: DashboardWidgetVariantDefinition | undefined
): DashboardWidgetIssue[] {
  const gridPos = panel.gridPos as
    | Partial<DashboardPanel['gridPos']>
    | undefined
  if (!isDashboardPlainObject(gridPos)) return []

  const { min, max } = resolveDashboardWidgetGridConstraints(
    definition,
    variant
  )
  const issues: DashboardWidgetIssue[] = []

  for (const key of ['w', 'h'] as const) {
    const value = gridPos[key]
    if (typeof value !== 'number') continue
    const axis = key === 'w' ? 'width' : 'height'
    const path = `${panelPath}/gridPos/${key}`
    const base = {
      panelId: panel.id,
      widget: panel.widget,
      variant: panel.variant,
      path,
    }

    const minValue = min[key]
    const maxValue = max[key]
    const unit = key === 'w' ? 'columns' : 'rows'

    if (minValue !== undefined && value < minValue) {
      issues.push({
        ...base,
        severity: 'error',
        code: 'grid_below_min',
        message: `Panel "${panel.id}" ${axis} ${value} is below the widget minimum ${minValue}.`,
        suggestion: `Resize the panel to at least ${minValue} ${unit}.`,
      })
    }

    if (maxValue !== undefined && value > maxValue) {
      issues.push({
        ...base,
        severity: 'error',
        code: 'grid_above_max',
        message: `Panel "${panel.id}" ${axis} ${value} exceeds the widget maximum ${maxValue}.`,
        suggestion: `Resize the panel to at most ${maxValue} ${unit}.`,
      })
    }
  }

  return issues
}

function toWidgetIssue(
  issue: DashboardWidgetRegistryIssue,
  panel: DashboardPanel,
  fallbackPath: string
): DashboardWidgetIssue {
  return {
    ...issue,
    panelId: issue.panelId ?? panel.id,
    widget: issue.widget ?? panel.widget,
    variant: issue.variant ?? panel.variant,
    path: normalizePanelPath(issue.path, fallbackPath),
  }
}

function normalizeWidgetIssue(
  issue: DashboardWidgetIssue,
  panel: DashboardPanel,
  panelPath: string
): DashboardWidgetIssue {
  return {
    ...issue,
    panelId: issue.panelId ?? panel.id,
    widget: issue.widget ?? panel.widget,
    variant: issue.variant ?? panel.variant,
    path: normalizePanelPath(issue.path, panelPath),
  }
}

function normalizePanelPath(
  path: string | undefined,
  fallback: string
): string {
  if (!path) return fallback
  if (path.startsWith('/panels/')) return path
  if (path.startsWith('/')) return `${fallback}${path}`
  return joinDashboardJsonPointer(fallback, path)
}

function readPluginVersion(
  document: DashboardDocument | undefined,
  widget: string
): string | undefined {
  return isDashboardPlainObject(document?.pluginVersions) &&
    typeof document.pluginVersions[widget] === 'string'
    ? document.pluginVersions[widget]
    : undefined
}
