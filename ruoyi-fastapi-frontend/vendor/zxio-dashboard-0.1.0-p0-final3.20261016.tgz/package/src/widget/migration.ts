import {
  DASHBOARD_SCHEMA_VERSION,
  cloneDashboardJson,
  collectDashboardJsonIssues,
  isDashboardPlainObject,
} from '../schema'
import { hasBlockingDashboardIssues } from '../validation'
import { createReadonlyDashboardWidgetRegistry } from './registry'

import type { DashboardPanel } from '../schema'
import type { DashboardWidgetMigrator } from '../migration'
import type {
  DashboardWidgetDefinition,
  DashboardWidgetMigrationAdapterOptions,
  DashboardWidgetMigrationContext,
  DashboardWidgetMigratorMap,
  DashboardWidgetRegistry,
  DashboardWidgetRegistryIssue,
} from './types'

export function createDashboardWidgetMigrators(
  registry: DashboardWidgetRegistry,
  options: DashboardWidgetMigrationAdapterOptions = {}
): DashboardWidgetMigratorMap {
  const migrators: DashboardWidgetMigratorMap = {}

  for (const definition of registry.list({ includeHidden: true })) {
    if (
      !definition.migrate &&
      !definition.variants?.some((item) => item.migrate)
    ) {
      continue
    }

    migrators[definition.name] = createWidgetMigrator(
      definition,
      registry,
      options
    )
  }

  return migrators
}

function createWidgetMigrator(
  definition: DashboardWidgetDefinition,
  registry: DashboardWidgetRegistry,
  options: DashboardWidgetMigrationAdapterOptions
): DashboardWidgetMigrator {
  return {
    widget: definition.name,
    targetVersion: definition.version,
    migratePanel(panel, foundationContext) {
      const resolved = registry.resolve(panel)
      const migrate = resolved.migrate

      if (!resolved.ok || !resolved.definition || !migrate) {
        return panel
      }

      const context: DashboardWidgetMigrationContext = {
        definition: resolved.definition,
        variant: resolved.variant,
        registry: createReadonlyDashboardWidgetRegistry(registry),
        fromVersion: foundationContext.fromVersion,
        toVersion: definition.version,
        documentSchemaVersion:
          foundationContext.documentSchemaVersion ?? DASHBOARD_SCHEMA_VERSION,
      }

      const result = migrate(panel, context)
      if (result === undefined) return panel

      const migrated = mergeMigrationResult(panel, result)
      const issues = collectDashboardJsonIssues(migrated, '', {
        phase: 'import',
      })

      if (hasBlockingDashboardIssues(issues)) {
        const issue = createInvalidWidgetMigrationIssue(
          panel,
          issues[0]?.message ?? 'Widget migration returned invalid JSON.'
        )
        options.onIssue?.(issue)
        throw new Error(issue.message)
      }

      return cloneDashboardJson(migrated)
    },
  }
}

function mergeMigrationResult(
  panel: DashboardPanel,
  result:
    | DashboardPanel
    | Partial<Omit<DashboardPanel, 'id' | 'widget' | 'gridPos'>>
): DashboardPanel {
  if (!isDashboardPlainObject(result)) {
    throw new Error('Widget migration must return a panel object or patch.')
  }

  if (
    ('id' in result && result.id !== panel.id) ||
    ('widget' in result && result.widget !== panel.widget) ||
    ('gridPos' in result &&
      JSON.stringify(result.gridPos) !== JSON.stringify(panel.gridPos))
  ) {
    throw new Error(
      'Widget migration cannot change protected panel fields id, widget, or gridPos.'
    )
  }

  return {
    ...panel,
    ...(result as Partial<DashboardPanel>),
    id: panel.id,
    widget: panel.widget,
    gridPos: panel.gridPos,
  }
}

function createInvalidWidgetMigrationIssue(
  panel: DashboardPanel,
  message: string
): DashboardWidgetRegistryIssue {
  return {
    severity: 'error',
    code: 'invalid_widget_migration',
    message,
    widget: panel.widget,
    variant: panel.variant,
    panelId: panel.id,
  }
}
