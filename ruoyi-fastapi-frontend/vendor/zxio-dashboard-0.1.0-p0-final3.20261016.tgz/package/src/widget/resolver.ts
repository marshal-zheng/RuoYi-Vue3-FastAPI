import {
  type Component,
  type PropType,
  defineComponent,
  h,
  onBeforeUnmount,
  onMounted,
  readonly,
  ref,
} from 'vue'
import { resolveDashboardWidgetComponent } from './async-component'
import { provideDashboardWidgetContext } from './context/dashboard-widget-context'
import { createReadonlyDashboardWidgetRegistry } from './registry'

import type { DashboardPanel } from '../schema'
import type { DashboardPanelContentResolver } from '../runtime'
import type {
  DashboardWidgetComponent,
  DashboardWidgetDefinition,
  DashboardWidgetDisposeHandler,
  DashboardWidgetEvent,
  DashboardWidgetHostRenderContext,
  DashboardWidgetReadonlyPanel,
  DashboardWidgetRegistry,
  DashboardWidgetRegistryIssue,
  DashboardWidgetRegistryReadonly,
  DashboardWidgetRenderContext,
  DashboardWidgetResizeEvent,
  DashboardWidgetResizeHandler,
  DashboardWidgetResolverOptions,
  DashboardWidgetVariantDefinition,
} from './types'

interface CachedResolvedComponent {
  source: DashboardWidgetComponent
  component: Component
}

export function createDashboardPanelContentResolver(
  registry: DashboardWidgetRegistry,
  options: DashboardWidgetResolverOptions = {}
): DashboardPanelContentResolver {
  const componentCache = new Map<string, CachedResolvedComponent>()

  return (panel, renderContext) => {
    const resolved = registry.resolve(panel)

    if (!resolved.ok || !resolved.definition || !resolved.component) {
      resolved.issues.forEach((issue) => options.onIssue?.(issue))
      return undefined
    }

    const cacheKey = `${resolved.definition.name}::${
      resolved.variant?.name ?? '__base'
    }`
    const cached = componentCache.get(cacheKey)
    const component =
      cached?.source === resolved.component
        ? cached.component
        : resolveDashboardWidgetComponent(resolved.component, {
            widget: resolved.definition.name,
            variant: resolved.variant?.name,
            loadingComponent: options.loadingComponent,
            errorComponent: options.errorComponent,
            delay: options.asyncDelay,
            timeout: options.asyncTimeout,
            onIssue: options.onIssue,
          })

    if (cached?.source !== resolved.component) {
      componentCache.set(cacheKey, {
        source: resolved.component,
        component,
      })
    }

    return h(DashboardWidgetHost, {
      panel,
      definition: resolved.definition,
      variant: resolved.variant,
      component,
      registry,
      renderContext,
      resolverOptions: options,
      onIssue: options.onIssue,
    })
  }
}

const DashboardWidgetHost = defineComponent({
  name: 'DashboardWidgetHost',
  props: {
    panel: {
      type: Object as PropType<DashboardPanel>,
      required: true,
    },
    definition: {
      type: Object as PropType<DashboardWidgetDefinition>,
      required: true,
    },
    variant: Object as PropType<DashboardWidgetVariantDefinition>,
    component: {
      type: [Object, Function] as PropType<Component>,
      required: true,
    },
    registry: {
      type: Object as PropType<DashboardWidgetRegistry>,
      required: true,
    },
    renderContext: {
      type: Object as PropType<DashboardWidgetHostRenderContext>,
      required: true,
    },
    resolverOptions: {
      type: Object as PropType<DashboardWidgetResolverOptions>,
      default: () => ({}),
    },
    onIssue: Function as PropType<
      (issue: DashboardWidgetRegistryIssue) => void
    >,
  },
  setup(props) {
    const hostRef = ref<HTMLElement>()
    const resizeHandlers: DashboardWidgetResizeHandler[] = []
    const disposeHandlers: DashboardWidgetDisposeHandler[] = []
    const readonlyRegistry: DashboardWidgetRegistryReadonly =
      createReadonlyDashboardWidgetRegistry(props.registry)
    let resizeObserver: ResizeObserver | undefined

    const widgetContext: DashboardWidgetRenderContext = {
      get mode() {
        return props.renderContext.mode
      },
      get editable() {
        return props.renderContext.mode === 'edit'
      },
      get readonly() {
        return props.renderContext.mode === 'view'
      },
      get panel() {
        return readonly(props.panel) as DashboardWidgetReadonlyPanel
      },
      get definition() {
        return readonly(props.definition) as Readonly<DashboardWidgetDefinition>
      },
      get variant() {
        return props.variant
          ? (readonly(
              props.variant
            ) as Readonly<DashboardWidgetVariantDefinition>)
          : undefined
      },
      registry: readonlyRegistry,
      updatePanel: (patch) => {
        props.renderContext.requestPanelUpdate({
          panelId: props.panel.id,
          panel: props.panel,
          patch,
          source: 'panel-content',
        })
      },
      requestAction: (action, payload) => {
        props.renderContext.dispatchPanelAction({
          panelId: props.panel.id,
          panel: props.panel,
          action,
          payload,
          source: 'panel-content',
        })
      },
      emitWidgetEvent: (event, payload) => {
        const normalized = createWidgetEvent(props, event, payload)
        props.resolverOptions.onWidgetEvent?.(normalized)
        props.renderContext.emitWidgetEvent(normalized)
      },
      onWidgetResize: (handler) => {
        resizeHandlers.push(handler)
        return () => removeHandler(resizeHandlers, handler)
      },
      onWidgetDispose: (handler) => {
        disposeHandlers.push(handler)
        return () => removeHandler(disposeHandlers, handler)
      },
      requestWidgetResize: (reason = 'manual') => {
        notifyWidgetResize(reason)
      },
    }

    provideDashboardWidgetContext(widgetContext)

    onMounted(() => {
      notifyWidgetResize('mounted')

      if (typeof ResizeObserver === 'undefined' || !hostRef.value) return

      resizeObserver = new ResizeObserver((entries) => {
        const entry = entries[0]
        notifyWidgetResize('observer', {
          width: entry.contentRect.width,
          height: entry.contentRect.height,
        })
      })
      resizeObserver.observe(hostRef.value)
    })

    onBeforeUnmount(() => {
      resizeObserver?.disconnect()
      runDisposeHandlers()
    })

    function notifyWidgetResize(
      reason: DashboardWidgetResizeEvent['reason'],
      rect = readHostRect(hostRef.value)
    ): void {
      const event: DashboardWidgetResizeEvent = {
        type: 'widget-resize',
        mode: props.renderContext.mode,
        panelId: props.panel.id,
        widget: props.panel.widget,
        variant: props.panel.variant,
        gridPos: props.panel.gridPos,
        rect,
        reason,
      }

      resizeHandlers.slice().forEach((handler) => handler(event))
    }

    function runDisposeHandlers(): void {
      const handlers = disposeHandlers.splice(0).reverse()

      for (const handler of handlers) {
        try {
          handler()
        } catch (error) {
          props.onIssue?.({
            severity: 'warn',
            code: 'widget_dispose_failed',
            message:
              error instanceof Error
                ? error.message
                : `Widget "${props.panel.widget}" dispose handler failed.`,
            widget: props.panel.widget,
            variant: props.panel.variant,
            panelId: props.panel.id,
          })
        }
      }
    }

    return () => {
      const widgetProps = resolveWidgetProps(props, widgetContext)

      return h(
        'div',
        {
          ref: hostRef,
          class: 'zx-dashboard-widget-host',
          'data-dashboard-widget': props.panel.widget,
          'data-dashboard-widget-variant': props.panel.variant,
        },
        [h(props.component, widgetProps)]
      )
    }
  },
})

function resolveWidgetProps(
  props: Readonly<{
    panel: DashboardPanel
    definition: DashboardWidgetDefinition
    variant?: DashboardWidgetVariantDefinition
  }>,
  context: DashboardWidgetRenderContext
): Record<string, unknown> {
  const resolveProps =
    props.variant?.resolveProps ?? props.definition.resolveProps
  if (resolveProps) return resolveProps(context.panel, context)

  const panel = context.panel
  return {
    panel,
    data: panel.data,
    params: panel.params,
    metadata: panel.metadata,
    mode: context.mode,
    editable: context.editable,
    readonly: context.readonly,
  }
}

function createWidgetEvent(
  props: Readonly<{
    panel: DashboardPanel
    renderContext: DashboardWidgetHostRenderContext
  }>,
  event: string,
  payload: DashboardWidgetEvent['payload']
): DashboardWidgetEvent {
  return {
    type: 'widget-event',
    mode: props.renderContext.mode,
    source: 'panel-content',
    panelId: props.panel.id,
    panel: props.panel,
    widget: props.panel.widget,
    variant: props.panel.variant,
    event,
    payload,
  }
}

function removeHandler<T>(handlers: T[], handler: T): void {
  const index = handlers.indexOf(handler)
  if (index >= 0) handlers.splice(index, 1)
}

function readHostRect(
  element: HTMLElement | undefined
): DashboardWidgetResizeEvent['rect'] {
  if (!element) return undefined
  const rect = element.getBoundingClientRect()
  return {
    width: rect.width,
    height: rect.height,
  }
}
