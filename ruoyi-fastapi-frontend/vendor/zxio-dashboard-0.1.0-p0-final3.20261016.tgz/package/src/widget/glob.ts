import { isDashboardPlainObject } from '../schema'
import {
  createInvalidGlobWidgetModuleIssue,
  normalizeDashboardWidgetDefinition,
} from './issues'

import type { DashboardWidgetDefinition, DashboardWidgetPlugin } from './types'

export interface DashboardGlobWidgetsOptions {
  name?: string
  version?: string
}

export type DashboardGlobWidgetModules = Record<string, unknown>

export function createGlobWidgets(
  modules: DashboardGlobWidgetModules,
  options: DashboardGlobWidgetsOptions = {}
): DashboardWidgetPlugin {
  return {
    name: options.name ?? 'glob-widgets',
    version: options.version,
    install(context) {
      for (const [path, module] of Object.entries(modules)) {
        const manifest = readWidgetManifest(module)

        if (!manifest) {
          context.addIssue(
            createInvalidGlobWidgetModuleIssue(
              path,
              'Glob widget modules must explicitly export a DashboardWidgetDefinition as default, dashboardWidget, or widgetDefinition.'
            )
          )
          continue
        }

        const normalized = normalizeDashboardWidgetDefinition(manifest)
        if (!normalized.definition) {
          context.addIssue(
            createInvalidGlobWidgetModuleIssue(
              path,
              `Glob widget module "${path}" contains an invalid widget definition.`,
              { widget: readWidgetName(manifest) }
            )
          )
          normalized.issues.forEach(context.addIssue)
          continue
        }

        context.register(normalized.definition)
      }
    },
  }
}

function readWidgetManifest(
  module: unknown
): DashboardWidgetDefinition | undefined {
  if (!isDashboardPlainObject(module)) return undefined

  const candidates = [
    module.default,
    module.dashboardWidget,
    module.widgetDefinition,
  ]

  return candidates.find(isDashboardPlainObject) as
    | DashboardWidgetDefinition
    | undefined
}

function readWidgetName(manifest: unknown): string | undefined {
  return isDashboardPlainObject(manifest) && typeof manifest.name === 'string'
    ? manifest.name
    : undefined
}
