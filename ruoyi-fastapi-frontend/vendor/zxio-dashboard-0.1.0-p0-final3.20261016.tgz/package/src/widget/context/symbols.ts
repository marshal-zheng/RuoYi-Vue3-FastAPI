import type { InjectionKey } from 'vue'
import type { DashboardWidgetRenderContext } from '../types'

export const dashboardWidgetContextKey: InjectionKey<DashboardWidgetRenderContext> =
  Symbol('DashboardWidgetContext')
