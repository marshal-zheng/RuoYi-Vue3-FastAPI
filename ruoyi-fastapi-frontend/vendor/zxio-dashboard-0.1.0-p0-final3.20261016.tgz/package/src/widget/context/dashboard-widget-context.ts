import { inject, provide } from 'vue'
import { dashboardWidgetContextKey } from './symbols'

import type { DashboardWidgetRenderContext } from '../types'

export function provideDashboardWidgetContext(
  context: DashboardWidgetRenderContext
): DashboardWidgetRenderContext {
  provide(dashboardWidgetContextKey, context)
  return context
}

export function useDashboardWidgetContext(): DashboardWidgetRenderContext | null {
  return inject(dashboardWidgetContextKey, null)
}

export function useRequiredDashboardWidgetContext(): DashboardWidgetRenderContext {
  const context = useDashboardWidgetContext()
  if (!context) {
    throw new Error(
      '[dashboard] Missing DashboardWidgetContext. Mount this component through createDashboardPanelContentResolver() or call provideDashboardWidgetContext().'
    )
  }
  return context
}
