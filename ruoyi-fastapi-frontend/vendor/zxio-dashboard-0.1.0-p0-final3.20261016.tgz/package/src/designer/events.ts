import type {
  DashboardDesignerEventSource,
  DashboardDesignerMode,
  DashboardDesignerPanelMutationEvent,
} from './types'

export function createDashboardDesignerMutationEvent<
  T extends DashboardDesignerPanelMutationEvent
>(
  event: T,
  defaults?: {
    mode?: DashboardDesignerMode
    source?: DashboardDesignerEventSource
  }
): T {
  return {
    ...event,
    mode: event.mode ?? defaults?.mode ?? 'edit',
    source: event.source ?? defaults?.source ?? 'designer',
  }
}
