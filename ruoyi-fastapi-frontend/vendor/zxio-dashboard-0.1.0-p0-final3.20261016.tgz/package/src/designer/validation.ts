import { DASHBOARD_SCHEMA_VERSION, cloneDashboardJson } from '../schema'
import {
  type DashboardExportOptions,
  type DashboardExportResult,
  exportDashboardDocument,
} from '../import-export'
import { validateDashboardDocument } from '../validation'
import { validateDashboardWidgets } from '../widget'
import {
  hasBlockingDashboardDesignerIssues,
  toDashboardDesignerIssue,
} from './issues'

import type { DashboardDocument, DashboardPanel } from '../schema'
import type { DashboardWidgetRegistry } from '../widget'
import type {
  DashboardDesignerEventSource,
  DashboardDesignerExportRequestEvent,
  DashboardDesignerMode,
  DashboardDesignerSaveRequestEvent,
  DashboardDesignerValidationSummary,
} from './types'

export function createDashboardDesignerDocumentSnapshot(input: {
  document?: DashboardDocument
  panels: readonly DashboardPanel[]
}): DashboardDocument {
  if (input.document) {
    return {
      ...cloneDashboardJson(input.document),
      panels: cloneDashboardJson(input.panels) as DashboardPanel[],
    }
  }

  return {
    schemaVersion: DASHBOARD_SCHEMA_VERSION,
    panels: cloneDashboardJson(input.panels) as DashboardPanel[],
  }
}

export function validateDashboardDesignerSnapshot(input: {
  document?: DashboardDocument
  panels: readonly DashboardPanel[]
  registry: DashboardWidgetRegistry
}): DashboardDesignerValidationSummary {
  const document = createDashboardDesignerDocumentSnapshot(input)
  const schemaValidation = validateDashboardDocument(document, {
    knownWidgets: input.registry.names(),
  })
  const widgetValidation = validateDashboardWidgets(document, input.registry)
  const issues = [
    ...schemaValidation.issues.map((issue) =>
      toDashboardDesignerIssue(issue, 'designer')
    ),
    ...widgetValidation.issues.map((issue) =>
      toDashboardDesignerIssue(issue, 'designer')
    ),
  ]

  return {
    document,
    schemaValidation,
    widgetValidation,
    issues,
    valid: !hasBlockingDashboardDesignerIssues(issues),
  }
}

export function createDashboardDesignerSaveRequest(input: {
  document?: DashboardDocument
  panels: readonly DashboardPanel[]
  registry: DashboardWidgetRegistry
  mode: DashboardDesignerMode
  source?: DashboardDesignerEventSource
  command?: string
}): DashboardDesignerSaveRequestEvent {
  const summary = validateDashboardDesignerSnapshot(input)

  return {
    type: 'save-request',
    mode: input.mode,
    source: input.source ?? 'toolbar',
    command: input.command ?? 'save',
    document: summary.document,
    panels: cloneDashboardJson(input.panels) as DashboardPanel[],
    // The revision the edit started from, for optimistic concurrency on save.
    revision: input.document?.meta?.revision,
    schemaValidation: summary.schemaValidation,
    widgetValidation: summary.widgetValidation,
    issues: summary.issues,
    valid: summary.valid,
  }
}

export function createDashboardDesignerExportRequest(input: {
  document?: DashboardDocument
  panels: readonly DashboardPanel[]
  registry: DashboardWidgetRegistry
  mode: DashboardDesignerMode
  source?: DashboardDesignerEventSource
  command?: string
  options?: DashboardExportOptions
}): DashboardDesignerExportRequestEvent {
  const summary = validateDashboardDesignerSnapshot(input)
  const exportResult: DashboardExportResult = summary.valid
    ? exportDashboardDocument(summary.document, input.options)
    : {
        issues: summary.schemaValidation.issues,
      }
  const exportIssues = exportResult.issues.map((issue) =>
    toDashboardDesignerIssue(issue, 'designer')
  )
  const issues = [...summary.issues, ...exportIssues]

  return {
    type: 'export-request',
    mode: input.mode,
    source: input.source ?? 'toolbar',
    command: input.command ?? 'export',
    document: summary.document,
    panels: cloneDashboardJson(input.panels) as DashboardPanel[],
    schemaValidation: summary.schemaValidation,
    widgetValidation: summary.widgetValidation,
    exportResult,
    issues,
    valid: !hasBlockingDashboardDesignerIssues(issues),
  }
}
