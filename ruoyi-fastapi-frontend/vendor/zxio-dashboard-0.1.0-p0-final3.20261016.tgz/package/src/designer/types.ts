import type { Component, DeepReadonly, Ref } from 'vue'
import type {
  DashboardDocument,
  DashboardGridPosition,
  DashboardJsonValue,
  DashboardPanel,
} from '../schema'
import type {
  DashboardExportOptions,
  DashboardExportResult,
} from '../import-export'
import type {
  DashboardChromeVariant,
  DashboardGridOptions,
  DashboardLocaleSource,
  DashboardPanelChromeOptions,
  DashboardReadonlyDocument,
  DashboardRuntimeMode,
} from '../runtime'
import type {
  DashboardSchemaIssue,
  DashboardValidationResult,
} from '../validation'
import type {
  DashboardWidgetDefinition,
  DashboardWidgetIssue,
  DashboardWidgetRegistry,
  DashboardWidgetRegistryIssue,
  DashboardWidgetRegistryReadonly,
  DashboardWidgetResolverOptions,
  DashboardWidgetValidationResult,
  DashboardWidgetVariantDefinition,
} from '../widget'

export type DashboardDesignerMode = 'edit' | 'preview' | 'view'

export type DashboardDesignerEventSource =
  | 'designer'
  | 'palette'
  | 'toolbar'
  | 'renderer'
  | 'grid'
  | 'panel-chrome'
  | 'panel-content'
  | 'drawer'
  | 'editor'
  | 'keyboard'

export type DashboardDesignerIssueSeverity = 'error' | 'warn' | 'info'

export interface DashboardDesignerIssue {
  severity: DashboardDesignerIssueSeverity
  code: string
  message: string
  path?: string
  panelId?: string
  widget?: string
  variant?: string
  source?: DashboardDesignerEventSource
  suggestion?: string
}

export interface DashboardDesignerPaletteItem {
  key: string
  widget: string
  variant?: string
  title: string
  description?: string
  group: string
  icon?: string | Component
  tags: string[]
  order: number
  defaultGrid?: Partial<DashboardGridPosition>
}

export interface DashboardDesignerPaletteGroup {
  name: string
  order: number
  items: DashboardDesignerPaletteItem[]
}

export type DashboardDesignerCreatePanelId = (input: {
  widget: string
  variant?: string
  existingPanels: readonly DashboardPanel[]
}) => string

export interface DashboardDesignerPanelCreateInput {
  definition: DashboardWidgetDefinition
  variant?: DashboardWidgetVariantDefinition
  /** Explicit geometry (a drop position); without `x` and `y` the first free slot is used. */
  gridPos?: Partial<DashboardGridPosition>
  existingPanels: readonly DashboardPanel[]
  defaultPanelSize?: Pick<DashboardGridPosition, 'w' | 'h'>
  /** Grid width used for first-fit placement and width clamping. Defaults to 24. */
  columns?: number
  createPanelId?: DashboardDesignerCreatePanelId
}

export interface DashboardDesignerPanelCreateResult {
  ok: boolean
  panel?: DashboardPanel
  issues: DashboardDesignerIssue[]
}

export interface DashboardDesignerContext {
  mode: Readonly<Ref<DashboardDesignerMode>>
  rendererMode: Readonly<Ref<DashboardRuntimeMode>>
  document: Readonly<Ref<DashboardReadonlyDocument | undefined>>
  panels: Readonly<Ref<readonly DeepReadonly<DashboardPanel>[]>>
  registry: DashboardWidgetRegistryReadonly
  selectedPanelId: Readonly<Ref<string | undefined>>
  selectPanel: (
    panelId: string | undefined,
    source?: DashboardDesignerEventSource
  ) => void
  requestPanelPatch: (
    panelId: string,
    patch: Partial<Omit<DashboardPanel, 'id'>>,
    source?: DashboardDesignerEventSource
  ) => void
  requestSave: (command?: string) => void
  requestExport: (options?: DashboardExportOptions) => void
  reportDesignerIssue: (issue: DashboardDesignerIssue) => void
  /** Document history (see `createDashboardDesignerHistory`). */
  canUndo: Readonly<Ref<boolean>>
  canRedo: Readonly<Ref<boolean>>
  /** Whether `panels` differ from the last saved snapshot. */
  dirty: Readonly<Ref<boolean>>
  undo: (source?: DashboardDesignerEventSource) => boolean
  redo: (source?: DashboardDesignerEventSource) => boolean
  /** Restores the last saved snapshot and clears the history. */
  discard: (source?: DashboardDesignerEventSource) => boolean
  /** Makes the current panels (or `panels`) the clean baseline after a host save. */
  markSaved: (panels?: readonly DashboardPanel[]) => void
}

export type DashboardDesignerHistoryAction =
  | 'push'
  | 'undo'
  | 'redo'
  | 'discard'
  | 'saved'
  | 'reset'

export interface DashboardDesignerHistoryChangeEvent
  extends DashboardDesignerEventBase {
  type: 'history-change'
  action: DashboardDesignerHistoryAction
  canUndo: boolean
  canRedo: boolean
  dirty: boolean
  /** Panels after an `undo` / `redo` / `discard`; absent for bookkeeping actions. */
  panels?: DashboardPanel[]
  previousPanels?: DashboardPanel[]
}

export interface DashboardDesignerEventBase {
  type: string
  mode: DashboardDesignerMode
  source: DashboardDesignerEventSource
}

export interface DashboardDesignerPanelMutationEvent
  extends DashboardDesignerEventBase {
  type:
    | 'panel-add-request'
    | 'panel-remove-request'
    | 'panel-duplicate-request'
    | 'panel-patch-request'
    | 'layout-change'
  panels: DashboardPanel[]
  previousPanels: DashboardPanel[]
  panelId?: string
  panel?: DashboardPanel
  gridPos?: DashboardGridPosition
  patch?: Partial<Omit<DashboardPanel, 'id'>>
  changes?: {
    panelId: string
    before: DashboardGridPosition
    after: DashboardGridPosition
  }[]
  payload?: DashboardJsonValue | Record<string, unknown>
}

export interface DashboardDesignerPanelAddRequestEvent
  extends DashboardDesignerPanelMutationEvent {
  type: 'panel-add-request'
  panelId: string
  panel: DashboardPanel
  gridPos: DashboardGridPosition
}

export interface DashboardDesignerPanelRemoveRequestEvent
  extends DashboardDesignerPanelMutationEvent {
  type: 'panel-remove-request'
  panelId: string
  panel: DashboardPanel
}

export interface DashboardDesignerPanelDuplicateRequestEvent
  extends DashboardDesignerPanelMutationEvent {
  type: 'panel-duplicate-request'
  panelId: string
  panel: DashboardPanel
}

export interface DashboardDesignerPanelPatchRequestEvent
  extends DashboardDesignerPanelMutationEvent {
  type: 'panel-patch-request'
  panelId: string
  panel: DashboardPanel
  patch: Partial<Omit<DashboardPanel, 'id'>>
}

export interface DashboardDesignerLayoutChangeEvent
  extends DashboardDesignerPanelMutationEvent {
  type: 'layout-change'
  changes: {
    panelId: string
    before: DashboardGridPosition
    after: DashboardGridPosition
  }[]
}

export type DashboardDesignerEvent =
  | DashboardDesignerPanelAddRequestEvent
  | DashboardDesignerPanelRemoveRequestEvent
  | DashboardDesignerPanelDuplicateRequestEvent
  | DashboardDesignerPanelPatchRequestEvent
  | DashboardDesignerLayoutChangeEvent
  | DashboardDesignerHistoryChangeEvent
  | DashboardDesignerSaveRequestEvent
  | DashboardDesignerExportRequestEvent

export interface DashboardDesignerSaveRequestEvent
  extends DashboardDesignerEventBase {
  type: 'save-request'
  command: string
  document: DashboardDocument
  panels: DashboardPanel[]
  /** `document.meta.revision` the edit started from, for optimistic concurrency. */
  revision?: DashboardJsonValue
  schemaValidation: DashboardValidationResult
  widgetValidation: DashboardWidgetValidationResult
  issues: DashboardDesignerIssue[]
  valid: boolean
}

export interface DashboardDesignerExportRequestEvent
  extends DashboardDesignerEventBase {
  type: 'export-request'
  command: string
  document: DashboardDocument
  panels: DashboardPanel[]
  schemaValidation: DashboardValidationResult
  widgetValidation: DashboardWidgetValidationResult
  exportResult: DashboardExportResult
  issues: DashboardDesignerIssue[]
  valid: boolean
}

export interface DashboardDesignerValidationSummary {
  document: DashboardDocument
  schemaValidation: DashboardValidationResult
  widgetValidation: DashboardWidgetValidationResult
  issues: DashboardDesignerIssue[]
  valid: boolean
}

export interface ZxDashboardDesignerProps {
  document?: DashboardDocument
  panels?: DashboardPanel[]
  registry: DashboardWidgetRegistry
  mode?: DashboardDesignerMode
  selectedPanelId?: string
  grid?: DashboardGridOptions
  panelChrome?: DashboardPanelChromeOptions
  chromeVariant?: DashboardChromeVariant
  locale?: DashboardLocaleSource
  createPanelId?: DashboardDesignerCreatePanelId
  defaultPanelSize?: Pick<DashboardGridPosition, 'w' | 'h'>
  showPalette?: boolean
  showDrawer?: boolean
  resolverOptions?: DashboardWidgetResolverOptions
  /** Undo depth. Defaults to 100. */
  historyLimit?: number
}

export interface DashboardDesignerPanelEditorProps {
  panel: DeepReadonly<DashboardPanel>
  definition?: Readonly<DashboardWidgetDefinition>
  variant?: Readonly<DashboardWidgetVariantDefinition>
  requestPanelPatch: (patch: Partial<Omit<DashboardPanel, 'id'>>) => void
}

export type DashboardDesignerAnyIssue =
  | DashboardDesignerIssue
  | DashboardSchemaIssue
  | DashboardWidgetIssue
  | DashboardWidgetRegistryIssue
