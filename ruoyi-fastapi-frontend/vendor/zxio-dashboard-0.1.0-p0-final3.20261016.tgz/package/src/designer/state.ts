import { type Ref, computed, ref } from 'vue'

import type { DashboardDesignerMode } from './types'
import type { DashboardRuntimeMode } from '../runtime'

export function useControlledDashboardDesignerMode(props: {
  mode?: DashboardDesignerMode
  onUpdateMode?: (mode: DashboardDesignerMode) => void
}): {
  mode: Readonly<Ref<DashboardDesignerMode>>
  rendererMode: Readonly<Ref<DashboardRuntimeMode>>
  setMode: (mode: DashboardDesignerMode) => void
} {
  const internalMode = ref<DashboardDesignerMode>('edit')
  const mode = computed(() => props.mode ?? internalMode.value)
  const rendererMode = computed<DashboardRuntimeMode>(() =>
    mode.value === 'edit' ? 'edit' : 'view'
  )

  function setMode(nextMode: DashboardDesignerMode): void {
    if (props.mode === undefined) {
      internalMode.value = nextMode
    }
    props.onUpdateMode?.(nextMode)
  }

  return {
    mode,
    rendererMode,
    setMode,
  }
}

export function useControlledDashboardDesignerSelection(props: {
  selectedPanelId?: string
  onUpdateSelectedPanelId?: (panelId: string | undefined) => void
}): {
  selectedPanelId: Readonly<Ref<string | undefined>>
  selectPanel: (panelId: string | undefined) => void
} {
  const internalSelectedPanelId = ref<string>()
  const selectedPanelId = computed(
    () => props.selectedPanelId ?? internalSelectedPanelId.value
  )

  function selectPanel(panelId: string | undefined): void {
    if (props.selectedPanelId === undefined) {
      internalSelectedPanelId.value = panelId
    }
    props.onUpdateSelectedPanelId?.(panelId)
  }

  return {
    selectedPanelId,
    selectPanel,
  }
}
