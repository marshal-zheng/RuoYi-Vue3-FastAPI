<template>
  <aside
    v-if="panel"
    class="zx-dashboard-designer-drawer"
    data-dashboard-designer-region="drawer"
  >
    <header class="zx-dashboard-designer-drawer__header">
      <div class="zx-dashboard-designer-drawer__title">
        {{ panel.title || definition?.title || panel.widget }}
      </div>
      <button
        class="zx-dashboard-designer-drawer__close"
        type="button"
        :aria-label="locale.drawer.close"
        :title="locale.drawer.close"
        @click="$emit('close')"
      >
        ×
      </button>
    </header>

    <div class="zx-dashboard-designer-drawer__body">
      <slot
        name="editor"
        :panel="panel"
        :definition="definition"
        :variant="variant"
        :request-panel-patch="requestPanelPatch"
      >
        <component
          :is="editor"
          v-if="editor"
          :panel="panel"
          :definition="definition"
          :variant="variant"
          :request-panel-patch="requestPanelPatch"
        />
        <slot
          v-else
          name="fallback"
          :panel="panel"
          :definition="definition"
          :variant="variant"
        >
          <div class="zx-dashboard-designer-drawer__fallback">
            {{ locale.drawer.fallback }}
          </div>
        </slot>
      </slot>
    </div>
  </aside>
</template>

<script setup lang="ts">
import { useDashboardLocale } from '../../locale'

import type { Component } from 'vue'
import type { DashboardPanel } from '../../schema'
import type {
  DashboardWidgetDefinition,
  DashboardWidgetVariantDefinition,
} from '../../widget'

defineProps<{
  panel?: Readonly<DashboardPanel>
  definition?: Readonly<DashboardWidgetDefinition>
  variant?: Readonly<DashboardWidgetVariantDefinition>
  editor?: Component
  requestPanelPatch: (patch: Partial<Omit<DashboardPanel, 'id'>>) => void
}>()

defineEmits<{
  (event: 'close'): void
}>()

const locale = useDashboardLocale()
</script>
