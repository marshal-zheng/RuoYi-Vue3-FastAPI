<template>
  <aside
    class="zx-dashboard-designer-palette"
    data-dashboard-designer-region="palette"
  >
    <div class="zx-dashboard-designer-palette__search">
      <input
        class="zx-dashboard-designer-palette__input"
        type="search"
        :value="search"
        :placeholder="locale.palette.search"
        :aria-label="locale.palette.search"
        @input="handleSearchInput"
      />
    </div>

    <slot v-if="groups.length === 0" name="empty">
      <div class="zx-dashboard-designer-palette__empty">
        {{ locale.palette.empty }}
      </div>
    </slot>

    <section
      v-for="group in groups"
      :key="group.name"
      class="zx-dashboard-designer-palette__group"
      :data-palette-group="group.name"
    >
      <h3 class="zx-dashboard-designer-palette__group-title">
        {{ group.name }}
      </h3>
      <button
        v-for="item in group.items"
        :key="item.key"
        class="zx-dashboard-designer-palette__item"
        type="button"
        draggable="true"
        :data-widget="item.widget"
        :data-variant="item.variant"
        @click="$emit('add', item)"
        @dragstart="handleDragStart($event, item)"
        @dragend="endDashboardDesignerDrag"
      >
        <span
          v-if="typeof item.icon === 'string'"
          class="zx-dashboard-designer-palette__item-icon"
          aria-hidden="true"
        >
          {{ item.icon }}
        </span>
        <span class="zx-dashboard-designer-palette__item-body">
          <span class="zx-dashboard-designer-palette__item-title">
            {{ item.title }}
          </span>
          <span
            v-if="item.description"
            class="zx-dashboard-designer-palette__item-description"
          >
            {{ item.description }}
          </span>
        </span>
      </button>
    </section>
  </aside>
</template>

<script setup lang="ts">
import { useDashboardLocale } from '../../locale'
import { beginDashboardDesignerDrag, endDashboardDesignerDrag } from '../drag'

import type {
  DashboardDesignerPaletteGroup,
  DashboardDesignerPaletteItem,
} from '../types'

defineProps<{
  groups: DashboardDesignerPaletteGroup[]
  search?: string
}>()

const locale = useDashboardLocale()

const emit = defineEmits<{
  (event: 'update:search', value: string): void
  (event: 'add', item: DashboardDesignerPaletteItem): void
}>()

function handleSearchInput(event: Event): void {
  emit('update:search', (event.target as HTMLInputElement).value)
}

function handleDragStart(
  event: DragEvent,
  item: DashboardDesignerPaletteItem
): void {
  beginDashboardDesignerDrag(event.dataTransfer, {
    widget: item.widget,
    variant: item.variant,
  })
}
</script>
