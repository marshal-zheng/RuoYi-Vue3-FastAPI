<template>
  <section
    v-if="issues.length > 0"
    class="zx-dashboard-designer-issues"
    data-dashboard-designer-region="issues"
  >
    <article
      v-for="(issue, index) in issues"
      :key="`${index}:${issue.code}:${issue.path ?? issue.panelId ?? ''}`"
      class="zx-dashboard-designer-issues__item"
      :data-issue-severity="issue.severity"
      :data-issue-code="issue.code"
    >
      <strong class="zx-dashboard-designer-issues__severity">
        {{ severityLabel(issue.severity) }}
      </strong>
      <span class="zx-dashboard-designer-issues__message">
        {{ localizedIssueMessage(issue) }}
      </span>
      <code v-if="issue.path" class="zx-dashboard-designer-issues__path">
        {{ issue.path }}
      </code>
    </article>
  </section>
</template>

<script setup lang="ts">
import {
  dashboardLocaleEn,
  formatDashboardIssueMessage,
  useDashboardLocale,
} from '../../locale'

import type { DashboardDesignerIssue } from '../types'

defineProps<{
  issues: DashboardDesignerIssue[]
}>()

const locale = useDashboardLocale()

function localizedIssueMessage(issue: DashboardDesignerIssue): string {
  // Keep detailed default English diagnostics. Every locale may replace a
  // known message, including an English host override.
  const template = (locale.value.issues as Record<string, string | undefined>)[
    issue.code
  ]
  const defaultTemplate = (
    dashboardLocaleEn.issues as Record<string, string | undefined>
  )[issue.code]
  if (
    template === defaultTemplate &&
    issue.code !== 'grid_below_min' &&
    issue.code !== 'grid_above_max'
  )
    return issue.message
  const translated = formatDashboardIssueMessage(locale.value, issue.code, {
    panelId: issue.panelId,
    widget: issue.widget,
    path: issue.path,
  })
  return translated && !/\{\w+\}/.test(translated) ? translated : issue.message
}

function severityLabel(severity: string): string {
  const labels = locale.value.severity as Record<string, string | undefined>
  return labels[severity] ?? severity
}
</script>
