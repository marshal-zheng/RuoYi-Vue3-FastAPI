<template>
  <header
    class="zx-dashboard-designer-toolbar"
    data-dashboard-designer-region="toolbar"
  >
    <div
      class="zx-dashboard-designer-toolbar__modes"
      role="group"
      :aria-label="locale.toolbar.modeGroup"
    >
      <button
        v-for="item in modeItems"
        :key="item.mode"
        class="zx-dashboard-designer-toolbar__mode"
        :class="{ 'is-active': mode === item.mode }"
        type="button"
        :aria-pressed="mode === item.mode"
        @click="$emit('update:mode', item.mode)"
      >
        {{ item.label }}
      </button>
    </div>

    <div
      class="zx-dashboard-designer-toolbar__history"
      role="group"
      :aria-label="locale.toolbar.historyGroup"
    >
      <button
        v-for="item in historyItems"
        :key="item.action"
        class="zx-dashboard-designer-toolbar__history-command"
        type="button"
        :disabled="!item.enabled"
        :title="`${item.label} (${item.shortcut})`"
        :aria-label="item.label"
        :aria-keyshortcuts="item.ariaKeyShortcuts"
        :data-dashboard-history-action="item.action"
        @click="$emit(item.action)"
      >
        <component :is="item.icon" />
      </button>
      <button
        v-if="dirty"
        class="zx-dashboard-designer-toolbar__discard"
        type="button"
        :disabled="mode !== 'edit'"
        data-dashboard-history-action="discard"
        @click="$emit('discard')"
      >
        {{ locale.toolbar.discard }}
      </button>
    </div>

    <div class="zx-dashboard-designer-toolbar__commands">
      <span
        v-if="dirty"
        class="zx-dashboard-designer-toolbar__dirty"
        role="status"
        data-dashboard-dirty="true"
      >
        {{ locale.toolbar.unsaved }}
      </span>
      <button
        class="zx-dashboard-designer-toolbar__command"
        :class="{ 'is-primary': dirty }"
        type="button"
        :title="`${locale.toolbar.save} (${saveShortcut})`"
        :aria-keyshortcuts="saveAriaKeyShortcuts"
        @click="$emit('save')"
      >
        {{ locale.toolbar.save }}
      </button>
      <button
        class="zx-dashboard-designer-toolbar__command"
        type="button"
        @click="$emit('export')"
      >
        {{ locale.toolbar.export }}
      </button>
    </div>
  </header>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useDashboardLocale } from '../../locale'
import { DASHBOARD_DESIGNER_ICONS } from '../icons'
import {
  formatDashboardDesignerAriaKeyShortcuts,
  formatDashboardDesignerShortcut,
} from '../keymap'

import type { Component, PropType } from 'vue'
import type { DashboardDesignerMode } from '../types'

const props = defineProps({
  mode: {
    type: String as PropType<DashboardDesignerMode>,
    required: true,
  },
  canUndo: Boolean,
  canRedo: Boolean,
  dirty: Boolean,
})

defineEmits<{
  (event: 'update:mode', mode: DashboardDesignerMode): void
  (event: 'undo'): void
  (event: 'redo'): void
  (event: 'discard'): void
  (event: 'save'): void
  (event: 'export'): void
}>()

const locale = useDashboardLocale()

const modeItems = computed<{ mode: DashboardDesignerMode; label: string }[]>(
  () => [
    { mode: 'edit', label: locale.value.toolbar.edit },
    { mode: 'preview', label: locale.value.toolbar.preview },
    { mode: 'view', label: locale.value.toolbar.view },
  ]
)

const historyItems = computed<
  {
    action: 'undo' | 'redo'
    label: string
    icon: Component
    enabled: boolean
    shortcut: string
    ariaKeyShortcuts: string
  }[]
>(() => {
  const editing = props.mode === 'edit'
  return [
    {
      action: 'undo',
      label: locale.value.toolbar.undo,
      icon: DASHBOARD_DESIGNER_ICONS.undo,
      enabled: editing && props.canUndo,
      shortcut: formatDashboardDesignerShortcut('undo'),
      ariaKeyShortcuts: formatDashboardDesignerAriaKeyShortcuts('undo'),
    },
    {
      action: 'redo',
      label: locale.value.toolbar.redo,
      icon: DASHBOARD_DESIGNER_ICONS.redo,
      enabled: editing && props.canRedo,
      shortcut: formatDashboardDesignerShortcut('redo'),
      ariaKeyShortcuts: formatDashboardDesignerAriaKeyShortcuts('redo'),
    },
  ]
})

const saveShortcut = formatDashboardDesignerShortcut('save')
const saveAriaKeyShortcuts = formatDashboardDesignerAriaKeyShortcuts('save')
</script>
