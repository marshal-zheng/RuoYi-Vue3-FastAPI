import { createDashboardIcon } from '../runtime/actions'

export const DASHBOARD_DESIGNER_ICONS = {
  undo: createDashboardIcon('Undo', [
    'M6 4.5 3 7.5l3 3',
    'M3 7.5h6.5a3 3 0 0 1 0 6H6.5',
  ]),
  redo: createDashboardIcon('Redo', [
    'm10 4.5 3 3-3 3',
    'M13 7.5H6.5a3 3 0 0 0 0 6h3',
  ]),
}
