import { DASHBOARD_PANEL_DRAG_MIME } from '../runtime/grid/drag-mime'

/** Alias of the runtime `DASHBOARD_PANEL_DRAG_MIME`; the grid reads it first on drop. */
export const DASHBOARD_DESIGNER_DRAG_MIME = DASHBOARD_PANEL_DRAG_MIME

export interface DashboardDesignerDragPayload {
  widget: string
  variant?: string
}

export function encodeDashboardDesignerDragPayload(
  payload: DashboardDesignerDragPayload
): string {
  return JSON.stringify(payload)
}

// Browsers hide `dataTransfer` data during `dragover` (protected mode), so a
// drag started on this page is also remembered here for the live drop preview.
let activeDrag: DashboardDesignerDragPayload | undefined

/**
 * Starts a designer drag: writes the typed payload (plus JSON / plain-text
 * fallbacks for foreign drop targets) and records it as the active drag.
 */
export function beginDashboardDesignerDrag(
  dataTransfer: DataTransfer | null | undefined,
  payload: DashboardDesignerDragPayload
): string {
  const encoded = encodeDashboardDesignerDragPayload(payload)
  activeDrag = { widget: payload.widget, variant: payload.variant }

  if (dataTransfer) {
    dataTransfer.setData(DASHBOARD_DESIGNER_DRAG_MIME, encoded)
    dataTransfer.setData('application/json', encoded)
    dataTransfer.setData('text/plain', encoded)
    dataTransfer.effectAllowed = 'copy'
  }

  return encoded
}

/** Clears the active drag; call on `dragend`. */
export function endDashboardDesignerDrag(): void {
  activeDrag = undefined
}

/** The drag started on this page, if one is in flight. */
export function readDashboardDesignerActiveDrag():
  | DashboardDesignerDragPayload
  | undefined {
  return activeDrag ? { ...activeDrag } : undefined
}

export function parseDashboardDesignerDragPayload(
  raw: unknown
): DashboardDesignerDragPayload | undefined {
  if (typeof raw !== 'string' || raw.trim().length === 0) return undefined

  try {
    const parsed = JSON.parse(raw) as Partial<DashboardDesignerDragPayload>
    if (
      typeof parsed.widget !== 'string' ||
      parsed.widget.trim().length === 0
    ) {
      return undefined
    }

    return {
      widget: parsed.widget,
      variant:
        typeof parsed.variant === 'string' && parsed.variant.trim().length > 0
          ? parsed.variant
          : undefined,
    }
  } catch {
    return undefined
  }
}
