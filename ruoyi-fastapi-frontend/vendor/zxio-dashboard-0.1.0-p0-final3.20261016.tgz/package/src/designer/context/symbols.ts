import type { InjectionKey } from 'vue'
import type { DashboardDesignerContext } from '../types'

export const dashboardDesignerContextKey: InjectionKey<DashboardDesignerContext> =
  Symbol('dashboardDesignerContext')
