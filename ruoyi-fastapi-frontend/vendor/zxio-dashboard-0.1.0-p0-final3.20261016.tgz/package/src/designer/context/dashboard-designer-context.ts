import { inject, provide } from 'vue'
import { dashboardDesignerContextKey } from './symbols'

import type { DashboardDesignerContext } from '../types'

export function provideDashboardDesignerContext(
  context: DashboardDesignerContext
): DashboardDesignerContext {
  provide(dashboardDesignerContextKey, context)
  return context
}

export function useDashboardDesignerContext():
  | DashboardDesignerContext
  | undefined {
  return inject(dashboardDesignerContextKey)
}

export function useRequiredDashboardDesignerContext(): DashboardDesignerContext {
  const context = useDashboardDesignerContext()
  if (!context) {
    throw new Error(
      'Dashboard designer context is not available. Use this hook inside ZxDashboardDesigner.'
    )
  }
  return context
}
