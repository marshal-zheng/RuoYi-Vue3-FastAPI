import type {
  DashboardDesignerAnyIssue,
  DashboardDesignerEventSource,
  DashboardDesignerIssue,
} from './types'

export function createDashboardDesignerIssue(
  issue: DashboardDesignerIssue
): DashboardDesignerIssue {
  return issue
}

export function toDashboardDesignerIssue(
  issue: DashboardDesignerAnyIssue,
  source: DashboardDesignerEventSource = 'designer'
): DashboardDesignerIssue {
  return {
    severity: issue.severity,
    code: issue.code,
    message: issue.message,
    path: 'path' in issue ? issue.path : undefined,
    panelId: 'panelId' in issue ? issue.panelId : undefined,
    widget: 'widget' in issue ? issue.widget : undefined,
    variant: 'variant' in issue ? issue.variant : undefined,
    suggestion: 'suggestion' in issue ? issue.suggestion : undefined,
    source,
  }
}

export function hasBlockingDashboardDesignerIssues(
  issues: readonly DashboardDesignerIssue[]
): boolean {
  return issues.some((issue) => issue.severity === 'error')
}
