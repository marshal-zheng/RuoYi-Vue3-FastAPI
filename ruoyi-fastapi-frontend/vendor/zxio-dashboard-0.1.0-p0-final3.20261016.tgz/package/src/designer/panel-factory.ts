import {
  DASHBOARD_SCHEMA_VERSION,
  cloneDashboardJson,
  isDashboardImportLikeWidgetKey,
  validateDashboardGridPositionInput,
} from '../schema'
import {
  hasBlockingDashboardIssues,
  validateDashboardDocument,
} from '../validation'
import {
  clampDashboardGridSize,
  resolveDashboardWidgetGridConstraints,
} from '../widget'
import { toDashboardDesignerIssue } from './issues'

import type { DashboardGridPosition, DashboardPanel } from '../schema'
import type { DashboardGridSize, DashboardWidgetDefaultPanel } from '../widget'
import type {
  DashboardDesignerCreatePanelId,
  DashboardDesignerPanelCreateInput,
  DashboardDesignerPanelCreateResult,
} from './types'

const DEFAULT_PANEL_SIZE = { w: 8, h: 6 }
const DEFAULT_GRID_COLUMNS = 24

export function createDashboardDesignerPanel(
  input: DashboardDesignerPanelCreateInput
): DashboardDesignerPanelCreateResult {
  const definition = input.definition
  const variant = input.variant
  const widget = definition.name
  const variantName = variant?.name
  const issues = [
    ...validateDesignerKey(widget, '/widget', 'Widget'),
    ...(variantName
      ? validateDesignerKey(variantName, '/variant', 'Widget variant')
      : []),
  ]

  if (issues.length > 0) {
    return {
      ok: false,
      issues,
    }
  }

  let defaultPanel: DashboardWidgetDefaultPanel
  try {
    defaultPanel = cloneDashboardJson({
      ...(definition.defaultPanel ?? {}),
      ...(variant?.defaultPanel ?? {}),
    })
  } catch {
    return {
      ok: false,
      issues: [
        {
          severity: 'error',
          code: 'invalid_default_panel',
          message:
            'Widget defaultPanel must be serializable dashboard JSON data.',
          widget,
          variant: variantName,
          source: 'designer',
        },
      ],
    }
  }

  const id = resolvePanelId({
    widget,
    variant: variantName,
    existingPanels: input.existingPanels,
    createPanelId: input.createPanelId,
  })
  const gridPos = resolveGridPosition(input)
  const protectedPanel = stripProtectedFields(defaultPanel)
  const panel: DashboardPanel = {
    ...protectedPanel,
    id,
    widget,
    ...(variantName ? { variant: variantName } : {}),
    gridPos,
  }

  const validation = validateDashboardDocument(
    {
      schemaVersion: DASHBOARD_SCHEMA_VERSION,
      panels: [...input.existingPanels, panel],
    },
    {
      knownWidgets: [widget],
    }
  )

  if (hasBlockingDashboardIssues(validation.issues)) {
    return {
      ok: false,
      issues: validation.issues.map((issue) =>
        toDashboardDesignerIssue(issue, 'designer')
      ),
    }
  }

  return {
    ok: true,
    panel,
    issues: validation.issues.map((issue) =>
      toDashboardDesignerIssue(issue, 'designer')
    ),
  }
}

export function createDefaultDashboardDesignerPanelId(input: {
  widget: string
  variant?: string
  existingPanels: readonly DashboardPanel[]
}): string {
  const base = `panel-${slugifyPanelIdPart(input.widget)}`
  const existingIds = new Set(input.existingPanels.map((panel) => panel.id))
  let index = 1

  while (existingIds.has(`${base}-${index}`)) {
    index += 1
  }

  return `${base}-${index}`
}

function resolvePanelId(input: {
  widget: string
  variant?: string
  existingPanels: readonly DashboardPanel[]
  createPanelId?: DashboardDesignerCreatePanelId
}): string {
  return (
    input.createPanelId?.({
      widget: input.widget,
      variant: input.variant,
      existingPanels: input.existingPanels,
    }) ?? createDefaultDashboardDesignerPanelId(input)
  )
}

/**
 * Size a new panel of this widget gets: explicit `gridPos` size, then the
 * variant / definition `defaultGrid`, then `defaultPanelSize`, clamped into
 * the widget `minGrid` / `maxGrid` and the grid width.
 */
export function resolveDashboardDesignerPanelSize(
  input: Pick<
    DashboardDesignerPanelCreateInput,
    'definition' | 'variant' | 'gridPos' | 'defaultPanelSize' | 'columns'
  >
): DashboardGridSize {
  const defaultGrid = mergeDefaultGrid(input)
  const fallback = input.defaultPanelSize ?? DEFAULT_PANEL_SIZE
  const size = {
    w: input.gridPos?.w ?? defaultGrid.w ?? fallback.w,
    h: input.gridPos?.h ?? defaultGrid.h ?? fallback.h,
  }

  return clampDashboardGridSize(
    size,
    resolveDashboardWidgetGridConstraints(input.definition, input.variant),
    { columns: input.columns ?? DEFAULT_GRID_COLUMNS }
  )
}

/**
 * First slot, scanning rows top-down and columns left-right, where `size`
 * overlaps no existing panel. The row below the lowest panel always fits.
 */
export function findDashboardDesignerFreeSlot(
  panels: readonly DashboardPanel[],
  size: DashboardGridSize,
  columns = DEFAULT_GRID_COLUMNS
): Pick<DashboardGridPosition, 'x' | 'y'> {
  const width = Math.max(1, Math.min(size.w, columns))
  const height = Math.max(1, size.h)
  const lastRow = nextDashboardPanelY(panels)

  for (let y = 0; y <= lastRow; y += 1) {
    for (let x = 0; x + width <= columns; x += 1) {
      const candidate = { x, y, w: width, h: height }
      if (!panels.some((panel) => overlaps(panel.gridPos, candidate))) {
        return { x, y }
      }
    }
  }

  return { x: 0, y: lastRow }
}

function resolveGridPosition(
  input: DashboardDesignerPanelCreateInput
): DashboardGridPosition {
  const defaultGrid = mergeDefaultGrid(input)
  const columns = input.columns ?? DEFAULT_GRID_COLUMNS
  const size = resolveDashboardDesignerPanelSize(input)
  const x = input.gridPos?.x ?? defaultGrid.x
  const y = input.gridPos?.y ?? defaultGrid.y
  // A drop or an explicit default position is honoured; palette adds take
  // the first free slot instead of stacking at the bottom.
  const position =
    x === undefined && y === undefined
      ? findDashboardDesignerFreeSlot(input.existingPanels, size, columns)
      : { x: x ?? 0, y: y ?? nextDashboardPanelY(input.existingPanels) }
  const normalized = validateDashboardGridPositionInput(
    { ...position, ...size },
    '/gridPos'
  ).value

  if (normalized) return normalized

  const fallbackSize = input.defaultPanelSize ?? DEFAULT_PANEL_SIZE
  return {
    ...findDashboardDesignerFreeSlot(
      input.existingPanels,
      fallbackSize,
      columns
    ),
    w: fallbackSize.w,
    h: fallbackSize.h,
  }
}

function mergeDefaultGrid(
  input: Pick<DashboardDesignerPanelCreateInput, 'definition' | 'variant'>
): Partial<DashboardGridPosition> {
  return {
    ...(input.definition.defaultGrid ?? {}),
    ...(input.variant?.defaultGrid ?? {}),
  }
}

function overlaps(a: DashboardGridPosition, b: DashboardGridPosition): boolean {
  return (
    a.x < b.x + b.w && b.x < a.x + a.w && a.y < b.y + b.h && b.y < a.y + a.h
  )
}

function nextDashboardPanelY(panels: readonly DashboardPanel[]): number {
  return panels.reduce(
    (nextY, panel) => Math.max(nextY, panel.gridPos.y + panel.gridPos.h),
    0
  )
}

function stripProtectedFields(
  panel: DashboardWidgetDefaultPanel
): DashboardWidgetDefaultPanel {
  const {
    id: _stripId,
    widget: _stripWidget,
    variant: _stripVariant,
    gridPos: _stripGridPos,
    ...rest
  } = panel as DashboardWidgetDefaultPanel & Partial<DashboardPanel>

  return rest
}

function slugifyPanelIdPart(value: string): string {
  const slug = value
    .trim()
    .toLocaleLowerCase()
    .replace(/[^a-z0-9_-]+/g, '-')
    .replace(/^-+|-+$/g, '')

  return slug || 'widget'
}

function validateDesignerKey(value: string, path: string, label: string) {
  if (typeof value !== 'string' || value.trim().length === 0) {
    return [
      {
        severity: 'error' as const,
        code: 'invalid_widget',
        message: `${label} key must be a non-empty string.`,
        path,
        source: 'designer' as const,
      },
    ]
  }

  if (isDashboardImportLikeWidgetKey(value)) {
    return [
      {
        severity: 'error' as const,
        code: 'import_like_widget',
        message: `${label} key must be stable data, not a path, URL, glob, or import expression.`,
        path,
        widget: value,
        source: 'designer' as const,
        suggestion: 'Use a stable key such as "chart" or "risk-score".',
      },
    ]
  }

  return []
}
