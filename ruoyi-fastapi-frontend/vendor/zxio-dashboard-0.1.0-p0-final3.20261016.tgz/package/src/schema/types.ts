import type { DASHBOARD_SCHEMA_VERSION } from './constants'

export type DashboardJsonPrimitive = string | number | boolean | null

export type DashboardJsonValue =
  | DashboardJsonPrimitive
  | DashboardJsonObject
  | DashboardJsonValue[]

export interface DashboardJsonObject {
  [key: string]: DashboardJsonValue
}

export interface DashboardDocument {
  schemaVersion: typeof DASHBOARD_SCHEMA_VERSION
  uid?: string
  title?: string
  description?: string
  panels: DashboardPanel[]
  pluginVersions?: Record<string, string>
  references?: DashboardReference[]
  meta?: DashboardJsonObject
}

export interface DashboardPanel {
  id: string
  widget: string
  variant?: string
  title?: string
  description?: string
  gridPos: DashboardGridPosition
  params?: DashboardJsonObject
  data?: DashboardJsonValue
  metadata?: DashboardJsonObject
  references?: string[]
}

export interface DashboardGridPosition {
  x: number
  y: number
  w: number
  h: number
}

export interface DashboardReference {
  id: string
  type: string
  name: string
  target?: string | DashboardJsonObject
  metadata?: DashboardJsonObject
}
