export const DASHBOARD_SCHEMA_VERSION = 1 as const

export const DASHBOARD_SCHEMA_TOP_LEVEL_FIELDS = [
  'schemaVersion',
  'uid',
  'title',
  'description',
  'panels',
  'pluginVersions',
  'references',
  'meta',
] as const

export const DASHBOARD_GRID_POSITION_FIELDS = ['x', 'y', 'w', 'h'] as const

export const DASHBOARD_DANGEROUS_KEYS = [
  '__proto__',
  'prototype',
  'constructor',
] as const
