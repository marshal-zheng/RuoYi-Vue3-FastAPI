import { cloneDashboardJson } from '../schema'
import {
  hasBlockingDashboardIssues,
  validateDashboardDocument,
} from '../validation'

import type { DashboardDocument } from '../schema'
import type { DashboardSchemaIssue } from '../validation'

export interface DashboardExportOptions {
  pretty?: boolean
}

export interface DashboardExportResult {
  document?: DashboardDocument
  json?: string
  issues: DashboardSchemaIssue[]
}

export function exportDashboardDocument(
  document: DashboardDocument,
  options: DashboardExportOptions = {}
): DashboardExportResult {
  const validation = validateDashboardDocument(document, { phase: 'export' })

  if (hasBlockingDashboardIssues(validation.issues)) {
    return {
      issues: validation.issues,
    }
  }

  try {
    const exported = cloneDashboardJson(document)
    return {
      document: exported,
      json: JSON.stringify(exported, null, options.pretty ? 2 : 0),
      issues: validation.issues,
    }
  } catch {
    return {
      issues: [
        ...validation.issues,
        {
          severity: 'error',
          code: 'non_serializable_value',
          message: 'Dashboard document could not be serialized to JSON.',
          path: '',
        },
      ],
    }
  }
}
