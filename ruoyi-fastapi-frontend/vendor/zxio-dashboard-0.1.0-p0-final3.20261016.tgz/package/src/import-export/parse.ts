import {
  DASHBOARD_SCHEMA_VERSION,
  cloneDashboardJson,
  isDashboardPlainObject,
} from '../schema'
import {
  hasBlockingDashboardIssues,
  validateDashboardDocument,
} from '../validation'
import { migrateDashboardDocument } from '../migration'

import type { DashboardDocument, DashboardJsonObject } from '../schema'
import type {
  DashboardSchemaIssue,
  DashboardValidationOptions,
} from '../validation'
import type {
  DashboardMigrationOptions,
  DashboardMigrationReport,
} from '../migration'

export interface DashboardImportOptions
  extends DashboardValidationOptions,
    DashboardMigrationOptions {
  migrate?: boolean
}

export interface DashboardImportResult {
  document?: DashboardDocument
  issues: DashboardSchemaIssue[]
  migration?: DashboardMigrationReport
}

export function parseDashboardDocument(
  input: string | unknown,
  options: DashboardImportOptions = {}
): DashboardImportResult {
  const currentSchemaVersion =
    options.currentSchemaVersion ?? DASHBOARD_SCHEMA_VERSION
  const parsed = parseDashboardInput(input)

  if (parsed.issues.length > 0) {
    return {
      issues: parsed.issues,
    }
  }

  const documentInput = parsed.value
  const versionIssue = getImportVersionIssue(
    documentInput,
    currentSchemaVersion
  )
  if (versionIssue) {
    return {
      issues: [versionIssue],
    }
  }

  const schemaVersion = (documentInput as DashboardJsonObject).schemaVersion
  if (
    typeof schemaVersion === 'number' &&
    schemaVersion < currentSchemaVersion
  ) {
    if (options.migrate === false) {
      return {
        issues: [
          {
            severity: 'error',
            code: 'migration_required',
            message: `schemaVersion ${schemaVersion} must be migrated to ${currentSchemaVersion}.`,
            path: '/schemaVersion',
            migratable: true,
            suggestion: 'Run parseDashboardDocument() with migrate enabled.',
          },
        ],
      }
    }

    const migration = migrateDashboardDocument(documentInput, options)
    if (!migration.document) {
      return {
        issues: migration.issues,
        migration: migration.report,
      }
    }

    const migratedValidation = validateDashboardDocument(migration.document, {
      ...options,
      phase: 'import',
      currentSchemaVersion,
    })

    return {
      document: migratedValidation.valid ? migration.document : undefined,
      issues: mergeIssues(migration.issues, migratedValidation.issues),
      migration: migration.report,
    }
  }

  const validation = validateDashboardDocument(documentInput, {
    ...options,
    phase: 'import',
    currentSchemaVersion,
  })

  if (hasBlockingDashboardIssues(validation.issues)) {
    return {
      issues: validation.issues,
    }
  }

  return {
    document: cloneDashboardJson(
      documentInput as DashboardJsonObject
    ) as unknown as DashboardDocument,
    issues: validation.issues,
  }
}

function parseDashboardInput(input: string | unknown): {
  value?: unknown
  issues: DashboardSchemaIssue[]
} {
  if (typeof input !== 'string') {
    return {
      value: input,
      issues: [],
    }
  }

  try {
    return {
      value: JSON.parse(input),
      issues: [],
    }
  } catch {
    return {
      issues: [
        {
          severity: 'error',
          code: 'invalid_document',
          message: 'Dashboard import only supports valid JSON strings.',
          path: '',
        },
      ],
    }
  }
}

function getImportVersionIssue(
  input: unknown,
  currentSchemaVersion: number
): DashboardSchemaIssue | undefined {
  if (!isDashboardPlainObject(input)) return undefined

  const schemaVersion = input.schemaVersion
  if (!Number.isInteger(schemaVersion) || (schemaVersion as number) <= 0) {
    return {
      severity: 'error',
      code: 'unsupported_schema_version',
      message: 'schemaVersion must be a positive integer.',
      path: '/schemaVersion',
    }
  }

  if ((schemaVersion as number) > currentSchemaVersion) {
    return {
      severity: 'error',
      code: 'unsupported_schema_version',
      message: `schemaVersion ${String(
        schemaVersion
      )} is newer than supported version ${currentSchemaVersion}.`,
      path: '/schemaVersion',
    }
  }

  return undefined
}

function mergeIssues(
  first: DashboardSchemaIssue[],
  second: DashboardSchemaIssue[]
): DashboardSchemaIssue[] {
  const seen = new Set<string>()
  const result: DashboardSchemaIssue[] = []

  for (const issue of [...first, ...second]) {
    const key = `${issue.severity}:${issue.code}:${issue.path}:${issue.message}`
    if (!seen.has(key)) {
      seen.add(key)
      result.push(issue)
    }
  }

  return result
}
