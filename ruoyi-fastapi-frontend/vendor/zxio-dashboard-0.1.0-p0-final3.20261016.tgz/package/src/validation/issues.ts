export type DashboardIssueSeverity = 'error' | 'warn' | 'info'

export type DashboardIssueCode =
  | 'invalid_document'
  | 'invalid_schema_version'
  | 'unsupported_schema_version'
  | 'migration_required'
  | 'non_serializable_value'
  | 'dangerous_key'
  | 'unknown_top_level_field'
  | 'unknown_panel_field'
  | 'missing_panel_id'
  | 'invalid_panel_id'
  | 'duplicate_panel_id'
  | 'missing_widget'
  | 'invalid_widget'
  | 'import_like_widget'
  | 'invalid_grid_position'
  | 'invalid_plugin_versions'
  | 'duplicate_reference_id'
  | 'missing_reference'
  | 'invalid_reference'
  | 'unresolved_widget'
  | 'missing_widget_version'
  | 'invalid_migration_step'
  | 'legacy_gridcom_invalid_snapshot'
  | 'legacy_gridcom_id_rewritten'
  | 'legacy_gridcom_widget_from_type'
  | 'legacy_gridcom_metadata_data_migrated'
  | 'legacy_gridcom_metadata_data_unparsed'
  | 'legacy_gridcom_runtime_field_stripped'
  | 'legacy_gridcom_default_grid_used'

export interface DashboardSchemaIssue {
  severity: DashboardIssueSeverity
  code: DashboardIssueCode | string
  message: string
  path: string
  suggestion?: string
  migratable?: boolean
}

export function createDashboardIssue(
  issue: DashboardSchemaIssue
): DashboardSchemaIssue {
  return issue
}

export function hasBlockingDashboardIssues(
  issues: readonly DashboardSchemaIssue[]
): boolean {
  return issues.some((issue) => issue.severity === 'error')
}
