import {
  DASHBOARD_SCHEMA_TOP_LEVEL_FIELDS,
  DASHBOARD_SCHEMA_VERSION,
  collectDashboardJsonIssues,
  isDashboardImportLikeWidgetKey,
  isDashboardPlainObject,
  joinDashboardJsonPointer,
  validateDashboardGridPositionInput,
} from '../schema'
import { hasBlockingDashboardIssues } from './issues'

import type { DashboardSchemaIssue } from './issues'

export type DashboardValidationPhase = 'authoring' | 'import' | 'export'

export interface DashboardValidationOptions {
  phase?: DashboardValidationPhase
  currentSchemaVersion?: number
  knownWidgets?: Iterable<string>
}

export interface DashboardValidationResult {
  valid: boolean
  issues: DashboardSchemaIssue[]
}

const allowedTopLevelFields = new Set<string>(DASHBOARD_SCHEMA_TOP_LEVEL_FIELDS)
const allowedPanelFields = new Set([
  'id',
  'widget',
  'variant',
  'title',
  'description',
  'gridPos',
  'params',
  'data',
  'metadata',
  'references',
])

export function validateDashboardDocument(
  input: unknown,
  options: DashboardValidationOptions = {}
): DashboardValidationResult {
  const phase = options.phase ?? 'authoring'
  const currentSchemaVersion =
    options.currentSchemaVersion ?? DASHBOARD_SCHEMA_VERSION
  const issues: DashboardSchemaIssue[] = [
    ...collectDashboardJsonIssues(input, '', { phase }),
  ]

  if (!isDashboardPlainObject(input)) {
    issues.push({
      severity: 'error',
      code: 'invalid_document',
      message: 'Dashboard document must be a plain JSON object.',
      path: '',
    })
    return {
      valid: false,
      issues,
    }
  }

  validateTopLevelFields(input, issues)
  validateOptionalString(input, 'uid', issues)
  validateOptionalString(input, 'title', issues)
  validateOptionalString(input, 'description', issues)

  validateSchemaVersion(input.schemaVersion, currentSchemaVersion, issues)

  const referenceIds = validateReferences(input.references, issues)
  const panelWidgets = validatePanels(
    input.panels,
    referenceIds,
    options,
    issues
  )
  validatePluginVersions(input.pluginVersions, panelWidgets, issues)

  if (input.meta !== undefined && !isDashboardPlainObject(input.meta)) {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message: 'meta must be a JSON object when provided.',
      path: '/meta',
    })
  }

  return {
    valid: !hasBlockingDashboardIssues(issues),
    issues,
  }
}

function validateTopLevelFields(
  input: Record<string, unknown>,
  issues: DashboardSchemaIssue[]
): void {
  for (const key of Object.keys(input)) {
    if (!allowedTopLevelFields.has(key)) {
      issues.push({
        severity: 'error',
        code: 'unknown_top_level_field',
        message: `Unknown dashboard document field "${key}".`,
        path: joinDashboardJsonPointer('', key),
        suggestion:
          'Move extension data into meta or a documented extension field.',
      })
    }
  }
}

function validateSchemaVersion(
  schemaVersion: unknown,
  currentSchemaVersion: number,
  issues: DashboardSchemaIssue[]
): void {
  if (!Number.isInteger(currentSchemaVersion) || currentSchemaVersion <= 0) {
    issues.push({
      severity: 'error',
      code: 'invalid_schema_version',
      message: 'currentSchemaVersion must be a positive integer.',
      path: '/schemaVersion',
    })
    return
  }

  if (!Number.isInteger(schemaVersion) || (schemaVersion as number) <= 0) {
    issues.push({
      severity: 'error',
      code: 'invalid_schema_version',
      message: 'schemaVersion must be a positive integer.',
      path: '/schemaVersion',
    })
    return
  }

  if ((schemaVersion as number) > currentSchemaVersion) {
    issues.push({
      severity: 'error',
      code: 'unsupported_schema_version',
      message: `schemaVersion ${String(
        schemaVersion
      )} is newer than supported version ${currentSchemaVersion}.`,
      path: '/schemaVersion',
    })
  }

  if ((schemaVersion as number) < currentSchemaVersion) {
    issues.push({
      severity: 'error',
      code: 'migration_required',
      message: `schemaVersion ${String(
        schemaVersion
      )} must be migrated to ${currentSchemaVersion}.`,
      path: '/schemaVersion',
      migratable: true,
      suggestion: 'Run migrateDashboardDocument() before using this document.',
    })
  }
}

function validatePanels(
  panels: unknown,
  referenceIds: Set<string>,
  options: DashboardValidationOptions,
  issues: DashboardSchemaIssue[]
): string[] {
  if (!Array.isArray(panels)) {
    issues.push({
      severity: 'error',
      code: 'invalid_document',
      message: 'Dashboard document must include a panels array.',
      path: '/panels',
    })
    return []
  }

  const panelIds = new Map<string, string>()
  const widgets: string[] = []
  const knownWidgets =
    options.knownWidgets === undefined
      ? undefined
      : new Set(Array.from(options.knownWidgets))

  panels.forEach((panel, index) => {
    const panelPath = joinDashboardJsonPointer('/panels', index)
    if (!isDashboardPlainObject(panel)) {
      issues.push({
        severity: 'error',
        code: 'invalid_document',
        message: 'Panel must be a plain JSON object.',
        path: panelPath,
      })
      return
    }

    for (const key of Object.keys(panel)) {
      if (!allowedPanelFields.has(key)) {
        issues.push({
          severity: 'error',
          code: 'unknown_panel_field',
          message: `Unknown panel field "${key}" is not part of the dashboard schema.`,
          path: joinDashboardJsonPointer(panelPath, key),
          suggestion: 'Move host or plugin extension data into panel.metadata.',
        })
      }
    }

    const id = panel.id
    if (id === undefined) {
      issues.push({
        severity: 'error',
        code: 'missing_panel_id',
        message: 'Panel id is required.',
        path: `${panelPath}/id`,
      })
    } else if (typeof id !== 'string' || id.trim().length === 0) {
      issues.push({
        severity: 'error',
        code: 'invalid_panel_id',
        message: 'Panel id must be a non-empty string.',
        path: `${panelPath}/id`,
      })
    } else {
      const previousPath = panelIds.get(id)
      if (previousPath) {
        issues.push({
          severity: 'error',
          code: 'duplicate_panel_id',
          message: `Panel id "${id}" is already used.`,
          path: `${panelPath}/id`,
          suggestion: `First occurrence is ${previousPath}.`,
        })
      } else {
        panelIds.set(id, `${panelPath}/id`)
      }
    }

    const widget = panel.widget
    if (widget === undefined) {
      issues.push({
        severity: 'error',
        code: 'missing_widget',
        message: 'Panel widget is required.',
        path: `${panelPath}/widget`,
      })
    } else if (typeof widget !== 'string' || widget.trim().length === 0) {
      issues.push({
        severity: 'error',
        code: 'invalid_widget',
        message: 'Panel widget must be a non-empty string.',
        path: `${panelPath}/widget`,
      })
    } else if (isDashboardImportLikeWidgetKey(widget)) {
      issues.push({
        severity: 'error',
        code: 'import_like_widget',
        message:
          'Panel widget must be a stable widget key, not a path, URL, glob, or import expression.',
        path: `${panelPath}/widget`,
        suggestion:
          'Use a registry widget key such as "chart" or "risk-score".',
      })
    } else {
      widgets.push(widget)
      if (knownWidgets && !knownWidgets.has(widget)) {
        issues.push({
          severity: 'warn',
          code: 'unresolved_widget',
          message: `Widget "${widget}" is not registered in the current host.`,
          path: `${panelPath}/widget`,
          suggestion:
            'Keep the panel data and resolve the widget through the dashboard registry.',
        })
      }
    }

    issues.push(
      ...validateDashboardGridPositionInput(
        panel.gridPos,
        `${panelPath}/gridPos`
      ).issues
    )

    validateOptionalString(panel, 'variant', issues, panelPath)
    validateOptionalString(panel, 'title', issues, panelPath)
    validateOptionalString(panel, 'description', issues, panelPath)
    validateJsonObjectField(panel, 'params', issues, panelPath)
    validateJsonObjectField(panel, 'metadata', issues, panelPath)

    if (panel.references !== undefined) {
      if (!Array.isArray(panel.references)) {
        issues.push({
          severity: 'error',
          code: 'invalid_reference',
          message: 'panel.references must be an array of reference ids.',
          path: `${panelPath}/references`,
        })
      } else {
        panel.references.forEach((referenceId, referenceIndex) => {
          const referencePath = `${panelPath}/references/${referenceIndex}`
          if (
            typeof referenceId !== 'string' ||
            referenceId.trim().length === 0
          ) {
            issues.push({
              severity: 'error',
              code: 'invalid_reference',
              message: 'panel.references entries must be non-empty strings.',
              path: referencePath,
            })
            return
          }

          if (!referenceIds.has(referenceId)) {
            issues.push({
              severity: 'error',
              code: 'missing_reference',
              message: `Reference "${referenceId}" is not declared in document references.`,
              path: referencePath,
            })
          }
        })
      }
    }
  })

  return widgets
}

function validateReferences(
  references: unknown,
  issues: DashboardSchemaIssue[]
): Set<string> {
  const referenceIds = new Set<string>()

  if (references === undefined) return referenceIds

  if (!Array.isArray(references)) {
    issues.push({
      severity: 'error',
      code: 'invalid_reference',
      message: 'references must be an array when provided.',
      path: '/references',
    })
    return referenceIds
  }

  references.forEach((reference, index) => {
    const referencePath = joinDashboardJsonPointer('/references', index)
    if (!isDashboardPlainObject(reference)) {
      issues.push({
        severity: 'error',
        code: 'invalid_reference',
        message: 'Reference must be a plain JSON object.',
        path: referencePath,
      })
      return
    }

    const id = reference.id
    if (typeof id !== 'string' || id.trim().length === 0) {
      issues.push({
        severity: 'error',
        code: 'invalid_reference',
        message: 'Reference id must be a non-empty string.',
        path: `${referencePath}/id`,
      })
    } else if (referenceIds.has(id)) {
      issues.push({
        severity: 'error',
        code: 'duplicate_reference_id',
        message: `Reference id "${id}" is already used.`,
        path: `${referencePath}/id`,
      })
    } else {
      referenceIds.add(id)
    }

    if (
      typeof reference.type !== 'string' ||
      reference.type.trim().length === 0
    ) {
      issues.push({
        severity: 'error',
        code: 'invalid_reference',
        message: 'Reference type must be a non-empty string.',
        path: `${referencePath}/type`,
      })
    }

    if (
      typeof reference.name !== 'string' ||
      reference.name.trim().length === 0
    ) {
      issues.push({
        severity: 'error',
        code: 'invalid_reference',
        message: 'Reference name must be a non-empty string.',
        path: `${referencePath}/name`,
      })
    }

    if (
      reference.target !== undefined &&
      typeof reference.target !== 'string' &&
      !isDashboardPlainObject(reference.target)
    ) {
      issues.push({
        severity: 'error',
        code: 'invalid_reference',
        message: 'Reference target must be a string or JSON object.',
        path: `${referencePath}/target`,
      })
    }

    validateJsonObjectField(reference, 'metadata', issues, referencePath)
  })

  return referenceIds
}

function validatePluginVersions(
  pluginVersions: unknown,
  widgets: string[],
  issues: DashboardSchemaIssue[]
): void {
  const uniqueWidgets = Array.from(new Set(widgets))

  if (pluginVersions !== undefined && !isDashboardPlainObject(pluginVersions)) {
    issues.push({
      severity: 'error',
      code: 'invalid_plugin_versions',
      message:
        'pluginVersions must be an object mapping widget keys to versions.',
      path: '/pluginVersions',
    })
    return
  }

  if (isDashboardPlainObject(pluginVersions)) {
    for (const [key, value] of Object.entries(pluginVersions)) {
      if (typeof value !== 'string' || value.trim().length === 0) {
        issues.push({
          severity: 'error',
          code: 'invalid_plugin_versions',
          message: 'pluginVersions values must be non-empty version strings.',
          path: `/pluginVersions/${escapeJsonPointerSegment(key)}`,
        })
      }
    }
  }

  for (const widget of uniqueWidgets) {
    if (
      !isDashboardPlainObject(pluginVersions) ||
      typeof pluginVersions[widget] !== 'string' ||
      pluginVersions[widget].trim().length === 0
    ) {
      issues.push({
        severity: 'warn',
        code: 'missing_widget_version',
        message: `pluginVersions is missing a version for widget "${widget}".`,
        path: '/pluginVersions',
        migratable: true,
        suggestion: `Add pluginVersions["${widget}"] before relying on widget migration.`,
      })
    }
  }
}

function validateOptionalString(
  input: Record<string, unknown>,
  field: string,
  issues: DashboardSchemaIssue[],
  basePath = ''
): void {
  const value = input[field]
  if (value !== undefined && typeof value !== 'string') {
    issues.push({
      severity: 'error',
      code: 'invalid_document',
      message: `${field} must be a string when provided.`,
      path: joinDashboardJsonPointer(basePath, field),
    })
  }
}

function validateJsonObjectField(
  input: Record<string, unknown>,
  field: string,
  issues: DashboardSchemaIssue[],
  basePath = ''
): void {
  const value = input[field]
  if (value !== undefined && !isDashboardPlainObject(value)) {
    issues.push({
      severity: 'error',
      code: 'non_serializable_value',
      message: `${field} must be a JSON object when provided.`,
      path: joinDashboardJsonPointer(basePath, field),
    })
  }
}

function escapeJsonPointerSegment(segment: string): string {
  return segment.replace(/~/g, '~0').replace(/\//g, '~1')
}
