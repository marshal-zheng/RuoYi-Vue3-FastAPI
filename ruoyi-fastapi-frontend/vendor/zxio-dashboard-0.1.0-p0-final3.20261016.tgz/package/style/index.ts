import '@zxio/vue-grid-layout/style.css'
import './dashboard.scss'
