import { ArrayKey } from './formily/types';
import { FieldPath } from './fields/types';
type Identity = {
    index: number;
    key?: string;
    value?: string | number;
    snapshot?: unknown;
    unsafe?: true;
};
export type AnchoredPath = readonly (string | Identity)[];
export declare function validPath(path: unknown): path is FieldPath;
export declare function readPath(value: unknown, path: FieldPath): unknown;
export declare function anchorPath(path: FieldPath, submitted: unknown, keys: readonly ArrayKey[]): AnchoredPath;
export declare function resolvePath(anchor: AnchoredPath, current: unknown): {
    path?: FieldPath;
    deleted?: true;
};
/** Native array graph moves can stringify indices. Object keys remain strings. */
export declare function dataPath(path: readonly (string | number)[], values: unknown): FieldPath;
export {};
