import { Field } from '@formily/core';
import { ArrayKey, FieldIssue } from './formily/types';
/** Errors are authoritative here. Native feedback is only a disposable projection. */
export declare function createErrorLedger(ports: {
    read(): object;
    fields(): readonly Field[];
    visible(field: Field): boolean;
    composite(field: Field): boolean;
    active(field: Field): boolean;
    version(): number;
    changed(): void;
}, keys: readonly ArrayKey[]): {
    messages: (field: Field) => FieldIssue[];
    formIssues: import('vue').ComputedRef<FieldIssue[]>;
    project: () => void;
    set: (code: string, issues: readonly FieldIssue[], submitted?: object) => void;
    changed: () => void;
    clear: () => void;
    clearValidation(identity: string): void;
    clearField(field: Field): void;
};
