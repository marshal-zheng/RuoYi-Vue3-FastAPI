type Value = string | number | boolean;
interface Option {
    label: string;
    value: Value;
    disabled?: boolean;
}
type __VLS_Props = {
    modelValue?: Value;
    options?: Option[] | (() => Option[]);
    disabled?: boolean;
    readonly?: boolean;
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus(): void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
    "update:modelValue": (value: Value | undefined) => void;
    blur: (event: FocusEvent) => void;
    focus: (event: FocusEvent) => void;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((event: FocusEvent) => any) | undefined;
    onFocus?: ((event: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: Value | undefined) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    group: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: {
            readonly id?: string | undefined;
            readonly size?: import('element-plus').ComponentSize | undefined;
            readonly disabled?: boolean | undefined;
            readonly modelValue?: (string | number | boolean) | undefined;
            readonly fill?: string | undefined;
            readonly textColor?: string | undefined;
            readonly name?: string | undefined;
            readonly validateEvent?: boolean | undefined;
            readonly options?: import('element-plus').radioOption[] | undefined;
            readonly props?: import('element-plus').radioOptionProp | undefined;
            readonly type?: ("radio" | "button") | undefined;
            readonly ariaLabel?: string | undefined;
            readonly "onUpdate:modelValue"?: ((val: string | number | boolean | undefined) => any) | undefined;
            readonly onChange?: ((val: string | number | boolean | undefined) => any) | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps;
        $attrs: import('vue').Attrs;
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: import('vue').ComponentPublicInstance | null;
        $parent: import('vue').ComponentPublicInstance | null;
        $host: Element | null;
        $emit: ((event: "change", val: string | number | boolean | undefined) => void) & ((event: "update:modelValue", val: string | number | boolean | undefined) => void);
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<import('element-plus').RadioGroupProps> & Readonly<{
            "onUpdate:modelValue"?: ((val: string | number | boolean | undefined) => any) | undefined;
            onChange?: ((val: string | number | boolean | undefined) => any) | undefined;
        }>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {
            "update:modelValue": (val: string | number | boolean | undefined) => void;
            change: (val: string | number | boolean | undefined) => void;
        }, string, {
            fill: string;
            type: "radio" | "button";
            props: import('element-plus').radioOptionProp;
            id: string;
            disabled: boolean;
            name: string;
            modelValue: string | number | boolean;
            textColor: string;
            validateEvent: boolean;
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: import('vue').ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import('vue').nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        fill: string;
        type: "radio" | "button";
        props: import('element-plus').radioOptionProp;
        id: string;
        disabled: boolean;
        name: string;
        modelValue: string | number | boolean;
        textColor: string;
        validateEvent: boolean;
    }> & Omit<Readonly<import('element-plus').RadioGroupProps> & Readonly<{
        "onUpdate:modelValue"?: ((val: string | number | boolean | undefined) => any) | undefined;
        onChange?: ((val: string | number | boolean | undefined) => any) | undefined;
    }>, "name" | "fill" | "props" | "type" | "id" | "disabled" | "modelValue" | "validateEvent" | "textColor"> & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: {
            default?: (props: {}) => any;
        };
    }) | null;
}, any>;
export default _default;
