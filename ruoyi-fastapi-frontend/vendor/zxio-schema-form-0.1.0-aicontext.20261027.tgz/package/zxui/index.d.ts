import { Bindings } from '../types';
import { DefinitionPolicy } from '../formily/types';
/** Trusted code registration; JSON admission is an explicit separate policy. */
export declare function createZxuiBindings(): Bindings;
export declare function createZxuiDefinitionPolicy(): DefinitionPolicy;
