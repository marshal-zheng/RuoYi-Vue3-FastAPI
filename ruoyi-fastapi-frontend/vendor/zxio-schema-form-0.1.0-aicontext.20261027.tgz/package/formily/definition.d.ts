import { Definition, DefinitionPolicy } from './types';
/** Pure JSON admission. Never passes untrusted expressions to Formily's compiler. */
export declare function parseDefinition(text: string, policy: DefinitionPolicy): Definition;
