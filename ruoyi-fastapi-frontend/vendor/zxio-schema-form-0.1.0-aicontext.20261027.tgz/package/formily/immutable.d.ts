/** Copy configuration without executing or serializing trusted validator functions. */
export declare function cloneConfig<T>(input: T): T;
/** Unlike Object.freeze, reports writes even from non-strict callers. */
export declare function immutable<T>(input: T, fail: (message: string) => void): T;
