import { Json } from '../types';
import { ConditionalLimits, ReadGrant, SafeValue, ValueShape } from './conditional-types';
export declare const limits: Readonly<ConditionalLimits>;
export declare class ConditionalError extends Error {
    readonly code: string;
    constructor(code: string);
}
export declare const reject: (code: string) => never;
export declare const safeKey: (key: string) => boolean;
export declare const bytes: (value: unknown) => number;
export declare function freeze<T>(value: T): T;
/** Descriptor reads precede value reads. Never invokes accessors/toJSON. */
export declare function jsonCopy(value: unknown, budget?: number): Json;
export declare function project(value: Json, grant: ReadGrant): Json | undefined;
export declare function visibleValue(present: boolean, value: Json | undefined, grant: ReadGrant): SafeValue | undefined;
export declare function matches(value: Json, shape: ValueShape): boolean;
export declare function validShape(shape: ValueShape): boolean;
export declare function validGrant(grant: ReadGrant): boolean;
