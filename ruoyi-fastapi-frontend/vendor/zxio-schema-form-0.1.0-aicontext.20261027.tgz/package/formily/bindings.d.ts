import { Component } from 'vue';
import { Bindings } from '../types';
import { FormRuntime } from './runtime';
/** Owns exactly one canonical write. Native SchemaField callbacks are consumed. */
export declare function createBindings(runtime: FormRuntime, bindings: Bindings, disabled?: () => boolean): Record<string, Component>;
