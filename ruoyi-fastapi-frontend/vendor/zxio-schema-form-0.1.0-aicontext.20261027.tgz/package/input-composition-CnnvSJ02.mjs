import { defineComponent, useId, inject, computed, createBlock, openBlock, resolveDynamicComponent, mergeProps, withCtx, createElementBlock, createCommentVNode, createVNode, createTextVNode, toDisplayString, unref, normalizeClass, createSlots, createElementVNode, renderSlot, Fragment, renderList, shallowRef } from "vue";
import { ElFormItem } from "element-plus";
const fieldLayoutKey = Symbol("schema-field-layout");
const _hoisted_1 = ["id"];
const _hoisted_2 = {
  key: 0,
  "aria-hidden": "true",
  class: "zx-schema-field__required"
};
const _hoisted_3 = ["id"];
const _hoisted_4 = { class: "zx-schema-field__control" };
const _hoisted_5 = ["id"];
const _hoisted_6 = ["id"];
const _hoisted_7 = ["data-severity"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{ name: "ZxField", inheritAttrs: false },
  __name: "Field",
  props: {
    label: {},
    description: {},
    required: { type: Boolean },
    group: { type: Boolean },
    messages: {},
    invalid: { type: Boolean },
    reserveFeedback: { type: Boolean, default: true }
  },
  setup(__props) {
    const props = __props;
    const id = `zx-field-${useId()}`;
    const layout = inject(fieldLayoutKey, void 0);
    const controlProps = computed(() => {
      var _a, _b;
      return {
        id,
        "aria-required": !props.group && props.required || void 0,
        "aria-labelledby": props.label ? `${id}-label` : void 0,
        "aria-invalid": props.invalid || ((_a = props.messages) == null ? void 0 : _a.some((item) => item.severity === "error")) || void 0,
        "aria-describedby": [
          props.description ? `${id}-help` : "",
          ((_b = props.messages) == null ? void 0 : _b.length) ? `${id}-messages` : ""
        ].filter(Boolean).join(" ") || void 0
      };
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(resolveDynamicComponent(__props.group ? "fieldset" : "div"), mergeProps(_ctx.$attrs, { class: "zx-schema-field" }), {
        default: withCtx(() => {
          var _a, _b, _c, _d;
          return [
            __props.group ? (openBlock(), createElementBlock("legend", {
              key: 0,
              id: `${id}-label`,
              class: "zx-schema-field__label"
            }, [
              createTextVNode(toDisplayString(__props.label), 1),
              __props.required ? (openBlock(), createElementBlock("span", _hoisted_2, " *")) : createCommentVNode("", true)
            ], 8, _hoisted_1)) : createCommentVNode("", true),
            createVNode(unref(ElFormItem), {
              label: __props.group ? void 0 : __props.label,
              for: __props.group ? void 0 : id,
              "label-position": __props.group ? "top" : ((_a = unref(layout)) == null ? void 0 : _a.labelPosition) ?? "top",
              "label-width": __props.group ? void 0 : (_b = unref(layout)) == null ? void 0 : _b.labelWidth,
              required: !__props.group && __props.required,
              error: (_d = (_c = __props.messages) == null ? void 0 : _c.find((item) => item.severity === "error")) == null ? void 0 : _d.message,
              "show-message": false,
              class: normalizeClass({
                "zx-schema-field--own-feedback": !__props.reserveFeedback,
                "is-error": __props.invalid
              })
            }, createSlots({
              default: withCtx(() => {
                var _a2;
                return [
                  createElementVNode("div", _hoisted_4, [
                    renderSlot(_ctx.$slots, "default", { controlProps: controlProps.value })
                  ]),
                  __props.description ? (openBlock(), createElementBlock("small", {
                    key: 0,
                    id: `${id}-help`,
                    class: "zx-schema-field__help"
                  }, toDisplayString(__props.description), 9, _hoisted_5)) : createCommentVNode("", true),
                  ((_a2 = __props.messages) == null ? void 0 : _a2.length) ? (openBlock(), createElementBlock("ul", {
                    key: 1,
                    id: `${id}-messages`,
                    class: "el-form-item__error zx-schema-field__messages",
                    "aria-live": "polite"
                  }, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(__props.messages, (item, index) => {
                      return openBlock(), createElementBlock("li", {
                        key: index,
                        "data-severity": item.severity
                      }, toDisplayString(item.message), 9, _hoisted_7);
                    }), 128))
                  ], 8, _hoisted_6)) : createCommentVNode("", true)
                ];
              }),
              _: 2
            }, [
              !__props.group ? {
                name: "label",
                fn: withCtx(() => [
                  createElementVNode("span", {
                    id: `${id}-label`,
                    class: "zx-schema-field__label"
                  }, toDisplayString(__props.label), 9, _hoisted_3)
                ]),
                key: "0"
              } : void 0
            ]), 1032, ["label", "for", "label-position", "label-width", "required", "error", "class"])
          ];
        }),
        _: 3
      }, 16);
    };
  }
});
function parseNumberText(text) {
  const value = text.trim();
  if (!value) return { status: "empty" };
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(value))
    return { status: "invalid" };
  const number = Number(value);
  return Number.isFinite(number) ? { status: "valid", value: number } : { status: "invalid" };
}
function useInputComposition() {
  const pending = shallowRef(/* @__PURE__ */ new Set());
  let active;
  const has = (key = "value") => pending.value.has(key);
  function observe(event, key = "value") {
    const next = new Set(pending.value);
    if (event.type === "compositionstart" || event.type === "input" && event.isComposing === true) {
      active = { key, target: event.target };
      next.add(key);
    } else if (event.type === "compositionend") {
      if ((active == null ? void 0 : active.key) === key && active.target === event.target) {
        active = void 0;
        next.delete(key);
      }
    } else if (event.type === "input" && ((active == null ? void 0 : active.key) !== key || active.target !== event.target)) {
      next.delete(key);
    }
    pending.value = next;
  }
  function acceptChange(key = "value") {
    if ((active == null ? void 0 : active.key) === key || !has(key)) return false;
    const next = new Set(pending.value);
    next.delete(key);
    pending.value = next;
    return true;
  }
  function restore(keys) {
    active = void 0;
    pending.value = new Set(
      Array.isArray(keys) ? keys.filter((key) => typeof key === "string") : []
    );
  }
  function prune(keys) {
    const keep = new Set(keys);
    if (active && !keep.has(active.key)) active = void 0;
    const next = new Set([...pending.value].filter((key) => keep.has(key)));
    if (next.size === pending.value.size) return false;
    pending.value = next;
    return true;
  }
  return {
    blocked: computed(() => pending.value.size > 0),
    keys: computed(() => [...pending.value]),
    has,
    observe,
    acceptChange,
    restore,
    prune
  };
}
export {
  _sfc_main as _,
  fieldLayoutKey as f,
  parseNumberText as p,
  useInputComposition as u
};
