import { p as parseNumberText } from "../input-composition-CnnvSJ02.mjs";
import { _, u } from "../input-composition-CnnvSJ02.mjs";
import { defineComponent, shallowRef, createBlock, openBlock, unref, mergeProps } from "vue";
import { ZxInput } from "@zxio/zxui/input";
import { s as safeJson } from "../index-BiqhT_5-.mjs";
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  ...{ name: "ZxNumberTextInput", inheritAttrs: false },
  __name: "NumberTextInput",
  props: {
    text: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean }
  },
  emits: ["edit"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const input = shallowRef();
    function setInput(value) {
      input.value = value;
    }
    function edit(text) {
      emit("edit", { text, badInput: parseNumberText(text).status === "invalid" });
    }
    __expose({ focus: () => {
      var _a;
      return (_a = input.value) == null ? void 0 : _a.focus();
    } });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ZxInput), mergeProps({ ref: setInput }, _ctx.$attrs, {
        type: "text",
        inputmode: "decimal",
        "model-value": __props.text,
        disabled: __props.disabled,
        readonly: __props.readonly,
        "onUpdate:modelValue": edit
      }), null, 16, ["model-value", "disabled", "readonly"]);
    };
  }
});
function parseJsonText(text) {
  if (!text.trim()) return { status: "empty" };
  try {
    const value = JSON.parse(text);
    safeJson(value, "$", false);
    return { status: "valid", value };
  } catch {
    return { status: "invalid" };
  }
}
const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{ name: "ZxJsonTextInput", inheritAttrs: false },
  __name: "JsonTextInput",
  props: {
    text: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean }
  },
  emits: ["edit"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const input = shallowRef();
    function setInput(value) {
      input.value = value;
    }
    function edit(text) {
      emit("edit", { text, badInput: parseJsonText(text).status === "invalid" });
    }
    __expose({ focus: () => {
      var _a;
      return (_a = input.value) == null ? void 0 : _a.focus();
    } });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(ZxInput), mergeProps({ ref: setInput }, _ctx.$attrs, {
        type: "textarea",
        "model-value": __props.text,
        disabled: __props.disabled,
        readonly: __props.readonly,
        "onUpdate:modelValue": edit
      }), null, 16, ["model-value", "disabled", "readonly"]);
    };
  }
});
export {
  _ as ZxField,
  _sfc_main as ZxJsonTextInput,
  _sfc_main$1 as ZxNumberTextInput,
  parseJsonText,
  parseNumberText,
  u as useInputComposition
};
