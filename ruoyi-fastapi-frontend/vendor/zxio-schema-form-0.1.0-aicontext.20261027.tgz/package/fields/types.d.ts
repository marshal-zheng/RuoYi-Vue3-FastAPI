import { Json } from '../types';
/** Data addressing only; interpretation and stable row identity belong to the host. */
export type FieldPath = readonly (string | number)[];
export interface FieldMessage {
    severity: 'error' | 'warning' | 'info';
    message: string;
    /** Relative to the receiving composite field. */
    path?: FieldPath;
}
/** A complete snapshot: omitted pending/blocking mean false/empty in every host. */
export interface FieldEditState {
    /** Monotonic genuine raw edits; report synchronously before canonical updates. */
    editSequence?: number;
    /** Activity indicator. Non-blocking option refreshes may set this alone. */
    pending?: boolean;
    /** Unfinished edits that the host must check at every commit entry point. */
    blocking?: readonly FieldMessage[];
}
export interface FieldControl {
    /** Retained raw draft for temporary hiding; never restore an active DOM IME session. */
    captureEdit?(): Json;
    restoreEdit?(draft: Json): void;
    focus(path?: FieldPath): void;
    /** Commit validation feedback only through the supplied ownership context. */
    validate?(context: FieldValidationContext): boolean | Promise<boolean>;
}
export interface FieldValidationContext {
    readonly signal: AbortSignal;
    /** False after input, replacement, timeout or a newer validation. */
    current(): boolean;
    /** Runs synchronously only while this validation still owns its feedback. */
    commit(update: () => void): boolean;
}
export interface FieldControlAttrs {
    id: string;
    'aria-required'?: true;
    'aria-invalid'?: true;
    'aria-describedby'?: string;
    'aria-labelledby'?: string;
}
export interface NumberTextEdit {
    text: string;
    badInput: boolean;
}
export type ParsedNumberText = {
    status: 'empty';
} | {
    status: 'valid';
    value: number;
} | {
    status: 'invalid';
};
export interface JsonTextEdit {
    text: string;
    badInput: boolean;
}
export type ParsedJsonText = {
    status: 'empty';
} | {
    status: 'valid';
    value: Json;
} | {
    status: 'invalid';
};
