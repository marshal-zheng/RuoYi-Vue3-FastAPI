<script setup lang="ts">
import { ref } from 'vue'
import { ZxSchemaForm } from '@zxio/schema-form/formily'

import type {
  BusinessContext,
  NativeSchema,
  Save,
  SchemaFormInstance,
  SettledCheck,
  Validate,
} from '@zxio/schema-form/formily'

interface LinkedValues {
  region: 'local' | 'remote'
  maxRetries: number
  target: string
  retries: number
}
const props = defineProps<{ initial: LinkedValues; save: Save<LinkedValues> }>()
const form = ref<SchemaFormInstance<LinkedValues>>()
const targetOptions = (region: unknown) =>
  region === 'remote'
    ? [
        { value: 'cloud', label: '云端' },
        { value: 'backup', label: '远程备份' },
      ]
    : [{ value: 'lab', label: '本地实验室' }]
const integer = (value: unknown) =>
  Number.isInteger(value) && Number(value) >= 0 ? '' : '请输入有效重试次数'
const createSchema = (
  context: BusinessContext<LinkedValues>
): NativeSchema => ({
  type: 'object',
  properties: {
    source: {
      type: 'void',
      title: '来源与限制',
      'x-component': 'ZxSection',
      'x-component-props': { 'data-linked-section': 'source' },
      properties: {
        region: {
          type: 'string',
          title: '区域',
          'x-component': 'ZxSelect',
          'x-component-props': {
            'aria-label': '目标区域',
            options: [
              { value: 'local', label: '本地' },
              { value: 'remote', label: '远程' },
            ],
          },
          'x-validator': [
            {
              required: true,
              enum: ['local', 'remote'],
              message: '请选择有效区域',
            },
          ],
        },
        maxRetries: {
          type: 'number',
          title: '允许重试次数',
          'x-component': 'ZxInputNumber',
          'x-component-props': {
            'aria-label': '允许重试次数',
            min: 0,
            precision: 0,
          },
          'x-validator': [{ required: true, validator: integer }],
        },
      },
    },
    delivery: {
      type: 'void',
      title: '提交设置',
      'x-component': 'ZxSection',
      'x-component-props': { 'data-linked-section': 'delivery' },
      properties: {
        target: {
          type: 'string',
          title: '目标',
          'x-component': 'ZxSelect',
          'x-component-props': { 'aria-label': '提交目标' },
          'x-validator': [{ required: true, message: '请选择提交目标' }],
          'x-reactions': (field) => {
            const options = targetOptions(field.form.values.region)
            context.configure(field, {
              dataSource: options,
              componentProps: { 'aria-label': '提交目标', options },
            })
            if (!options.some((option) => option.value === field.value))
              field.form.setValuesIn(field.path, options[0].value)
          },
        },
        retries: {
          type: 'number',
          title: '重试次数',
          'x-component': 'ZxInputNumber',
          'x-component-props': {
            'aria-label': '实际重试次数',
            min: 0,
            precision: 0,
          },
          'x-validator': [{ required: true, validator: integer }],
        },
      },
    },
  },
})
const assertSettled: SettledCheck<LinkedValues> = (values, states) => {
  const options = targetOptions(values.region)
  const target = states.find(
    (state) => state.path.length === 1 && state.path[0] === 'target'
  )
  return options.some((option) => option.value === values.target) &&
    JSON.stringify(target?.dataSource) === JSON.stringify(options) &&
    JSON.stringify(target?.componentProps.options) === JSON.stringify(options)
    ? []
    : [{ path: ['target'], message: '目标值或候选尚未满足当前区域' }]
}
const validate: Validate<LinkedValues> = (values) =>
  values.retries > values.maxRetries
    ? [{ path: ['retries'], message: '重试次数不能超过来源区域的上限' }]
    : []
</script>

<template>
  <section data-linked-sections>
    <ZxSchemaForm
      ref="form"
      :initial="initial"
      :create-schema="createSchema"
      :assert-settled="assertSettled"
      :validate="validate"
      :save="props.save"
    />
    <button
      type="button"
      data-linked-submit
      :disabled="form?.pending || form?.blocked"
      @click="form?.submit()"
    >
      保存
    </button>
    <button type="button" :disabled="form?.pending" @click="form?.reset()">
      恢复保存基线
    </button>
  </section>
</template>
