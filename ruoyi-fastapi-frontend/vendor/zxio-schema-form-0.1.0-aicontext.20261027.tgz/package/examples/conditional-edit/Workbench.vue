<script setup lang="ts">
import { computed, onBeforeUnmount, ref } from 'vue'
import { ZxSchemaForm } from '@zxio/schema-form/formily'

import type {
  BusinessContext,
  ConditionalChange,
  ConditionalEditApi,
  ConditionalEditPolicy,
  PrepareResult,
  SchemaFormInstance,
} from '@zxio/schema-form/formily'

type RecordValue = {
  name: string
  items: { id: string; quantity: number }[]
  audit?: number
}
const form = ref<SchemaFormInstance<RecordValue>>()
const mode = ref('normal')
const candidate = ref<Extract<PrepareResult, { status: 'prepared' }>>()
const result = ref<unknown>()
const receipt = ref<unknown>()
const waiting = ref<AbortController>()
const history = ref<unknown[]>([])
let nextId = 0
let hostAuthorized = true
let hostContext: BusinessContext<RecordValue>
const inputsVisible = ref(true)
const hideScheduled = ref(false)
let hideTimer: ReturnType<typeof setTimeout> | undefined
function cancelHide() {
  clearTimeout(hideTimer)
  hideTimer = undefined
  hideScheduled.value = false
}
function showInputs(visible: boolean) {
  cancelHide()
  inputsVisible.value = visible
  // Hide the editable fields while retaining the array's row identity.
  for (const pattern of ['name', 'items.*.quantity'])
    for (const field of hostContext.form.query(pattern).map())
      field.visible = visible
}
function scheduleHide() {
  cancelHide()
  hideScheduled.value = true
  hideTimer = setTimeout(() => showInputs(false), 2000)
}
onBeforeUnmount(cancelHide)
const field = {
  describe: true,
  read: { kind: 'all' as const },
  write: true,
  atomic: false,
}
const policy: ConditionalEditPolicy = {
  fields: [
    { ...field, path: ['name'], shape: { type: 'string' } },
    {
      ...field,
      path: ['items', { row: true }, 'quantity'],
      shape: { type: 'number', minimum: 0 },
    },
  ],
  arrays: [
    {
      path: ['items'],
      key: 'id',
      describe: true,
      readRows: true,
      readKeys: true,
      insert: true,
      remove: true,
      move: true,
      insertFields: [
        { ...field, path: ['quantity'], shape: { type: 'number', minimum: 0 } },
      ],
    },
  ],
}
function schema(context: BusinessContext<RecordValue>) {
  hostContext = context
  return {
    type: 'object',
    properties: {
      name: {
        type: 'string',
        title: '名称（也可手动编辑）',
        'x-component': 'ZxInput',
        'x-component-props': { clearable: true },
        required: true,
        'x-reactions': (node: any) => {
          if (node.value === 'unknown') context.form.values.audit = Number.NaN
        },
      },
      items: {
        type: 'array',
        title: '检查项',
        'x-component': 'ZxArray',
        items: {
          type: 'object',
          properties: {
            id: {
              type: 'string',
              title: '行 ID',
              'x-component': 'ZxInput',
              'x-pattern': 'readOnly',
            },
            quantity: {
              type: 'number',
              title: '数量',
              'x-component': 'ZxInputNumber',
              'x-reactions': (node: any) => {
                node.disabled = node.query('name').get('value') === 'partial'
              },
            },
          },
        },
      },
    },
  }
}
// This is the complete capability held by the adapter. The Host setter,
// unrestricted read/setValues, reconcile and submit are never passed through.
const adapter = computed<ConditionalEditApi | undefined>(
  () =>
    form.value && {
      readSnapshot: form.value.readSnapshot,
      prepareEdit: form.value.prepareEdit,
      applyPrepared: form.value.applyPrepared,
      discardPrepared: form.value.discardPrepared,
      getOperation: form.value.getOperation,
      waitOperation: form.value.waitOperation,
    }
)
function changes(): ConditionalChange[] {
  if (mode.value === 'array')
    return [
      {
        kind: 'arrayInsert',
        target: ['items'],
        localRef: 'new',
        before: { row: 'a' },
        value: { quantity: 1 },
      },
      {
        kind: 'set',
        target: ['items', { inserted: 'new' }, 'quantity'],
        value: 3,
      },
    ]
  if (mode.value === 'rejected')
    return [
      { kind: 'set', target: ['name'], value: 'corrected' },
      { kind: 'set', target: ['items', { row: 'a' }, 'quantity'], value: -1 },
    ]
  if (mode.value === 'partial')
    return [
      { kind: 'set', target: ['name'], value: 'partial' },
      { kind: 'set', target: ['items', { row: 'a' }, 'quantity'], value: 4 },
    ]
  return [
    {
      kind: 'set',
      target: ['name'],
      value: mode.value === 'unknown' ? 'unknown' : 'corrected',
    },
  ]
}
function prepare() {
  // The Host reserves the read-only identity before observation. The adapter
  // cannot supply or overwrite it, and preparing cannot restore revoked access.
  if (mode.value === 'array' && hostAuthorized)
    form.value!.setConditionalEditPolicy({
      ...policy,
      arrays: policy.arrays.map((rule) => ({
        ...rule,
        defaults: { id: `host-${++nextId}` },
      })),
    })
  const api = adapter.value!
  const snapshot = api.readSnapshot()
  result.value = snapshot
  candidate.value = undefined
  if (snapshot.status !== 'observed') return
  const prepared = api.prepareEdit(changes(), {
    observationRef: snapshot.observationRef,
  })
  result.value = prepared
  if (prepared.status === 'prepared') candidate.value = prepared
}
async function apply() {
  if (!candidate.value) return
  const api = adapter.value!,
    operationRef = candidate.value.operationRef
  history.value.push({ operationRef, stage: 'associated-before-apply' })
  receipt.value = api.applyPrepared(candidate.value.candidateRef)
  history.value.push(receipt.value) // Writing fact is recorded before waiting.
  waiting.value = new AbortController()
  result.value = await api.waitOperation(operationRef, {
    signal: waiting.value.signal,
  })
  history.value.push(result.value)
}
async function runAdapter() {
  prepare()
  await apply()
}
async function validate() {
  await new Promise<void>((resolve) => setTimeout(resolve, 80))
  return []
}
function cancelWait() {
  waiting.value?.abort()
}
function withdraw() {
  hostAuthorized = false
  form.value?.setConditionalEditPolicy({ fields: [], arrays: [] })
  result.value = candidate.value
    ? form.value?.getOperation(candidate.value.operationRef)
    : form.value?.readSnapshot()
  candidate.value = undefined
  receipt.value = undefined
  history.value = []
}
async function recover() {
  cancelHide()
  await form.value!.reconcile({
    name: 'recovered',
    items: [{ id: 'a', quantity: 1 }],
  })
  inputsVisible.value = true
  hostAuthorized = true
  form.value!.setConditionalEditPolicy(policy)
  candidate.value = undefined
  receipt.value = undefined
  history.value = []
  result.value = form.value!.readSnapshot()
}
defineExpose({
  form,
  adapter,
  prepare,
  apply,
  runAdapter,
  recover,
  mode,
  candidate,
  result,
  receipt,
  history,
  withdraw,
  cancelWait,
  showInputs,
})
</script>

<template>
  <main>
    <h1>表单条件编辑工作台</h1>
    <p>
      人工、API 与受控 adapter
      共用一个草稿。应用不代表保存；拟改预览不包含真实联动结果。
    </p>
    <ZxSchemaForm
      ref="form"
      :initial="{ name: '', items: [{ id: 'a', quantity: 1 }] }"
      :create-schema="schema"
      :assert-settled="() => []"
      :initial-conditional-edit-policy="policy"
      :array-keys="[{ path: ['items'], key: 'id' }]"
      :validate="validate"
    />
    <label
      >场景
      <select v-model="mode">
        <option value="normal">正常与纠错</option>
        <option value="array">数组新增与行编辑</option>
        <option value="rejected">整份拒绝</option>
        <option value="partial">联动造成部分写入</option>
        <option value="unknown">未知效果与恢复</option>
      </select></label
    >
    <p aria-live="polite" data-visibility>
      {{
        hideScheduled
          ? '两秒后隐藏输入；现在可开始输入法组合。'
          : inputsVisible
          ? '输入可见；可测试隐藏期间的草稿保护。'
          : '输入已隐藏，未确认草稿仍受保护。'
      }}
    </p>
    <nav>
      <button @click="prepare">API：观察与准备</button>
      <button :disabled="!candidate" @click="apply">API：应用并等待</button>
      <button @click="runAdapter">受控 adapter 执行</button>
      <button @click="form?.setValues({ name: 'human takeover' })">
        人工接管／制造冲突
      </button>
      <button @click="cancelWait">仅取消当前等待</button>
      <button @click="withdraw">Host 收紧读取与写入</button>
      <button @click="recover">Host 核对并恢复</button>
      <button :disabled="!inputsVisible || hideScheduled" @click="scheduleHide">
        Host 两秒后隐藏输入
      </button>
      <button
        :disabled="inputsVisible && !hideScheduled"
        @click="showInputs(true)"
      >
        Host 显示输入
      </button>
    </nav>
    <h2>写入事实</h2>
    <pre data-fact>{{ JSON.stringify(receipt, null, 2) }}</pre>
    <h2>观察、拟改与核验</h2>
    <pre data-result>{{ JSON.stringify(result, null, 2) }}</pre>
    <p v-if="candidate">操作引用：{{ candidate.operationRef }}</p>
    <details>
      <summary>adapter 事实关联顺序</summary>
      <pre>{{ JSON.stringify(history, null, 2) }}</pre>
    </details>
  </main>
</template>

<style scoped>
main {
  box-sizing: border-box;
  max-width: 960px;
  margin: 32px auto;
  padding: 0 16px;
  font: 15px/1.6 system-ui;
  color: #1b2936;
}
nav {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin: 16px 0;
}
button,
select {
  font: inherit;
  padding: 6px 12px;
}
pre {
  background: #f3f5f7;
  padding: 16px;
  overflow: auto;
  max-height: 360px;
}
</style>
