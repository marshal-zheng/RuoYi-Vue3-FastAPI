<script setup lang="ts">
import { computed, ref, useId, watch } from 'vue'
import { ZxInput } from '@zxio/zxui/input'
import {
  ZxNumberTextInput,
  parseNumberText,
  useInputComposition,
} from '@zxio/schema-form/fields'
import { ZxButton } from '@zxio/zxui/button'

import type { Measurement } from './model'
import type {
  FieldEditState,
  FieldMessage,
  FieldPath,
  NumberTextEdit,
} from '@zxio/schema-form/fields'

defineOptions({ inheritAttrs: false })
const props = defineProps<{
  modelValue: Measurement[]
  disabled?: boolean
  messages?: readonly FieldMessage[]
}>()
const emit = defineEmits<{
  (e: 'update:modelValue', value: Measurement[]): void
  (e: 'edit-state', state: FieldEditState): void
}>()
let editSequence = 0
const drafts = ref<Record<string, string>>({})
const names = ref<Record<string, string>>({})
const composition = useInputComposition()
const nameKey = (id: string) => `name:${id}`
const readingKey = (id: string) => `reading:${id}`
const blocking = () =>
  composition.blocked.value ||
  Object.values(drafts.value).some(
    (text) => parseNumberText(text).status === 'invalid'
  )
function report() {
  emit('edit-state', {
    editSequence,
    blocking: blocking()
      ? [{ severity: 'error', message: '请完成检查项输入' }]
      : [],
  })
}
function observeRaw(event: Event) {
  const input = event.target as HTMLInputElement
  const id = input.dataset.reading ?? input.dataset.name
  if (id !== undefined) {
    const key = input.dataset.reading ? readingKey(id) : nameKey(id)
    composition.observe(event, key)
    if (input.dataset.reading) drafts.value[id] = input.value
    else names.value[id] = input.value
  }
  editSequence++
  report()
  if (input.dataset.reading) commitReading(input.dataset.reading, input.value)
  else if (input.dataset.name) editName(input.dataset.name, input.value)
}
function editName(id: string, name: string) {
  if (!composition.has(nameKey(id))) edit(id, { name })
}
function reading(row: Measurement) {
  return (
    drafts.value[row.id] ?? (row.reading == null ? '' : String(row.reading))
  )
}
function editReading(row: Measurement, value: NumberTextEdit) {
  drafts.value[row.id] = value.text
  editSequence++
  report()
  commitReading(row.id, value.text)
}
function commitReading(id: string, text: string) {
  if (composition.has(readingKey(id))) return
  const parsed = parseNumberText(text)
  if (parsed.status !== 'invalid')
    edit(id, { reading: parsed.status === 'empty' ? null : parsed.value })
}
watch(
  () => props.modelValue,
  (rows) => {
    let changed = composition.prune(
      rows.flatMap((row) => [nameKey(row.id), readingKey(row.id)])
    )
    for (const id of Object.keys(drafts.value)) {
      const row = rows.find((row) => row.id === id)
      const parsed = parseNumberText(drafts.value[id])
      if (
        !row ||
        (!composition.has(readingKey(id)) &&
          parsed.status === 'valid' &&
          parsed.value !== row.reading)
      ) {
        delete drafts.value[id]
        changed = true
      }
    }
    for (const id of Object.keys(names.value)) {
      const row = rows.find((row) => row.id === id)
      if (
        !row ||
        (!composition.has(nameKey(id)) && names.value[id] !== row.name)
      ) {
        delete names.value[id]
        changed = true
      }
    }
    // Publish the remaining raw state without counting canonical cleanup as input.
    if (changed) report()
  }
)
const fields = ref<Record<string, { focus(): void }>>({})
const readingFields = ref<Record<string, { focus(): void }>>({})
const messagePrefix = useId()
const messagesFor = (index: number, key: string) =>
  props.messages?.filter(
    (message) => message.path?.[0] === index && message.path[1] === key
  ) ?? []
const messageId = (index: number, key: string) =>
  `${messagePrefix}-${index}-${key}`
const summary = computed(
  () =>
    props.messages?.filter((message) => {
      const [index, key] = message.path ?? []
      return (
        typeof index !== 'number' ||
        !props.modelValue[index] ||
        (key !== 'name' && key !== 'reading')
      )
    }) ?? []
)
function edit(id: string, patch: Partial<Measurement>) {
  emit(
    'update:modelValue',
    props.modelValue.map((row) =>
      row.id === id ? { ...row, ...patch } : { ...row }
    )
  )
}
function add() {
  emit('update:modelValue', [
    ...props.modelValue,
    { id: crypto.randomUUID(), name: '', reading: null },
  ])
}
function move(index: number) {
  const next = props.modelValue.map((row) => ({ ...row }))
  ;[next[index - 1], next[index]] = [next[index], next[index - 1]]
  emit('update:modelValue', next)
}
function focusRow(id: string) {
  fields.value[id]?.focus()
}
function focus(path: FieldPath = []) {
  const row = props.modelValue[typeof path[0] === 'number' ? path[0] : 0]
  if (!row) return
  ;(path[1] === 'reading' ? readingFields : fields).value[row.id]?.focus()
}
defineExpose({
  focus,
  focusRow,
  validate: () => !blocking(),
  captureEdit: () => ({
    drafts: { ...drafts.value },
    names: { ...names.value },
    composition: composition.keys.value,
  }),
  restoreEdit(value: any) {
    drafts.value = { ...(value?.drafts ?? {}) }
    names.value = { ...(value?.names ?? {}) }
    composition.restore(value?.composition)
    composition.prune(
      props.modelValue.flatMap((row) => [nameKey(row.id), readingKey(row.id)])
    )
    report()
  },
})
</script>

<template>
  <div
    v-bind="$attrs"
    class="measurements"
    data-measurements
    @input.capture="observeRaw"
    @compositionstart.capture="observeRaw"
    @compositionend.capture="observeRaw"
  >
    <ul v-if="summary.length" role="alert">
      <li v-for="(message, index) in summary" :key="index">
        {{ message.message }}
      </li>
    </ul>
    <table>
      <caption>
        检查项读数
      </caption>
      <thead>
        <tr>
          <th>检查项</th>
          <th>读数</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr
          v-for="(row, index) in modelValue"
          :key="row.id"
          :data-row-id="row.id"
        >
          <td>
            <ZxInput
              :ref="(value: any) => { if (value) fields[row.id] = value; else delete fields[row.id] }"
              :data-name="row.id"
              :model-value="names[row.id] ?? row.name"
              :disabled="disabled"
              :validate-event="false"
              :aria-label="`检查项 ${index + 1} 名称`"
              :aria-invalid="messagesFor(index, 'name').length > 0 || undefined"
              :aria-describedby="
                messagesFor(index, 'name').length
                  ? messageId(index, 'name')
                  : undefined
              "
              @update:model-value="(value) => editName(row.id, String(value))"
            />
            <p
              v-if="messagesFor(index, 'name').length"
              :id="messageId(index, 'name')"
              role="alert"
            >
              {{
                messagesFor(index, 'name')
                  .map((message) => message.message)
                  .join('；')
              }}
            </p>
          </td>
          <td>
            <ZxNumberTextInput
              :ref="(value: any) => { if (value) readingFields[row.id] = value; else delete readingFields[row.id] }"
              :text="reading(row)"
              :data-reading="row.id"
              :disabled="disabled"
              :validate-event="false"
              :aria-label="`检查项 ${index + 1} 读数`"
              :aria-invalid="
                messagesFor(index, 'reading').length > 0 || undefined
              "
              :aria-describedby="
                messagesFor(index, 'reading').length
                  ? messageId(index, 'reading')
                  : undefined
              "
              @edit="(value) => editReading(row, value)"
            />
            <p
              v-if="messagesFor(index, 'reading').length"
              :id="messageId(index, 'reading')"
              role="alert"
            >
              {{
                messagesFor(index, 'reading')
                  .map((message) => message.message)
                  .join('；')
              }}
            </p>
          </td>
          <td class="row-actions">
            <ZxButton
              :disabled="disabled || index === 0"
              :aria-label="`上移 ${row.name || '检查项'}`"
              @click="move(index)"
              >上移</ZxButton
            >
            <ZxButton
              :disabled="disabled"
              :aria-label="`删除 ${row.name || '检查项'}`"
              @click="
                emit(
                  'update:modelValue',
                  modelValue.filter((item) => item.id !== row.id)
                )
              "
              >删除</ZxButton
            >
          </td>
        </tr>
      </tbody>
    </table>
    <ZxButton :disabled="disabled" data-add-row @click="add"
      >添加检查项</ZxButton
    >
  </div>
</template>
