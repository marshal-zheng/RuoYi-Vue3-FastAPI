/** Retire callbacks that ignore AbortSignal, without leaving the UI reserved. */
export declare function awaitSignal<T>(work: Promise<T>, signal: AbortSignal): Promise<T>;
