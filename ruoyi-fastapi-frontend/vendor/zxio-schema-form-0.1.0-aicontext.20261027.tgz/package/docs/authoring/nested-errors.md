# 明细、数组身份与错误

错误以 `FieldIssue { path?: readonly (string | number)[], message, severity? }` 表达；省略/未知 path 进入表单摘要。复合字段收到相对其根的 FieldMessage.path，并自行渲染到内部控件。纯布局 address 不得混入业务 path。

```ts
const arrayKeys = [{ path: ['rows'], key: 'id' }]
const failure = {
  ok: false,
  outcome: 'rejected',
  issues: [{ path: ['rows', 1, 'reading'], message: '第二个提交行的数值无效' }],
}
```

数组原生 insert/remove/move 通过 ArrayField 公开操作迁移模型、控件与反馈；外部全量替换先按声明 key 对齐。后台索引错误以提交 snapshot 的稳定业务 id 找当前对应行；删除行丢弃其错误，重复/缺失 key 或无法安全定位转表单摘要，禁止猜测数字索引。未声明 key 只在原生结构操作中依模型身份保留；外部全量替换不能推断行身份。

反馈的会话 ledger 不依赖原生 hidden/readonly 自动清错。隐藏路径错误仍在表单摘要可见，禁止 focus 隐藏控件；恢复可见重新投影。真正退出业务分支才用 validationActive=false 失效该规则错误。未知路径始终有可行动摘要，不静默丢弃。

普通字段由 ZxField 标签/帮助/错误关联真实 input。复合字段接收父 ARIA 并合并自己的描述，暴露 focus(relativePath)。同值 bindings 替换也会废弃旧控件身份，旧 validate/错误不能落到后继。

原始 row id、DTO 取舍与领域规则属于业务；库不生成业务 id。业务示例：[MeasurementRows.vue](../../examples/inspection/MeasurementRows.vue)、[ProtocolConfig.vue](../../examples/protocol/ProtocolConfig.vue)。
