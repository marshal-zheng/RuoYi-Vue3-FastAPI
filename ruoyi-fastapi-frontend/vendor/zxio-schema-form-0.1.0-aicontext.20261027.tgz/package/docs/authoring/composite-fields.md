# 编写 JSON、上传或对象复合字段

适用于一个字段内部有多个控件、未完成输入或异步资源的场景。CRUD 会话先读 [普通 CRUD](crud.md)；已有 DAG / Dashboard 会话先读 [受控配置面板](controlled-fields.md)。字段共享相同的受控值、错误和编辑活动语义。

## 接入现有值所有者

CRUD 在 `bindings` 中显式登记复合字段，普通组件仍可直接登记：

```ts
const bindings = {
  SettingsEditor: { component: SettingsEditor, composite: true },
  BusinessLabel: BusinessLabel,
}
```

字段接收 `modelValue`、`disabled`、`messages: readonly FieldMessage[]`，发出 `update:modelValue`。`FieldMessage.path` 相对当前字段，省略 path 表示当前字段整体。适配器单层写入原生 Field.value，消费原生自动事件以避免重复校验，不持有另一份可写值。

组件只持有确实无法表达为 canonical 值的输入状态，例如尚未解析的 raw 文本、上传进度和资源取消句柄；更新对象/数组时创建新值，不能直接改 `modelValue`。canonical 值仍须是 JSON：附件上传得到业务元数据后再写入 canonical，File 不进入表单快照。

## 让所有提交入口感知未完成输入

发出 `edit-state({ pending?, blocking? })` **完整快照**；省略 pending 表示 false，省略 blocking 表示空数组。公开契约见 [字段类型](../../fields/types.d.ts)。

| 字段状态                    | 上报与提交行为                                          |
| --------------------------- | ------------------------------------------------------- |
| 刷新可选项，但现有值可提交  | 仅 pending；宿主可以显示活动，仍允许提交                |
| 上传中，业务不能先保存      | pending 与 blocking 同时上报                            |
| JSON/数字文本非法或尚未完成 | 保留 raw，报告 blocking；不能静默提交上一个合法值       |
| 解析成功或活动结束          | 更新 canonical，报告新的完整状态，清除已结束的活动/阻断 |

用 `defineExpose` 提供 `focus(relativePath?)`，必要时提供 `validate(): boolean | Promise<boolean>`。CRUD 提交先等全部复合校验，再运行会话隔离的字段校验和整记录校验，每个异步边界复查会话有效性和 blocking。按钮 disabled 仅是交互提示，字段不能自行绕过宿主提交管线。

可选暴露 captureEdit/restoreEdit 保存临时隐藏期间的 raw；reset、authority 和记录切换会重新挂载字段并废弃旧 raw。组件负责取消自己的异步资源并拒绝失效回调；适配器在卸载时清理字段状态。宿主回填值时区分父级对同一值的回声与真正的外部替换，避免无意义覆盖用户仍有效的 raw 格式。

隐藏时适配器在子组件清理资源前只捕获一次临时状态；组件卸载后的迟到上报不能覆盖该状态。重新显示后，`restoreEdit` 在子组件 `mounted` 完成后调用，此时可以使用编辑器实例、焦点目标等挂载资源。对象文档始终留在表单 canonical 值中，`captureEdit` 只返回无法表达为正文的临时状态，没有时返回 `null`；备注字段在此先把未结束的输入法组合提交到表单值，不保留浮层草稿。单控件型复合字段登记 `composite: true, group: false`，由字段本身关联错误与输入，不增加 fieldset 组语义。

## 保留输入法草稿并允许人工接管

`@zxio/schema-form/fields` 提供无 Formily 依赖的 `useInputComposition()`，供内建和复合字段共享输入生命周期。它只管理未完成输入的 key，不拥有 raw 文本或 canonical 值。

- `observe(event, key?)` 接收真实 `input`、`compositionstart`、`compositionend`；单输入可省略 key（默认为 `value`），复合字段使用稳定行 ID 与属性组成的 key。
- `blocked`、`keys` 是只读 computed；`has(key?)` 判断该输入是否仍未确认。先同步 report 编辑序号/阻塞，再在 `!has(key)` 且解析有效时提交 canonical。
- `captureEdit` 连同 raw 保存 `keys.value`；`restore(keys)` 恢复未确认标记，但不恢复旧 DOM 的活动 IME 会话。重挂、focus、blur 本身不确认草稿；新 DOM 上普通 input 或新一轮 compositionend 只确认对应 key。
- 步进/清除按钮等不产生原生 `input` 的明确人工编辑，应在值编辑回调中先调用 `acceptChange(key?)`，再同步 report 和提交 canonical。它仅接管没有活动 IME 的保留键，活动会话仍等待 compositionend；返回 true 表示保留标记已解除。不能从 prop watch、restore、focus 或 blur 中调用。
- 行删除/替换后用 `prune(validKeys)` 清理消失的 key；返回 true 时重新 report 完整剩余状态，不增加用户编辑序号。编辑其他输入不能解除当前 key 的保护。

保留草稿时不能自动提交未确认文字，也不能直接清空阻塞；恢复后必须保留普通输入接管入口。数字/JSON 的解析失败独立于 IME 状态，即使用户已结束组合输入仍继续保护非法 raw。参考 MeasurementRows 与 ProtocolConfig 的 capture/restore 和稳定 key 示例。

## 渲染错误与可访问关系

组件负责把当前和后代 messages 呈现到真实控件，并让 `focus` 按相对路径定位。不能只在外层 div 上放 `aria-invalid` / `aria-describedby`。合并已有帮助说明和错误描述 ID，保持父级传入的关联；未知或无法定位的子路径在字段摘要显示。组控件可用 `ZxField group` 的 fieldset/legend 语义。

可见复合控件在自身反馈区域呈现 raw blocking，Formily 不再在表单底部重复显示；隐藏或卸载后仍保留的 raw blocking 会出现在表单摘要，并继续阻止保存。反馈区域应预留一行空间，外层 `ZxField` 的占位由复合绑定关闭；详见 [受控字段布局](controlled-fields.md#运行与验证)。

内置数字字段的 raw 尚未解析时，只展示当前 raw 错误；此时保留的 canonical 值所产生的旧规则反馈不叠加到输入框下方。raw 恢复有效后重新显示当前适用的字段反馈，保存仍须通过全部校验。

数组包含可移动行时，CRUD 表单同时声明 `arrayKeys`。行身份、错误迁移、删除和降级规则见 [明细与错误](nested-errors.md)。

## 复用已验证的 recipe

这些链接指向 pilot 原始实现，构建把同一源文件交付到安装包，不维护第二套文档实现：

- [JsonSettingsField.vue](../../examples/recipes/JsonSettingsField.vue)：raw/canonical 分离，`parseJsonText`，blocking，父值回声判断，validate/focus 与 ARIA 合并。
- [AttachmentField.vue](../../examples/inspection/AttachmentField.vue)：上传期间 pending/blocking，独立请求取消，丢弃失效结果，canonical 只保留已完成附件元数据。它使用 [inspection/model.ts](../../examples/inspection/model.ts) 的业务类型。
- [MeasurementRows.vue](../../examples/inspection/MeasurementRows.vue)：对象数组编辑、增删排序、相对子路径错误和 focus。
- [ProtocolConfig.vue](../../examples/protocol/ProtocolConfig.vue)：一个对象字段内的数组与其他属性组合。

recipe 的领域规则与服务接口属于示例业务，按真实需求替换；字段契约、生命周期和所有权遵循 [完整参考](reference.md#复合字段契约)。验证至少覆盖一次非法 raw 阻断、有效输入恢复、reset/卸载清理，以及本任务实际使用的异步或错误定位路径。

## 条件编辑

见[条件编辑契约](conditional-edit.md)：公开六方法、Host 同步策略安装、整域版本、raw 编辑序号、受控数组与写入事实/异步核验。带 raw 的 binding 必须声明 `editObservation: 'raw-sequence'` 并先同步上报 `editSequence`，再发 canonical；没有 raw 的控件才可声明 `canonical`。不支持观测的控件保留人工能力，但不能条件写。

## 受管控件核验

参与条件编辑的 composite binding 还须声明 `validationOwnership: 'managed'`。`FieldControl.validate(context)` 接收公开 `/fields` 的 `FieldValidationContext`；同步纯检查可直接返回 boolean，异步完成后所有本地反馈写入必须使用 `context.commit(() => { ... })`，并可用 `context.signal` 取消请求。`context.current()` 在人工 raw/canonical 编辑、控件/owner 替换或超时后返回 false；commit 此时不执行回调。未声明该协议的复合控件没有条件写资格。

```ts
async function validate(context: FieldValidationContext) {
  const issues = await checkCurrentValue(context.signal)
  if (!context.commit(() => { feedback.value = issues })) return false
  return issues.length === 0
}
```

Host 仍负责遵守受管提交契约；能力声明不沙箱化任意 JavaScript。超时不伪造回滚，尚未结束的控件核验仍保持排他。
