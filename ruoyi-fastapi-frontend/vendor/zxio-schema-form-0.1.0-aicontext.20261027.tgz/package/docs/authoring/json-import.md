# 安全 JSON v2 定义

可信 TypeScript schema 和外部 JSON 是两种入口。TS 可使用原生 function reactions/validator/事件；外部 JSON 只进入版本化白名单，不能执行表达式或完整 designer 输出。

```ts
import {
  parseDefinition,
  createZxuiDefinitionPolicy,
} from '@zxio/schema-form/formily'
const raw = {
  id: 'post',
  revision: 2,
  engine: 'formily@2.3.7',
  contract: 'zxui-schema-form-v2',
  schema: {
    type: 'object',
    properties: {
      name: {
        type: 'string',
        title: '名称',
        'x-component': 'ZxInput',
        'x-validator': [
          {
            required: true,
            valueType: 'string',
            min: 1,
            max: 40,
            triggerType: 'onBlur',
            message: '请输入名称',
          },
        ],
      },
    },
  },
}
const compiled = parseDefinition(
  JSON.stringify(raw),
  createZxuiDefinitionPolicy()
)
const createSchema = () => compiled.schema
```

保留 raw 定义以保存/往返；parseDefinition 输出含受信任编译后的 validator 函数，不能再 JSON.stringify 当原始可保存定义。业务闭包、资源和复合组件只在 TS 注入，不序列化。

规则字段为 required、valueType（string/number/array）、min/max、triggerType（onInput/onBlur）和 message。range 对 number 检查数值，对 string/array 检查长度；类型严格，不把字符串当数字；非有限值拒绝。submit 检查全部规则。整数、enum、trim 空白等业务语义用可信 TS validator 明示。旧 type/trigger 键不透传，也没有旧 Rule 兼容 parser。

v1/form-create 定义明确拒绝；本轮内置 fixtures 已在源码显式转换。新 profile 限 100000 字符串码元、200 schema 节点、16 层，保留 40 普通字段能力。仅支持扁平业务字段和 void 布局，动态 object/array items 使用可信 TS schema。

逐节点拒绝未知组件/键/props、事件、函数标记、x-reactions、x-content、`{{...}}` 字符串、危险路径、原型键和重复 data path。组件 props 还检查类型/范围。自定义 JSON 组件需显式 policy 与可信 binding 同时登记；policy 是准入约束，不是执行任意代码的沙箱。完整类型见[参考](reference.md)。
