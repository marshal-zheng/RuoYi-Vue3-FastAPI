# 普通 CRUD 与保存生命周期

从 `@zxio/schema-form/formily` 导入 ZxSchemaForm 和 `Save<T>`。宿主加载完整 JSON 记录，按记录 key 挂载表单；`createSchema(context)` 返回原生 Formily Schema。不要另建可写 draft 再 watch 双向同步。业务保留 DTO、权限、API、加载重试和关闭政策。

```ts
import type {
  BusinessContext,
  Save,
  SchemaProperties,
} from '@zxio/schema-form/formily'
type Post = { postName: string; postSort: number; status: string }
function createSchema(ctx: BusinessContext<Post>) {
  const properties: SchemaProperties<Post> = {
    postName: {
      type: 'string',
      title: '名称',
      required: true,
      'x-component': 'ZxInput',
      'x-validator': (value) =>
        typeof value === 'string' && value.trim() ? '' : '请输入名称',
    },
    postSort: {
      type: 'number',
      title: '排序',
      'x-component': 'ZxInputNumber',
      'x-validator': (value) =>
        Number.isInteger(value) && value >= 0 ? '' : '请输入非负整数',
    },
    status: {
      type: 'string',
      title: '状态',
      'x-component': 'ZxSelect',
      'x-reactions': (field) =>
        ctx.bindResource(
          () => dictionary.value,
          (options) => ctx.configure(field, { dataSource: options }),
          { scope: field }
        ),
    },
  }
  return { type: 'object', properties }
}
const assertSettled = (values, states) => {
  // 实际项目须对字典投影与提交相关状态做完整检查。
  return states.find((field) => field.path[0] === 'status')
    ? []
    : [{ message: '状态字段尚未就绪' }]
}
```

这里 dictionary 是宿主 Vue ref。含 reaction 必须提供足够完整的 assertSettled；不能照搬仅检查存在性的示意断言作为领域正确性保证。完整联动模式见[分区](form-sections.md)。

`save(values, signal)` 获得与已校验快照相同内容的独立副本；不能在 callback 内改参数后假定表单值已更新。成功返回 `{ ok: true, values: completeAuthority }`；省略 values 表示确认原提交值。明确服务端拒绝返回 `{ ok: false, outcome: 'rejected', issues }`，未知结果返回 `outcome: 'unknown'`。抛错也按未知处理，必须读取核对。不能用“请求取消”推断服务端回滚。

提交先准备，再复合校验、字段校验、整记录 validate，最后一次 save。每个 await 都核验 generation、值/配置/raw/控件票据；ABA 同样使旧尝试失效。异步 validator 忽略 signal 的迟到结果也不能污染当前反馈。

初始化、authority/reset 和成功回填必须等同步传播、必要受管任务完成并通过不变量才接受 baseline。read 是隔离快照；dirty 只比较 canonical。非法 raw 可能 dirty=false 但 blocked=true，所有 submit 入口仍阻止保存。

已派发请求后编辑、reset、结果不明或本地接纳失败会要求核对。按钮可根据 `reconciliationRequired` 显示业务读取入口；完整 GET 后调用 `await form.reconcile(authority)`。新建响应丢失按已确认唯一业务身份查找；无法唯一确认保持锁定，禁止盲目重发。

Dialog 只管理显示、读取和关闭保护。关闭时检查 pending、reconciliationRequired 和 dirty；不要把 SchemaFormInstance 当 Element Plus FormInstance，亦不要让 shell 再校验/reset 一份值。保存后 `saved` 只在权威基线接受成功后发出；saved listener 新编辑保留为 dirty。
