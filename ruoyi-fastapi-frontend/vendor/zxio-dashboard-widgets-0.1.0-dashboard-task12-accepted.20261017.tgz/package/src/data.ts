import type { DashboardWidgetReadonlyPanel } from '@zxio/dashboard/widget'
import type {
  DashboardBarData,
  DashboardStatusData,
  DashboardTableData,
  DashboardTimeSeriesData,
} from './types'

export function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
}
export function finite(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value)
}
export function readMetric(value: unknown): number | undefined {
  const metric = isRecord(value) ? value.value : value
  return finite(metric) ? metric : undefined
}
export function isTimeSeries(value: unknown): value is DashboardTimeSeriesData {
  return (
    isRecord(value) &&
    Array.isArray(value.series) &&
    value.series.every(
      (s: unknown) =>
        isRecord(s) &&
        typeof s.name === 'string' &&
        Array.isArray(s.points) &&
        s.points.every(
          (p: unknown) =>
            Array.isArray(p) &&
            p.length === 2 &&
            finite(p[0]) &&
            Number.isSafeInteger(p[0]) &&
            Math.abs(p[0]) <= 8640000000000000 &&
            (p[1] === null || finite(p[1]))
        )
    )
  )
}
export function isBarData(value: unknown): value is DashboardBarData {
  if (
    !isRecord(value) ||
    !Array.isArray(value.categories) ||
    !value.categories.every((v) => typeof v === 'string') ||
    !Array.isArray(value.series)
  )
    return false
  const count = value.categories.length
  return value.series.every(
    (s: unknown) =>
      isRecord(s) &&
      typeof s.name === 'string' &&
      Array.isArray(s.values) &&
      s.values.length === count &&
      s.values.every((v) => v === null || finite(v))
  )
}
export function isTableData(value: unknown): value is DashboardTableData {
  if (
    !isRecord(value) ||
    !Array.isArray(value.columns) ||
    !Array.isArray(value.rows)
  )
    return false
  const keys = new Set<string>()
  return (
    value.columns.every((c: unknown) => {
      if (
        !isRecord(c) ||
        typeof c.key !== 'string' ||
        !c.key ||
        typeof c.label !== 'string' ||
        keys.has(c.key) ||
        ['__proto__', 'prototype', 'constructor'].includes(c.key)
      )
        return false
      keys.add(c.key)
      return true
    }) && value.rows.every(isRecord)
  )
}
export function isStatusData(value: unknown): value is DashboardStatusData {
  return (
    isRecord(value) &&
    ['ok', 'warn', 'error', 'offline'].includes(String(value.state)) &&
    (value.label === undefined || typeof value.label === 'string')
  )
}
export function paramText(
  panel: DashboardWidgetReadonlyPanel,
  key: string,
  fallback = ''
): string {
  const value = panel.params?.[key]
  return typeof value === 'string' ? value : fallback
}
export function paramNumber(
  panel: DashboardWidgetReadonlyPanel,
  key: string,
  fallback: number
): number {
  const value = panel.params?.[key]
  return finite(value) ? value : fallback
}
export function metricText(
  value: number | undefined,
  decimals: number,
  locale: string
): string {
  if (value === undefined) return '—'
  const digits = Math.min(6, Math.max(0, Math.trunc(decimals)))
  return new Intl.NumberFormat(locale, {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(value)
}
/** Reject executable, protocol-relative, credential-bearing and ambiguous URLs. */
export function safeEmbedUrl(value: unknown): string | undefined {
  if (
    typeof value !== 'string' ||
    !value ||
    value !== value.trim() ||
    /[\s\\]/.test(value) ||
    Array.from(value).some((char) => char.charCodeAt(0) < 32)
  )
    return undefined
  if (value.startsWith('/') && !value.startsWith('//')) return value
  try {
    const url = new URL(value)
    return ['http:', 'https:'].includes(url.protocol) &&
      !url.username &&
      !url.password
      ? url.href
      : undefined
  } catch {
    return undefined
  }
}
