import type { MaybeRefOrGetter } from 'vue'
import type { ChartThemeProjection } from '@zxio/chart'
import type { DashboardJsonObject } from '@zxio/dashboard/schema'

export type DashboardWidgetsLocale = 'en' | 'zh-CN'

export interface DashboardWidgetsOptions {
  locale?: DashboardWidgetsLocale
  /** The host's active projection; read reactively on each widget render. */
  themeProjection: MaybeRefOrGetter<ChartThemeProjection | undefined>
  /** Additional host policy, after built-in URL validation. */
  allowEmbedUrl?: (url: string) => boolean
}

export interface DashboardMetricData {
  value: number
}

export interface DashboardTimeSeriesData {
  series: { name: string; points: [number, number | null][] }[]
}

export interface DashboardBarData {
  categories: string[]
  series: { name: string; values: (number | null)[] }[]
}

export interface DashboardTableData {
  columns: { key: string; label: string }[]
  rows: DashboardJsonObject[]
}

export interface DashboardStatusData {
  state: 'ok' | 'warn' | 'error' | 'offline'
  label?: string
}
