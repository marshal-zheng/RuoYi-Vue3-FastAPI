import type { PropType } from 'vue'
import type { ChartThemeProjection } from '@zxio/chart'
import type { DashboardWidgetReadonlyPanel } from '@zxio/dashboard/widget'
import type { DashboardWidgetsLocale } from './types'

export const widgetProps = {
  panel: {
    type: Object as PropType<DashboardWidgetReadonlyPanel>,
    required: true as const,
  },
  locale: {
    type: String as PropType<DashboardWidgetsLocale>,
    default: 'en' as const,
  },
  themeProjection: Object as PropType<ChartThemeProjection>,
}
