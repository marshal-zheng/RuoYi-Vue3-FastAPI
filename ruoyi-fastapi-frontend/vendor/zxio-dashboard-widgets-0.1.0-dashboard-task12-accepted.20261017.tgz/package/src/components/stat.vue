<template>
  <div class="zx-dashboard-widgets zx-dashboard-widgets__metric">
    <span class="zx-dashboard-widgets__label">{{ label }}</span>
    <div class="zx-dashboard-widgets__value">
      {{ valueText }}<small v-if="value !== undefined">{{ unit }}</small>
    </div>
    <span v-if="value === undefined" class="zx-dashboard-widgets__message">{{
      panel.data == null ? copy.empty : copy.invalid
    }}</span>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { widgetProps } from '../props'
import { metricText, paramNumber, paramText, readMetric } from '../data'
import { widgetCopy } from '../locale'

const props = defineProps(widgetProps)
const copy = computed(() => widgetCopy(props.locale))
const value = computed(() => readMetric(props.panel.data))
const label = computed(() => paramText(props.panel, 'label', props.panel.title))
const unit = computed(() => paramText(props.panel, 'unit'))
const valueText = computed(() =>
  metricText(value.value, paramNumber(props.panel, 'decimals', 0), props.locale)
)
</script>
