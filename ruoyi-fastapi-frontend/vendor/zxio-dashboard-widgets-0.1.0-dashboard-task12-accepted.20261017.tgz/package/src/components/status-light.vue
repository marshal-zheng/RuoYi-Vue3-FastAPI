<template>
  <div
    class="zx-dashboard-widgets zx-dashboard-widgets__status"
    :data-state="state"
  >
    <span class="zx-dashboard-widgets__light" aria-hidden="true" />
    <div>
      <strong>{{ label }}</strong>
      <p v-if="caption">{{ caption }}</p>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { widgetProps } from '../props'
import { isStatusData, paramText } from '../data'
import { widgetCopy } from '../locale'

const props = defineProps(widgetProps)
const copy = computed(() => widgetCopy(props.locale))
const data = computed(() =>
  isStatusData(props.panel.data) ? props.panel.data : undefined
)
const state = computed(() => data.value?.state ?? 'offline')
const label = computed(
  () =>
    data.value?.label ||
    (props.panel.data != null && !data.value
      ? copy.value.invalid
      : copy.value[state.value])
)
const caption = computed(() => paramText(props.panel, 'label'))
</script>
