<template>
  <div
    class="zx-dashboard-widgets zx-dashboard-widgets__table"
    role="region"
    :aria-label="panel.title || copy.table"
    tabindex="0"
  >
    <ZxListView
      v-if="data"
      :rows="rows"
      :columns="columns"
      row-key="__row"
      :options="options"
    />
    <div v-else class="zx-dashboard-widgets__message">
      {{ panel.data == null ? copy.empty : copy.invalid }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { ZxListView } from '@zxio/zxui/list-view'
import { widgetProps } from '../props'
import { isTableData } from '../data'
import { widgetCopy } from '../locale'

const props = defineProps(widgetProps)
const copy = computed(() => widgetCopy(props.locale))
const data = computed(() =>
  isTableData(props.panel.data) ? props.panel.data : undefined
)
// Flatten cells into safe text; never pass arbitrary column callbacks or row routes.
const rows = computed(
  () =>
    data.value?.rows.map((row, index) => ({
      ...Object.fromEntries(
        data.value!.columns.map((c, columnIndex) => [
          `cell${columnIndex}`,
          row[c.key] == null
            ? '—'
            : typeof row[c.key] === 'object'
            ? JSON.stringify(row[c.key])
            : String(row[c.key]),
        ])
      ),
      __row: index,
    })) ?? []
)
const columns = computed(
  () =>
    data.value?.columns.map((c, index) => ({
      key: `cell${index}`,
      label: c.label,
      width: 'minmax(100px, 1fr)',
    })) ?? []
)
const options = computed(() => ({
  selectable: false,
  showTooltip: false,
  showHeader: props.panel.params?.showHeader !== false,
  enableActive: false,
  resizeColumn: false,
  virtual: true,
  virtualThreshold: 100,
  emptyState: { title: copy.value.empty, description: '' },
}))
</script>
