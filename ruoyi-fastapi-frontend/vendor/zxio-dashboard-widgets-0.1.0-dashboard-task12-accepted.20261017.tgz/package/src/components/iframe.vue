<template>
  <div class="zx-dashboard-widgets zx-dashboard-widgets__embed">
    <iframe
      v-if="url"
      :src="url"
      :title="panel.title || copy.iframe"
      sandbox="allow-scripts"
      referrerpolicy="no-referrer"
      loading="lazy"
    />
    <div v-else class="zx-dashboard-widgets__message">{{ copy.blocked }}</div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { widgetProps } from '../props'
import { paramText, safeEmbedUrl } from '../data'
import { widgetCopy } from '../locale'

import type { PropType } from 'vue'

const props = defineProps({
  ...widgetProps,
  allowEmbedUrl: Function as PropType<(url: string) => boolean>,
})
const copy = computed(() => widgetCopy(props.locale))
const url = computed(() => {
  const url = safeEmbedUrl(paramText(props.panel, 'url'))
  if (!url) return undefined
  try {
    return !props.allowEmbedUrl || props.allowEmbedUrl(url) ? url : undefined
  } catch {
    return undefined
  }
})
</script>
