<template>
  <div
    class="zx-dashboard-widgets zx-dashboard-widgets__chart"
    :data-chart-kind="kind"
  >
    <div v-if="!options" class="zx-dashboard-widgets__message">
      {{ panel.data == null ? copy.empty : copy.invalid }}
    </div>
    <div v-else-if="!themeProjection" class="zx-dashboard-widgets__message">
      {{ copy.theme }}
    </div>
    <template v-else>
      <ZxChart
        :options="options"
        :theme-projection="themeProjection"
        :empty-text="copy.empty"
        :loading-text="copy.loading"
        :error-text="copy.invalid"
        :enable-retry="false"
        :aria-label="panel.title || copy[kind]"
        role="img"
      />
      <div v-if="kind === 'gauge'" class="zx-dashboard-widgets__gauge-value">
        {{ valueText }}<small>{{ unit }}</small>
      </div>
      <div v-if="kind === 'gauge'" class="zx-dashboard-widgets__gauge-range">
        <span>{{ paramNumber(panel, 'min', 0) }}</span>
        <span>{{ paramNumber(panel, 'max', 100) }}</span>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { ZxChart } from '@zxio/chart'
import { widgetProps } from '../props'
import { createWidgetChartOptions } from '../chart-options'
import { metricText, paramNumber, paramText, readMetric } from '../data'
import { widgetCopy } from '../locale'

import type { PropType } from 'vue'
import type { WidgetChartKind } from '../chart-options'

const props = defineProps({
  ...widgetProps,
  kind: { type: String as PropType<WidgetChartKind>, required: true },
})
const copy = computed(() => widgetCopy(props.locale))
const options = computed(() =>
  createWidgetChartOptions(props.panel, props.kind)
)
const unit = computed(() => paramText(props.panel, 'unit'))
const valueText = computed(() =>
  metricText(
    readMetric(props.panel.data),
    paramNumber(props.panel, 'decimals', 0),
    props.locale
  )
)
</script>
