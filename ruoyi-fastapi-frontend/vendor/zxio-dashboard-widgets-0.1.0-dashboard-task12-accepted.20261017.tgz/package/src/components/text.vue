<template>
  <div class="zx-dashboard-widgets zx-dashboard-widgets__text">
    <!-- HTML is emitted only by the fixed Markdown parser with raw HTML disabled. -->
    <div
      v-if="panel.params?.format === 'markdown'"
      class="zx-dashboard-widgets__markdown"
      v-html="html"
    />
    <p v-else class="zx-dashboard-widgets__plain">
      {{ content || copy.empty }}
    </p>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { widgetProps } from '../props'
import { paramText } from '../data'
import { widgetCopy } from '../locale'
import { renderWidgetMarkdown } from '../markdown'

const props = defineProps(widgetProps)
const copy = computed(() => widgetCopy(props.locale))
const content = computed(() =>
  typeof props.panel.data === 'string'
    ? props.panel.data
    : paramText(props.panel, 'content')
)
const html = computed(() =>
  renderWidgetMarkdown(content.value || copy.value.empty)
)
</script>
