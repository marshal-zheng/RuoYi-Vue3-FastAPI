import { toValue } from 'vue'
import {
  isBarData,
  isStatusData,
  isTableData,
  isTimeSeries,
  readMetric,
  safeEmbedUrl,
} from './data'
import { widgetCopy } from './locale'

import type {
  DashboardWidgetDefinition,
  DashboardWidgetPlugin,
  DashboardWidgetSettingsField,
} from '@zxio/dashboard/widget'
import type { DashboardWidgetsOptions } from './types'

const chart = () => import('./components/chart.vue')
const components = {
  stat: () => import('./components/stat.vue'),
  gauge: chart,
  'time-series': chart,
  bar: chart,
  table: () => import('./components/table.vue'),
  text: () => import('./components/text.vue'),
  iframe: () => import('./components/iframe.vue'),
  'status-light': () => import('./components/status-light.vue'),
}
type Kind = keyof typeof components
const shapes: Record<Kind, string> = {
  stat: '<text x="20" y="47" font-size="34" fill="currentColor" stroke="none">42</text>',
  gauge: '<path d="M20 50a28 28 0 1 1 56 0M48 44l17-20"/>',
  'time-series': '<path d="M12 52l14-18 12 8 16-28 14 16 16-8"/>',
  bar: '<path d="M20 52V34h12v18M42 52V14h12v38M64 52V24h12v28"/>',
  table: '<path d="M14 14h68v40H14zM14 26h68M14 40h68M38 14v40"/>',
  text: '<path d="M16 16h64M16 28h64M16 40h48M16 52h56"/>',
  iframe:
    '<path d="M12 12h72v44H12zM12 24h72M22 18h2m6 0h2M36 34l-6 6 6 6m24-12 6 6-6 6"/>',
  'status-light':
    '<circle cx="48" cy="34" r="18"/><circle cx="48" cy="34" r="8"/>',
}
const validators = {
  stat: (data: unknown) => readMetric(data) !== undefined,
  gauge: (data: unknown) => readMetric(data) !== undefined,
  'time-series': isTimeSeries,
  bar: isBarData,
  table: isTableData,
  text: (data: unknown) => typeof data === 'string',
  iframe: () => true,
  'status-light': isStatusData,
}

/** A standard registry plugin. Core does not import or automatically install it. */
export function createDashboardWidgets(
  options: DashboardWidgetsOptions
): DashboardWidgetPlugin {
  const locale = options.locale ?? 'en'
  const copy = widgetCopy(locale)
  const field = (
    id: keyof typeof copy,
    type: DashboardWidgetSettingsField['type'],
    defaultValue: string | number | boolean,
    extra: Partial<DashboardWidgetSettingsField> = {}
  ): DashboardWidgetSettingsField => ({
    id,
    type,
    label: copy[id],
    defaultValue,
    ...extra,
  })
  const metric = [
    field('unit', 'string', ''),
    field('decimals', 'number', 0, { validation: { min: 0, max: 6 } }),
  ]
  const settings: Record<Kind, DashboardWidgetSettingsField[]> = {
    stat: [field('label', 'string', ''), ...metric],
    gauge: [field('min', 'number', 0), field('max', 'number', 100), ...metric],
    'time-series': [
      field('legend', 'boolean', true),
      field('smooth', 'boolean', false),
    ],
    bar: [
      field('legend', 'boolean', true),
      field('horizontal', 'boolean', false),
    ],
    table: [
      {
        id: 'showHeader',
        type: 'boolean',
        label: locale === 'zh-CN' ? '显示表头' : 'Show header',
        defaultValue: true,
      },
    ],
    text: [
      field('format', 'enum', 'markdown', {
        options: [
          { value: 'markdown', label: copy.markdown },
          { value: 'plain', label: copy.plain },
        ],
      }),
      field('content', 'text', '', { validation: { maxLength: 100000 } }),
    ],
    iframe: [field('url', 'string', '')],
    'status-light': [field('label', 'string', '')],
  }
  const widgets = (Object.keys(components) as Kind[]).map(
    (kind, order): DashboardWidgetDefinition => ({
      name: `zx.${kind}`,
      title: copy[kind],
      group: copy.group,
      version: '1.0.0',
      order,
      tags: [kind, copy[kind]],
      lifecycle: 'stable',
      component: components[kind],
      minGrid: {
        w: kind === 'stat' || kind === 'status-light' ? 3 : 6,
        h: kind === 'stat' || kind === 'status-light' ? 2 : 4,
      },
      defaultGrid: {
        w: kind === 'time-series' || kind === 'table' ? 12 : 6,
        h: kind === 'stat' || kind === 'status-light' ? 3 : 6,
      },
      defaultPanel: { title: copy[kind] },
      thumbnail: `data:image/svg+xml,${encodeURIComponent(
        `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 96 68" color="#64748b" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round">${shapes[kind]}</svg>`
      )}`,
      settings: { version: '1', fields: settings[kind] },
      resolveProps: (panel) => ({
        panel,
        locale,
        themeProjection: toValue(options.themeProjection),
        ...(kind === 'gauge' || kind === 'time-series' || kind === 'bar'
          ? { kind }
          : {}),
        ...(kind === 'iframe' ? { allowEmbedUrl: options.allowEmbedUrl } : {}),
      }),
      validate: (panel) => {
        const fail = (message: string, path: string) => ({
          severity: 'error' as const,
          code: 'invalid_standard_widget',
          panelId: panel.id,
          path,
          message,
          widget: panel.widget,
        })
        const issues = []
        if (panel.data != null && !validators[kind](panel.data))
          issues.push(fail(copy.invalid, '/data'))
        if (kind === 'gauge') {
          const min = panel.params?.min ?? 0
          const max = panel.params?.max ?? 100
          if (typeof min === 'number' && typeof max === 'number' && min >= max)
            issues.push(
              fail(
                locale === 'zh-CN'
                  ? '最大值必须大于最小值'
                  : 'Maximum must exceed minimum',
                '/params/max'
              )
            )
        }
        if (
          panel.params?.decimals !== undefined &&
          !Number.isInteger(panel.params.decimals)
        )
          issues.push(
            fail(
              locale === 'zh-CN'
                ? '小数位数必须是整数'
                : 'Decimal places must be an integer',
              '/params/decimals'
            )
          )
        if (
          kind === 'iframe' &&
          panel.params?.url &&
          !safeEmbedUrl(panel.params.url)
        )
          issues.push(fail(copy.blocked, '/params/url'))
        return issues
      },
    })
  )
  return { name: 'zx.dashboard-widgets', version: '0.1.0', widgets }
}
