import MarkdownIt from 'markdown-it'

// No raw HTML or plugins. The parser's built-in protocol validator rejects scripts.
const markdown = new MarkdownIt({
  html: false,
  linkify: false,
  typographer: false,
})
// Dashboard text does not initiate image requests from untrusted saved content.
markdown.disable('image')
export function renderWidgetMarkdown(content: string): string {
  return markdown.render(content)
}
