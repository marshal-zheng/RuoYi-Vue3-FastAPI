import '@zxio/chart/style'
import './widgets.css'
