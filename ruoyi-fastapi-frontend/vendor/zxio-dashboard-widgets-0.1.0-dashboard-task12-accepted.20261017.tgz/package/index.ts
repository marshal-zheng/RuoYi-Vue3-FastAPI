export { createDashboardWidgets } from './src/plugin'
export type {
  DashboardWidgetsOptions,
  DashboardWidgetsLocale,
  DashboardMetricData,
  DashboardTimeSeriesData,
  DashboardBarData,
  DashboardTableData,
  DashboardStatusData,
} from './src/types'
