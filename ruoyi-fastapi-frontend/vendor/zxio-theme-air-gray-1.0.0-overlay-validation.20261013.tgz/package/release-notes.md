# Release notes

## 1.0.0

- Add the Slate Theme v4 package with 162 deterministic variants. The
  package id remains `air-gray`.
- Anchor light chrome to a deep blue-grey. Dark canvas is the same blue-grey
  family at a darker depth, with status colors encoded as green, amber, red,
  and cyan.
