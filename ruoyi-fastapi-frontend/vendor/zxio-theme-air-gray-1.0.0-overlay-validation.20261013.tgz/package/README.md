# @zxio/theme-air-gray

Slate is a deep blue-grey Theme v4 package. The package id remains
`air-gray`.

Run `pnpm -C packages/theme-air-gray build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
