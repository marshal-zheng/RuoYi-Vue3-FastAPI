# Release notes

## 1.0.0

- Add the Air Gray Theme v4 package with 162 deterministic variants.
- Anchor light chrome to a screen-safe reconstruction of PLA 07 深蓝灰.
  Dark canvas is the same blue-grey family at command-console depth, with
  aviation-style status encoding (green / amber / red / cyan advisory).
