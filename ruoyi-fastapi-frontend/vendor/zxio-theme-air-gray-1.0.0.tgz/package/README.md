# @zxio/theme-air-gray

Air Gray is a PLA Air Force 07-series 深蓝灰 Theme v4 package. Identity is
the deep blue-grey service uniform, not the ceremonial sky-blue flag bar.

Run `pnpm -C packages/theme-air-gray build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
