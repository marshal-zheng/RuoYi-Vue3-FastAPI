import { Extension as Li } from "@tiptap/core";
import { Plugin as Bo, PluginKey as Mo, NodeSelection as En, TextSelection as rt } from "@tiptap/pm/state";
import { computePosition as Bi, flip as Mi } from "@floating-ui/dom";
import { Y as Di, $ as Ci, a0 as Do, z as Co, a1 as Fi, H as Nt, G as Fo, F as zi, p as Pi, a2 as Vi, A as zo, B as ji, D as Hi } from "./runtime-extensions-BmAczR2S.mjs";
import { am as $i } from "./delivery-surfaces-BeupB41w.mjs";
import { watch as Q, defineAsyncComponent as Ft, defineComponent as ge, inject as vt, computed as E, ref as W, onBeforeUnmount as gt, createBlock as Be, createCommentVNode as le, openBlock as C, unref as h, withCtx as ft, createElementVNode as j, normalizeClass as H, createElementBlock as V, withModifiers as _e, createVNode as P, Fragment as Oe, renderList as Pe, toDisplayString as de, nextTick as pt, useAttrs as jt, shallowRef as Re, onMounted as Lt, mergeProps as Qe, h as zt, provide as bn, normalizeStyle as mt, renderSlot as Me, reactive as Ui, onScopeDispose as Ht, isRef as hn, normalizeProps as bt, guardReactiveProps as ht, toRef as $e, resolveComponent as Ki, toRaw as cn, withKeys as Zn, createTextVNode as qi, withDirectives as Xn, vModelSelect as Gi, vModelText as Wi, toValue as Xe } from "vue";
import { useNamespace as Ne, useOverlayZIndex as Po, useLocale as Ji } from "@zxio/zxui/hooks";
import { ZxIcon as Ie } from "@zxio/zxui/core";
import { ZxTooltipOrPopover as Zt } from "@zxio/zxui/tooltip-or-popover";
import { bB as Sn, bS as Zi, bw as Xi, bu as Yi, bq as Qi, bo as yn, bP as er, bz as tr, bC as nr, bQ as or, bR as Vo, cc as ir, bG as nn, bK as Xt, d as rr, cd as sr, bL as ar, e as jo, g as lr, ce as cr, bE as ur, c as dr, a as fr, r as pr, S as mr, a4 as vr, $ as gr, a3 as br, a0 as hr, l as yr, m as Ho, cf as Yn, c5 as kr, c7 as wr, c0 as xr, c1 as Tr, bZ as Ar, b_ as Ir, c2 as Er, c3 as Sr, j as _r } from "./authoring-action-port-BO658pvW.mjs";
import { useShortcutRuntime as _n, useParentShortcutOwner as $o, useShortcutPresentation as Or, useShortcutOwner as Rr, useShortcutAction as un, useActionView as dn, bindShortcutOwner as Nr } from "@zxio/keybindings/vue";
import { BubbleMenu as Uo, FloatingMenu as Lr } from "@tiptap/vue-3/menus";
import { n as Br, q as Mr, m as Ko, I as qo, f as Dr, H as Qn } from "./inline-ai-shortcut-router-a-QG5h2e.mjs";
import { DecorationSet as ut, Decoration as Cr } from "@tiptap/pm/view";
import { useThemeRuntime as Fr, useThemeScope as zr, useThemeApp as Pr } from "@zxio/zxui/theme-provider";
import { bu as qe, c as eo, bC as Vr, bX as Ye, h as Go, c9 as ct, bh as jr, r as Hr } from "./link-paste-handler-COpsSlXB.mjs";
import * as Wo from "@tiptap/pm/history";
import { Slice as Jo, Fragment as Zo } from "@tiptap/pm/model";
import { E as dt, F as Yt, v as On, b as $r, S as Ur, p as Kr, f as qr } from "./envelope-CrN5-dS1.mjs";
import { c as Gr } from "./stable-block-ids-CPxz-1sA.mjs";
import { buildProps as Wr, definePropType as he, withInstall as Jr } from "@zxio/zxui/runtime";
import { EditorContent as Zr } from "@tiptap/vue-3";
import { dropPoint as Xr } from "@tiptap/pm/transform";
import { DragHandle as Yr } from "@tiptap/extension-drag-handle-vue-3";
import { createPackageTextEditorRuntimeHostEditorV2 as Qr } from "#runtime-host-authority";
import { createActionPort as Xo } from "@zxio/keybindings/core";
import { z as Yo, o as es, q as ts, s as ns, n as os } from "./actions-Sd62WBGv.mjs";
const rd = Li.create(
  {
    name: "floatingQuoteButton",
    addOptions() {
      return {
        onClick: void 0,
        themeOwner: null
      };
    },
    addProseMirrorPlugins() {
      const e = this.options, t = this.editor;
      return [
        new Bo({
          key: new Mo("floatingQuoteButton"),
          view: (o) => new is(o, t, e)
        })
      ];
    }
  }
);
class is {
  constructor(t, o, n) {
    this.button = null, this.binding = null, this.portalGeneration = 0, this.view = t, this.editor = o, this.options = n, this.createButton();
  }
  createButton() {
    this.button = this.view.dom.ownerDocument.createElement("button"), this.button.className = $i("text-editor-quote-button"), this.button.type = "button", this.button.innerHTML = `
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
      </svg>
    `, this.button.style.cssText = `
      position: absolute;
      display: none;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
      border: none;
      border-radius: var(--zx-semantic-radius-control);
      background: var(--zx-semantic-action-focus-ring);
      color: var(--zx-semantic-text-primary);
      cursor: pointer;
      z-index: 100;
      transition: background var(--zx-semantic-motion-duration) ease;
    `, this.button.addEventListener("click", this.handleClick.bind(this)), this.button.addEventListener("mouseenter", () => {
      this.button && (this.button.style.background = "var(--zx-semantic-text-primary)");
    }), this.button.addEventListener("mouseleave", () => {
      this.button && (this.button.style.background = "var(--zx-semantic-action-focus-ring)");
    });
  }
  handleClick() {
    if (!this.options.onClick) return;
    const { from: t, to: o } = this.view.state.selection, n = this.editor.state.doc.textBetween(t, o);
    this.options.onClick(n), this.hide();
  }
  update(t) {
    this.view = t;
    const { state: o } = t, { selection: n } = o, { empty: i } = n;
    if (i || this.editor.isEditable) {
      this.hide();
      return;
    }
    this.show();
  }
  async show() {
    if (!this.button) return;
    if (!this.binding) {
      const f = this.options.themeOwner;
      if (!f) return;
      const l = ++this.portalGeneration, u = await f.acquirePortal();
      if (l !== this.portalGeneration) {
        u.ok && u.value.release();
        return;
      }
      if (!u.ok || !this.button) return;
      this.binding = u.value, this.binding.target.appendChild(this.button);
    }
    const t = this.portalGeneration, { from: o, to: n } = this.view.state.selection, i = this.view.coordsAtPos(o), r = this.view.coordsAtPos(n), s = {
      getBoundingClientRect() {
        return {
          x: i.left,
          y: i.top,
          width: r.right - i.left,
          height: r.bottom - i.top,
          top: i.top,
          right: r.right,
          bottom: r.bottom,
          left: i.left
        };
      }
    }, { x: c, y: a } = await Bi(s, this.button, {
      placement: "top",
      middleware: [Di(4), Mi(), Ci(4)]
    });
    t !== this.portalGeneration || !this.button || !this.binding || (this.button.style.left = `${c}px`, this.button.style.top = `${a}px`, this.button.style.display = "flex");
  }
  hide() {
    var t, o;
    this.portalGeneration += 1, this.button && (this.button.style.display = "none"), (t = this.button) == null || t.remove(), (o = this.binding) == null || o.release(), this.binding = null;
  }
  destroy() {
    var t;
    this.hide(), (t = this.button) == null || t.remove(), this.button = null;
  }
}
const rs = (e, t) => {
  if (!e)
    return t.documentState.value;
  t.hasCommentExtension.value && (t.annotationBridgeState.value = tr(
    e.getJSON(),
    t.annotationBridgeState.value
  ));
  const o = nr(
    t.documentState.value,
    t.annotationBridgeState.value
  ), n = or(e, o, {
    markdownExportMode: t.getMarkdownExportMode()
  });
  return t.documentState.value = n, t.annotationBridgeState.value = Sn(n), n;
}, fn = (e) => Sn(e), ss = (e) => {
  const t = (v = e.editor.value) => rs(v, e), o = (v) => er(v), n = (v) => o({
    documentValue: v,
    contentType: "document",
    stableBlockIdentity: e.getStableBlockIdentityOptions()
  }).document, i = (v) => {
    if (!e.editor.value)
      return !1;
    switch (v.sourceType) {
      case "html":
        return yn(t(e.editor.value)) === v.content;
      case "json":
        return JSON.stringify(e.editor.value.getJSON()) === JSON.stringify(v.content);
      case "markdown":
        return JSON.stringify(t(e.editor.value).body.content) === JSON.stringify(v.document.body.content);
      case "document": {
        const O = n(
          t(e.editor.value)
        ), N = n(
          v.document
        );
        return JSON.stringify(O) === JSON.stringify(N);
      }
    }
  }, r = (v) => {
    e.editor.value && (e.isApplyingExternalContent.value = !0, e.documentState.value = v.document, e.annotationBridgeState.value = Sn(v.document), e.editor.value.commands.setContent(v.content ?? ""), e.isApplyingExternalContent.value = !1);
  }, s = ({
    editor: v,
    document: O,
    outputType: N
  }) => {
    const y = O ?? t(v);
    return Vo(v, {
      outputType: N,
      markdownExportMode: e.getMarkdownExportMode(),
      document: y
    });
  }, c = () => t(e.editor.value), a = () => yn(c()), f = (v = {}) => Qi(c(), {
    mode: v.mode ?? e.getMarkdownExportMode()
  }), l = () => {
    var v;
    return ((v = e.editor.value) == null ? void 0 : v.getJSON()) ?? e.documentState.value.body.content ?? dt().body.content;
  }, u = (v = {}) => Yi(c(), v), p = (v = {}) => Xi(c(), v), g = (v, O = {}) => {
    if (!e.editor.value)
      return;
    const N = O.contentType ?? (Yt(v) ? "document" : typeof v == "string" ? "html" : "json"), y = o({
      baseDocument: e.documentState.value,
      modelValue: v,
      documentValue: N === "document" ? v : void 0,
      content: N === "html" && typeof v == "string" ? v : null,
      contentType: N,
      hydrateAnnotations: e.hasCommentExtension.value,
      stableBlockIdentity: e.getStableBlockIdentityOptions()
    });
    r(y);
  };
  return {
    getCurrentDocument: t,
    resolveHydratedState: o,
    isHydratedStateSynced: i,
    applyHydratedEditorState: r,
    exportEditorContentValue: s,
    getHTML: a,
    getMarkdown: f,
    getJSON: l,
    getDocument: c,
    getText: u,
    getExcerpt: p,
    setContent: g,
    setHTML: (v) => {
      g(v, { contentType: "html" });
    },
    setMarkdown: (v) => {
      g(v, { contentType: "markdown" });
    },
    setJSON: (v) => {
      g(v, { contentType: "json" });
    },
    setDocument: (v) => {
      g(v, { contentType: "document" });
    },
    getRuntimeStatus: () => Zi({
      editor: e.editor.value,
      document: c()
    })
  };
};
let as = 0, ls = 0;
const cs = () => `zx-editor-${++as}`, us = () => `zx-asset-task-${++ls}`, ds = (e) => e.type.startsWith("image/") ? "image" : e.type.startsWith("video/") ? "video" : "file", fs = (e, t) => {
  var i, r, s;
  const o = e.asset.meta ?? {}, n = e.asset.type === "file" ? {
    ...o,
    fileName: ((i = e.asset.meta) == null ? void 0 : i.fileName) ?? e.asset.title ?? t.name,
    size: typeof ((r = e.asset.meta) == null ? void 0 : r.size) == "number" ? (s = e.asset.meta) == null ? void 0 : s.size : t.size
  } : Object.keys(o).length ? o : void 0;
  return {
    ...e,
    asset: {
      ...e.asset,
      mimeType: e.asset.mimeType ?? (t.type ? t.type : void 0),
      title: e.asset.title ?? t.name,
      ...n ? { meta: n } : {}
    }
  };
}, ps = (e) => {
  var o;
  const t = (o = e.body.content) == null ? void 0 : o.content;
  return !Array.isArray(t) || t.length === 0;
}, ms = ({
  editor: e,
  filePlatform: t,
  intakeDispatcher: o,
  getCurrentDocument: n,
  editorId: i = cs()
}) => {
  const r = () => t.value ?? null, s = (p) => {
    var g, T;
    (T = (g = r()) == null ? void 0 : g.onDiagnostic) == null || T.call(g, p);
  }, c = ({
    files: p,
    source: g = "programmatic",
    htmlContent: T,
    dropPos: L = null,
    context: D
  }) => {
    var O;
    const w = e.value, k = w == null ? void 0 : w.state.selection, v = n();
    return {
      source: g,
      files: Array.from(p),
      htmlContent: T,
      dropPos: L,
      selectionFrom: (k == null ? void 0 : k.from) ?? null,
      selectionTo: (k == null ? void 0 : k.to) ?? null,
      editorId: i,
      currentDocumentEmpty: (w == null ? void 0 : w.isEmpty) ?? ps(v),
      context: D,
      constraints: (O = r()) == null ? void 0 : O.constraints
    };
  }, a = async ({
    files: p,
    source: g = "programmatic",
    htmlContent: T,
    dropPos: L = null,
    anchorPos: D = null,
    context: w
  }) => {
    const k = c({
      files: p,
      source: g,
      htmlContent: T,
      dropPos: L,
      context: w
    }), v = o == null ? void 0 : o.value;
    return v ? v.dispatch({
      event: k,
      anchorPos: D
    }) : {
      event: k,
      decision: {
        intent: "reject",
        code: "intake-dispatcher-missing",
        reason: "dispatcher-missing",
        message: "The unified file intake dispatcher is not configured for this editor instance."
      },
      handled: !1
    };
  }, f = (p, g = {}) => ({
    id: us(),
    kind: ds(p),
    status: g.status ?? "queued",
    fileName: p.name,
    mimeType: p.type || "application/octet-stream",
    size: p.size,
    anchorPos: g.anchorPos ?? null,
    previewUrl: g.previewUrl,
    progress: g.progress
  }), l = (p) => {
    var g, T;
    (T = (g = r()) == null ? void 0 : g.onTaskEvent) == null || T.call(g, p);
  };
  return {
    editorId: i,
    getFilePlatform: r,
    emitDiagnostic: s,
    emitTaskEvent: l,
    captureIntakeEvent: c,
    intakeFiles: a,
    createAssetTaskRecord: f,
    uploadAsset: async (p, g = {}) => {
      const T = r();
      if (!(T != null && T.uploadAsset))
        throw new Error("filePlatform.uploadAsset is not provided");
      const L = g.intake ?? c({
        source: g.source,
        files: [p],
        htmlContent: g.htmlContent,
        dropPos: g.dropPos,
        context: g.context
      }), D = g.emitTaskLifecycle ?? !g.task, w = g.task ?? f(p, {
        anchorPos: g.anchorPos,
        previewUrl: g.previewUrl,
        progress: g.progress
      }), k = {
        ...w,
        status: "uploading"
      };
      D && (l({
        type: "task-created",
        intake: L,
        task: w
      }), l({
        type: "task-updated",
        intake: L,
        task: k
      }));
      try {
        const v = fs(
          await T.uploadAsset({
            event: L,
            file: p,
            task: k,
            context: g.context ?? L.context,
            signal: g.signal,
            updateTask: g.updateTask
          }),
          p
        ), O = {
          ...k,
          status: "completed"
        };
        return D && l({
          type: "task-completed",
          intake: L,
          task: O,
          asset: v
        }), v;
      } catch (v) {
        const O = {
          ...k,
          status: "failed",
          errorMessage: v instanceof Error ? v.message : "Unknown error"
        };
        throw D && l({
          type: "task-failed",
          intake: L,
          task: O,
          error: {
            message: O.errorMessage
          }
        }), v;
      }
    }
  };
};
class Ot extends Error {
  constructor(t, o) {
    super(o), this.name = "ZxAssetMaterializationError", this.code = t;
  }
}
const vs = (e, t) => {
  const o = e.state.doc.content.size;
  return typeof t != "number" || !Number.isFinite(t) ? e.state.selection.from : Math.max(0, Math.min(t, o));
}, gs = (e) => typeof e == "string" && e ? e : void 0, bs = (e, t, o) => {
  var i;
  const n = t.nodeKind ?? o;
  if (n === "image") {
    const r = e.schema.nodes.image;
    if (!r)
      throw new Ot(
        "asset-materializer-image-missing",
        "The image extension is not available for asset materialization."
      );
    return r.create({
      assetId: t.asset.id,
      src: t.asset.src,
      title: t.asset.title ?? null,
      alt: gs((i = t.asset.meta) == null ? void 0 : i.alt) ?? t.asset.title ?? null
    });
  }
  if (n === "video") {
    const r = e.schema.nodes.video;
    if (!r)
      throw new Ot(
        "asset-materializer-video-missing",
        "The video extension is not available for asset materialization."
      );
    return r.create({
      assetId: t.asset.id,
      src: t.asset.src
    });
  }
  if (n === "attachment") {
    const r = e.schema.nodes.attachment;
    if (!r)
      throw new Ot(
        "asset-materializer-attachment-missing",
        "The attachment extension is not available for asset materialization."
      );
    return r.create({
      assetId: t.asset.id
    });
  }
  throw new Ot(
    "asset-materializer-node-kind-unsupported",
    `Unsupported asset node kind "${String(n)}".`
  );
}, hs = async ({
  editor: e,
  documentState: t,
  preferredNodeKind: o,
  resolveTaskPosition: n,
  resolvedAsset: i,
  task: r
}) => {
  if (!e)
    throw new Ot(
      "asset-materializer-editor-missing",
      "The editor instance is unavailable for asset materialization."
    );
  const s = bs(e, i, o), c = vs(
    e,
    (n == null ? void 0 : n(r.id)) ?? r.anchorPos
  );
  e.view.dispatch(e.state.tr.insert(c, s)), t.value = dt({
    ...t.value,
    assets: On(t.value.assets, [i.asset])
  });
}, ys = 1, ks = (e) => ({
  ...Object.hasOwn(e, "status") ? { status: e.status } : {},
  ...Object.hasOwn(e, "previewUrl") ? { previewUrl: e.previewUrl } : {},
  ...Object.hasOwn(e, "progress") ? { progress: e.progress } : {},
  ...Object.hasOwn(e, "errorCode") ? { errorCode: e.errorCode } : {},
  ...Object.hasOwn(e, "errorMessage") ? {
    errorMessage: e.errorMessage
  } : {}
}), pn = (e, t) => {
  if (t.type === "set") {
    const o = [...e], n = o.findIndex(
      (i) => i.id === t.task.id
    );
    return n === -1 ? (o.push(t.task), o) : (o.splice(n, 1, t.task), o);
  }
  return t.type === "patch" ? e.map(
    (o) => o.id === t.id ? {
      ...o,
      ...ks(t.patch)
    } : o
  ) : e.filter((o) => o.id !== t.id);
}, ws = () => {
  let e = [];
  const t = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Map(), n = () => {
    const r = {
      tasks: [...e]
    };
    t.forEach((s) => s(r));
  }, i = (r) => e.find((s) => s.id === r) ?? null;
  return {
    getSnapshot: () => ({
      tasks: [...e]
    }),
    getTask: i,
    listTasks: () => [...e],
    patchTask: (r, s) => (e = pn(e, {
      type: "patch",
      id: r,
      patch: s
    }), n(), i(r)),
    registerControls: (r, s) => {
      o.set(r, s);
    },
    removeTask: (r) => {
      o.delete(r), e = pn(e, {
        type: "remove",
        id: r
      }), n();
    },
    retryTask: (r) => {
      var s, c;
      (c = (s = o.get(r)) == null ? void 0 : s.retry) == null || c.call(s);
    },
    setTask: (r) => {
      e = pn(e, {
        type: "set",
        task: r
      }), n();
    },
    subscribe: (r) => (t.add(r), () => {
      t.delete(r);
    }),
    cancelTask: (r) => {
      var s, c;
      (c = (s = o.get(r)) == null ? void 0 : s.cancel) == null || c.call(s);
    },
    requestRemove: (r) => {
      var s, c;
      (c = (s = o.get(r)) == null ? void 0 : s.remove) == null || c.call(s);
    }
  };
}, xs = (e) => {
  if (!(typeof URL > "u" || typeof URL.createObjectURL != "function"))
    try {
      return URL.createObjectURL(e);
    } catch {
      return;
    }
}, Jt = (e) => {
  if (!(!e || typeof URL > "u" || typeof URL.revokeObjectURL != "function"))
    try {
      URL.revokeObjectURL(e);
    } catch {
    }
}, Ts = (e) => e instanceof DOMException || e instanceof Error ? e.name === "AbortError" : !1, As = (e, t) => e instanceof Error && e.message ? e.message : t, Is = ({
  documentState: e,
  editor: t,
  filePlatformRuntime: o,
  maxConcurrentTasks: n = ys
}) => {
  const i = ws(), r = /* @__PURE__ */ new Map(), s = [], c = /* @__PURE__ */ new Set();
  let a = null;
  const f = (w) => i.getTask(w), l = (w, k, v) => {
    const O = i.patchTask(w, k);
    return O ? (o.emitTaskEvent({
      type: "task-updated",
      intake: v,
      task: O
    }), O) : null;
  }, u = (w, k = "Asset task cancelled.") => {
    var m;
    const v = r.get(w), O = i.getTask(w);
    if (!v || !O || ["completed", "cancelled"].includes(O.status))
      return;
    const N = s.indexOf(w);
    N >= 0 && s.splice(N, 1), (m = v.uploadController) == null || m.abort(), v.uploadController = null;
    const y = i.patchTask(w, {
      status: "cancelled",
      errorCode: void 0,
      errorMessage: void 0,
      progress: void 0
    });
    y && o.emitTaskEvent({
      type: "task-cancelled",
      intake: v.event,
      task: y,
      error: {
        message: k
      }
    });
  }, p = (w) => {
    const k = i.getTask(w);
    k && !["failed", "completed", "cancelled"].includes(k.status) && u(w);
    const v = r.get(w);
    Jt(v == null ? void 0 : v.previewUrl), r.delete(w), i.removeTask(w);
  }, g = (w) => {
    const k = r.get(w), v = i.getTask(w);
    !k || !v || !["failed", "cancelled"].includes(v.status) || !l(
      w,
      {
        status: "queued",
        errorCode: void 0,
        errorMessage: void 0,
        progress: void 0
      },
      k.event
    ) || (s.push(w), T());
  }, T = () => {
    for (; c.size < Math.max(1, n) && s.length > 0; ) {
      const w = s.shift();
      !w || c.has(w) || L(w).catch((k) => {
        o.emitDiagnostic({
          code: "asset-task-runner-unhandled",
          message: k instanceof Error ? k.message : "The asset task runner failed unexpectedly.",
          severity: "error",
          stage: "asset-pipeline",
          cause: k
        });
      });
    }
  }, L = async (w) => {
    var N;
    const k = r.get(w), v = i.getTask(w);
    if (!k || !v)
      return;
    c.add(w), k.uploadController = new AbortController(), k.previewUrl || (k.previewUrl = xs(k.file)), l(
      w,
      {
        status: "reading",
        previewUrl: k.previewUrl
      },
      k.event
    );
    const O = l(
      w,
      {
        status: "uploading"
      },
      k.event
    );
    if (!O) {
      c.delete(w), k.uploadController = null;
      return;
    }
    try {
      const y = await o.uploadAsset(
        k.file,
        {
          intake: k.event,
          anchorPos: O.anchorPos,
          previewUrl: k.previewUrl,
          context: {
            ...k.event.context ?? {},
            preferredNodeKind: k.preferredNodeKind,
            ...k.preferredNodeKind ? {
              nodeKind: k.preferredNodeKind
            } : {}
          },
          emitTaskLifecycle: !1,
          signal: k.uploadController.signal,
          task: O,
          updateTask: (ne) => {
            l(w, ne, k.event);
          }
        }
      ), m = i.getTask(w);
      if (!m || m.status === "cancelled") {
        Jt(k.previewUrl);
        return;
      }
      const _ = l(
        w,
        {
          status: "processing",
          progress: 100
        },
        k.event
      );
      if (!_)
        return;
      await hs({
        editor: t.value,
        documentState: e,
        preferredNodeKind: k.preferredNodeKind,
        resolveTaskPosition: a ?? ((ne) => {
          var ie;
          return ((ie = i.getTask(ne)) == null ? void 0 : ie.anchorPos) ?? null;
        }),
        resolvedAsset: y,
        task: _
      });
      const q = i.patchTask(w, {
        status: "completed",
        errorCode: void 0,
        errorMessage: void 0,
        progress: 100
      });
      q && o.emitTaskEvent({
        type: "task-completed",
        intake: k.event,
        task: q,
        asset: y
      }), Jt(k.previewUrl);
    } catch (y) {
      if ((N = k.uploadController) != null && N.signal.aborted || Ts(y)) {
        u(w), Jt(k.previewUrl);
        return;
      }
      const m = i.patchTask(w, {
        status: "failed",
        errorCode: y instanceof Error && "code" in y && typeof y.code == "string" ? y.code : "asset-task-failed",
        errorMessage: As(y, "Asset task failed.")
      });
      m && (o.emitTaskEvent({
        type: "task-failed",
        intake: k.event,
        task: m,
        error: {
          code: m.errorCode,
          message: m.errorMessage ?? "Asset task failed."
        }
      }), o.emitDiagnostic({
        code: m.errorCode ?? "asset-task-failed",
        message: m.errorMessage ?? "Asset task failed.",
        severity: "error",
        stage: y instanceof Ot ? "materialization" : "asset-pipeline",
        intake: k.event,
        task: m,
        cause: y
      }));
    } finally {
      c.delete(w), k.uploadController = null, T();
    }
  };
  return {
    enqueue: ({
      anchorPos: w = null,
      event: k,
      preferredNodeKind: v = null
    }) => k.files.length ? (k.files.forEach((O) => {
      const N = o.createAssetTaskRecord(O, {
        anchorPos: w
      });
      r.set(N.id, {
        event: k,
        file: O,
        preferredNodeKind: v,
        uploadController: null
      }), i.registerControls(N.id, {
        cancel: () => u(N.id),
        remove: () => p(N.id),
        retry: () => g(N.id)
      }), i.setTask(N), o.emitTaskEvent({
        type: "task-created",
        intake: k,
        task: N
      }), s.push(N.id);
    }), T(), !0) : !1,
    getTask: f,
    getTasks: () => i.listTasks(),
    removeTask: p,
    retryTask: g,
    setTaskPositionResolver: (w) => {
      a = w;
    },
    subscribe: (w) => i.subscribe(w),
    cancelTask: (w) => u(w)
  };
};
class _t extends Error {
  constructor(t, o) {
    super(o), this.name = "ZxRemoteEmbedResolutionError", this.code = t;
  }
}
const At = (e) => typeof e == "string" && e.trim().length > 0, Es = (e, t) => {
  const o = e.state.doc.content.size;
  return typeof t != "number" || !Number.isFinite(t) ? null : Math.max(0, Math.min(t, o));
}, Ss = (e) => {
  var n, i, r, s;
  const t = e.asset, o = {
    ...e.attrs ?? {},
    url: e.url
  };
  return t != null && t.id && !At(o.assetId) && (o.assetId = t.id), t != null && t.title && !At(o.title) && (o.title = t.title), At((n = t == null ? void 0 : t.meta) == null ? void 0 : n.name) && !At(o.name) && (o.name = (i = t.meta) == null ? void 0 : i.name), At((r = t == null ? void 0 : t.meta) == null ? void 0 : r.icon) && !At(o.icon) && (o.icon = (s = t.meta) == null ? void 0 : s.icon), o;
}, _s = async ({
  anchorPos: e = null,
  documentState: t,
  editor: o,
  event: n,
  filePlatform: i,
  url: r
}) => {
  if (!(i != null && i.resolveRemoteEmbed))
    throw new _t(
      "remote-embed-resolver-missing",
      "The host platform does not provide resolveRemoteEmbed()."
    );
  if (!o)
    throw new _t(
      "remote-embed-editor-missing",
      "The editor instance is unavailable for remote embed materialization."
    );
  const s = await i.resolveRemoteEmbed({
    event: n,
    url: r,
    htmlContent: n.htmlContent,
    context: n.context
  });
  if (!s)
    throw new _t(
      "remote-embed-unresolved",
      `The host platform declined to resolve remote embed URL "${r}".`
    );
  if (!o.schema.nodes.embed)
    throw new _t(
      "remote-embed-node-missing",
      "The embed extension is not available for remote embed materialization."
    );
  const a = o.chain().focus(), f = Es(o, e);
  if (f !== null && a.setTextSelection(f), !a.insertContent({
    type: "embed",
    attrs: Ss(s)
  }).run())
    throw new _t(
      "remote-embed-materialization-failed",
      `Failed to insert the resolved remote embed for URL "${r}".`
    );
  return s.asset && (t.value = dt({
    ...t.value,
    assets: On(t.value.assets, [s.asset])
  })), {
    handled: !0,
    resolution: s
  };
}, Rn = (e) => typeof window < "u" && e === window, Qo = (e) => typeof e == "function" ? e() ?? null : e ?? null, Os = (e) => [...e].sort((t, o) => {
  const n = typeof t.pos == "number" ? t.pos : Number.MAX_SAFE_INTEGER, i = typeof o.pos == "number" ? o.pos : Number.MAX_SAFE_INTEGER;
  if (n !== i)
    return n - i;
  const r = typeof t.order == "number" ? t.order : 0, s = typeof o.order == "number" ? o.order : 0;
  return r - s;
}), ei = (e) => !!(e.dom && typeof e.dom.getBoundingClientRect == "function" && e.dom.isConnected !== !1), ti = (e, t) => {
  const o = Qo(t);
  if (o)
    return o;
  const n = e.find(ei);
  return n ? ir(n.dom) ?? (typeof window < "u" ? window : null) : typeof window < "u" ? window : null;
}, Rs = (e, t) => {
  const o = Qo(t);
  if (o != null && Number.isFinite(o))
    return Math.max(o, 0);
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return 0;
  const n = Rn(e) ? document.documentElement : e, i = window.getComputedStyle(n), r = Number.parseFloat(i.scrollPaddingTop || "0") || 0, s = Number.parseFloat(i.paddingTop || "0") || 0;
  return Math.max(r || s, 0);
}, Ns = (e, t) => !e || Rn(e) ? t + 1 : e.getBoundingClientRect().top + t + 1, Ls = (e) => {
  if (!e)
    return !1;
  if (!Rn(e))
    return e.scrollHeight <= e.clientHeight + 1 ? !1 : e.scrollTop + e.clientHeight >= e.scrollHeight - 1;
  if (typeof document > "u")
    return !1;
  const t = e.innerHeight || document.documentElement.clientHeight || 0, o = e.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0, n = Math.max(
    document.documentElement.scrollHeight,
    document.body.scrollHeight
  );
  return n <= t + 1 ? !1 : o + t >= n - 1;
}, kn = (e = [], t = {}) => {
  var a, f, l, u;
  const o = Os(e);
  if (o.length === 0)
    return null;
  const n = o.filter(ei);
  if (n.length === 0)
    return ((a = o.find((p) => p.isActive)) == null ? void 0 : a.id) ?? ((f = o[0]) == null ? void 0 : f.id) ?? null;
  const i = ti(
    n,
    t.scrollContainer
  );
  if (Ls(i))
    return ((l = n[n.length - 1]) == null ? void 0 : l.id) ?? null;
  const r = Ns(
    i,
    Rs(i, t.topInset)
  );
  let s = null, c = null;
  for (const p of n) {
    const g = p.dom.getBoundingClientRect();
    g.top <= r && (s = p), !c && g.bottom >= r && (c = p);
  }
  return (s == null ? void 0 : s.id) ?? (c == null ? void 0 : c.id) ?? ((u = n[0]) == null ? void 0 : u.id) ?? null;
}, Bs = (e) => {
  let t = kn(
    e.getHeadings(),
    {
      scrollContainer: e.scrollContainer,
      topInset: e.topInset
    }
  ), o = 0, n = null, i = null;
  const r = /* @__PURE__ */ new Set(), s = () => {
    r.forEach((u) => u(t));
  }, c = () => {
    const u = kn(e.getHeadings(), {
      scrollContainer: e.scrollContainer,
      topInset: e.topInset
    });
    u !== t && (t = u, s());
  }, a = () => {
    o || typeof window > "u" || (o = window.requestAnimationFrame(() => {
      o = 0, c();
    }));
  }, f = () => {
    o && typeof window < "u" && (window.cancelAnimationFrame(o), o = 0), n == null || n(), n = null, i = null;
  }, l = () => {
    if (typeof window > "u")
      return;
    const u = ti(
      e.getHeadings(),
      e.scrollContainer
    );
    if (u === i && n || (f(), !u))
      return;
    i = u;
    const p = window;
    u.addEventListener("scroll", a, {
      passive: !0
    }), p.addEventListener("resize", a), n = () => {
      u.removeEventListener("scroll", a), p.removeEventListener("resize", a);
    };
  };
  return {
    getActiveReadingHeadingId() {
      return t;
    },
    subscribe(u) {
      return r.add(u), l(), () => {
        r.delete(u), r.size === 0 && f();
      };
    },
    refresh() {
      l(), c();
    },
    destroy() {
      r.clear(), f();
    }
  };
}, Ms = (e) => {
  var n;
  const t = (n = e.node) == null ? void 0 : n.attrs, o = t == null ? void 0 : t[Ur];
  return typeof o == "string" && o.length > 0 ? o : null;
}, Ds = (e) => {
  const t = e.dom;
  if (!(t instanceof HTMLElement))
    return null;
  const o = t.getAttribute($r) || t.dataset.blockId;
  return typeof o == "string" && o.length > 0 ? o : null;
}, Rt = (e) => Ds(e) ?? Ms(e) ?? e.id, Cs = (e, t) => e.id === t || Rt(e) === t, Qt = (e) => typeof e == "string" && e.length > 0, to = (e) => {
  if (!e || typeof e != "object")
    return !1;
  const t = e;
  return typeof t.id == "string" && typeof t.pos == "number" && typeof t.textContent == "string" && typeof t.level == "number" && typeof t.itemIndex == "number" && typeof t.dom == "object" && t.dom !== null;
}, Fs = (e) => {
  var t;
  return (t = e == null ? void 0 : e.storage) == null ? void 0 : t.tableOfContents;
}, ni = (e) => {
  const t = Fs(e), o = Array.isArray(t == null ? void 0 : t.content) ? t.content.filter(to) : [];
  return o.length > 0 ? [...o] : Array.isArray(t == null ? void 0 : t.anchors) ? t.anchors.filter(to) : [];
}, Nn = (e, t) => ({
  status: "resolved",
  target: {
    target: e,
    ...t
  }
}), zs = (e, t) => {
  if (!Qt(e.blockId))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = nn(t, e.blockId);
  if (!o)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  const n = Xt(
    t,
    e.blockId,
    e.offset ?? 0
  ) ?? o.pos;
  return Nn(e, {
    key: `block:${e.blockId}`,
    dom: o.dom,
    blockId: e.blockId,
    pos: n,
    selection: {
      from: n,
      to: n
    }
  });
}, Ps = (e, t) => {
  if (!Qt(e.blockId))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = ni(t).find(
    (s) => Cs(s, e.blockId)
  ), n = o ? Rt(o) : e.blockId, i = nn(t, n);
  if (!i)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  const r = Xt(t, n, 0) ?? i.pos;
  return Nn(e, {
    key: `heading:${n}`,
    dom: (o == null ? void 0 : o.dom) ?? i.dom,
    blockId: n,
    pos: (o == null ? void 0 : o.pos) ?? r,
    selection: {
      from: r,
      to: r
    }
  });
}, Vs = (e) => {
  const t = e.anchor.start, o = e.anchor.end;
  return !Qt(t.blockId) || !Qt(o.blockId) || !Number.isFinite(t.offset) || !Number.isFinite(o.offset) || t.offset < 0 || o.offset < 0;
}, js = (e, t) => {
  if (Vs(e))
    return {
      status: "failed",
      reason: "invalid-target"
    };
  if (!t)
    return {
      status: "pending",
      reason: "awaiting-provider"
    };
  const o = e.anchor.start, n = e.anchor.end, i = Xt(
    t,
    o.blockId,
    o.offset
  ), r = Xt(
    t,
    n.blockId,
    n.offset
  );
  if (i === null || r === null)
    return {
      status: "failed",
      reason: "target-unavailable"
    };
  if (r <= i)
    return {
      status: "failed",
      reason: "invalid-target"
    };
  const s = nn(t, o.blockId);
  return Nn(e, {
    key: `range:${o.blockId}:${o.offset}-${n.blockId}:${n.offset}`,
    dom: (s == null ? void 0 : s.dom) ?? null,
    blockId: o.blockId,
    anchor: e.anchor,
    pos: i,
    selection: {
      from: i,
      to: r
    }
  });
}, Hs = (e) => e ? ni(e).map((t) => ({
  key: `heading:${Rt(t)}`,
  kind: "heading",
  label: t.textContent,
  blockId: Rt(t),
  outlineEligible: !0,
  shareable: !0
})) : [], $s = () => [
  {
    kind: "heading",
    resolve: (e, t) => Ps(e, t.editor),
    list: (e) => Hs(e.editor)
  },
  {
    kind: "block",
    resolve: (e, t) => zs(e, t.editor)
  },
  {
    kind: "range",
    resolve: (e, t) => js(e, t.editor)
  }
], Us = (e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((o) => {
    t.has(o.key) || t.set(o.key, o);
  }), [...t.values()];
}, Ks = (e = []) => {
  const t = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Set(), n = (s) => (t.set(s.kind, s), () => {
    t.get(s.kind) === s && t.delete(s.kind);
  }), i = (s) => Array.isArray(s == null ? void 0 : s.kinds) && s.kinds.length > 0 ? [...new Set(s.kinds)] : [...t.keys()], r = (s) => {
    const c = {
      kinds: s
    };
    o.forEach((a) => a(c));
  };
  return e.forEach((s) => {
    n(s);
  }), {
    register: n,
    getProvider(s) {
      return t.get(s) ?? null;
    },
    async resolve(s, c) {
      const a = t.get(s.kind);
      return a ? a.resolve(s, c) : {
        status: "failed",
        reason: "target-unavailable"
      };
    },
    async list(s, c) {
      const a = [];
      for (const f of i(c)) {
        const l = t.get(f);
        if (!(l != null && l.list))
          continue;
        const u = await l.list(s);
        a.push(...u);
      }
      return Us(a);
    },
    invalidate(s) {
      const c = Array.isArray(s) && s.length > 0 ? [...new Set(s)] : [...t.keys()];
      c.forEach((a) => {
        var f, l;
        (l = (f = t.get(a)) == null ? void 0 : f.invalidate) == null || l.call(f);
      }), r(c);
    },
    subscribeInvalidation(s) {
      return o.add(s), () => {
        o.delete(s);
      };
    }
  };
}, qs = [
  "heading",
  "block",
  "range",
  "annotation",
  "bookmark",
  "search-hit",
  "ai-suggestion",
  "presence"
], Gs = (e) => {
  const t = [
    ...e.invalidationKinds ?? qs
  ], o = () => e.editor.value ? Array.from(ur(e.editor.value).values()).filter((_) => _.nodeType === "heading").map((_, q) => ({
    id: _.blockId,
    dom: _.dom,
    pos: _.pos,
    order: q
  })) : [], n = Ks([
    ...$s(),
    lr()
  ]);
  let i = null, r = [];
  const s = Bs({
    getHeadings: o,
    scrollContainer: () => cr(e.rootRef.value) ? e.rootRef.value : null
  }), c = (_) => {
    if (!e.editor.value || !_.resolvedTarget.selection || _.request.focusMode !== "editor" || e.editor.value.isEditable === !1)
      return;
    const q = e.editor.value.state.doc.content.size, ne = Math.min(
      Math.max(_.resolvedTarget.selection.from, 0),
      q
    ), ie = Math.min(
      Math.max(_.resolvedTarget.selection.to, 0),
      q
    ), ee = typeof _.resolvedTarget.pos == "number" ? e.editor.value.state.doc.nodeAt(
      _.resolvedTarget.pos
    ) : null, B = ne === ie && ee && (ee.isAtom || ee.isLeaf) ? En.create(e.editor.value.state.doc, ne) : ne === ie ? rt.near(e.editor.value.state.doc.resolve(ne)) : rt.create(e.editor.value.state.doc, ne, ie);
    e.editor.value.view.dispatch(
      e.editor.value.state.tr.setSelection(B)
    );
  }, a = rr({
    resolver: async (_, q) => n.resolve(_.target, {
      ...q,
      editor: e.editor.value,
      annotations: e.documentState.value.annotations
    }),
    descriptorReader: async (_, q) => n.list(
      {
        ..._,
        editor: e.editor.value,
        annotations: e.documentState.value.annotations
      },
      q
    ),
    observer: s,
    executor: async (_) => (c(_), sr(_))
  });
  let f = 0;
  const l = () => {
    var _;
    if (typeof window > "u") {
      a.retryDeferredNavigation(), (_ = s.refresh) == null || _.call(s);
      return;
    }
    f || (f = window.requestAnimationFrame(() => {
      var q;
      f = 0, a.retryDeferredNavigation(), (q = s.refresh) == null || q.call(s);
    }));
  }, u = () => {
    n.invalidate(t), l();
  }, p = () => {
    i == null || i(), i = null, r.forEach((ne) => ne()), r = [];
    const _ = e.getBookmarkProvider();
    _ && (i = n.register(_));
    const q = e.getEphemeralProviders();
    Array.isArray(q) && (r = q.map(
      (ne) => n.register(ne)
    )), u();
  };
  Q(
    () => [e.getBookmarkProvider(), e.getEphemeralProviders()],
    () => {
      p();
    },
    {
      immediate: !0
    }
  );
  const g = (_) => a.navigate(_), T = () => {
    a.cancel();
  }, L = () => a.getSnapshot(), D = () => jo(a.getSnapshot()), w = (_) => a.listDescriptors(_), k = (_) => a.syncFromLocation(_), v = (_) => a.createShareableFragment(_), O = (_) => e.editor.value ? ar(e.editor.value, _) : null, N = (_, q = {}) => !e.editor.value || !nn(e.editor.value, _) ? !1 : (a.navigate({
    source: "external-api",
    target: {
      kind: "block",
      blockId: _
    },
    align: q.align,
    behavior: q.scrollBehavior,
    focusMode: q.focus === !1 ? "preserve" : "editor",
    history: "none",
    reason: "legacy-block-navigation"
  }), !0);
  return {
    navigationController: a,
    scheduleNavigationRefresh: l,
    refreshNavigationRuntime: u,
    syncEditorNavigationBridge: () => {
      if (!e.editor.value)
        return;
      const _ = e.editor.value;
      _.navigationController = a, _.navigate = g, _.cancelNavigation = T, _.getNavigationSnapshot = L, _.getNavigationDebugSnapshot = D, _.listNavigationDescriptors = w, _.syncNavigationFromLocation = k, _.createShareableFragment = v, _.navigateToBlock = N;
    },
    destroy: () => {
      f && typeof window < "u" && (window.cancelAnimationFrame(f), f = 0), i == null || i(), i = null, r.forEach((_) => _()), r = [], a.destroy();
    },
    navigateToBlock: N,
    navigate: g,
    cancelNavigation: T,
    getNavigationSnapshot: L,
    getNavigationDebugSnapshot: D,
    listNavigationDescriptors: w,
    syncNavigationFromLocation: k,
    createShareableFragment: v,
    getBlockElement: O
  };
}, Ws = {
  "insert.link": Ft(
    () => import("./insert-link-CFJ1N_EA.mjs")
  ),
  "insert.image": Ft(
    () => Promise.resolve().then(() => yl)
  ),
  "insert.video": Ft(
    () => import("./insert-video-yY1AMgig.mjs")
  ),
  "insert.iframe": Ft(
    () => import("./InsertIframe-Cx9V6UDn.mjs")
  ),
  "table.menu": Ft(
    () => import("./table-menu-B5YRXsHk.mjs")
  )
}, oi = (e = {}) => dr({
  ...e,
  renderers: { ...Ws, ...e.renderers }
}), Js = [
  "fixed-menu",
  "bubble-menu",
  "floating-menu"
], sd = {
  id: "document-workbench-toolbar-platform",
  package: "@zxio/text-editor",
  role: "toolbar-engine",
  owns: [
    "editor-command-truth",
    "toolbar-state-snapshots",
    "editor-toolbar-contributions",
    "toolbar-surface-contracts"
  ],
  doesNotOwn: ["workbench-layout", "shell-actions", "host-product-semantics"],
  legacyCompat: {
    menuModel: "MenuButton/MenuButtonConfig",
    surfaces: Js,
    status: "removed",
    replacementSurfaces: ["workbench-top", "bubble", "floating"]
  }
}, ii = (e) => {
  const t = [], o = /* @__PURE__ */ new Map();
  for (const n of e) {
    const i = Math.max(0, n.width), r = o.get(n.groupId);
    if (r == null) {
      o.set(n.groupId, t.length), t.push({
        id: n.groupId,
        width: i,
        itemIds: [n.id],
        priority: n.priority
      });
      continue;
    }
    const s = t[r];
    s.width += i, s.itemIds.push(n.id), s.priority = Math.min(s.priority, n.priority);
  }
  return t;
}, Zs = (e) => {
  const t = e.items.filter((l) => l.width >= 0);
  if (t.length === 0 || e.containerWidth <= 0)
    return {
      visibleIds: [],
      overflowIds: t.map((l) => l.id)
    };
  const o = ii(t);
  if (o.length === 0)
    return { visibleIds: [], overflowIds: [] };
  if (o.reduce((l, u) => l + u.width, 0) <= e.containerWidth)
    return {
      visibleIds: o.flatMap((l) => l.itemIds),
      overflowIds: []
    };
  const i = Math.max(0, e.moreButtonWidth), r = Math.max(0, e.containerWidth - i), s = [];
  let c = 0;
  for (const l of o) {
    if (c + l.width <= r) {
      s.push(l), c += l.width;
      continue;
    }
    break;
  }
  s.length === 0 && o[0].width <= r && s.push(o[0]);
  const a = new Set(s.flatMap((l) => l.itemIds)), f = t.map((l) => l.id).filter((l) => !a.has(l));
  return {
    visibleIds: [...a],
    overflowIds: f
  };
}, Xs = (e) => {
  const t = e.items.filter((u) => u.width >= 0);
  if (t.length === 0 || e.containerWidth <= 0)
    return e.overflowIds.length === t.length;
  const o = ii(t);
  if (o.length === 0)
    return e.overflowIds.length === 0;
  const n = new Set(e.overflowIds);
  let i = o.length;
  for (let u = 0; u < o.length; u += 1) {
    const p = o[u];
    if (p.itemIds.some((T) => n.has(T))) {
      if (!p.itemIds.every((T) => n.has(T)))
        return !1;
      i = u;
      break;
    }
  }
  for (let u = i; u < o.length; u += 1)
    if (!o[u].itemIds.every((g) => n.has(g)))
      return !1;
  const s = o.slice(0, i).reduce((u, p) => u + p.width, 0), c = o.reduce((u, p) => u + p.width, 0);
  if (i === o.length)
    return c <= e.containerWidth;
  const a = Math.max(0, e.moreButtonWidth), f = Math.max(0, e.containerWidth - a);
  if (s > f)
    return !1;
  const l = o[i];
  return s + l.width > f;
}, ri = Symbol(
  "basicRichTextFieldContext"
), Ys = (e, t) => qe(e, {
  ...t,
  characters: Number.MAX_SAFE_INTEGER,
  bytes: Number.MAX_SAFE_INTEGER,
  nodes: Number.MAX_SAFE_INTEGER
}), Qs = Object.freeze([
  {
    skillId: "improve-writing",
    label: "Improve writing",
    commandId: "improve-writing",
    description: "Clarify and strengthen the selected text"
  },
  {
    skillId: "proofread",
    label: "Proofread",
    commandId: "proofread",
    description: "Fix grammar and spelling"
  },
  {
    skillId: "explain",
    label: "Explain",
    commandId: "explain",
    description: "Explain the selected text"
  },
  {
    skillId: "reformat",
    label: "Reformat",
    commandId: "reformat",
    description: "Reformat the selected text"
  }
]), ea = Object.freeze([
  {
    id: "continue-writing",
    label: "Continue writing",
    commandId: "continue-writing",
    parameters: Object.freeze({}),
    icon: "lucide:pen-line"
  },
  {
    id: "draft-outline",
    label: "Draft an outline",
    commandId: "draft-outline",
    parameters: Object.freeze({}),
    icon: "lucide:list-tree"
  },
  {
    id: "brainstorm-ideas",
    label: "Brainstorm ideas",
    commandId: "brainstorm-ideas",
    parameters: Object.freeze({}),
    icon: "lucide:lightbulb"
  }
]), wn = (e) => e === "brewing" ? { kind: "close-presentation" } : e === "reviewing" ? { kind: "dismiss-review-ui" } : e === "skills" || e === "user-input" || e === "selection-bubble" ? { kind: "close-idle" } : { kind: "noop" }, ta = [
  {
    id: Br,
    label: "Ask AI",
    shortcutBindingId: "textEditor.askAI.open"
  }
], na = ["aria-label", "aria-haspopup", "aria-expanded"], oa = /* @__PURE__ */ ge({
  name: "ZxDragHandle",
  __name: "drag-handle",
  props: {
    editor: {},
    showPlus: { type: Boolean },
    onPlusClick: { type: Function },
    askAIBridge: {}
  },
  setup(e) {
    const t = e, o = Ne("drag-handle"), n = vt("editor", null), i = E(() => t.editor ?? (n == null ? void 0 : n.value) ?? null), r = W(-1), s = W(null), c = W(!1), a = W(null), f = W([]), l = W(null), u = W(!1), p = {
      duration: 100,
      offset: [0, 0],
      zIndex: 99
    }, g = ta, { text: T } = Do({
      runtime: () => {
        var S;
        return (S = Co(i.value)) == null ? void 0 : S.runtime;
      },
      bindingId: "textEditor.askAI.open"
    }), L = E(() => t.askAIBridge ?? null), D = (S) => {
      r.value = S.pos, s.value = S.node, S.node || m();
    }, w = () => {
      var J;
      const S = (J = s.value) == null ? void 0 : J.attrs, U = S == null ? void 0 : S.blockId;
      return typeof U == "string" && U.length > 0 ? U : null;
    }, k = () => {
      var fe;
      const S = i.value;
      if (!S) return;
      const U = r.value;
      if (U < 0 || !s.value) return;
      const J = U + s.value.nodeSize;
      S.chain().focus().insertContentAt(J, { type: "paragraph" }).focus(J + 1).run(), (fe = t.onPlusClick) == null || fe.call(t), m();
    }, v = () => {
      l.value = null, u.value = !1;
    }, O = () => {
      u.value = !0, l.value && (l.value.exceeded = !0), m();
    }, N = (S) => {
      var J;
      if (!L.value) return;
      l.value = {
        pointerId: S.pointerId,
        x: S.clientX,
        y: S.clientY,
        exceeded: !1
      }, u.value = !1;
      const U = S.currentTarget;
      if (U instanceof HTMLElement) {
        (J = U.setPointerCapture) == null || J.call(U, S.pointerId);
        const fe = (ce) => {
          const ue = l.value;
          if (!ue || ue.pointerId !== ce.pointerId) return;
          const De = ce.clientX - ue.x, we = ce.clientY - ue.y;
          (Math.hypot(De, we) > Mr || u.value) && (ue.exceeded = !0, m());
        }, G = (ce) => {
          var ue;
          (ue = U.releasePointerCapture) == null || ue.call(U, ce.pointerId), U.removeEventListener("pointermove", fe), U.removeEventListener("pointerup", G), U.removeEventListener("pointercancel", G);
        };
        U.addEventListener("pointermove", fe), U.addEventListener("pointerup", G), U.addEventListener("pointercancel", G);
      }
    }, y = async () => {
      var S;
      L.value && (c.value = !0, await pt(), (S = f.value[0]) == null || S.focus());
    }, m = () => {
      c.value = !1;
    }, _ = (S) => {
      if (!L.value) return;
      const U = l.value;
      if (!U || U.pointerId !== S.pointerId) return;
      const J = !U.exceeded && !u.value && S.button === 0;
      v(), J && y();
    }, q = (S) => {
      L.value && (S.preventDefault(), S.stopPropagation());
    }, ne = (S) => {
      L.value && (S.key === "Enter" || S.key === " " ? (S.preventDefault(), y()) : S.key === "Escape" && m());
    }, ie = () => {
      const S = L.value;
      if (!S) return;
      const U = w();
      S.openInvocation({
        surface: "block-handle",
        ...U ? { blockIds: [U] } : {}
      }), m();
    }, ee = (S) => {
      var U;
      S.key === "Escape" ? (S.preventDefault(), m()) : S.key === "Enter" || S.key === " " ? (S.preventDefault(), ie()) : (S.key === "ArrowDown" || S.key === "ArrowUp") && (S.preventDefault(), (U = f.value[0]) == null || U.focus());
    }, B = (S) => {
      var J;
      if (!c.value) return;
      const U = S.target;
      U instanceof Node && ((J = a.value) != null && J.contains(U) || m());
    }, R = (S) => {
      S.key === "Escape" && c.value && m();
    };
    return Q(c, (S) => {
      typeof document > "u" || (S ? (document.addEventListener("pointerdown", B, !0), document.addEventListener("keydown", R, !0)) : (document.removeEventListener("pointerdown", B, !0), document.removeEventListener("keydown", R, !0)));
    }), gt(() => {
      typeof document > "u" || (document.removeEventListener("pointerdown", B, !0), document.removeEventListener("keydown", R, !0));
    }), (S, U) => i.value ? (C(), Be(h(Yr), {
      key: 0,
      editor: i.value,
      "tippy-options": p,
      "on-node-change": D
    }, {
      default: ft(() => [
        j("div", {
          class: H(h(o).b()),
          onDragstart: O
        }, [
          e.showPlus ? (C(), V("button", {
            key: 0,
            type: "button",
            class: H(h(o).e("btn")),
            "aria-label": "insert block",
            onMousedown: U[0] || (U[0] = _e(() => {
            }, ["prevent", "stop"])),
            onClick: _e(k, ["prevent", "stop"])
          }, [
            P(h(Ie), { icon: "lucide:plus" })
          ], 34)) : le("", !0),
          j("button", {
            type: "button",
            class: H([
              h(o).e("btn"),
              h(o).e("grip"),
              h(o).is("menu-enabled", !!L.value)
            ]),
            "aria-label": L.value ? "block actions" : "drag handle",
            "aria-haspopup": L.value ? "menu" : void 0,
            "aria-expanded": L.value ? c.value : void 0,
            onPointerdown: N,
            onPointerup: _,
            onPointercancel: v,
            onClick: q,
            onKeydown: ne
          }, [
            P(h(Ie), { icon: "lucide:grip-vertical" })
          ], 42, na),
          c.value && L.value ? (C(), V("div", {
            key: 1,
            ref_key: "menuRef",
            ref: a,
            class: H(h(o).e("menu")),
            role: "menu",
            "aria-label": "Block actions"
          }, [
            (C(!0), V(Oe, null, Pe(h(g), (J) => (C(), V("button", {
              key: J.id,
              ref_for: !0,
              ref_key: "menuItemRefs",
              ref: f,
              type: "button",
              class: H(h(o).e("menu-item")),
              role: "menuitem",
              onClick: _e(ie, ["stop"]),
              onKeydown: ee
            }, [
              j("span", null, de(J.label), 1),
              j("kbd", {
                class: H(h(o).e("shortcut"))
              }, de(h(T)), 3)
            ], 34))), 128))
          ], 2)) : le("", !0)
        ], 34)
      ]),
      _: 1
    }, 8, ["editor"])) : le("", !0);
  }
}), ia = 8, no = (e) => !!(e && typeof e == "object" && typeof e.on == "function" && typeof e.off == "function"), ra = (e, t) => {
  if (e.size !== t.size)
    return !1;
  for (const o of e)
    if (!t.has(o))
      return !1;
  return !0;
}, sa = (e) => {
  const t = [];
  let o = [];
  const n = () => {
    o.length !== 0 && (t.push(o), o = []);
  };
  for (const i of e) {
    if (i.definition.kind === "separator") {
      n();
      continue;
    }
    if (i.definition.kind === "spacer") {
      n(), t.push([i]);
      continue;
    }
    o.push(i);
  }
  return n(), t;
}, He = (e) => {
  e.preventDefault();
}, oo = (e) => e.kind === "dropdown", mn = (e) => e.kind === "select", io = (e) => e.kind === "color", ro = (e) => e.kind === "split-button", xn = (e, t) => e == null || t == null ? e == null && t == null : e === t || String(e) === String(t), aa = (e, t) => e.find((o) => xn(o.value, t)) ?? null, la = (e) => !!(e && (typeof e == "object" || typeof e == "function" && ("setup" in e || "render" in e || "__asyncLoader" in e))), ca = (e) => typeof e == "function" && !la(e), Ln = /* @__PURE__ */ ge({
  name: "TextEditorToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    surface: {
      type: String,
      default: "workbench-top"
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    }
  },
  setup(e) {
    const t = Ne("text-editor-toolbar"), {
      text: o
    } = Fi(), n = jt(), i = vt("editor", null), r = E(() => e.editor ?? (i == null ? void 0 : i.value) ?? null), {
      binding: s
    } = Nt(e.themeOwner), c = Re(null), a = Re(null), f = Re(eo()), l = W(""), u = W(null), p = W(null), g = W(null), T = W(null), L = W(/* @__PURE__ */ new Set()), D = W(!1);
    let w = null, k = null, v = !1, O = !1, N = !1, y = !1;
    const m = E(() => e.surface === "workbench-top"), _ = (d) => {
      c.value = fr({
        contributions: [...e.includeDefaultContribution ? [oi()] : [], ...pr(d), ...e.contributions]
      });
    }, q = (d) => [...d.capabilities].sort().join("|"), ne = (d) => {
      var z;
      const I = ((z = c.value) == null ? void 0 : z.resolveState(d)) ?? eo();
      return f.value = I, I;
    }, ie = (d, I = ne(d)) => {
      var z;
      a.value = ((z = c.value) == null ? void 0 : z.prepareSurface(e.surface, {
        editor: d,
        state: I
      })) ?? {
        surface: e.surface,
        items: []
      }, l.value = q(I);
    }, ee = () => {
      const d = r.value, I = ne(d);
      (!a.value || a.value.surface !== e.surface || l.value !== q(I)) && ie(d, I);
    }, B = () => {
      N || (N = !0, Promise.resolve().then(() => {
        N = !1, !y && ee();
      }));
    }, R = (d) => {
      no(d) && (d.off("selectionUpdate", B), d.off("transaction", B));
    }, S = (d) => {
      no(d) && (d.on("selectionUpdate", B), d.on("transaction", B));
    };
    Q(r, (d, I) => {
      R(I), S(d), _(d), ie(d);
    }, {
      immediate: !0
    }), Q(() => [e.includeDefaultContribution, e.contributions], () => {
      _(r.value), ie(r.value);
    }, {
      deep: !0
    }), Q(() => e.surface, () => {
      ie(r.value);
    }), gt(() => {
      y = !0, k == null || k.disconnect(), k = null, R(r.value);
    });
    const U = E(() => {
      var d;
      return (a.value && ((d = c.value) == null ? void 0 : d.resolvePreparedSurface(a.value, {
        editor: r.value,
        state: f.value
      }))) ?? {
        surface: e.surface,
        state: f.value,
        items: []
      };
    }), J = E(() => sa(U.value.items)), fe = (d, I) => {
      var z;
      return ((z = d[0]) == null ? void 0 : z.definition.id) ?? `group-${I}`;
    }, G = (d, I) => {
      const z = d.querySelector(`[data-overflow-group="${I}"]`);
      return Math.max(0, (z == null ? void 0 : z.getBoundingClientRect().width) ?? 0);
    }, ce = (d) => {
      const I = T.value;
      return I ? I.getBoundingClientRect().width + (Number.parseFloat(window.getComputedStyle(I).marginLeft) || 0) + (Number.parseFloat(d.columnGap) || 0) : 0;
    }, ue = E(() => U.value.items.map((d) => {
      const I = d.resolved.value == null ? "" : String(d.resolved.value), z = d.definition.label ?? "";
      return `${d.definition.id}:${d.definition.kind}:${I}:${z}`;
    }).join("|")), De = (d = {}) => {
      if (!m.value || v || y) {
        d.force && (O = !0);
        return;
      }
      d.force && (O = !0), v = !0, pt(() => {
        requestAnimationFrame(() => {
          if (v = !1, y || !m.value) {
            O = !1;
            return;
          }
          const I = p.value, z = g.value, X = J.value, ae = O;
          if (O = !1, !I || !z || X.length === 0) {
            L.value.size > 0 && (L.value = /* @__PURE__ */ new Set()), w = null;
            return;
          }
          const Ee = window.getComputedStyle(I), Je = (Number.parseFloat(Ee.paddingLeft) || 0) + (Number.parseFloat(Ee.paddingRight) || 0), wt = Math.max(0, I.getBoundingClientRect().width - Je);
          if (!ae && w != null && Math.abs(wt - w) < 1)
            return;
          const on = X.flatMap((Ut, Bt) => {
            const Mt = fe(Ut, Bt), sn = G(z, Mt);
            return Ut.map((Tt, Kt) => ({
              id: Tt.definition.id,
              width: Kt === 0 ? sn : 0,
              groupId: Mt,
              priority: Tt.definition.priority ?? Bt * 100
            }));
          }), $t = {
            containerWidth: Math.max(0, wt - ia),
            moreButtonWidth: ce(Ee),
            items: on
          }, rn = [...L.value];
          if (Xs({
            ...$t,
            overflowIds: rn
          }) && !ae) {
            w = wt;
            return;
          }
          const nt = Zs($t), xt = new Set(nt.overflowIds);
          ra(xt, L.value) || (L.value = xt), w = wt, xt.size === 0 && (D.value = !1);
        });
      });
    };
    Lt(() => {
      !m.value || typeof ResizeObserver > "u" || (k = new ResizeObserver((d) => {
        De({
          force: d.some((I) => I.target !== p.value)
        });
      }), p.value && k.observe(p.value), T.value && k.observe(T.value), De());
    }), Q(() => [m.value, ue.value], ([d]) => {
      if (!d) {
        L.value = /* @__PURE__ */ new Set(), D.value = !1, w = null;
        return;
      }
      k && p.value && k.observe(p.value), De({
        force: !0
      });
    }), Q(p, (d, I) => {
      k && (I && k.unobserve(I), d && m.value && (k.observe(d), De()));
    }), Q(T, (d, I) => {
      k && (I && k.unobserve(I), d && k.observe(d));
    });
    const we = () => ({
      editor: r.value,
      snapshot: f.value
    }), Ge = (d, I) => {
      u.value = I ? d : u.value === d ? null : u.value;
    }, ve = () => {
      u.value = null;
    }, Le = (d) => o(d.definition.id, d.definition.label ?? d.definition.id), Ae = (d) => o(`option:${d.id}`, d.label), oe = (d) => {
      if (!mn(d.definition))
        return Le(d);
      const I = aa(d.definition.options, d.resolved.value);
      return I ? Ae(I) : d.resolved.value != null ? String(d.resolved.value) : Le(d);
    }, be = (d) => d ? typeof d == "string" ? P(Ie, {
      icon: d,
      class: t.e("button-icon")
    }, null) : zt(d, {
      class: t.e("button-icon")
    }) : null, re = (d, I) => typeof I == "boolean" ? I : !!d.definition.icon && (d.definition.kind === "action" || d.definition.kind === "toggle" || d.definition.kind === "color" || d.definition.kind === "custom"), Ve = (d, I = {}) => {
      const z = re(d, I.iconOnly), X = I.label ?? Le(d);
      return P(Oe, null, [!I.hideIcon && d.definition.icon ? P("span", {
        class: t.e("button-icon-shell"),
        "aria-hidden": "true"
      }, [be(d.definition.icon)]) : null, z ? null : P("span", {
        class: t.e("button-label")
      }, [X]), I.showCaret ? P("span", {
        class: t.e("button-caret"),
        "aria-hidden": "true"
      }, [P(Ie, {
        icon: "lucide:chevron-down"
      }, null)]) : null, d.resolved.indicatorColor ? P("span", {
        class: t.e("button-indicator"),
        style: {
          backgroundColor: d.resolved.indicatorColor
        },
        "aria-hidden": "true"
      }, null) : null]);
    }, Ue = (d, I = {}) => P(Oe, null, [P("span", {
      class: t.e("button-icon-shell"),
      "aria-hidden": "true"
    }, [be(d.definition.icon), d.resolved.indicatorColor ? P("span", {
      class: t.e("button-indicator"),
      style: {
        backgroundColor: d.resolved.indicatorColor
      }
    }, null) : null]), P("span", {
      class: t.e("menu-item-label")
    }, [I.label ?? Le(d)]), I.value ? P("span", {
      class: t.e("menu-item-value")
    }, [I.value]) : null, I.showCaret ? P("span", {
      class: t.e("button-caret"),
      "aria-hidden": "true"
    }, [P(Ie, {
      icon: "lucide:chevron-right"
    }, null)]) : null]), at = async (d) => {
      await mr(d.definition, {
        ...we(),
        surface: e.surface,
        capabilities: U.value.state.capabilities
      });
    }, yt = async (d, I) => {
      var z, X;
      oo(d.definition) && (await ((X = (z = d.definition).onOptionSelect) == null ? void 0 : X.call(z, I, we())), ve());
    }, We = async (d, I) => {
      if (mn(d.definition)) {
        await d.definition.onValueChange(I, we()), ve();
        return;
      }
      io(d.definition) && (await d.definition.onValueChange(typeof I == "string" ? I : null, we()), ve());
    }, lt = async (d) => {
      if (!ro(d.definition)) {
        await at(d);
        return;
      }
      await d.definition.runPrimary(we());
    }, et = (d, I = {}) => {
      const z = I.active ?? d.resolved.active, X = I.disabled ?? d.resolved.disabled, ae = I.presentation === "menu", Ee = !ae && re(d, I.iconOnly), Je = !!I.showCaret;
      return P("button", {
        key: d.definition.id,
        type: "button",
        class: [t.e(ae ? "menu-item" : "button"), I.class, z && "is-active", X && "is-disabled", u.value === d.definition.id && "is-open"],
        disabled: X,
        title: [Le(d), I.shortcut].filter(Boolean).join(" · "),
        "aria-keyshortcuts": I.shortcutAriaLabel || void 0,
        "aria-label": Le(d),
        "aria-haspopup": Je ? "menu" : void 0,
        "aria-expanded": Je ? u.value === d.definition.id : void 0,
        "aria-pressed": d.definition.kind === "toggle" ? z ? "true" : "false" : void 0,
        "data-item-id": d.definition.id,
        "data-kind": d.definition.kind,
        "data-icon-only": ae ? void 0 : Ee ? "true" : "false",
        "data-has-caret": ae ? void 0 : Je ? "true" : "false",
        onMousedown: He,
        onClick: I.onClick
      }, [ae ? Ue(d, {
        label: I.label,
        value: I.value,
        showCaret: I.showCaret
      }) : Ve(d, {
        label: I.label,
        iconOnly: Ee,
        showCaret: I.showCaret,
        hideIcon: I.hideIcon
      })]);
    }, kt = (d) => d === "menu" ? "right-start" : "bottom-start", tt = (d, I, z = {}) => {
      var X;
      return zt(Zt, {
        key: d.definition.id,
        visible: u.value === d.definition.id,
        variant: "popover",
        trigger: "click",
        placement: kt(z.presentation ?? "toolbar"),
        offset: 6,
        // ElPopover defaults to 150px; color grid needs ~256px+.
        width: "auto",
        popperClass: t.e("popover"),
        persistent: !1,
        disabled: !s.value,
        appendTo: (X = s.value) == null ? void 0 : X.target,
        "onUpdate:visible": (ae) => {
          Ge(d.definition.id, ae);
        }
      }, {
        default: () => et(d, {
          label: z.label,
          value: z.value,
          iconOnly: z.iconOnly,
          hideIcon: z.hideIcon,
          presentation: z.presentation,
          showCaret: !0
        }),
        content: () => P("div", {
          class: t.e("menu"),
          onMousedown: He
        }, [I])
      });
    }, ye = (d, I, z = {}) => P("button", {
      type: "button",
      class: [t.e("menu-item"), (z.active ?? !1) && "is-active", I.disabled && "is-disabled"],
      disabled: I.disabled,
      "data-option-id": I.id,
      onMousedown: He,
      onClick: z.onClick
    }, [P("span", {
      class: t.e("menu-item-label")
    }, [Ae(I)])]), x = (d, I) => {
      if (d.definition.kind !== "custom")
        return null;
      if (ca(d.definition.render)) {
        const z = d.definition.render;
        return P("div", {
          key: d.definition.id,
          class: t.e("custom"),
          "data-item-id": d.definition.id
        }, [z({
          editor: r.value,
          snapshot: U.value.state,
          item: d.definition
        })]);
      }
      return P("div", {
        key: d.definition.id,
        class: t.e("custom"),
        "data-item-id": d.definition.id
      }, [zt(d.definition.render, {
        key: d.definition.id,
        editor: r.value
      }, {
        default: (z) => et(d, {
          presentation: I,
          disabled: z == null ? void 0 : z.disabled,
          shortcut: z == null ? void 0 : z.shortcut,
          shortcutAriaLabel: z == null ? void 0 : z.shortcutAriaLabel,
          active: typeof (z == null ? void 0 : z.isActive) == "boolean" ? z.isActive : d.resolved.active,
          onClick: () => {
            if (typeof (z == null ? void 0 : z.onClick) == "function") {
              z.onClick();
              return;
            }
            at(d);
          }
        })
      })]);
    }, A = (d, I = "toolbar") => {
      var z;
      if (d.definition.kind === "separator")
        return null;
      if (d.definition.kind === "spacer")
        return P("span", {
          key: d.definition.id,
          class: t.e("spacer"),
          "data-item-id": d.definition.id,
          "aria-hidden": "true"
        }, null);
      if (d.definition.kind === "custom")
        return x(d, I);
      if (oo(d.definition))
        return tt(d, P("div", {
          class: t.e("menu-list")
        }, [d.definition.options.map((X) => ye(d, X, {
          active: X.id === d.resolved.value,
          onClick: () => {
            yt(d, X.id);
          }
        }))]), {
          presentation: I
        });
      if (mn(d.definition)) {
        const X = d.definition.includeResetOption !== !1;
        return tt(
          d,
          P("div", {
            class: t.e("menu-list")
          }, [X ? P("button", {
            type: "button",
            class: [t.e("menu-item"), d.resolved.value == null && "is-active"],
            onMousedown: He,
            onClick: () => {
              We(d, null);
            }
          }, [P("span", {
            class: t.e("menu-item-label")
          }, [o("panel:default", "Default")])]) : null, d.definition.options.map((ae) => ye(d, ae, {
            active: xn(ae.value, d.resolved.value),
            onClick: () => {
              We(d, ae.value ?? null);
            }
          }))]),
          // The track shows the current value in place of the name; a menu
          // row keeps the name and trails the value.
          I === "menu" ? {
            presentation: I,
            value: d.resolved.value != null ? oe(d) : null
          } : {
            label: oe(d)
          }
        );
      }
      if (io(d.definition))
        return tt(d, P("div", {
          class: t.e("color-panel")
        }, [P("button", {
          type: "button",
          class: [t.e("color-clear"), d.resolved.value == null && "is-active"],
          onMousedown: He,
          onClick: () => {
            We(d, null);
          }
        }, [P("span", {
          class: t.e("menu-item-label")
        }, [o("panel:clear-color", "Clear color")])]), P("div", {
          class: t.e("color-grid")
        }, [d.definition.options.map((X) => P("button", {
          type: "button",
          class: [t.e("color-swatch"), xn(X.value, d.resolved.value) && "is-active"],
          title: Ae(X),
          "aria-label": Ae(X),
          style: {
            backgroundColor: X.swatch
          },
          onMousedown: He,
          onClick: () => {
            We(d, X.value ?? null);
          }
        }, null))]), d.definition.allowCustomValue ? P("label", {
          class: t.e("color-picker")
        }, [P("span", {
          class: t.e("color-picker-label")
        }, [o("panel:custom", "Custom")]), P("input", {
          type: "color",
          value: typeof d.resolved.value == "string" ? d.resolved.value : "#000000",
          onMousedown: He,
          onInput: (X) => {
            We(d, X.target.value);
          }
        }, null)]) : null]), {
          presentation: I
        });
      if (ro(d.definition)) {
        const X = d.definition;
        return P("div", {
          key: X.id,
          class: [t.e("split-button"), d.resolved.active && "is-active", d.resolved.disabled && "is-disabled"]
        }, [et(d, {
          presentation: I,
          label: X.primaryAction.label ?? Le(d),
          onClick: () => {
            lt(d);
          }
        }), zt(Zt, {
          visible: u.value === X.id,
          variant: "popover",
          trigger: "click",
          placement: kt(I),
          offset: 6,
          width: "auto",
          popperClass: t.e("popover"),
          persistent: !1,
          disabled: !s.value,
          appendTo: (z = s.value) == null ? void 0 : z.target,
          "onUpdate:visible": (ae) => {
            Ge(X.id, ae);
          }
        }, {
          default: () => P("button", {
            type: "button",
            class: [t.e("split-caret"), d.resolved.disabled && "is-disabled"],
            "aria-label": `${Le(d)} options`,
            disabled: d.resolved.disabled,
            onMousedown: He
          }, [P("span", {
            class: t.e("button-caret"),
            "aria-hidden": "true"
          }, [P(Ie, {
            icon: I === "menu" ? "lucide:chevron-right" : "lucide:chevron-down"
          }, null)])]),
          content: () => P("div", {
            class: t.e("menu"),
            onMousedown: He
          }, [P("div", {
            class: t.e("menu-list")
          }, [X.options.map((ae) => ye(d, ae, {
            onClick: () => {
              var Ee;
              (Ee = X.onOptionSelect) == null || Ee.call(X, ae.id, we()), ve();
            }
          }))])])
        })]);
      }
      return et(d, {
        presentation: I,
        onClick: () => {
          at(d), I === "menu" && (D.value = !1);
        }
      });
    }, K = (d) => m.value && d.some((I) => L.value.has(I.definition.id)), Y = E(() => J.value.filter((d) => d.some((I) => L.value.has(I.definition.id)))), se = (d, I, z = {
      includeLeadingSeparator: !0
    }) => {
      const X = fe(d, I), ae = z.includeLeadingSeparator !== !1;
      return P("div", {
        key: X,
        class: [t.e("group"), K(d) && "is-overflowed"],
        "data-group-index": I,
        "data-overflow-group": X
      }, [ae && I > 0 ? P("span", {
        class: t.e("separator"),
        "aria-hidden": "true"
      }, null) : null, d.map((Ee) => A(Ee))]);
    }, xe = (d) => {
      const I = d.definition;
      return I.kind === "separator" || I.kind === "spacer" ? null : P("div", {
        key: `overflow-${I.id}`,
        class: t.e("overflow-entry"),
        "data-overflow-item-id": I.id
      }, [A(d, "menu")]);
    }, Fe = () => {
      var I;
      if (!m.value)
        return null;
      const d = Y.value.length === 0;
      return zt(Zt, {
        visible: D.value,
        variant: "popover",
        trigger: "click",
        placement: "bottom-end",
        offset: 6,
        width: "auto",
        popperClass: t.e("popover"),
        persistent: !1,
        disabled: d || !s.value,
        appendTo: (I = s.value) == null ? void 0 : I.target,
        "onUpdate:visible": (z) => {
          D.value = z;
        }
      }, {
        default: () => P("button", {
          ref: T,
          type: "button",
          class: [t.e("button"), t.e("more-button"), d && "is-idle", D.value && "is-open"],
          "aria-hidden": d ? "true" : void 0,
          tabindex: d ? -1 : void 0,
          title: "More",
          "aria-label": o("panel:more", "More toolbar actions"),
          "aria-haspopup": "menu",
          "aria-expanded": D.value ? "true" : "false",
          "data-icon-only": "true",
          "data-has-caret": "false",
          onMousedown: He
        }, [P("span", {
          class: t.e("button-icon-shell"),
          "aria-hidden": "true"
        }, [P(Ie, {
          icon: "lucide:ellipsis",
          class: t.e("button-icon")
        }, null)])]),
        content: () => P("div", {
          class: [t.e("menu"), t.e("overflow-panel")],
          role: "menu",
          onMousedown: He
        }, [Y.value.map((z, X) => P("div", {
          key: `overflow-group-${fe(z, X)}`,
          class: t.e("overflow-section")
        }, [X > 0 ? P("div", {
          class: t.e("overflow-section-divider"),
          "aria-hidden": "true"
        }, null) : null, z.map((ae) => xe(ae))]))])
      });
    };
    return () => {
      const d = r.value, I = U.value.items;
      if (!d || I.length === 0)
        return null;
      const z = J.value;
      if (z.length === 0)
        return null;
      const X = Object.fromEntries(Object.entries(n).filter(([ae]) => ae !== "class" && ae !== "style"));
      return m.value ? P("div", Qe({
        ref: p,
        class: [t.b(), n.class],
        style: n.style,
        "data-surface": e.surface,
        "data-overflow": "true"
      }, X), [P("div", {
        ref: g,
        class: t.e("track")
      }, [z.map((ae, Ee) => se(ae, Ee))]), Fe()]) : P("div", Qe({
        class: [t.b(), n.class],
        style: n.style,
        "data-surface": e.surface
      }, X), [z.map((ae, Ee) => se(ae, Ee))]);
    };
  }
}), so = ["image", "iframe", "video", "imageGroup", "codeBlock", "horizontalRule"], ua = (e) => {
  var o;
  if (!e || typeof e != "object") return !1;
  const t = (o = e.toJSON) == null ? void 0 : o.call(e);
  return (t == null ? void 0 : t.type) === "nodeRange";
}, da = Object.freeze({
  strategy: "fixed",
  placement: "top-start",
  offset: 8,
  flip: Object.freeze({
    fallbackPlacements: ["bottom-start"]
  }),
  shift: Object.freeze({
    padding: 8,
    crossAxis: !0
  })
}), fa = ({
  state: e
}) => {
  var n, i;
  const {
    selection: t
  } = e;
  if (t.empty || ua(t))
    return !1;
  if (t instanceof En) {
    const r = t.node;
    if (r && so.includes(r.type.name))
      return !1;
  }
  const o = (i = (n = t.$from) == null ? void 0 : n.node) == null ? void 0 : i.call(n, t.$from.depth);
  return !(o && so.includes(o.type.name));
}, pa = /* @__PURE__ */ ge({
  name: "TextEditorBubbleToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    },
    options: {
      type: Object,
      default: () => ({})
    },
    shouldShow: {
      type: Function,
      default: null
    }
  },
  setup(e) {
    const t = Ne("text-editor-bubble-menu"), o = jt(), n = vt("editor", null), i = E(() => e.editor ?? (n == null ? void 0 : n.value) ?? null), {
      binding: r
    } = Nt(e.themeOwner), s = W(!1), c = Po(s), a = () => {
      s.value = !0, typeof e.options.onShow == "function" && e.options.onShow();
    }, f = () => {
      s.value = !1, typeof e.options.onHide == "function" && e.options.onHide();
    };
    return () => {
      const l = i.value, u = r.value;
      if (!l || !u)
        return null;
      const p = Object.fromEntries(Object.entries(o).filter(([g]) => g !== "class" && g !== "style"));
      return (
        // TipTap removes/reparents its menu element. Keep a Vue-owned root so
        // toggling the toolbar (for example on readonly) has a stable anchor.
        P("div", {
          style: {
            display: "contents"
          }
        }, [P(Uo, Qe({
          editor: l,
          shouldShow: e.shouldShow ?? fa,
          options: {
            ...da,
            ...e.options,
            onShow: a,
            onHide: f
          },
          appendTo: () => u.target,
          class: [t.b(), o.class],
          style: {
            zIndex: c.value
          }
        }, p), {
          default: () => [P(Ln, {
            themeOwner: e.themeOwner,
            editor: l,
            surface: "bubble",
            contributions: e.contributions,
            includeDefaultContribution: e.includeDefaultContribution,
            style: o.style
          }, null)]
        })])
      );
    };
  }
}), ma = (e) => typeof e == "object" && e !== null && !Array.isArray(e), ao = (e) => typeof e == "string" || ma(e), va = Wr({
  contentProfile: { type: String, values: ["full", "basic-rich-text"], default: "full" },
  contentLimits: { type: he(Object), default: void 0 },
  /**
   * @description Frozen Runtime-derived owner for every editor overlay and feedback surface.
   */
  themeOwner: {
    type: he(Object),
    default: void 0
  },
  /**
   * @description Editor content (deprecated HTML import bridge alias)
   */
  content: {
    type: String,
    default: null
  },
  /**
   * @description v-model binding value for explicit HTML import, Markdown, or JSON modes
   */
  modelValue: {
    type: he([String, Object]),
    default: ""
  },
  /**
   * @description Explicit input content type. Prefer `document` or `markdown`; `html` is import-only bridge mode.
   */
  contentType: {
    type: String,
    values: ["html", "markdown", "json", "document"],
    default: "html"
  },
  /**
   * @description Explicit output content type
   */
  outputType: {
    type: String,
    values: ["html", "markdown", "json", "document"],
    default: "html"
  },
  /**
   * @description Markdown export mode
   */
  markdownExportMode: {
    type: String,
    values: ["semantic"],
    default: "semantic"
  },
  /**
   * @description Canonical document envelope value (preferred persistence contract)
   */
  documentValue: {
    type: he(Object),
    default: null
  },
  /**
   * @description Placeholder text or function (supports Tiptap's node-based placeholder)
   * @example
   * // Static placeholder
   * placeholder="Write something..."
   * // Dynamic placeholder based on node type
   * :placeholder="({ node }) => node.type.name === 'heading' ? 'Enter title...' : 'Write something...'"
   */
  placeholder: {
    type: he([String, Function]),
    default: void 0
  },
  /**
   * @description Placeholder contract for structured block-level defaults (Notion-style headings, lists, etc.)
   */
  placeholderContract: {
    type: he(Object),
    default: null
  },
  /**
   * @description Custom class for editor content area
   */
  editorClass: {
    type: he([
      String,
      Array,
      Object
    ]),
    default: ""
  },
  /**
   * @description Effective typography contract override for root and block defaults
   */
  typography: {
    type: he(Object),
    default: null
  },
  /**
   * @description Whether the editor is editable
   */
  editable: {
    type: Boolean,
    default: !0
  },
  /**
   * @description Whether to autofocus on mount
   */
  autofocus: {
    type: Boolean,
    default: !1
  },
  /**
   * @description Selection bubble toolbar. Mounted by default; pass `false`
   * when the host composes its own bubble surface.
   */
  bubbleToolbar: {
    type: he([Boolean, Object]),
    default: !0
  },
  /**
   * @description Drag handle configuration
   */
  dragHandle: {
    type: he([Boolean, Object]),
    default: !1
  },
  /**
   * @description Additional TipTap extensions
   */
  extensions: {
    type: he(Array),
    default: () => []
  },
  /**
   * @description Stable block identity configuration
   */
  stableBlockIdentity: {
    type: he(Object),
    default: () => ({})
  },
  /**
   * @description Collaboration mode model emit strategy
   */
  collaborationEmit: {
    type: he(String),
    values: ["none", "html", "markdown", "json", "document", "delta"],
    default: "none"
  },
  /**
   * @description StarterKit configuration options
   */
  starterkitOptions: {
    type: he(Object),
    default: () => ({})
  },
  /**
   * @description Optional editor-only Pages layout engine config. Disabled unless an object is provided.
   */
  pagesLayout: {
    type: he([
      Boolean,
      Object
    ]),
    default: !1
  },
  /**
   * @description Optional Pages header/footer contract and command layer. Disabled unless an object is provided.
   */
  pagesHeaderFooter: {
    type: he([
      Boolean,
      Object
    ]),
    default: !1
  },
  /**
   * @description Mention configuration
   */
  mentions: {
    type: he([Array, Object]),
    default: null
  },
  /**
   * @description Tag suggestions
   */
  tags: {
    type: he(Array),
    default: () => []
  },
  /**
   * @description Suggestion runtime configuration for mention, tag, emoji, and slash triggers
   */
  suggestions: {
    type: he(Object),
    default: () => ({})
  },
  /**
   * @description Formal Slash Catalog Contribution/merge entries (e.g. platform Ask AI).
   */
  slashCatalogContributions: {
    type: he(Array),
    default: () => []
  },
  /**
   * @description Formal host contract for the file intake and asset platform.
   * Use this as the long-term integration boundary for classify/import/upload/
   * resolve/policy/openNew/task hooks.
   */
  filePlatform: {
    type: he(Object),
    default: null
  },
  /**
   * @description Host-provided bookmark navigation source for shareable bookmark navigation and deep-link recovery. Use `createBookmarkNavigationProvider({ getBookmarks })`.
   */
  bookmarkProvider: {
    type: he(Object),
    default: void 0
  },
  /**
   * @description Host-provided ephemeral navigation sources such as search hits, AI suggestions, or collaborator follow. These targets participate in controller navigation but never enter the shareable URL contract.
   */
  ephemeralProviders: {
    type: he(Array),
    default: void 0
  },
  /**
   * @description Host-owned code block preferences. These never enter document JSON; they only influence new code block defaults and local authoring UI ordering.
   */
  codeBlockPreferences: {
    type: he(Object),
    default: null
  }
}), ga = {
  "content-issue": (e) => !0,
  /**
   * @description Emitted when content changes
   */
  change: (e) => ao(e),
  /**
   * @description v-model update event
   */
  "update:modelValue": (e) => ao(e),
  /**
   * @description Document envelope update event
   */
  "update:documentValue": (e) => Yt(e),
  /**
   * @description Emitted when the document envelope changes
   */
  "document-change": (e) => Yt(e),
  /**
   * @description Emitted when editor gains focus
   */
  focus: (e) => e instanceof FocusEvent,
  /**
   * @description Emitted when editor loses focus
   */
  blur: (e) => e instanceof FocusEvent,
  /**
   * @description Emitted on every editor transaction
   */
  transaction: (e) => !0,
  /**
   * @description Emitted when collaboration delta strategy is enabled
   */
  delta: (e) => Array.isArray(e == null ? void 0 : e.steps) && typeof (e == null ? void 0 : e.version) == "number"
}, ba = (e, t, o) => {
  switch (t) {
    case "none":
    case "delta":
      return;
    case "html":
    case "markdown":
    case "json":
    case "document":
      return Vo(e, {
        outputType: t,
        document: o
      });
  }
}, ha = Object.freeze([
  ".md",
  ".markdown",
  ".html",
  ".htm",
  ".json",
  ".txt"
]), It = (e, t, o) => ({
  intent: "reject",
  code: e,
  reason: t,
  message: o
}), ya = (e) => {
  const t = e.lastIndexOf(".");
  return t < 0 ? "" : e.slice(t).toLowerCase();
}, ka = (e) => e.trim().toLowerCase() === "readme", wa = (e) => {
  var t, o;
  return (o = (t = e.constraints) == null ? void 0 : t.importExtensions) != null && o.length ? e.constraints.importExtensions.map(
    (n) => n.toLowerCase()
  ) : [...ha];
}, xa = (e, t) => {
  const o = ya(e.name);
  if (!t.includes(o))
    return ka(e.name) || e.type === "text/markdown" ? "markdown" : e.type === "text/html" ? "html" : e.type === "application/json" || e.type === "text/json" ? "json" : e.type === "text/plain" ? "text" : null;
  switch (o) {
    case ".md":
    case ".markdown":
      return "markdown";
    case ".html":
    case ".htm":
      return "html";
    case ".json":
      return "json";
    case ".txt":
      return "text";
    default:
      return null;
  }
}, Ta = (e) => e.type.startsWith("image/") ? "image" : e.type.startsWith("video/") ? "video" : "file", Aa = (e) => {
  var i;
  const t = (i = e.context) == null ? void 0 : i.remoteUrl;
  if (typeof t == "string" && /^https?:\/\//i.test(t))
    return t;
  const o = e.htmlContent;
  if (!o)
    return null;
  const n = o.match(/\b(?:src|href)=["'](https?:\/\/[^"']+)["']/i);
  return (n == null ? void 0 : n[1]) ?? null;
}, Ia = (e, t, o) => ({
  event: e,
  decision: t,
  handled: o
}), Ea = async ({
  event: e,
  filePlatform: t
}) => {
  var l, u, p, g, T, L;
  const o = Aa(e);
  if ((u = (l = e.constraints) == null ? void 0 : l.allowedSources) != null && u.length && !e.constraints.allowedSources.includes(e.source))
    return It(
      "source-not-allowed",
      "source-rejected",
      `File intake source "${e.source}" is not allowed by the current platform policy.`
    );
  const n = (p = e.constraints) != null && p.maxFileSizeBytes ? e.files.find(
    (D) => D.size > e.constraints.maxFileSizeBytes
  ) : null;
  if (n)
    return It(
      "file-too-large",
      "size-rejected",
      `File "${n.name}" exceeds the maximum allowed size.`
    );
  const i = await ((g = t == null ? void 0 : t.classify) == null ? void 0 : g.call(t, e));
  if (i)
    return i;
  if (e.files.length === 0)
    return o ? {
      intent: "embed-remote",
      url: o
    } : It(
      "empty-intake",
      "no-files",
      "The intake event did not contain files or a resolvable remote URL."
    );
  const r = wa(e), s = e.files.map(
    (D) => xa(D, r)
  ), c = s.filter(
    (D) => !!D
  );
  if (c.length > 0 && c.length !== e.files.length)
    return It(
      "mixed-intents-not-supported",
      "mixed-intents",
      "A single intake event cannot mix import-content files with attachment files."
    );
  if (c.length > 0)
    return e.files.length > 1 ? It(
      "multiple-import-files-not-supported",
      "multiple-import-files",
      "A single intake event cannot import more than one text file at a time."
    ) : {
      intent: "import-content",
      format: s[0] ?? void 0
    };
  const a = (L = (T = e.constraints) == null ? void 0 : T.allowedMimeTypes) != null && L.length ? e.files.find(
    (D) => {
      var w, k;
      return !!D.type && !((k = (w = e.constraints) == null ? void 0 : w.allowedMimeTypes) != null && k.includes(D.type));
    }
  ) : null;
  if (a)
    return It(
      "mime-not-allowed",
      "mime-rejected",
      `File "${a.name}" is not allowed by the current MIME policy.`
    );
  const f = Array.from(
    new Set(e.files.map((D) => Ta(D)))
  );
  return {
    intent: "attach-asset",
    assetKind: f.length === 1 ? f[0] : void 0
  };
}, it = (e, t, o) => Ia(e, t, o), Sa = (e) => {
  var o;
  const t = (o = e.body.content) == null ? void 0 : o.content;
  return !Array.isArray(t) || t.length === 0;
}, _a = (e) => e.source === "drop" || e.source === "paste", Oa = async ({
  currentDocument: e,
  event: t,
  file: o,
  filePlatform: n,
  format: i
}) => {
  var s;
  if (Sa(e))
    return "replace-current";
  const r = await ((s = n == null ? void 0 : n.chooseImportDisposition) == null ? void 0 : s.call(n, {
    event: t,
    file: o,
    format: i,
    currentDocument: e
  }));
  return r || (_a(t) ? "insert-at-selection" : "cancel");
};
function Ra(e, t = !1) {
  const o = e.length;
  let n = 0, i = "", r = 0, s = 16, c = 0, a = 0, f = 0, l = 0, u = 0;
  function p(v, O) {
    let N = 0, y = 0;
    for (; N < v; ) {
      let m = e.charCodeAt(n);
      if (m >= 48 && m <= 57)
        y = y * 16 + m - 48;
      else if (m >= 65 && m <= 70)
        y = y * 16 + m - 65 + 10;
      else if (m >= 97 && m <= 102)
        y = y * 16 + m - 97 + 10;
      else
        break;
      n++, N++;
    }
    return N < v && (y = -1), y;
  }
  function g(v) {
    n = v, i = "", r = 0, s = 16, u = 0;
  }
  function T() {
    let v = n;
    if (e.charCodeAt(n) === 48)
      n++;
    else
      for (n++; n < e.length && Et(e.charCodeAt(n)); )
        n++;
    if (n < e.length && e.charCodeAt(n) === 46)
      if (n++, n < e.length && Et(e.charCodeAt(n)))
        for (n++; n < e.length && Et(e.charCodeAt(n)); )
          n++;
      else
        return u = 3, e.substring(v, n);
    let O = n;
    if (n < e.length && (e.charCodeAt(n) === 69 || e.charCodeAt(n) === 101))
      if (n++, (n < e.length && e.charCodeAt(n) === 43 || e.charCodeAt(n) === 45) && n++, n < e.length && Et(e.charCodeAt(n))) {
        for (n++; n < e.length && Et(e.charCodeAt(n)); )
          n++;
        O = n;
      } else
        u = 3;
    return e.substring(v, O);
  }
  function L() {
    let v = "", O = n;
    for (; ; ) {
      if (n >= o) {
        v += e.substring(O, n), u = 2;
        break;
      }
      const N = e.charCodeAt(n);
      if (N === 34) {
        v += e.substring(O, n), n++;
        break;
      }
      if (N === 92) {
        if (v += e.substring(O, n), n++, n >= o) {
          u = 2;
          break;
        }
        switch (e.charCodeAt(n++)) {
          case 34:
            v += '"';
            break;
          case 92:
            v += "\\";
            break;
          case 47:
            v += "/";
            break;
          case 98:
            v += "\b";
            break;
          case 102:
            v += "\f";
            break;
          case 110:
            v += `
`;
            break;
          case 114:
            v += "\r";
            break;
          case 116:
            v += "	";
            break;
          case 117:
            const m = p(4);
            m >= 0 ? v += String.fromCharCode(m) : u = 4;
            break;
          default:
            u = 5;
        }
        O = n;
        continue;
      }
      if (N >= 0 && N <= 31)
        if (Pt(N)) {
          v += e.substring(O, n), u = 2;
          break;
        } else
          u = 6;
      n++;
    }
    return v;
  }
  function D() {
    if (i = "", u = 0, r = n, a = c, l = f, n >= o)
      return r = o, s = 17;
    let v = e.charCodeAt(n);
    if (vn(v)) {
      do
        n++, i += String.fromCharCode(v), v = e.charCodeAt(n);
      while (vn(v));
      return s = 15;
    }
    if (Pt(v))
      return n++, i += String.fromCharCode(v), v === 13 && e.charCodeAt(n) === 10 && (n++, i += `
`), c++, f = n, s = 14;
    switch (v) {
      // tokens: []{}:,
      case 123:
        return n++, s = 1;
      case 125:
        return n++, s = 2;
      case 91:
        return n++, s = 3;
      case 93:
        return n++, s = 4;
      case 58:
        return n++, s = 6;
      case 44:
        return n++, s = 5;
      // strings
      case 34:
        return n++, i = L(), s = 10;
      // comments
      case 47:
        const O = n - 1;
        if (e.charCodeAt(n + 1) === 47) {
          for (n += 2; n < o && !Pt(e.charCodeAt(n)); )
            n++;
          return i = e.substring(O, n), s = 12;
        }
        if (e.charCodeAt(n + 1) === 42) {
          n += 2;
          const N = o - 1;
          let y = !1;
          for (; n < N; ) {
            const m = e.charCodeAt(n);
            if (m === 42 && e.charCodeAt(n + 1) === 47) {
              n += 2, y = !0;
              break;
            }
            n++, Pt(m) && (m === 13 && e.charCodeAt(n) === 10 && n++, c++, f = n);
          }
          return y || (n++, u = 1), i = e.substring(O, n), s = 13;
        }
        return i += String.fromCharCode(v), n++, s = 16;
      // numbers
      case 45:
        if (i += String.fromCharCode(v), n++, n === o || !Et(e.charCodeAt(n)))
          return s = 16;
      // found a minus, followed by a number so
      // we fall through to proceed with scanning
      // numbers
      case 48:
      case 49:
      case 50:
      case 51:
      case 52:
      case 53:
      case 54:
      case 55:
      case 56:
      case 57:
        return i += T(), s = 11;
      // literals and unknown symbols
      default:
        for (; n < o && w(v); )
          n++, v = e.charCodeAt(n);
        if (r !== n) {
          switch (i = e.substring(r, n), i) {
            case "true":
              return s = 8;
            case "false":
              return s = 9;
            case "null":
              return s = 7;
          }
          return s = 16;
        }
        return i += String.fromCharCode(v), n++, s = 16;
    }
  }
  function w(v) {
    if (vn(v) || Pt(v))
      return !1;
    switch (v) {
      case 125:
      case 93:
      case 123:
      case 91:
      case 34:
      case 58:
      case 44:
      case 47:
        return !1;
    }
    return !0;
  }
  function k() {
    let v;
    do
      v = D();
    while (v >= 12 && v <= 15);
    return v;
  }
  return {
    setPosition: g,
    getPosition: () => n,
    scan: t ? k : D,
    getToken: () => s,
    getTokenValue: () => i,
    getTokenOffset: () => r,
    getTokenLength: () => n - r,
    getTokenStartLine: () => a,
    getTokenStartCharacter: () => r - l,
    getTokenError: () => u
  };
}
function vn(e) {
  return e === 32 || e === 9;
}
function Pt(e) {
  return e === 10 || e === 13;
}
function Et(e) {
  return e >= 48 && e <= 57;
}
var lo;
(function(e) {
  e[e.lineFeed = 10] = "lineFeed", e[e.carriageReturn = 13] = "carriageReturn", e[e.space = 32] = "space", e[e._0 = 48] = "_0", e[e._1 = 49] = "_1", e[e._2 = 50] = "_2", e[e._3 = 51] = "_3", e[e._4 = 52] = "_4", e[e._5 = 53] = "_5", e[e._6 = 54] = "_6", e[e._7 = 55] = "_7", e[e._8 = 56] = "_8", e[e._9 = 57] = "_9", e[e.a = 97] = "a", e[e.b = 98] = "b", e[e.c = 99] = "c", e[e.d = 100] = "d", e[e.e = 101] = "e", e[e.f = 102] = "f", e[e.g = 103] = "g", e[e.h = 104] = "h", e[e.i = 105] = "i", e[e.j = 106] = "j", e[e.k = 107] = "k", e[e.l = 108] = "l", e[e.m = 109] = "m", e[e.n = 110] = "n", e[e.o = 111] = "o", e[e.p = 112] = "p", e[e.q = 113] = "q", e[e.r = 114] = "r", e[e.s = 115] = "s", e[e.t = 116] = "t", e[e.u = 117] = "u", e[e.v = 118] = "v", e[e.w = 119] = "w", e[e.x = 120] = "x", e[e.y = 121] = "y", e[e.z = 122] = "z", e[e.A = 65] = "A", e[e.B = 66] = "B", e[e.C = 67] = "C", e[e.D = 68] = "D", e[e.E = 69] = "E", e[e.F = 70] = "F", e[e.G = 71] = "G", e[e.H = 72] = "H", e[e.I = 73] = "I", e[e.J = 74] = "J", e[e.K = 75] = "K", e[e.L = 76] = "L", e[e.M = 77] = "M", e[e.N = 78] = "N", e[e.O = 79] = "O", e[e.P = 80] = "P", e[e.Q = 81] = "Q", e[e.R = 82] = "R", e[e.S = 83] = "S", e[e.T = 84] = "T", e[e.U = 85] = "U", e[e.V = 86] = "V", e[e.W = 87] = "W", e[e.X = 88] = "X", e[e.Y = 89] = "Y", e[e.Z = 90] = "Z", e[e.asterisk = 42] = "asterisk", e[e.backslash = 92] = "backslash", e[e.closeBrace = 125] = "closeBrace", e[e.closeBracket = 93] = "closeBracket", e[e.colon = 58] = "colon", e[e.comma = 44] = "comma", e[e.dot = 46] = "dot", e[e.doubleQuote = 34] = "doubleQuote", e[e.minus = 45] = "minus", e[e.openBrace = 123] = "openBrace", e[e.openBracket = 91] = "openBracket", e[e.plus = 43] = "plus", e[e.slash = 47] = "slash", e[e.formFeed = 12] = "formFeed", e[e.tab = 9] = "tab";
})(lo || (lo = {}));
new Array(20).fill(0).map((e, t) => " ".repeat(t));
const St = 200;
new Array(St).fill(0).map((e, t) => `
` + " ".repeat(t)), new Array(St).fill(0).map((e, t) => "\r" + " ".repeat(t)), new Array(St).fill(0).map((e, t) => `\r
` + " ".repeat(t)), new Array(St).fill(0).map((e, t) => `
` + "	".repeat(t)), new Array(St).fill(0).map((e, t) => "\r" + "	".repeat(t)), new Array(St).fill(0).map((e, t) => `\r
` + "	".repeat(t));
var en;
(function(e) {
  e.DEFAULT = {
    allowTrailingComma: !1
  };
})(en || (en = {}));
function Na(e, t = [], o = en.DEFAULT) {
  let n = null, i = [];
  const r = [];
  function s(a) {
    Array.isArray(i) ? i.push(a) : n !== null && (i[n] = a);
  }
  return La(e, {
    onObjectBegin: () => {
      const a = {};
      s(a), r.push(i), i = a, n = null;
    },
    onObjectProperty: (a) => {
      n = a;
    },
    onObjectEnd: () => {
      i = r.pop();
    },
    onArrayBegin: () => {
      const a = [];
      s(a), r.push(i), i = a, n = null;
    },
    onArrayEnd: () => {
      i = r.pop();
    },
    onLiteralValue: s,
    onError: (a, f, l) => {
      t.push({ error: a, offset: f, length: l });
    }
  }, o), i[0];
}
function La(e, t, o = en.DEFAULT) {
  const n = Ra(e, !1), i = [];
  let r = 0;
  function s(R) {
    return R ? () => r === 0 && R(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter()) : () => !0;
  }
  function c(R) {
    return R ? (S) => r === 0 && R(S, n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter()) : () => !0;
  }
  function a(R) {
    return R ? (S) => r === 0 && R(S, n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter(), () => i.slice()) : () => !0;
  }
  function f(R) {
    return R ? () => {
      r > 0 ? r++ : R(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter(), () => i.slice()) === !1 && (r = 1);
    } : () => !0;
  }
  function l(R) {
    return R ? () => {
      r > 0 && r--, r === 0 && R(n.getTokenOffset(), n.getTokenLength(), n.getTokenStartLine(), n.getTokenStartCharacter());
    } : () => !0;
  }
  const u = f(t.onObjectBegin), p = a(t.onObjectProperty), g = l(t.onObjectEnd), T = f(t.onArrayBegin), L = l(t.onArrayEnd), D = a(t.onLiteralValue), w = c(t.onSeparator), k = s(t.onComment), v = c(t.onError), O = o && o.disallowComments, N = o && o.allowTrailingComma;
  function y() {
    for (; ; ) {
      const R = n.scan();
      switch (n.getTokenError()) {
        case 4:
          m(
            14
            /* ParseErrorCode.InvalidUnicode */
          );
          break;
        case 5:
          m(
            15
            /* ParseErrorCode.InvalidEscapeCharacter */
          );
          break;
        case 3:
          m(
            13
            /* ParseErrorCode.UnexpectedEndOfNumber */
          );
          break;
        case 1:
          O || m(
            11
            /* ParseErrorCode.UnexpectedEndOfComment */
          );
          break;
        case 2:
          m(
            12
            /* ParseErrorCode.UnexpectedEndOfString */
          );
          break;
        case 6:
          m(
            16
            /* ParseErrorCode.InvalidCharacter */
          );
          break;
      }
      switch (R) {
        case 12:
        case 13:
          O ? m(
            10
            /* ParseErrorCode.InvalidCommentToken */
          ) : k();
          break;
        case 16:
          m(
            1
            /* ParseErrorCode.InvalidSymbol */
          );
          break;
        case 15:
        case 14:
          break;
        default:
          return R;
      }
    }
  }
  function m(R, S = [], U = []) {
    if (v(R), S.length + U.length > 0) {
      let J = n.getToken();
      for (; J !== 17; ) {
        if (S.indexOf(J) !== -1) {
          y();
          break;
        } else if (U.indexOf(J) !== -1)
          break;
        J = y();
      }
    }
  }
  function _(R) {
    const S = n.getTokenValue();
    return R ? D(S) : (p(S), i.push(S)), y(), !0;
  }
  function q() {
    switch (n.getToken()) {
      case 11:
        const R = n.getTokenValue();
        let S = Number(R);
        isNaN(S) && (m(
          2
          /* ParseErrorCode.InvalidNumberFormat */
        ), S = 0), D(S);
        break;
      case 7:
        D(null);
        break;
      case 8:
        D(!0);
        break;
      case 9:
        D(!1);
        break;
      default:
        return !1;
    }
    return y(), !0;
  }
  function ne() {
    return n.getToken() !== 10 ? (m(3, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ]), !1) : (_(!1), n.getToken() === 6 ? (w(":"), y(), B() || m(4, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ])) : m(5, [], [
      2,
      5
      /* SyntaxKind.CommaToken */
    ]), i.pop(), !0);
  }
  function ie() {
    u(), y();
    let R = !1;
    for (; n.getToken() !== 2 && n.getToken() !== 17; ) {
      if (n.getToken() === 5) {
        if (R || m(4, [], []), w(","), y(), n.getToken() === 2 && N)
          break;
      } else R && m(6, [], []);
      ne() || m(4, [], [
        2,
        5
        /* SyntaxKind.CommaToken */
      ]), R = !0;
    }
    return g(), n.getToken() !== 2 ? m(7, [
      2
      /* SyntaxKind.CloseBraceToken */
    ], []) : y(), !0;
  }
  function ee() {
    T(), y();
    let R = !0, S = !1;
    for (; n.getToken() !== 4 && n.getToken() !== 17; ) {
      if (n.getToken() === 5) {
        if (S || m(4, [], []), w(","), y(), n.getToken() === 4 && N)
          break;
      } else S && m(6, [], []);
      R ? (i.push(0), R = !1) : i[i.length - 1]++, B() || m(4, [], [
        4,
        5
        /* SyntaxKind.CommaToken */
      ]), S = !0;
    }
    return L(), R || i.pop(), n.getToken() !== 4 ? m(8, [
      4
      /* SyntaxKind.CloseBracketToken */
    ], []) : y(), !0;
  }
  function B() {
    switch (n.getToken()) {
      case 3:
        return ee();
      case 1:
        return ie();
      case 10:
        return _(!0);
      default:
        return q();
    }
  }
  return y(), n.getToken() === 17 ? o.allowEmptyContent ? !0 : (m(4, [], []), !1) : B() ? (n.getToken() !== 17 && m(9, [], []), !0) : (m(4, [], []), !1);
}
var co;
(function(e) {
  e[e.None = 0] = "None", e[e.UnexpectedEndOfComment = 1] = "UnexpectedEndOfComment", e[e.UnexpectedEndOfString = 2] = "UnexpectedEndOfString", e[e.UnexpectedEndOfNumber = 3] = "UnexpectedEndOfNumber", e[e.InvalidUnicode = 4] = "InvalidUnicode", e[e.InvalidEscapeCharacter = 5] = "InvalidEscapeCharacter", e[e.InvalidCharacter = 6] = "InvalidCharacter";
})(co || (co = {}));
var uo;
(function(e) {
  e[e.OpenBraceToken = 1] = "OpenBraceToken", e[e.CloseBraceToken = 2] = "CloseBraceToken", e[e.OpenBracketToken = 3] = "OpenBracketToken", e[e.CloseBracketToken = 4] = "CloseBracketToken", e[e.CommaToken = 5] = "CommaToken", e[e.ColonToken = 6] = "ColonToken", e[e.NullKeyword = 7] = "NullKeyword", e[e.TrueKeyword = 8] = "TrueKeyword", e[e.FalseKeyword = 9] = "FalseKeyword", e[e.StringLiteral = 10] = "StringLiteral", e[e.NumericLiteral = 11] = "NumericLiteral", e[e.LineCommentTrivia = 12] = "LineCommentTrivia", e[e.BlockCommentTrivia = 13] = "BlockCommentTrivia", e[e.LineBreakTrivia = 14] = "LineBreakTrivia", e[e.Trivia = 15] = "Trivia", e[e.Unknown = 16] = "Unknown", e[e.EOF = 17] = "EOF";
})(uo || (uo = {}));
const fo = Na;
var po;
(function(e) {
  e[e.InvalidSymbol = 1] = "InvalidSymbol", e[e.InvalidNumberFormat = 2] = "InvalidNumberFormat", e[e.PropertyNameExpected = 3] = "PropertyNameExpected", e[e.ValueExpected = 4] = "ValueExpected", e[e.ColonExpected = 5] = "ColonExpected", e[e.CommaExpected = 6] = "CommaExpected", e[e.CloseBraceExpected = 7] = "CloseBraceExpected", e[e.CloseBracketExpected = 8] = "CloseBracketExpected", e[e.EndOfFileExpected = 9] = "EndOfFileExpected", e[e.InvalidCommentToken = 10] = "InvalidCommentToken", e[e.UnexpectedEndOfComment = 11] = "UnexpectedEndOfComment", e[e.UnexpectedEndOfString = 12] = "UnexpectedEndOfString", e[e.UnexpectedEndOfNumber = 13] = "UnexpectedEndOfNumber", e[e.InvalidUnicode = 14] = "InvalidUnicode", e[e.InvalidEscapeCharacter = 15] = "InvalidEscapeCharacter", e[e.InvalidCharacter = 16] = "InvalidCharacter";
})(po || (po = {}));
function mo(e) {
  switch (e) {
    case 1:
      return "InvalidSymbol";
    case 2:
      return "InvalidNumberFormat";
    case 3:
      return "PropertyNameExpected";
    case 4:
      return "ValueExpected";
    case 5:
      return "ColonExpected";
    case 6:
      return "CommaExpected";
    case 7:
      return "CloseBraceExpected";
    case 8:
      return "CloseBracketExpected";
    case 9:
      return "EndOfFileExpected";
    case 10:
      return "InvalidCommentToken";
    case 11:
      return "UnexpectedEndOfComment";
    case 12:
      return "UnexpectedEndOfString";
    case 13:
      return "UnexpectedEndOfNumber";
    case 14:
      return "InvalidUnicode";
    case 15:
      return "InvalidEscapeCharacter";
    case 16:
      return "InvalidCharacter";
  }
  return "<unknown ParseErrorCode>";
}
const vo = (e) => e.map((t) => ({
  code: `json-parse/${mo(t.error)}`,
  message: mo(t.error),
  offset: t.offset,
  length: t.length
})), Ba = async (e, t) => {
  const o = await e.text();
  if (t === "json") {
    const n = [], i = fo(o, n, {
      allowEmptyContent: !1,
      allowTrailingComma: !1,
      disallowComments: !0
    });
    if (n.length === 0)
      return {
        format: t,
        rawText: o,
        value: i,
        parsedValue: i,
        jsonParseMode: "json",
        jsonDiagnostics: []
      };
    const r = [], s = fo(o, r, {
      allowEmptyContent: !1,
      allowTrailingComma: !0,
      disallowComments: !1
    });
    return r.length === 0 ? {
      format: t,
      rawText: o,
      value: s,
      parsedValue: s,
      jsonParseMode: "jsonc",
      jsonDiagnostics: vo(n)
    } : {
      format: t,
      rawText: o,
      value: o,
      jsonParseMode: "raw-text",
      jsonDiagnostics: vo(r)
    };
  }
  return {
    format: t,
    rawText: o,
    value: o
  };
}, Ma = (e) => typeof e == "object" && e !== null && !Array.isArray(e), Da = (e) => Ma(e) && typeof e.type == "string", Ca = (e) => Yt(e) || Da(e), Fa = async (e, t, o, n) => {
  const r = (o != null && o.resolveJsonImportMode && n ? await o.resolveJsonImportMode({
    event: n,
    file: e,
    rawText: t.rawText,
    parsedValue: t.parsedValue,
    parseMode: t.jsonParseMode ?? "raw-text",
    diagnostics: t.jsonDiagnostics ?? []
  }) : "auto") ?? "auto";
  if (r === "code-block")
    return t.rawText;
  if (r === "canonical-document") {
    if (!Ca(t.parsedValue))
      throw new Error(
        'JSON import mode "canonical-document" requires a canonical document envelope or JSONContent payload.'
      );
    return t.parsedValue;
  }
  return t.parsedValue ?? t.rawText;
}, za = async (e, t, o, n) => {
  const i = await Ba(e, t);
  switch (t) {
    case "markdown":
      return hr(i.value, {
        importMode: "fresh-import",
        meta: {
          source: "import"
        }
      }).document;
    case "html":
      return br(
        o != null && o.sanitizeImportedHtml && n ? await o.sanitizeImportedHtml(i.value, {
          event: n,
          file: e
        }) : i.value,
        {
          importMode: "fresh-import",
          meta: {
            source: "import"
          }
        }
      ).document;
    case "json":
      return gr(
        await Fa(e, i, o, n),
        {
          importMode: "fresh-import",
          meta: {
            source: "import"
          }
        }
      ).document;
    case "text":
      return vr(i.value, {
        importMode: "fresh-import",
        meta: {
          source: "import"
        }
      }).document;
  }
}, Pa = (e) => ({
  ...e,
  body: {
    ...e.body,
    content: Vr(
      e.body.content,
      "file-intake"
    )
  }
}), Va = async ({
  applyImportedDocument: e,
  currentDocument: t,
  event: o,
  file: n,
  filePlatform: i,
  format: r,
  insertImportedDocument: s
}) => {
  const c = await Oa({
    currentDocument: t,
    event: o,
    file: n,
    filePlatform: i,
    format: r
  });
  if (c === "cancel")
    return {
      disposition: c,
      handled: !0
    };
  const a = Pa(
    await za(n, r, i, o)
  );
  if (c === "replace-current")
    return e(a), {
      disposition: c,
      document: a,
      handled: !0
    };
  if (c === "insert-at-selection") {
    if (!s)
      throw new Error(
        'Text file import disposition "insert-at-selection" requires an insertion callback.'
      );
    return s(a, {
      event: o,
      file: n,
      format: r
    }), {
      disposition: c,
      document: a,
      handled: !0
    };
  }
  return c === "open-new" ? (await (i == null ? void 0 : i.openNewImportedDocument({
    event: o,
    file: n,
    format: r,
    document: a
  })), {
    disposition: c,
    document: a,
    handled: !0
  }) : {
    disposition: c,
    handled: !0
  };
}, ja = (e, t) => {
  var i, r;
  const o = (i = e.context) == null ? void 0 : i.preferredNodeKind;
  if (o === "image" || o === "video" || o === "attachment")
    return o;
  const n = (r = e.context) == null ? void 0 : r.nodeKind;
  if (n === "image" || n === "video" || n === "attachment")
    return n;
  if (t.intent === "attach-asset") {
    if (t.assetKind === "image")
      return "image";
    if (t.assetKind === "video")
      return "video";
    if (t.assetKind === "file")
      return "attachment";
  }
  return null;
}, Ha = (e, t, o) => {
  const { event: n } = e, i = e.anchorPos ?? n.dropPos ?? null;
  return t.enqueue({
    anchorPos: i,
    event: n,
    preferredNodeKind: ja(n, o)
  });
}, $a = ({
  applyImportedDocument: e,
  assetPipelineRuntime: t,
  documentState: o,
  editor: n,
  filePlatformRuntime: i,
  getCurrentDocument: r,
  insertImportedDocument: s
}) => ({
  dispatch: async (c) => {
    const a = i.getFilePlatform(), f = c.event.htmlContent && (a != null && a.sanitizeImportedHtml) ? {
      ...c.event,
      htmlContent: await a.sanitizeImportedHtml(
        c.event.htmlContent,
        {
          event: c.event,
          file: c.event.files[0] ?? null
        }
      )
    } : c.event, l = await Ea({
      event: f,
      filePlatform: a
    });
    Ye("text-editor:file-intake", "intake classified", {
      source: f.source,
      dropPos: f.dropPos,
      selectionFrom: f.selectionFrom,
      selectionTo: f.selectionTo,
      files: f.files.map((g) => ({
        name: g.name,
        type: g.type,
        size: g.size
      })),
      decision: l
    });
    const u = n.value;
    if (l.intent === "reject")
      return it(f, l, !0);
    if (l.intent === "import-content") {
      const g = f.files[0];
      if (!g)
        return it(
          f,
          {
            intent: "reject",
            code: "missing-import-file",
            reason: "import-file-missing",
            message: "Import-content decisions require a concrete file payload."
          },
          !0
        );
      try {
        const T = await Va({
          applyImportedDocument: e,
          currentDocument: r(),
          event: f,
          file: g,
          filePlatform: a,
          format: l.format ?? "text",
          insertImportedDocument: s
        });
        return Ye("text-editor:file-intake", "text import executed", {
          source: f.source,
          fileName: g.name,
          format: l.format ?? "text",
          disposition: T.disposition,
          handled: T.handled
        }), it(f, l, T.handled);
      } catch (T) {
        return Ye("text-editor:file-intake", "text import failed", {
          source: f.source,
          fileName: g.name,
          format: l.format ?? "text",
          error: T instanceof Error ? T.message : String(T)
        }), it(
          f,
          {
            intent: "reject",
            code: "import-failed",
            reason: "import-error",
            message: T instanceof Error ? T.message : "The text file import pipeline failed."
          },
          !0
        );
      }
    }
    if (l.intent === "embed-remote")
      try {
        const g = await _s({
          anchorPos: c.anchorPos ?? f.dropPos ?? null,
          documentState: o,
          editor: u,
          event: f,
          filePlatform: a,
          url: l.url ?? ""
        });
        return Ye("text-editor:file-intake", "remote embed executed", {
          source: f.source,
          url: l.url ?? "",
          handled: g.handled
        }), it(f, l, g.handled);
      } catch (g) {
        const T = g instanceof _t ? g.code : "remote-embed-failed", L = g instanceof Error ? g.message : "The remote embed pipeline failed.";
        return i.emitDiagnostic({
          code: T,
          message: L,
          severity: "error",
          stage: "intake",
          intake: f,
          cause: g
        }), it(
          f,
          {
            intent: "reject",
            code: T,
            reason: "remote-embed-error",
            message: L
          },
          !0
        );
      }
    if (!u || l.intent !== "attach-asset")
      return it(
        f,
        {
          intent: "reject",
          code: "unsupported-intent",
          reason: "intent-not-supported",
          message: `The intake pipeline does not support intent "${String(
            l.intent
          )}".`
        },
        !0
      );
    const p = Ha(
      {
        ...c,
        event: f
      },
      t,
      l
    );
    return it(f, l, p);
  }
}), si = /* @__PURE__ */ ge({
  name: "ZxTextEditor",
  inheritAttrs: !1,
  __name: "text-editor",
  props: va,
  emits: ga,
  setup(e, { expose: t, emit: o }) {
    const n = e, i = _n(), r = $o(), s = o, c = Fo(n.themeOwner);
    if (!c || c.state !== "active")
      throw new Error("EDITOR_THEME_OWNER_REQUIRED");
    bn(zi, c);
    const a = Ne("text-editor"), f = Ne("code-block"), l = Re(null), u = W(null), p = W(dt()), g = W(fn()), T = W(!1), L = E(() => n.filePlatform ?? null), D = Re(null), w = E(
      () => n.bubbleToolbar !== !1 && n.editable
    ), k = E(
      () => typeof n.bubbleToolbar == "object" && n.bubbleToolbar !== null ? n.bubbleToolbar : {}
    ), v = E(() => n.dragHandle ? n.dragHandle === !0 ? !0 : n.dragHandle.showPlus !== !1 : !1), O = E(() => {
      if (!(!n.dragHandle || n.dragHandle === !0))
        return n.dragHandle.onPlusClick;
    }), N = E(() => !n.dragHandle || n.dragHandle === !0 ? null : n.dragHandle.askAIBridge ?? null), y = jt(), m = E(() => H(y.class)), _ = E(() => mt(y.style)), q = E(() => Object.fromEntries(
      Object.entries(y).filter(([b]) => b !== "class" && b !== "style")
    )), ne = E(() => {
      const b = l.value ? yr(l.value) : Go({
        override: n.typography
      });
      return Ho(b);
    }), ie = E(
      () => Pi(n.extensions, "comment")
    ), ee = (b, M) => {
      const F = b.state.doc.resolve(M);
      let $ = F.depth;
      for (; $ > 0 && F.node($).type.name !== "codeBlock"; ) $--;
      if ($ === 0) return null;
      const Z = F.node($), te = F.before($), pe = b.nodeDOM(te), ke = pe instanceof HTMLElement ? pe : null;
      return { node: Z, from: te, dom: ke };
    }, B = (b, M, F) => {
      const $ = f.b(), Z = Array.from(
        b.dom.querySelectorAll(`.${$}`)
      );
      if (!Z.length) return null;
      const te = 8, pe = 24;
      for (const ke of Z) {
        const me = ke.getBoundingClientRect(), ot = F >= me.top && F <= me.bottom, Ke = M >= me.left - pe && M <= me.right + pe;
        if (ot && (M < me.left - 1 || M > me.right + 1) || F > me.bottom && F <= me.bottom + te && Ke)
          return ke;
      }
      return null;
    }, R = (b, M, F) => {
      var ke;
      const $ = M + F, Z = b.state.doc.nodeAt($);
      if ((Z == null ? void 0 : Z.type.name) === "paragraph" && Z.content.size === 0) {
        const me = b.state.tr.setSelection(
          rt.create(b.state.doc, $ + 1)
        );
        return b.dispatch(me.scrollIntoView()), !0;
      }
      const te = b.state.schema.nodes.paragraph, pe = te == null ? void 0 : te.createAndFill();
      if (pe && te) {
        const me = b.state.doc.resolve($), ot = me.index();
        if (me.parent.canReplaceWith(ot, ot, te)) {
          const Ke = b.state.tr.insert($, pe);
          return Ke.setSelection(rt.create(Ke.doc, $ + 1)), b.dispatch(Ke.scrollIntoView()), !0;
        }
      }
      return (ke = l.value) == null || ke.chain().focus().setNodeSelection(M).createParagraphNear().run(), !0;
    }, S = (b, M) => {
      var pe;
      const F = b.state.doc.resolve(M), $ = F.nodeBefore;
      if (($ == null ? void 0 : $.type.name) === "paragraph" && $.content.size === 0) {
        const ke = b.state.tr.setSelection(
          rt.create(b.state.doc, M - 1)
        );
        return b.dispatch(ke.scrollIntoView()), !0;
      }
      const Z = b.state.schema.nodes.paragraph, te = Z == null ? void 0 : Z.createAndFill();
      if (te && Z) {
        const ke = F.index();
        if (F.parent.canReplaceWith(ke, ke, Z)) {
          const me = b.state.tr.insert(M, te);
          return me.setSelection(rt.create(me.doc, M + 1)), b.dispatch(me.scrollIntoView()), !0;
        }
      }
      return (pe = l.value) == null || pe.chain().focus().setNodeSelection(M).createParagraphNear().run(), !0;
    }, U = (b) => {
      const M = b.state.doc;
      let F = 0;
      for (let $ = 0; $ < M.childCount; $++) {
        const Z = M.child($);
        if ($ === M.childCount - 1) return { node: Z, from: F };
        F += Z.nodeSize;
      }
      return null;
    }, J = (b) => {
      var te, pe;
      const M = (te = l.value) == null ? void 0 : te.view;
      if (!M || b.button !== 0) return;
      const F = b.target;
      if (F && M.dom.contains(F)) return;
      const $ = M.dom.getBoundingClientRect();
      if (b.clientY <= $.bottom + 1) return;
      b.preventDefault();
      const Z = U(M);
      if ((Z == null ? void 0 : Z.node.type.name) === "codeBlock") {
        R(M, Z.from, Z.node.nodeSize), M.focus();
        return;
      }
      (pe = l.value) == null || pe.chain().focus("end").run();
    }, fe = (b) => {
      var M;
      return Array.from(((M = b.dataTransfer) == null ? void 0 : M.files) ?? []);
    }, G = (b) => {
      var F;
      if (fe(b).length > 0)
        return !0;
      const M = (F = b.dataTransfer) == null ? void 0 : F.types;
      return !!(M && Array.from(M).includes("Files"));
    }, ce = (b) => {
      nt.emitDiagnostic({
        code: "root-drop-intake-dispatch-failed",
        message: b instanceof Error ? b.message : "Failed to dispatch dropped files from the editor root.",
        severity: "error",
        stage: "intake",
        cause: b
      });
    }, ue = (b) => {
      var F;
      const M = (F = l.value) == null ? void 0 : F.view.dom;
      return !!(M && b instanceof Node && M.contains(b));
    }, De = (b) => {
      G(b) && (ue(b.target) || (b.preventDefault(), b.dataTransfer && (b.dataTransfer.dropEffect = "copy")));
    }, we = (b) => {
      if (n.contentProfile === "basic-rich-text" && fe(b).length) {
        b.preventDefault(), b.stopPropagation(), s("content-issue", "备注不支持图片或附件");
        return;
      }
      const M = fe(b);
      M.length !== 0 && (ue(b.target) || (b.preventDefault(), Promise.resolve(
        nt.intakeFiles({
          source: "drop",
          files: M,
          dropPos: null,
          anchorPos: null
        })
      ).catch((F) => {
        ce(F);
      })));
    }, Ge = (b, M, F) => {
      var $n, Un, Kn, qn;
      const $ = F.target;
      if (!$) return !1;
      const Z = F.clientX, te = F.clientY, pe = f.b(), ke = f.e("line-numbers"), me = f.e("body"), ot = f.e("pre"), Ke = f.e("code"), je = $.closest(`.${pe}`), xi = $.closest(`.${ke}`);
      let qt = ee(b, M);
      if (!qt && $ === b.dom) {
        const Ce = B(b, Z, te);
        if (Ce) {
          const ze = b.posAtDOM(Ce, 0);
          qt = ee(b, ze);
        }
      }
      if (je || qt) {
        const Ce = qt || (je ? ee(b, M) : null);
        if (Ce) {
          const ze = ($n = Ce.dom || je) == null ? void 0 : $n.getBoundingClientRect(), an = ze ? Z < ze.left - 2 && te >= ze.top && te <= ze.bottom : !1;
          if (xi || an)
            return S(b, Ce.from);
          const Gn = (Un = je || Ce.dom) == null ? void 0 : Un.querySelector(
            `.${me}`
          ), Wn = (Kn = je || Ce.dom) == null ? void 0 : Kn.querySelector(
            `.${ot}`
          ), Jn = (qn = je || Ce.dom) == null ? void 0 : qn.querySelector(
            `.${Ke}`
          );
          if (Gn && Wn && Jn && Gn.contains($) && Wn.contains($)) {
            const Wt = document.createRange();
            Wt.selectNodeContents(Jn);
            const Dt = Array.from(Wt.getClientRects()).filter(
              (Ct) => Ct.width > 0 && Ct.height > 0
            );
            if (Dt.length > 0) {
              const Ct = Math.max(...Dt.map((Ze) => Ze.bottom)), Ei = 1, ln = Dt.filter(
                (Ze) => Math.abs(Ze.bottom - Ct) <= Ei
              ), Si = Math.max(...ln.map((Ze) => Ze.right)), _i = Math.min(...ln.map((Ze) => Ze.top)), Oi = Math.max(...ln.map((Ze) => Ze.bottom)), Ri = te >= _i - 1 && te <= Oi + 1 && Z > Si + 6, Ni = te > Ct + 6;
              if (Ri || Ni)
                return R(b, Ce.from, Ce.node.nodeSize);
            }
          }
          if (ze) {
            const Wt = Z > ze.right + 2 && te >= ze.top && te <= ze.bottom, Dt = te > ze.bottom + 2;
            if (Wt || Dt)
              return R(b, Ce.from, Ce.node.nodeSize);
          }
        }
      }
      const Vn = $.closest(
        "p, h1, h2, h3, h4, h5, h6, li, blockquote, td, th"
      );
      if (!Vn) return !1;
      const Gt = [], Ti = document.createTreeWalker(Vn, NodeFilter.SHOW_TEXT);
      let jn;
      for (; jn = Ti.nextNode(); )
        Gt.push(jn);
      if (Gt.length === 0) return !1;
      const Hn = document.createRange(), Ai = Gt[Gt.length - 1];
      Hn.selectNodeContents(Ai);
      const Ii = Hn.getBoundingClientRect();
      if (Z > Ii.right + 2) {
        const ze = b.state.doc.resolve(M).end(), an = b.state.tr.setSelection(
          rt.create(b.state.doc, ze)
        );
        return b.dispatch(an), !0;
      }
      return !1;
    }, ve = Gs({
      editor: l,
      rootRef: u,
      documentState: p,
      getBookmarkProvider: () => n.bookmarkProvider,
      getEphemeralProviders: () => n.ephemeralProviders
    }), Le = ve.navigationController, Ae = ve.scheduleNavigationRefresh, oe = ve.refreshNavigationRuntime, be = ve.syncEditorNavigationBridge, re = ve.navigateToBlock, Ve = ve.navigate, Ue = ve.cancelNavigation, at = ve.getNavigationSnapshot, yt = ve.getNavigationDebugSnapshot, We = ve.listNavigationDescriptors, lt = ve.syncNavigationFromLocation, et = ve.createShareableFragment, kt = ve.getBlockElement, tt = E(() => ({
      attributes: {
        class: H([a.e("prose"), n.editorClass])
      },
      handleClick: Ge
    })), ye = ss({
      editor: l,
      documentState: p,
      annotationBridgeState: g,
      hasCommentExtension: ie,
      isApplyingExternalContent: T,
      getMarkdownExportMode: () => n.markdownExportMode,
      getStableBlockIdentityOptions: () => {
        var b, M;
        return {
          types: (b = n.stableBlockIdentity) == null ? void 0 : b.types,
          generateId: (M = n.stableBlockIdentity) == null ? void 0 : M.generateId
        };
      }
    }), x = ye.getCurrentDocument, A = ye.resolveHydratedState, K = ye.isHydratedStateSynced, Y = ye.getHTML, se = ye.getMarkdown, xe = ye.getJSON, Fe = ye.getDocument, d = ye.getText, I = ye.getExcerpt, z = (b, M) => {
      n.contentProfile === "basic-rich-text" && qe(b, n.contentLimits), ye.setContent(b, M);
    }, X = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      ye.setHTML(b);
    }, ae = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      ye.setMarkdown(b);
    }, Ee = (b) => {
      if (n.contentProfile === "basic-rich-text")
        throw new TypeError("basic-rich-text:document-required");
      ye.setJSON(b);
    }, Je = (b) => z(b, { contentType: "document" }), wt = ye.getRuntimeStatus, on = (b) => JSON.parse(
      JSON.stringify(
        Array.isArray(b.body.content.content) ? b.body.content.content : []
      )
    ), $t = (b, M) => {
      const { doc: F } = b.state, $ = Math.max(0, Math.min(M, F.content.size)), Z = F.resolve($);
      for (let te = Z.depth; te > 0; te -= 1)
        if (Z.node(te).isBlock && Z.depth >= te)
          return Z.before(te);
      return $;
    }, rn = (b, M, F) => {
      if (typeof F.dropPos == "number") {
        const $ = Xr(
          b.state.doc,
          F.dropPos,
          M
        ), Z = $ ?? $t(b, F.dropPos);
        return Ye(
          "text-editor:file-import",
          "resolved drop insertion range",
          {
            requestedDropPos: F.dropPos,
            normalizedDropPos: $,
            insertionPos: Z
          }
        ), {
          from: Z,
          to: Z
        };
      }
      return {
        from: F.selectionFrom ?? b.state.selection.from,
        to: F.selectionTo ?? b.state.selection.to
      };
    }, Pn = (b, M) => {
      var Ke;
      const F = l.value;
      if (!F) {
        Je(b);
        return;
      }
      const $ = on(b);
      if ($.length === 0)
        return;
      const Z = $.map(
        (je) => F.schema.nodeFromJSON(je)
      ), te = new Jo(Zo.fromArray(Z), 0, 0), pe = x(F), ke = dt({
        ...pe,
        assets: On(pe.assets, b.assets),
        annotations: Kr(
          pe.annotations,
          b.annotations
        )
      });
      p.value = ke, g.value = fn(ke);
      const me = rn(
        F,
        te,
        M.event
      );
      Ye("text-editor:file-import", "applying imported content", {
        importedNodeCount: $.length,
        importedNodeTypes: $.map((je) => je.type),
        event: M.event,
        insertionRange: me
      });
      const ot = F.state.tr.replaceRange(
        me.from,
        me.to,
        te
      );
      F.view.focus(), F.view.dispatch(ot.scrollIntoView()), Ye("text-editor:file-import", "import transaction applied", {
        selectionFrom: F.state.selection.from,
        selectionTo: F.state.selection.to,
        topLevelNodeTypes: ((Ke = x(F).body.content.content) == null ? void 0 : Ke.map(
          (je) => je.type
        )) ?? []
      });
    }, nt = ms({
      editor: l,
      filePlatform: L,
      intakeDispatcher: D,
      getCurrentDocument: () => x()
    }), xt = Is({
      documentState: p,
      editor: l,
      filePlatformRuntime: nt
    });
    D.value = $a({
      applyImportedDocument: (b) => Je(b),
      assetPipelineRuntime: xt,
      documentState: p,
      editor: l,
      filePlatformRuntime: nt,
      getCurrentDocument: () => x(),
      insertImportedDocument: (b, M) => Pn(b, M)
    });
    const Ut = (b) => {
      ye.applyHydratedEditorState(b), oe();
    };
    Q(
      () => [
        n.content,
        n.modelValue,
        n.documentValue,
        n.contentType
      ],
      () => {
        var Z, te;
        if (!l.value) return;
        const b = ct(
          "text-editor:external-sync",
          "props->editor sync watcher",
          {
            contentType: n.contentType,
            hasDocumentValue: !!n.documentValue
          }
        );
        if (n.contentProfile === "basic-rich-text") {
          if (JSON.stringify(n.documentValue) === JSON.stringify(ye.getDocument())) {
            b == null || b.end({ applied: !1, sourceType: "document" });
            return;
          }
          try {
            qe(n.documentValue, n.contentLimits);
          } catch (pe) {
            s("content-issue", String(pe)), b == null || b.end({ applied: !1 });
            return;
          }
        }
        const M = A({
          content: n.content,
          modelValue: n.modelValue,
          documentValue: n.documentValue,
          contentType: n.contentType,
          hydrateAnnotations: ie.value,
          stableBlockIdentity: {
            types: (Z = n.stableBlockIdentity) == null ? void 0 : Z.types,
            generateId: (te = n.stableBlockIdentity) == null ? void 0 : te.generateId
          }
        }), F = ct(
          "text-editor:external-sync",
          "isHydratedStateSynced"
        ), $ = K(M);
        F == null || F.end({
          synced: $,
          sourceType: M.sourceType
        }), $ || (Ye(
          "text-editor:external-sync",
          "applying external hydrated state",
          {
            sourceType: M.sourceType
          }
        ), Ut(M)), b == null || b.end({
          applied: !$,
          sourceType: M.sourceType
        });
      },
      { deep: !0 }
    ), Q(
      () => n.editable,
      (b) => {
        l.value && (l.value.setEditable(b, !1), l.value.view.dispatch(
          l.value.state.tr.setSelection(l.value.state.selection).setStoredMarks(l.value.state.storedMarks).setMeta("addToHistory", !1)
        ));
      }
    ), Q(
      tt,
      (b) => {
        l.value && l.value.setOptions({ editorProps: b });
      },
      { deep: !0 }
    );
    const Bt = () => {
      const b = l.value;
      b && ["codeBlock", "slashCommands", "contentPaste"].forEach((M) => {
        const F = b.extensionManager.extensions.find(
          ($) => $.name === M
        );
        F != null && F.options && (F.options.codeBlockPreferences = n.codeBlockPreferences);
      });
    }, Mt = () => {
      const b = l.value;
      if (!b) return;
      const M = b.extensionManager.extensions.find(
        (F) => F.name === "slashCommands"
      );
      M != null && M.options && (M.options.catalogContributions = n.slashCatalogContributions ?? null);
    };
    Q(
      () => n.codeBlockPreferences,
      () => {
        Bt();
      },
      { deep: !0 }
    ), Q(
      () => n.slashCatalogContributions,
      () => {
        Mt();
      },
      { deep: !0 }
    );
    const sn = vt(ri, !1);
    Lt(() => {
      var M, F;
      n.contentProfile === "basic-rich-text" && (sn ? Ys : qe)(n.documentValue, n.contentLimits);
      const b = A({
        content: n.content,
        modelValue: n.modelValue,
        documentValue: n.documentValue,
        contentType: n.contentType,
        hydrateAnnotations: ie.value,
        stableBlockIdentity: {
          types: (M = n.stableBlockIdentity) == null ? void 0 : M.types,
          generateId: (F = n.stableBlockIdentity) == null ? void 0 : F.generateId
        }
      });
      p.value = b.document, g.value = fn(
        b.document
      ), l.value = Qr(
        {
          content: b.content,
          editorProps: tt.value,
          editable: n.editable,
          autofocus: n.autofocus,
          onUpdate: ({ editor: $ }) => {
            Ye("text-editor:update", "editor onUpdate fired"), gi($);
          },
          onTransaction: ({
            editor: $,
            transaction: Z
          }) => {
            s("transaction", $), bi(Z), hi($, Z), Ae();
          },
          onFocus: ({ event: $ }) => {
            s("focus", $);
          },
          onBlur: ({ event: $ }) => {
            s("blur", $);
          }
        },
        {
          contentProfile: n.contentProfile,
          contentLimits: n.contentLimits,
          onContentIssue: ($) => s("content-issue", $),
          pages: n.contentProfile === "basic-rich-text" ? !1 : void 0,
          dragHandle: n.contentProfile === "basic-rich-text" ? !1 : n.dragHandle,
          shortcutRuntime: i,
          shortcutParentOwner: r,
          extensions: n.extensions,
          getCurrentDocument: () => x(),
          mentions: n.mentions,
          placeholder: n.placeholder,
          placeholderContract: n.placeholderContract,
          stableBlockIdentity: n.stableBlockIdentity,
          starterkitOptions: n.starterkitOptions,
          suggestions: n.suggestions,
          editable: n.editable,
          pagesHeaderFooter: n.pagesHeaderFooter,
          pagesLayout: n.pagesLayout,
          tags: n.tags,
          typography: n.typography,
          assetPipelineRuntime: xt,
          filePlatform: L.value,
          codeBlockPreferences: n.codeBlockPreferences,
          slashCatalogContributions: n.slashCatalogContributions,
          filePlatformRuntime: nt,
          themeOwner: c
        }
      ), be(), oe(), Bt(), Mt();
    }), gt(() => {
      ve.destroy(), l.value && (l.value.destroy(), l.value = null);
    }), bn(
      "editor",
      E(() => l.value)
    );
    const Tt = E(() => n.extensions.some((b) => {
      const M = b == null ? void 0 : b.name;
      return M === "collaboration" || M === "collaborationCursor";
    }));
    let Kt = 0;
    const gi = (b) => {
      if (T.value) return;
      const M = ct(
        "text-editor:update",
        "handleContentUpdate",
        {
          outputType: n.outputType,
          contentType: n.contentType,
          isCollaboration: Tt.value
        }
      ), F = ct(
        "text-editor:update",
        "getCurrentDocument"
      ), $ = x(b);
      F == null || F.end({
        topLevelNodes: Array.isArray($.body.content.content) ? $.body.content.content.length : 0
      });
      const Z = ct(
        "text-editor:update",
        "exportEditorContentValue"
      ), te = ye.exportEditorContentValue({
        editor: b,
        document: $,
        outputType: n.outputType
      });
      Z == null || Z.end({
        exportedType: typeof te
      });
      const pe = ct(
        "text-editor:update",
        "emit events"
      );
      if (s("change", te), s("update:documentValue", $), s("document-change", $), Tt.value) {
        const me = ba(
          b,
          n.collaborationEmit,
          $
        );
        me !== void 0 && s("update:modelValue", me);
      } else
        s("update:modelValue", te);
      pe == null || pe.end();
      const ke = ct(
        "text-editor:navigation",
        "refreshNavigationRuntime"
      );
      oe(), ke == null || ke.end(), M == null || M.end({
        topLevelNodes: Array.isArray($.body.content.content) ? $.body.content.content.length : 0
      });
    }, bi = (b) => {
      const M = jr(
        b
      );
      if (!M)
        return;
      const F = dt({
        ...p.value,
        meta: {
          ...p.value.meta,
          pages: M.pages
        }
      });
      p.value = F, s("update:documentValue", F), s("document-change", F);
    }, hi = (b, M) => {
      if (Tt.value && n.collaborationEmit === "delta" && M) {
        const F = M;
        F.steps && F.steps.length > 0 && (Kt++, s("delta", {
          steps: F.steps,
          version: Kt
        }));
      }
    }, yi = () => {
      var b;
      (b = l.value) == null || b.chain().focus().run();
    }, ki = () => {
      var b;
      (b = u.value) == null || b.blur();
    }, wi = Wo;
    return t({
      editor: l,
      navigationController: Le,
      rootRef: u,
      focus: yi,
      blur: ki,
      getHTML: Y,
      getMarkdown: se,
      getJSON: xe,
      getDocument: Fe,
      navigate: Ve,
      cancelNavigation: Ue,
      getNavigationSnapshot: at,
      getNavigationDebugSnapshot: yt,
      listNavigationDescriptors: We,
      syncNavigationFromLocation: lt,
      createShareableFragment: et,
      navigateToBlock: re,
      getBlockElement: kt,
      getRuntimeStatus: wt,
      getText: d,
      getExcerpt: I,
      setHTML: X,
      setMarkdown: ae,
      setJSON: Ee,
      setDocument: Je,
      setContent: z,
      intakeFiles: async (b, M = {}) => {
        if (n.contentProfile === "basic-rich-text")
          throw s("content-issue", "备注不支持图片或附件"), new TypeError("basic-rich-text:resources-not-supported");
        return nt.intakeFiles({
          files: Array.from(b),
          source: M.source,
          htmlContent: M.htmlContent,
          dropPos: M.dropPos,
          anchorPos: M.anchorPos,
          context: M.context
        });
      },
      clearContent: () => {
        n.contentProfile === "basic-rich-text" && l.value ? (l.value.view.dispatch(
          wi.closeHistory(l.value.state.tr)
        ), l.value.commands.clearContent()) : X("");
      },
      isEmpty: () => {
        var b;
        return ((b = l.value) == null ? void 0 : b.isEmpty) ?? !0;
      }
    }), (b, M) => l.value ? (C(), V("div", Qe({
      key: 0,
      ref_key: "rootRef",
      ref: u,
      class: [h(a).b(), m.value],
      style: _.value
    }, q.value, {
      onDragoverCapture: De,
      onDropCapture: we
    }), [
      b.dragHandle ? (C(), Be(oa, {
        key: 0,
        editor: l.value,
        "show-plus": v.value,
        "on-plus-click": O.value,
        "ask-ai-bridge": N.value
      }, null, 8, ["editor", "show-plus", "on-plus-click", "ask-ai-bridge"])) : le("", !0),
      Me(b.$slots, "top", { editor: l.value }),
      Me(b.$slots, "editor", { editor: l.value }, () => [
        P(h(Zr), {
          editor: l.value,
          class: H([h(a).e("content"), ne.value.className]),
          style: mt(ne.value.style),
          onMousedown: J
        }, null, 8, ["editor", "class", "style"])
      ]),
      w.value ? (C(), Be(h(pa), {
        key: 1,
        editor: l.value,
        contributions: k.value.contributions,
        "should-show": k.value.shouldShow,
        options: k.value.options
      }, null, 8, ["editor", "contributions", "should-show", "options"])) : le("", !0),
      Me(b.$slots, "bottom", { editor: l.value })
    ], 16)) : le("", !0);
  }
});
function ad() {
  const e = Ui({
    uploading: !1,
    progress: 0,
    uploaded: 0,
    total: 0,
    error: null,
    result: null
  }), t = () => {
    e.uploading = !1, e.progress = 0, e.uploaded = 0, e.total = 0, e.error = null, e.result = null;
  }, o = E(() => e.uploading), n = E(() => e.progress), i = E(() => e.error), r = E(() => e.result);
  return {
    upload: (c, a) => Ua(c, a, e, t),
    reset: t,
    state: e,
    isUploading: o,
    progress: n,
    error: i,
    result: r
  };
}
async function Ua(e, t, o, n) {
  var r;
  if (!(t != null && t.endpoint))
    throw new Error("Upload endpoint is required");
  if (!e)
    throw new Error("File is required");
  n(), o.uploading = !0;
  let i = e;
  if ((r = t.optimize) != null && r.enabled && e.type.startsWith("image/"))
    try {
      i = await Wa(e, t.optimize);
    } catch (s) {
      console.warn("Image optimization failed, using original file:", s);
    }
  return new Promise((s, c) => {
    const a = new XMLHttpRequest();
    a.upload.addEventListener("progress", (u) => {
      var p;
      u.lengthComputable && (o.uploaded = u.loaded, o.total = u.total, o.progress = Math.round(u.loaded / u.total * 100)), (p = t.onProgress) == null || p.call(t, u);
    }), a.upload.addEventListener("load", () => {
      o.progress = 100;
    }), a.addEventListener("error", () => {
      const u = new Error("Upload failed");
      o.error = u, o.uploading = !1, c(u);
    }), a.onreadystatechange = () => {
      if (a.readyState !== XMLHttpRequest.DONE) return;
      const u = Ka(a.getAllResponseHeaders()), p = qa(a.responseText), g = {
        data: p,
        status: a.status,
        headers: u
      };
      if (a.status >= 200 && a.status < 300) {
        o.result = g, o.uploading = !1, s(g);
        return;
      }
      const T = Ga(a.status, p);
      o.error = T, o.uploading = !1, c(T);
    };
    const f = t.method ?? "POST";
    if (a.open(f, t.endpoint, !0), a.withCredentials = !!t.withCredentials, t.headers)
      for (const [u, p] of Object.entries(t.headers))
        a.setRequestHeader(u, p);
    const l = new FormData();
    if (l.append(t.fieldName ?? "file", i, e.name), t.data)
      for (const [u, p] of Object.entries(t.data))
        l.append(u, p);
    a.send(l);
  });
}
function Ka(e) {
  return e ? e.split(`\r
`).filter(Boolean).reduce((t, o) => {
    const n = o.indexOf(": ");
    if (n > 0) {
      const i = o.slice(0, n).trim().toLowerCase(), r = o.slice(n + 2).trim();
      i && (t[i] = r);
    }
    return t;
  }, {}) : {};
}
function qa(e) {
  try {
    return JSON.parse(e);
  } catch {
    return e;
  }
}
function Ga(e, t) {
  if (t instanceof Error) return t;
  const o = (typeof t == "object" && t !== null && "message" in t ? String(t.message) : void 0) || (typeof t == "string" ? t : "Upload failed");
  return new Error(`${e || 0}: ${o}`);
}
async function Wa(e, t) {
  const { maxWidth: o, maxHeight: n, quality: i = 0.8, outputFormat: r } = t;
  return new Promise((s, c) => {
    const a = new Image(), f = URL.createObjectURL(e);
    a.onload = () => {
      URL.revokeObjectURL(f);
      let { width: l, height: u } = a;
      o && l > o && (u = Math.round(u * o / l), l = o), n && u > n && (l = Math.round(l * n / u), u = n);
      const p = document.createElement("canvas");
      p.width = l, p.height = u;
      const g = p.getContext("2d");
      if (!g) {
        c(new Error("Failed to get canvas context"));
        return;
      }
      g.drawImage(a, 0, 0, l, u);
      const T = r || e.type || "image/jpeg";
      p.toBlob(
        (L) => {
          L ? s(L) : c(new Error("Failed to create blob"));
        },
        T,
        i
      );
    }, a.onerror = () => {
      URL.revokeObjectURL(f), c(new Error("Failed to load image"));
    }, a.src = f;
  });
}
const Ja = (e) => ({
  requestId: "navigation-request-unavailable",
  status: "failed",
  target: e.target,
  phase: "failed",
  reason: "target-unavailable",
  settle: null
}), Za = (e = {}) => {
  const t = W(Yn());
  let o = null;
  const n = () => {
    const u = h(e.controller);
    if (u)
      return u;
    const p = h(e.editor);
    return p ? typeof p.navigate == "function" && typeof p.getSnapshot == "function" && typeof p.subscribe == "function" ? p : p.navigationController ?? null : null;
  }, i = (u) => {
    if (o == null || o(), o = null, !u) {
      t.value = Yn();
      return;
    }
    t.value = u.getSnapshot(), o = u.subscribe((p) => {
      t.value = p;
    });
  };
  Q(
    () => [h(e.controller), h(e.editor)],
    () => {
      i(n());
    },
    { immediate: !0 }
  ), Ht(() => {
    o == null || o(), o = null;
  });
  const r = async (u) => {
    const p = n();
    return p ? p.navigate(u) : Ja(u);
  }, s = (u, p) => r({
    ...p,
    source: "bookmark",
    target: {
      kind: "bookmark",
      bookmarkId: u
    }
  }), c = (u, p) => r({
    ...p,
    source: "annotation",
    target: {
      kind: "annotation",
      annotationId: u
    }
  }), a = (u, p) => r({
    ...p,
    source: "search",
    target: {
      kind: "search-hit",
      hitId: u
    }
  }), f = (u, p) => r({
    ...p,
    source: "ai",
    target: {
      kind: "ai-suggestion",
      suggestionId: u
    }
  }), l = (u, p) => r({
    ...p,
    source: "presence",
    target: {
      kind: "presence",
      presenceId: u
    }
  });
  return {
    snapshot: t,
    debug: E(() => jo(t.value)),
    activeReadingHeadingId: E(
      () => t.value.activeReadingHeadingId
    ),
    async listDescriptors(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.listDescriptors(u)) ?? [];
    },
    async listBookmarkDescriptors() {
      var u;
      return ((u = n()) == null ? void 0 : u.listDescriptors({ kinds: ["bookmark"] })) ?? [];
    },
    navigate: r,
    navigateToBookmark: s,
    navigateToAnnotation: c,
    navigateToCommentThread: c,
    navigateToSearchHit: a,
    navigateToAiSuggestion: f,
    navigateToPresence: l,
    followCollaborator: l,
    cancelNavigation() {
      var u;
      (u = n()) == null || u.cancel();
    },
    async syncFromLocation(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.syncFromLocation(u)) ?? null;
    },
    createShareableFragment(u) {
      var p;
      return ((p = n()) == null ? void 0 : p.createShareableFragment(u)) ?? null;
    }
  };
}, Bn = (e) => {
  const t = e.originalLevel ?? e.level;
  return Number.isFinite(t) && t > 0 ? t : 1;
}, Xa = (e, t = null, o = 0) => ({
  id: Rt(e),
  label: e.textContent,
  anchor: e,
  parentId: t,
  children: [],
  originalLevel: Bn(e),
  depth: o,
  indexLabel: null,
  isActive: !!e.isActive,
  isScrolledOver: !!e.isScrolledOver,
  isExpanded: !0,
  isVisible: !0
}), Mn = (e) => e.map((t) => ({
  ...t,
  children: Mn(t.children)
})), Dn = (e) => {
  const t = [], o = (n) => {
    for (const i of n)
      t.push(i), i.children.length > 0 && o(i.children);
  };
  return o(e), t;
}, Ya = (e = []) => {
  var i;
  const t = [...e].sort((r, s) => r.pos !== s.pos ? r.pos - s.pos : r.itemIndex - s.itemIndex), o = [], n = [
    {
      level: 0,
      node: null
    }
  ];
  for (const r of t) {
    const s = Bn(r);
    for (; n.length > 1 && n[n.length - 1].level >= s; )
      n.pop();
    const c = ((i = n[n.length - 1]) == null ? void 0 : i.node) ?? null, a = Xa(
      r,
      (c == null ? void 0 : c.id) ?? null,
      c ? c.depth + 1 : 0
    );
    c ? c.children.push(a) : o.push(a), n.push({
      level: s,
      node: a
    });
  }
  return {
    tree: o,
    flat: Dn(o)
  };
}, Qa = (e, t = {}) => {
  const o = Mn(e), n = Dn(o), i = t.showIndex ?? !1, r = (s, c = []) => {
    s.forEach((a, f) => {
      var p;
      const l = [...c, f + 1], u = i ? l.join(".") : null;
      a.indexLabel = ((p = t.indexStrategy) == null ? void 0 : p.call(t, {
        node: a,
        root: o,
        flat: n
      })) ?? u, a.children.length > 0 && r(a.children, l);
    });
  };
  return r(o), {
    tree: o,
    flat: n
  };
}, el = (e) => {
  if (typeof window > "u" || typeof document > "u" || e == null)
    return null;
  if (typeof e == "string")
    try {
      return document.querySelector(e);
    } catch {
      return null;
    }
  if (typeof e == "function")
    try {
      return e();
    } catch {
      return null;
    }
  return typeof HTMLElement < "u" && e instanceof HTMLElement ? e : null;
}, tn = (e, t) => {
  for (const o of e) {
    if (o.id === t)
      return [o.id];
    const n = tn(o.children, t);
    if (n.length > 0)
      return [o.id, ...n];
  }
  return [];
}, tl = (e = [], t = null) => kn(
  e.map((o) => ({
    id: Rt(o),
    dom: o.dom,
    pos: o.pos,
    order: o.itemIndex,
    isActive: o.isActive
  })),
  {
    scrollContainer: t
  }
), nl = (e, t) => {
  const o = e.originalLevel || Bn(e.anchor);
  return (t.minLevel == null || o >= t.minLevel) && (t.maxLevel == null || o <= t.maxLevel);
}, Tn = (e, t, o = 0, n = null) => {
  const i = [];
  for (const r of e) {
    if (nl(r, t)) {
      const c = {
        ...r,
        parentId: n,
        depth: o,
        isVisible: !0,
        children: Tn(
          r.children,
          t,
          o + 1,
          r.id
        )
      };
      i.push(c);
      continue;
    }
    i.push(
      ...Tn(r.children, t, o, n)
    );
  }
  return i;
}, ol = (e, t, o) => {
  if (!o)
    return null;
  const n = new Set(t.map((r) => r.id));
  if (n.has(o))
    return o;
  const i = tn(e, o);
  for (let r = i.length - 1; r >= 0; r -= 1)
    if (n.has(i[r]))
      return i[r];
  return null;
}, il = (e, t = {}) => {
  const o = Mn(e), n = Tn(o, t), i = Dn(n), r = new Set(t.expandedKeys ?? []), s = ol(o, i, t.activeId), c = s ? i.findIndex((a) => a.id === s) : -1;
  return i.forEach((a, f) => {
    a.isActive = a.id === s, a.isScrolledOver = c >= 0 && f < c, a.isVisible = !0, a.isExpanded = a.children.length === 0 || r.has(a.id);
  }), {
    tree: n,
    flat: i
  };
}, rl = { DEV: !1 }, go = (e) => Array.isArray(e) ? [...e] : [], sl = (e) => e.filter((t) => t.children.length > 0).map((t) => t.id), Se = (e) => hn(e) ? e.value : e, bo = /* @__PURE__ */ new Set(), al = () => rl.DEV, Vt = (e) => {
  !al() || bo.has(e) || (bo.add(e), console.warn(`[useTextEditorToc] ${e}`));
}, ai = (e) => {
  var t;
  return (t = e == null ? void 0 : e.storage) == null ? void 0 : t.tableOfContents;
}, ll = (e) => !!(e && typeof e.on == "function" && typeof e.off == "function"), ho = (e) => {
  if (!e || typeof e != "object")
    return !1;
  const t = e;
  return typeof t.id == "string" && typeof t.pos == "number" && typeof t.textContent == "string" && typeof t.level == "number" && typeof t.itemIndex == "number" && typeof t.dom == "object" && t.dom !== null;
}, cl = (e) => {
  const t = ai(e), o = Array.isArray(t == null ? void 0 : t.content) ? t.content.filter(ho) : [];
  if (o.length > 0)
    return [...o];
  const n = Array.isArray(t == null ? void 0 : t.anchors) ? t.anchors.filter(ho) : [];
  return n.length > 0 ? [...n] : [];
}, yo = (e) => ["auto", "scroll", "overlay"].includes(e), li = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return !1;
  const t = window.getComputedStyle(e);
  return (yo(t.overflowY) || yo(t.overflow)) && e.scrollHeight > e.clientHeight + 1;
}, ul = (e) => {
  if (!e || typeof document > "u")
    return null;
  let t = e.parentElement;
  for (; t && !(t === document.body || t === document.documentElement); ) {
    if (li(t))
      return t;
    const o = t.parentElement;
    t = o instanceof HTMLElement ? o : null;
  }
  return null;
}, ko = (e, t) => t && e && t.contains(e) && li(t) ? t : ul(e) ?? t, dl = (e) => {
  if (!e || typeof window > "u" || typeof window.getComputedStyle != "function")
    return 16;
  const t = window.getComputedStyle(e), o = Number.parseFloat(t.scrollPaddingTop || "0") || 0, n = Number.parseFloat(t.paddingTop || "0") || 0;
  return o || n;
}, wo = (e) => (e == null ? void 0 : e.navigationController) ?? null;
function fl(e = {}) {
  const t = e.editor !== void 0, o = Re([]), n = W(null), i = W(
    Se(e.defaultExpandedKeys) === void 0 ? null : go(Se(e.defaultExpandedKeys))
  ), r = E(
    () => Se(e.anchors) !== void 0
  ), s = E(
    () => Se(e.expandedKeys) !== void 0
  ), c = E(() => !!Se(e.editor)), a = E(
    () => wo(Se(e.editor))
  ), f = Za({
    controller: a
  });
  Q(
    () => Se(e.defaultExpandedKeys),
    (B) => {
      s.value || (B === void 0 ? i.value = null : i.value = go(B));
    },
    {
      deep: !0
    }
  );
  const l = (B) => {
    if (!B) {
      o.value = [], t || Vt(
        "Provide `anchors` or pass an editor instance with the TableOfContents extension enabled."
      );
      return;
    }
    if (!ai(B)) {
      o.value = [], Vt(
        "The editor is missing `storage.tableOfContents`. Enable the TableOfContents extension before using `useTextEditorToc`."
      );
      return;
    }
    wo(B) || Vt(
      "The editor is missing `navigationController`. Use `ZxTextEditor` for platform-backed TOC navigation, or pass standalone `anchors` instead of relying on editor fallback behavior."
    ), o.value = cl(B);
  };
  Q(
    () => [Se(e.editor), r.value],
    ([B, R], S, U) => {
      if (R) {
        o.value = [];
        return;
      }
      if (l(B), !B)
        return;
      if (!ll(B)) {
        Vt(
          "The editor is missing `on/off` transaction hooks. TOC anchors will be read once but cannot live-refresh from editor transactions."
        );
        return;
      }
      const J = () => {
        l(B);
      };
      B.on("transaction", J), U(() => {
        B.off("transaction", J);
      });
    },
    {
      immediate: !0
    }
  );
  const u = E(() => {
    const B = Se(e.anchors);
    return B !== void 0 ? B : o.value;
  }), p = E(
    () => Ya(u.value ?? [])
  ), g = E(
    () => el(Se(e.scrollContainer))
  ), T = E(
    () => {
      var B;
      return ko(
        ((B = u.value[0]) == null ? void 0 : B.dom) ?? null,
        g.value
      );
    }
  ), L = E(
    () => Qa(p.value.tree, {
      showIndex: Se(e.showIndex) ?? !1,
      indexStrategy: Se(e.indexStrategy)
    })
  ), D = E(
    () => sl(L.value.flat)
  ), w = E(
    () => a.value ? f.activeReadingHeadingId.value : c.value ? null : n.value
  ), k = () => {
    if (c.value) {
      n.value = null;
      return;
    }
    n.value = tl(
      u.value,
      T.value
    );
  };
  Q(
    u,
    () => {
      c.value || k();
    },
    {
      immediate: !0,
      deep: !0
    }
  ), Q(
    () => [T.value, c.value],
    ([B, R], S, U) => {
      if (R || (k(), typeof window > "u"))
        return;
      const J = B ?? window;
      let fe = 0;
      const G = () => {
        fe || (fe = window.requestAnimationFrame(() => {
          fe = 0, k();
        }));
      };
      J.addEventListener("scroll", G, {
        passive: !0
      }), window.addEventListener("resize", G), U(() => {
        fe && window.cancelAnimationFrame(fe), J.removeEventListener("scroll", G), window.removeEventListener("resize", G);
      });
    },
    {
      immediate: !0
    }
  );
  const v = E(() => {
    const R = Se(e.expandedKeys) ?? i.value ?? D.value, S = new Set(R);
    return (Se(e.autoExpandActivePath) ?? !0) && w.value && tn(L.value.tree, w.value).forEach((U) => {
      S.add(U);
    }), [...S];
  }), O = E(
    () => il(L.value.tree, {
      activeId: w.value,
      expandedKeys: v.value,
      minLevel: Se(e.minLevel),
      maxLevel: Se(e.maxLevel)
    })
  ), N = E(() => O.value.tree), y = E(() => O.value.flat), m = E(() => v.value), _ = E(
    () => y.value.filter((B) => B.isVisible).length === 0
  ), q = (B) => {
    s.value || (i.value = B);
  };
  return {
    tree: N,
    flat: y,
    activeId: w,
    expandedKeys: m,
    isEmpty: _,
    navigateTo: (B) => {
      var S, U;
      const R = y.value.find((J) => J.id === B);
      if (R) {
        if (a.value) {
          f.navigate({
            source: "outline",
            target: {
              kind: "heading",
              blockId: R.id
            },
            align: "start",
            history: "none"
          });
          return;
        }
        if (c.value) {
          Vt(
            "Editor-backed TOC navigation requires `navigationController`. Legacy block navigation fallback is intentionally disabled."
          );
          return;
        }
        if (n.value = R.id, !!R.anchor.dom)
          try {
            const J = ko(
              R.anchor.dom,
              T.value
            );
            if (J) {
              const fe = J.getBoundingClientRect(), G = R.anchor.dom.getBoundingClientRect(), ce = dl(J), ue = J.scrollTop + G.top - fe.top - ce;
              J.scrollTo({
                top: Math.max(ue, 0),
                behavior: "smooth"
              });
              return;
            }
            (U = (S = R.anchor.dom).scrollIntoView) == null || U.call(S, {
              block: "start",
              behavior: "smooth"
            });
          } catch {
          }
      }
    },
    toggleExpanded: (B) => {
      if (s.value)
        return;
      const R = new Set(i.value ?? D.value);
      R.has(B) ? R.delete(B) : R.add(B), q([...R]);
    },
    expandPath: (B) => {
      if (s.value)
        return;
      const R = new Set(i.value ?? D.value);
      tn(L.value.tree, B).forEach((S) => {
        R.add(S);
      }), q([...R]);
    }
  };
}
const pl = {
  white: "#ffffff"
};
function ml(e) {
  if (e === "transparent" || e === pl.white) return !0;
  if (!e.startsWith("#")) return !1;
  const t = e.replace("#", ""), o = Number.parseInt(t.slice(0, 2), 16), n = Number.parseInt(t.slice(2, 4), 16), i = Number.parseInt(t.slice(4, 6), 16);
  return (0.299 * o + 0.587 * n + 0.114 * i) / 255 > 0.65;
}
const vl = ["onClick"], ci = /* @__PURE__ */ ge({
  name: "ZxTextEditorFontColor",
  __name: "font-color",
  props: {
    editor: {
      type: null,
      required: !0
    },
    mode: {
      type: String,
      default: "both"
    }
  },
  setup(e) {
    const t = e, o = Ne("text-editor-font-color"), n = W(!1), i = W("text"), r = W(null), s = W(null), c = W(null), { binding: a } = Nt();
    Q(
      () => t.mode,
      (y) => {
        y && y !== "both" && (i.value = y);
      },
      { immediate: !0 }
    );
    const f = E(() => t.mode === "both"), l = () => {
      if (!t.editor) return;
      const { from: y, to: m } = t.editor.state.selection;
      c.value = { from: y, to: m };
    };
    Q(n, (y) => {
      y && l();
    });
    const u = E(() => {
      var y;
      return (y = a.value) == null ? void 0 : y.target;
    }), p = E(() => i.value === "background" ? kr : wr), g = (y) => ml(y), T = (y) => {
      const m = L();
      return m ? m.toLowerCase() === y.toLowerCase() : !1;
    }, L = () => {
      if (!t.editor) return null;
      if (i.value === "background") {
        const m = t.editor.getAttributes("namedHighlight");
        return D(m == null ? void 0 : m.color);
      }
      const y = t.editor.getAttributes("textStyle");
      return D(y == null ? void 0 : y.color);
    }, D = (y) => xr(
      y,
      i.value === "background" ? "highlight" : "text"
    ), w = E(() => {
      if (!t.editor) return !0;
      if (i.value === "background")
        return !t.editor.isActive("namedHighlight");
      const y = t.editor.getAttributes("textStyle");
      return !(y != null && y.color);
    }), k = (y) => {
      if (!t.editor) return;
      n.value = !1;
      const m = c.value || t.editor.state.selection;
      i.value === "background" && Tr(y), requestAnimationFrame(() => {
        t.editor && Ar(t.editor, {
          mode: i.value === "background" ? "highlight" : "text",
          value: y,
          selection: m
        });
      });
    }, v = () => {
      if (!t.editor) return;
      n.value = !1;
      const y = c.value || t.editor.state.selection;
      requestAnimationFrame(() => {
        t.editor && Ir(t.editor, {
          mode: i.value === "text" ? "text" : "highlight",
          selection: y
        });
      });
    }, O = async () => {
      var _;
      if (!("EyeDropper" in window)) {
        (_ = s.value) == null || _.click();
        return;
      }
      const m = await new window.EyeDropper().open();
      m != null && m.sRGBHex && k(m.sRGBHex);
    }, N = (y) => {
      const m = y.target, _ = m == null ? void 0 : m.value;
      _ && k(_);
    };
    return (y, m) => (C(), Be(h(Zt), {
      visible: n.value,
      "onUpdate:visible": m[8] || (m[8] = (_) => n.value = _),
      variant: "popover",
      trigger: "click",
      "show-arrow": !1,
      placement: "bottom-start",
      width: "auto",
      teleported: !0,
      "append-to": u.value,
      disabled: !h(a),
      "popper-class": h(o).e("popper")
    }, {
      content: ft(() => [
        j("div", {
          class: H(h(o).b()),
          onMousedown: m[7] || (m[7] = _e(() => {
          }, ["prevent"]))
        }, [
          f.value ? (C(), V("div", {
            key: 0,
            class: H(h(o).e("tabs"))
          }, [
            j("button", {
              class: H([h(o).e("tab"), { "is-active": i.value === "text" }]),
              type: "button",
              onMousedown: m[0] || (m[0] = _e(() => {
              }, ["prevent"])),
              onClick: m[1] || (m[1] = (_) => i.value = "text")
            }, [
              P(h(Ie), { icon: "lucide:type" }),
              m[9] || (m[9] = j("span", null, "文字颜色", -1))
            ], 34),
            j("button", {
              class: H([h(o).e("tab"), { "is-active": i.value === "background" }]),
              type: "button",
              onMousedown: m[2] || (m[2] = _e(() => {
              }, ["prevent"])),
              onClick: m[3] || (m[3] = (_) => i.value = "background")
            }, [
              P(h(Ie), { icon: "lucide:highlighter" }),
              m[10] || (m[10] = j("span", null, "背景颜色", -1))
            ], 34)
          ], 2)) : le("", !0),
          j("div", {
            class: H(h(o).e("palette"))
          }, [
            j("button", {
              class: H([h(o).e("clear-option"), { "is-active": w.value }]),
              type: "button",
              onMousedown: m[4] || (m[4] = _e(() => {
              }, ["prevent"])),
              onClick: v
            }, [
              j("span", {
                class: H([h(o).e("clear-swatch"), { "is-active": w.value }])
              }, [
                j("span", {
                  class: H(h(o).e("clear-line"))
                }, null, 2)
              ], 2),
              j("span", {
                class: H(h(o).e("clear-label"))
              }, "无", 2)
            ], 34),
            j("div", {
              class: H(h(o).e("grid"))
            }, [
              (C(!0), V(Oe, null, Pe(p.value, (_, q) => (C(), V("button", {
                key: q,
                class: H([
                  h(o).e("swatch"),
                  {
                    "is-light": g(_),
                    "is-active": T(_)
                  }
                ]),
                style: mt({ backgroundColor: _ }),
                type: "button",
                onMousedown: m[5] || (m[5] = _e(() => {
                }, ["prevent"])),
                onClick: (ne) => k(_)
              }, [
                T(_) ? (C(), Be(h(Ie), {
                  key: 0,
                  icon: "lucide:check",
                  class: H([h(o).e("check"), { "is-dark": g(_) }])
                }, null, 8, ["class"])) : le("", !0)
              ], 46, vl))), 128))
            ], 2),
            j("div", {
              class: H(h(o).e("custom-section"))
            }, [
              j("span", {
                class: H(h(o).e("custom-label"))
              }, "自定义", 2),
              j("div", {
                class: H(h(o).e("custom-actions"))
              }, [
                j("label", {
                  class: H(h(o).e("custom-btn"))
                }, [
                  P(h(Ie), { icon: "lucide:plus-circle" }),
                  j("input", {
                    ref_key: "customColorInputRef",
                    ref: s,
                    class: H(h(o).e("custom-input")),
                    type: "color",
                    tabindex: "-1",
                    onInput: N
                  }, null, 34)
                ], 2),
                j("button", {
                  class: H(h(o).e("custom-btn")),
                  type: "button",
                  onMousedown: m[6] || (m[6] = _e(() => {
                  }, ["prevent"])),
                  onClick: O
                }, [
                  P(h(Ie), { icon: "lucide:pipette" })
                ], 34)
              ], 2)
            ], 2)
          ], 2)
        ], 34)
      ]),
      default: ft(() => [
        j("span", {
          ref_key: "referenceRef",
          ref: r,
          onMousedown: _e(l, ["prevent"])
        }, [
          Me(y.$slots, "default", bt(ht({ isActive: n.value })))
        ], 544)
      ]),
      _: 3
    }, 8, ["visible", "append-to", "disabled", "popper-class"]));
  }
}), ld = /* @__PURE__ */ ge({
  name: "ZxTextEditorTextColor",
  __name: "text-color",
  props: {
    editor: {}
  },
  setup(e) {
    return (t, o) => (C(), Be(ci, {
      editor: e.editor,
      mode: "text"
    }, {
      default: ft((n) => [
        Me(t.$slots, "default", bt(ht(n)))
      ]),
      _: 3
    }, 8, ["editor"]));
  }
}), cd = /* @__PURE__ */ ge({
  name: "ZxTextEditorHighlightColor",
  __name: "highlight-color",
  props: {
    editor: {}
  },
  setup(e) {
    return (t, o) => (C(), Be(ci, {
      editor: e.editor,
      mode: "background"
    }, {
      default: ft((n) => [
        Me(t.$slots, "default", bt(ht(n)))
      ]),
      _: 3
    }, 8, ["editor"]));
  }
}), gl = /* @__PURE__ */ ge({
  name: "ZxTextEditorInsertImage",
  __name: "insert-image",
  props: {
    editor: {}
  },
  setup(e) {
    const t = e, o = Ne("text-editor-insert-image"), n = W(null), i = W(!1), r = W([]), { binding: s } = Nt(), c = () => {
      var l;
      (l = n.value) == null || l.click();
    }, a = (l) => {
      const u = l.target, p = u.files;
      p && p.length > 0 && t.editor && (p.length === 1 ? t.editor.chain().focus().uploadImage(p[0], "picker").run() : (r.value = Array.from(p), i.value = !0)), u && (u.value = "");
    }, f = () => {
      i.value = !1, r.value = [];
    };
    return (l, u) => (C(), V(Oe, null, [
      Me(l.$slots, "default", bt(ht({ onClick: c })), void 0, !0),
      j("input", {
        ref_key: "fileInputRef",
        ref: n,
        type: "file",
        class: H(h(o).e("file-input")),
        accept: "image/*",
        multiple: "",
        onChange: a
      }, null, 34),
      i.value && e.editor && h(s) ? (C(), Be(Vi, {
        key: 0,
        modelValue: i.value,
        "onUpdate:modelValue": u[0] || (u[0] = (p) => i.value = p),
        files: r.value,
        "onUpdate:files": u[1] || (u[1] = (p) => r.value = p),
        mode: "new",
        editor: e.editor,
        "portal-binding": h(s),
        onClose: f
      }, null, 8, ["modelValue", "files", "editor", "portal-binding"])) : le("", !0)
    ], 64));
  }
}), bl = (e, t) => {
  const o = e.__vccOpts || e;
  for (const [n, i] of t)
    o[n] = i;
  return o;
}, hl = /* @__PURE__ */ bl(gl, [["__scopeId", "data-v-3a55a987"]]), yl = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: hl
}, Symbol.toStringTag, { value: "Module" })), ud = /* @__PURE__ */ ge({
  name: "ZxTextEditorInsertVideo",
  __name: "insert-video",
  props: {
    editor: {}
  },
  setup(e) {
    const t = e, o = () => {
      t.editor && t.editor.chain().focus().selectAndUploadVideo().run();
    };
    return (n, i) => Me(n.$slots, "default", bt(ht({ onClick: o })));
  }
}), dd = /* @__PURE__ */ ge({
  name: "ZxTextEditorInsertLink",
  __name: "insert-link",
  props: {
    editor: {},
    actionRef: {}
  },
  setup(e) {
    var f;
    const t = e, o = Re(null);
    Q(
      () => t.editor,
      (l, u, p) => {
        p(
          zo(l, (g) => {
            o.value = (g == null ? void 0 : g.editLink) ?? null;
          })
        );
      },
      { immediate: !0, flush: "sync" }
    );
    const n = E(() => t.actionRef ?? o.value), i = Re((f = n.value) == null ? void 0 : f.getView()), r = Or(), s = E(() => {
      const l = i.value;
      if (!l) return;
      const u = r.formatMany(l.shortcuts, {
        platform: l.platform
      });
      return {
        ...l,
        shortcutText: u.label,
        shortcutAriaLabel: u.ariaLabel
      };
    });
    let c = () => {
    };
    Q(
      n,
      (l) => {
        c();
        const u = () => {
          i.value = l == null ? void 0 : l.getView();
        };
        c = (l == null ? void 0 : l.subscribe(u)) ?? (() => {
        }), u();
      },
      { immediate: !0 }
    ), Ht(() => c());
    const a = () => {
      var l;
      return (l = n.value) == null ? void 0 : l.invoke();
    };
    return (l, u) => {
      var p, g, T;
      return Me(l.$slots, "default", bt(ht({
        onClick: a,
        disabled: !((p = s.value) != null && p.enabled),
        shortcut: (g = s.value) == null ? void 0 : g.shortcutText,
        shortcutAriaLabel: (T = s.value) == null ? void 0 : T.shortcutAriaLabel
      })));
    };
  }
}), kl = ["onClick", "onMouseover"], wl = ["src", "alt"], fd = /* @__PURE__ */ ge({
  name: "ZxTextEditorMentionList",
  __name: "mention-list",
  props: {
    items: {},
    command: { type: Function }
  },
  setup(e, { expose: t }) {
    const o = e, n = Ne("text-editor-mention-list"), i = W(0);
    Q(
      () => o.items,
      () => {
        i.value = 0;
      }
    );
    const r = () => {
      i.value = (i.value + o.items.length - 1) % o.items.length;
    }, s = () => {
      i.value = (i.value + 1) % o.items.length;
    }, c = () => {
      a(i.value);
    }, a = (l) => {
      const u = o.items[l];
      u && o.command({
        id: u.value || u.id,
        label: u.label
      });
    };
    return t({
      onKeyDown: ({ event: l }) => l.key === "ArrowUp" ? (r(), !0) : l.key === "ArrowDown" ? (s(), !0) : l.key === "Enter" ? (c(), !0) : !1
    }), (l, u) => e.items.length ? (C(), V("div", {
      key: 0,
      class: H(h(n).b())
    }, [
      j("div", {
        class: H(h(n).e("scroll"))
      }, [
        (C(!0), V(Oe, null, Pe(e.items, (p, g) => (C(), V("button", {
          key: p.id || g,
          class: H([h(n).e("item"), h(n).is("selected", g === i.value)]),
          type: "button",
          onClick: (T) => a(g),
          onMouseover: (T) => i.value = g
        }, [
          p.avatar ? (C(), V("span", {
            key: 0,
            class: H(h(n).e("avatar"))
          }, [
            j("img", {
              src: p.avatar,
              alt: p.label
            }, null, 8, wl)
          ], 2)) : le("", !0),
          j("span", {
            class: H(h(n).e("label"))
          }, de(p.label), 3)
        ], 42, kl))), 128))
      ], 2)
    ], 2)) : le("", !0);
  }
}), xl = ["aria-expanded", "aria-current"], Tl = ["aria-label"], Al = ["title"], Il = /* @__PURE__ */ ge({
  name: "ZxTextEditorTocNode",
  __name: "toc-node",
  props: {
    node: {}
  },
  emits: ["navigate", "toggle"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = Ne("text-editor-toc"), r = $e(o, "node"), s = E(() => r.value.children.length > 0), c = () => {
      n("navigate", r.value);
    }, a = () => {
      n("toggle", r.value);
    };
    return (f, l) => {
      const u = Ki("TocNode", !0);
      return C(), V("div", {
        class: H([
          h(i).e("node"),
          h(i).is("active", r.value.isActive),
          h(i).is("scrolled", r.value.isScrolledOver)
        ]),
        role: "treeitem",
        "aria-expanded": s.value ? r.value.isExpanded ? "true" : "false" : void 0,
        "aria-current": r.value.isActive ? "location" : void 0
      }, [
        j("div", {
          class: H(h(i).e("row")),
          style: mt({ "--toc-depth": r.value.depth })
        }, [
          s.value ? (C(), V("button", {
            key: 0,
            type: "button",
            class: H([h(i).e("branch"), h(i).is("expanded", r.value.isExpanded)]),
            "aria-label": r.value.isExpanded ? "Collapse section" : "Expand section",
            onClick: _e(a, ["stop"])
          }, [
            (C(), V("svg", {
              viewBox: "0 0 12 12",
              fill: "currentColor",
              class: H(h(i).e("branch-icon")),
              "aria-hidden": "true"
            }, [...l[2] || (l[2] = [
              j("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M5.84 7.787a.2.2 0 0 0 .32 0l2.6-3.467A.2.2 0 0 0 8.6 4H3.4a.2.2 0 0 0-.16.32z"
              }, null, -1)
            ])], 2))
          ], 10, Tl)) : (C(), V("span", {
            key: 1,
            class: H(h(i).e("spacer")),
            "aria-hidden": "true"
          }, null, 2)),
          Me(f.$slots, "item", {
            node: r.value,
            navigate: c,
            toggle: a
          }, () => [
            j("button", {
              type: "button",
              class: H(h(i).e("item")),
              title: r.value.label,
              onClick: c
            }, [
              r.value.indexLabel ? (C(), V("span", {
                key: 0,
                class: H(h(i).e("index"))
              }, de(r.value.indexLabel), 3)) : le("", !0),
              j("span", {
                class: H(h(i).e("label"))
              }, de(r.value.label), 3)
            ], 10, Al)
          ])
        ], 6),
        s.value && r.value.isExpanded ? (C(), V("div", {
          key: 0,
          class: H(h(i).e("children")),
          role: "group"
        }, [
          (C(!0), V(Oe, null, Pe(r.value.children, (p) => (C(), Be(u, {
            key: p.id,
            node: p,
            onNavigate: l[0] || (l[0] = (g) => n("navigate", g)),
            onToggle: l[1] || (l[1] = (g) => n("toggle", g))
          }, {
            item: ft((g) => [
              Me(f.$slots, "item", Qe({ ref_for: !0 }, g))
            ]),
            _: 3
          }, 8, ["node"]))), 128))
        ], 2)) : le("", !0)
      ], 10, xl);
    };
  }
}), pd = /* @__PURE__ */ ge({
  name: "ZxTextEditorToC",
  __name: "toc",
  props: {
    editor: {
      type: Object,
      default: null
    },
    anchors: {
      type: Array,
      default: void 0
    },
    scrollContainer: {
      type: [String, Object, Function],
      default: void 0
    },
    minLevel: {
      type: Number,
      default: void 0
    },
    maxLevel: {
      type: Number,
      default: void 0
    },
    showIndex: {
      type: Boolean,
      default: !1
    },
    indexStrategy: {
      type: Function,
      default: void 0
    },
    expandedKeys: {
      type: Array,
      default: void 0
    },
    defaultExpandedKeys: {
      type: Array,
      default: void 0
    },
    autoExpandActivePath: {
      type: Boolean,
      default: !0
    },
    emptyText: {
      type: String,
      default: "暂无标题"
    }
  },
  emits: ["update:expandedKeys", "item-click"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = Ne("text-editor-toc"), r = W(null), { activeId: s, tree: c, expandedKeys: a, isEmpty: f, navigateTo: l, toggleExpanded: u } = fl({
      editor: $e(o, "editor"),
      anchors: $e(o, "anchors"),
      scrollContainer: $e(o, "scrollContainer"),
      minLevel: $e(o, "minLevel"),
      maxLevel: $e(o, "maxLevel"),
      showIndex: $e(o, "showIndex"),
      indexStrategy: $e(o, "indexStrategy"),
      expandedKeys: $e(o, "expandedKeys"),
      defaultExpandedKeys: $e(o, "defaultExpandedKeys"),
      autoExpandActivePath: $e(o, "autoExpandActivePath")
    }), p = async () => {
      var v, O;
      await pt();
      const w = (v = r.value) == null ? void 0 : v.querySelector(
        '[aria-current="location"]'
      ), k = (w == null ? void 0 : w.querySelector(`.${i.e("item")}`)) ?? w;
      (O = k == null ? void 0 : k.scrollIntoView) == null || O.call(k, {
        block: "nearest",
        behavior: "smooth"
      });
    };
    Q(s, (w) => {
      w && p();
    });
    const g = E(() => a.value), T = (w) => {
      const k = new Set(g.value);
      return k.has(w) ? k.delete(w) : k.add(w), [...k];
    }, L = (w) => {
      if (w.children.length === 0)
        return;
      const k = T(w.id);
      n("update:expandedKeys", k), u(w.id);
    }, D = (w) => {
      l(w.id), n("item-click", w);
    };
    return (w, k) => (C(), V("nav", {
      ref_key: "rootRef",
      ref: r,
      class: H(h(i).b()),
      "aria-label": "Table of contents"
    }, [
      j("div", {
        class: H(h(i).e("content"))
      }, [
        h(f) ? Me(w.$slots, "empty", bt(ht({ emptyText: e.emptyText })), () => [
          j("div", {
            class: H(h(i).e("empty"))
          }, de(e.emptyText), 3)
        ], void 0, 0) : (C(), V("div", {
          key: 1,
          class: H(h(i).e("tree")),
          role: "tree"
        }, [
          (C(!0), V(Oe, null, Pe(h(c), (v) => (C(), Be(Il, {
            key: v.id,
            node: v,
            onNavigate: D,
            onToggle: L
          }, {
            item: ft((O) => [
              Me(w.$slots, "item", Qe({ ref_for: !0 }, O))
            ]),
            _: 3
          }, 8, ["node"]))), 128))
        ], 2))
      ], 2)
    ], 2));
  }
}), ui = (e) => e, di = ui({
  status: {
    idle: "Ready",
    composing: "Writing instructions",
    prepared: "Ready to generate",
    starting: "Starting generation",
    streaming: "Generating",
    "abort-requested": "Requesting stop",
    "awaiting-review": "Ready to review",
    error: "Generation failed",
    conflict: "Document changed",
    stopped: "Stopped",
    completed: "Completed",
    detached: "Task running in background"
  },
  writingResultOutcome: {
    "document-changed": "The document changed. Regenerate to use the current text.",
    "anchor-lost": "The text at the cursor changed. Place the cursor, then regenerate.",
    "output-truncated": "The response hit the length limit. Copy it or regenerate.",
    "incomplete-result": "The response is incomplete. Copy it or regenerate.",
    "empty-result": "The response is empty. Add a topic and regenerate.",
    "invalid-structure": "The response does not match the requested format. Regenerate.",
    "outline-depth-exceeded": "The outline exceeds the requested depth. Regenerate.",
    "idea-count-mismatch": "The number of ideas differs from the request. Regenerate.",
    "duplicate-ideas": "Some ideas repeat. Regenerate."
  },
  chrome: {
    accept: "Accept",
    reject: "Reject",
    close: "Close",
    followUpPlaceholder: "Add a follow-up…",
    followUpAria: "Add a follow-up",
    reviewAria: "Inline diff review",
    reviewActionsAria: "Inline diff review actions",
    acceptUnavailable: "Accept unavailable: {reason}",
    controlUnavailable: "{label}. Unavailable: {reason}",
    hintAccept: "Accept",
    hintReject: "Reject",
    hintStep: "Step",
    followUpResets: "A follow-up clears {n} staged choice(s).",
    liveDecided: "Paragraph {ordinal}: {state}. {pending} pending.",
    liveAllDecided: "Paragraph {ordinal}: {state}. All changes decided.",
    liveFocused: "Paragraph {ordinal} of {total}: {state}.",
    liveUndecided: "Paragraph {ordinal}: back to pending."
  },
  hunk: {
    keep: "Keep",
    restore: "Keep original",
    undo: "Undo",
    kept: "Kept",
    restored: "Original kept",
    pending: "Pending",
    willDelete: "This paragraph will be removed",
    added: "New paragraph",
    ariaReplace: "Paragraph {ordinal} of {total}: {state}",
    ariaInsert: "Paragraph {ordinal} of {total} (new paragraph): {state}",
    ariaDelete: "Paragraph {ordinal} of {total} (removal): {state}"
  },
  presentation: {
    replacement: {
      title: "Review suggested edit",
      description: "Compare the removed and added text, then choose an action."
    },
    deletion: {
      title: "Review deletion",
      description: "This suggestion removes the selected text."
    },
    "no-change": {
      title: "No changes proposed",
      description: "The candidate matches the selected text. Accept closes the review without changing document history."
    },
    degraded: {
      title: "Limited diff preview",
      description: "The full inline diff cannot be shown safely. Accept is unavailable; reject or close this review."
    },
    conflict: {
      title: "Document changed",
      description: "Accept is unavailable until the review is restarted on the latest document."
    },
    error: {
      title: "Review unavailable",
      description: "The suggestion could not be prepared. Reject or close this review."
    }
  },
  disabledReason: {
    "disposition-pending": "Another review action is in progress.",
    "presentation-unverified": "The suggestion could not be verified.",
    "presentation-unsupported": "This suggestion cannot be reviewed inline.",
    "reject-only": "This review is reject-only.",
    conflict: "The document changed after this review started.",
    "action-unavailable": "This action is not currently available."
  },
  busy: {
    accept: "Accepting suggestion…",
    reject: "Rejecting suggestion…",
    "add-follow-up": "Starting follow-up…",
    close: "Closing preview…"
  },
  skills: {
    "improve-writing": {
      label: "Improve writing",
      description: "Clarify and strengthen the selected text"
    },
    proofread: {
      label: "Proofread",
      description: "Fix grammar and spelling"
    },
    explain: {
      label: "Explain",
      description: "Explain the selected text"
    },
    reformat: {
      label: "Reformat",
      description: "Reformat the selected text"
    }
  },
  slash: {
    "continue-writing": {
      label: "Continue writing"
    },
    "draft-outline": {
      label: "Draft an outline"
    },
    "brainstorm-ideas": {
      label: "Brainstorm ideas"
    }
  },
  surface: {
    askAi: "Ask AI",
    editWithAi: "Edit with AI",
    askAiPlaceholder: "Ask AI to write anything…",
    skills: "Skills",
    skillsSettings: "Skills settings",
    suggestions: "Suggestions",
    stop: "Stop",
    generating: "Generating",
    stopping: "Stopping…",
    insertBelow: "Insert below",
    insert: "Insert",
    copy: "Copy",
    copied: "Copied",
    copyFailed: "Could not copy. Select the text and copy it manually.",
    discard: "Discard",
    reviewRefine: "Review Refine",
    result: "AI result",
    resultActionsAria: "AI result actions",
    reviewResult: "Review AI result",
    continueReview: "Continue Review",
    selectionMenuAria: "Ask AI selection menu",
    skillsListAria: "AI skills",
    contextPlanned: "Will use {n} context blocks",
    contextSubmitted: "Used {n} context blocks",
    contextPrefix: "{n} preceding blocks",
    contextSuffix: "{n} following blocks",
    contextOutline: "outline",
    contextDigest: "summary",
    contextOmitted: "{n} blocks omitted",
    contextFull: "complete authorized text",
    contextPartial: "partial text",
    contextSummarized: "summary coverage",
    contextPolicyExcluded: "{n} blocks excluded by policy",
    contextTokensEstimated: "about {estimated} input tokens",
    contextTokensActual: "{actual} input tokens (estimated {estimated})"
  },
  handoff: {
    "multi-block-selection": "Skills work on one paragraph at a time. Select text within a single paragraph.",
    "explicit-line-break": "Selections with a manual line break are not supported yet. Select text on one line.",
    "unsupported-node": "AI editing is not available for this block type yet.",
    "collapsed-selection": "Select some text first.",
    "task-open": "An AI task is already open. Finish or close it before starting another.",
    "capture-failed": "Could not read this selection. Select the text again and retry.",
    unavailable: "Ask AI could not start for this selection."
  },
  error: {
    generic: "Something went wrong with this AI task.",
    category: {
      transport: "The AI service could not be reached.",
      "provider-adapter": "The AI service returned an error.",
      validation: "This request could not be completed as written.",
      "resource-limit": "This request is larger than the AI service allows.",
      unsupported: "This request is not supported here.",
      "anchor-lost": "The text this task was working on is no longer in the document.",
      conflict: "The document changed while this task was open.",
      abort: "This task could not be stopped."
    },
    code: {
      "transport.network": "Could not connect to the AI service. Check the network, then retry.",
      "transport.provider-unavailable": "The AI service is temporarily unavailable. Retry in a moment.",
      "transport.rate-limited": "Too many requests in a short time. Wait a moment, then retry.",
      "transport.transport-failed": "The request to the AI service failed.",
      "transport.transport-disconnected": "The connection closed before the response finished.",
      "transport.timeout": "The AI service took too long to respond.",
      "provider-adapter.auth-failed": "The AI service rejected the credentials of this site. Contact the site administrator.",
      "provider-adapter.quota-exceeded": "The AI service quota has run out. Contact the site administrator.",
      "provider-adapter.request-rejected": "The AI service rejected this request.",
      "provider-adapter.empty-output": "The AI service returned an empty response.",
      "provider-adapter.protocol": "The AI service returned a response that could not be read.",
      "provider-adapter.internal": "The AI integration hit an internal error.",
      "provider-adapter.handoff-failure": "The response could not be prepared for review.",
      "resource-limit.context-overflow": "The request is too long for the model. Select less text, then try again.",
      "resource-limit.output-truncated": "The response reached the length limit before it finished.",
      "resource-limit.resource-limit": "The response exceeded the allowed size.",
      "validation.content-filtered": "The AI service declined this request. Rephrase it, then try again.",
      "abort.abort-unsupported": "This AI service cannot stop a running task."
    }
  },
  action: {
    submit: "Generate",
    stop: "Stop",
    retry: "Retry",
    restart: "Regenerate",
    supersede: "Replace request",
    "follow-up": "Follow up",
    reveal: "Reveal",
    "review-previous": "Previous change",
    "review-next": "Next change",
    "review-decide": "Decide",
    "review-accept-all": "Accept all",
    "review-reject-all": "Reject all",
    "review-commit": "Apply",
    "review-regenerate": "Regenerate suggestion",
    "review-refine": "Review Refine",
    "retry-review-refine": "Retry refinement",
    close: "Close",
    "edit-prompt": "Edit instructions",
    "reselect-target": "Reselect text",
    "narrow-scope": "Narrow the selection",
    "choose-supported-command": "Choose another command",
    "contact-host": "Contact support"
  },
  actionHint: {
    retry: "Re-sends the same request",
    restart: "Uses the current document",
    "follow-up": "Builds on the previous result",
    "retry-review-refine": "Re-sends the same refinement"
  }
}), El = ui({
  status: {
    idle: "就绪",
    composing: "编辑要求",
    prepared: "准备生成",
    starting: "正在启动生成",
    streaming: "正在生成",
    "abort-requested": "正在请求停止",
    "awaiting-review": "等待审阅",
    error: "生成失败",
    conflict: "正文已变化",
    stopped: "已停止",
    completed: "已完成",
    detached: "任务在后台继续"
  },
  writingResultOutcome: {
    "document-changed": "正文已变化，请重新生成以使用当前正文。",
    "anchor-lost": "光标处的内容已变化，请先放置光标再重新生成。",
    "output-truncated": "回复达到长度上限被截断，可复制内容或重新生成。",
    "incomplete-result": "回复尚未完成，可复制内容或重新生成。",
    "empty-result": "回复为空，请补充主题后重新生成。",
    "invalid-structure": "回复不符合所需格式，请重新生成。",
    "outline-depth-exceeded": "大纲层级超出要求，请重新生成。",
    "idea-count-mismatch": "想法数量与要求不符，请重新生成。",
    "duplicate-ideas": "部分想法重复，请重新生成。"
  },
  chrome: {
    accept: "接受",
    reject: "拒绝",
    close: "关闭",
    followUpPlaceholder: "补充追问…",
    followUpAria: "补充追问",
    reviewAria: "行内改写审阅",
    reviewActionsAria: "行内改写审阅操作",
    acceptUnavailable: "无法接受：{reason}",
    controlUnavailable: "{label}。不可用：{reason}",
    hintAccept: "接受",
    hintReject: "拒绝",
    hintStep: "逐段",
    followUpResets: "追问会清空 {n} 项裁决。",
    liveDecided: "第 {ordinal} 段：{state}，还剩 {pending} 段待定。",
    liveAllDecided: "第 {ordinal} 段：{state}，已全部裁决。",
    liveFocused: "第 {ordinal} 段，共 {total} 段：{state}。",
    liveUndecided: "第 {ordinal} 段：已撤回，回到待定。"
  },
  hunk: {
    keep: "采用",
    restore: "留原文",
    undo: "撤回",
    kept: "已采用",
    restored: "留原文",
    pending: "待定",
    willDelete: "此段将删除",
    added: "新增",
    ariaReplace: "第 {ordinal} 段，共 {total} 段：{state}",
    ariaInsert: "第 {ordinal} 段，共 {total} 段（新增段落）：{state}",
    ariaDelete: "第 {ordinal} 段，共 {total} 段（删除）：{state}"
  },
  presentation: {
    replacement: {
      title: "审阅建议改写",
      description: "对比删除与新增内容，然后选择操作。"
    },
    deletion: {
      title: "审阅删除建议",
      description: "这条建议会删除所选文字。"
    },
    "no-change": {
      title: "没有提出改动",
      description: "候选文本与选区相同。接受后会关闭审阅，且不改写文档历史。"
    },
    degraded: {
      title: "仅提供有限预览",
      description: "完整行内 diff 无法安全展示。无法接受；请拒绝或关闭本次审阅。"
    },
    conflict: {
      title: "文档已变化",
      description: "请先按最新文档重新发起审阅，然后才能接受。"
    },
    error: {
      title: "无法审阅",
      description: "建议未能准备完成。请拒绝或关闭本次审阅。"
    }
  },
  disabledReason: {
    "disposition-pending": "另一项审阅操作正在进行。",
    "presentation-unverified": "建议未能通过校验。",
    "presentation-unsupported": "这条建议无法在行内审阅。",
    "reject-only": "本次审阅只能拒绝。",
    conflict: "审阅开始后文档已变化。",
    "action-unavailable": "当前无法执行此操作。"
  },
  busy: {
    accept: "正在接受建议…",
    reject: "正在拒绝建议…",
    "add-follow-up": "正在开始追问…",
    close: "正在关闭预览…"
  },
  skills: {
    "improve-writing": {
      label: "改进写作",
      description: "让所选文字更清晰、更有力"
    },
    proofread: {
      label: "校对",
      description: "修正语法和拼写"
    },
    explain: {
      label: "解释",
      description: "解释所选文字"
    },
    reformat: {
      label: "重排格式",
      description: "重新整理所选文字的格式"
    }
  },
  slash: {
    "continue-writing": {
      label: "继续写"
    },
    "draft-outline": {
      label: "起草大纲"
    },
    "brainstorm-ideas": {
      label: "头脑风暴"
    }
  },
  surface: {
    askAi: "问 AI",
    editWithAi: "用 AI 编辑",
    askAiPlaceholder: "让 AI 写任何内容…",
    skills: "技能",
    skillsSettings: "技能设置",
    suggestions: "建议",
    stop: "停止",
    generating: "生成中",
    stopping: "正在停止…",
    insertBelow: "插入到下方",
    insert: "插入",
    copy: "复制",
    copied: "已复制",
    copyFailed: "复制失败，请手动选中文本复制。",
    discard: "舍弃",
    reviewRefine: "继续改写",
    result: "AI 结果",
    resultActionsAria: "AI 结果操作",
    reviewResult: "审阅 AI 结果",
    continueReview: "继续审阅",
    selectionMenuAria: "问 AI 选区菜单",
    skillsListAria: "AI 技能",
    contextPlanned: "将参考 {n} 段上下文",
    contextSubmitted: "已参考 {n} 段上下文",
    contextPrefix: "光标前 {n} 段",
    contextSuffix: "光标后 {n} 段",
    contextOutline: "大纲",
    contextDigest: "摘要",
    contextOmitted: "省略 {n} 段",
    contextFull: "完整授权正文",
    contextPartial: "部分正文",
    contextSummarized: "摘要覆盖",
    contextPolicyExcluded: "策略排除 {n} 段",
    contextTokensEstimated: "约 {estimated} 输入 token",
    contextTokensActual: "实际 {actual} 输入 token（预估 {estimated}）"
  },
  handoff: {
    "multi-block-selection": "技能一次只处理一个段落。请在同一段内选择文字。",
    "explicit-line-break": "暂不支持包含手动换行的选区。请选择同一行中的文字。",
    "unsupported-node": "这类块暂不支持 AI 编辑。",
    "collapsed-selection": "请先选中一段文字。",
    "task-open": "已有进行中的 AI 任务。请先完成或关闭后再开始新的任务。",
    "capture-failed": "无法读取这次选区。请重新选择文字后再试。",
    unavailable: "无法对这次选区启动问 AI。"
  },
  error: {
    generic: "本次 AI 任务出错了。",
    category: {
      transport: "无法连接 AI 服务。",
      "provider-adapter": "AI 服务返回了错误。",
      validation: "这条请求无法按当前写法完成。",
      "resource-limit": "这条请求超出了 AI 服务的处理上限。",
      unsupported: "此处不支持这条请求。",
      "anchor-lost": "本次任务处理的文字已不在文档中。",
      conflict: "任务进行期间文档已变化。",
      abort: "无法停止本次任务。"
    },
    code: {
      "transport.network": "无法连接 AI 服务。请检查网络后重试。",
      "transport.provider-unavailable": "AI 服务暂时不可用，请稍后重试。",
      "transport.rate-limited": "短时间内请求过多，请稍等后重试。",
      "transport.transport-failed": "发往 AI 服务的请求失败了。",
      "transport.transport-disconnected": "回复完成前连接已断开。",
      "transport.timeout": "AI 服务响应超时。",
      "provider-adapter.auth-failed": "AI 服务拒绝了本站的凭据，请联系站点管理员。",
      "provider-adapter.quota-exceeded": "AI 服务额度已用完，请联系站点管理员。",
      "provider-adapter.request-rejected": "AI 服务拒绝了这条请求。",
      "provider-adapter.empty-output": "AI 服务返回了空回复。",
      "provider-adapter.protocol": "AI 服务返回的内容无法解析。",
      "provider-adapter.internal": "AI 集成内部出错。",
      "provider-adapter.handoff-failure": "回复未能整理成可审阅的结果。",
      "resource-limit.context-overflow": "请求内容超出模型上限。请少选一些文字后再试。",
      "resource-limit.output-truncated": "回复达到长度上限，未能写完。",
      "resource-limit.resource-limit": "回复超出了允许的大小。",
      "validation.content-filtered": "AI 服务拒绝回答这条请求。请换个说法后再试。",
      "abort.abort-unsupported": "这个 AI 服务不支持中途停止。"
    }
  },
  action: {
    submit: "生成",
    stop: "停止",
    retry: "重试",
    restart: "重新生成",
    supersede: "替换请求",
    "follow-up": "追问",
    reveal: "显示任务",
    "review-previous": "上一处",
    "review-next": "下一处",
    "review-decide": "裁决",
    "review-accept-all": "全部接受",
    "review-reject-all": "全部拒绝",
    "review-commit": "应用",
    "review-regenerate": "重新生成建议",
    "review-refine": "继续改写",
    "retry-review-refine": "重试改写",
    close: "关闭",
    "edit-prompt": "修改要求",
    "reselect-target": "重新选择",
    "narrow-scope": "缩小范围",
    "choose-supported-command": "换个命令",
    "contact-host": "联系管理员"
  },
  actionHint: {
    retry: "重发同一请求",
    restart: "按当前正文生成",
    "follow-up": "基于上一次结果",
    "retry-review-refine": "重发同一改写"
  }
}), Sl = (e, t) => e.replace(
  /\{(\w+)\}/g,
  (o, n) => `${t[n] ?? `{${n}}`}`
), _l = (e) => (e ?? "").toLowerCase().replace(/_/g, "-").startsWith("zh"), Ol = (e) => _l(e) ? El : di, Rl = (e) => Qs.map((t) => {
  const o = e.skills[t.skillId];
  return o ? { ...t, label: o.label, description: o.description } : t;
}), Nl = (e) => ea.map((t) => {
  const o = e.slash[t.id];
  return o ? { ...t, label: o.label } : t;
}), xo = (e, t = di) => t.handoff[e.reason] ?? t.handoff.unavailable, Cn = () => {
  const { lang: e } = Ji(), t = E(() => Ol(e.value)), o = E(
    () => Rl(t.value)
  ), n = E(
    () => Nl(t.value)
  );
  return {
    lang: e,
    messages: t,
    defaultSkills: o,
    slashSuggestions: n,
    formatCopy: Sl
  };
};
let Ll = 0;
const Bl = (e = `inline-ai-focus-${++Ll}`) => {
  let t = null;
  return {
    create: (o = 1500) => (t = {
      instanceId: e,
      expiresAt: Date.now() + Math.max(0, o),
      revoked: !1
    }, t),
    current: () => t,
    revoke: () => {
      t ? t = { ...t, revoked: !0 } : t = null;
    },
    isActive: (o = t) => !o || o !== t || o.revoked || o.instanceId !== e ? !1 : Date.now() <= o.expiresAt
  };
}, Ml = (e) => e instanceof HTMLElement ? !!e.closest('input, textarea, [contenteditable="true"]') : !1, Dl = (e) => {
  var i;
  const t = e.event.target, o = Ml(t);
  e.claim(), (i = e.focusToken) == null || i.create(), o || e.event.preventDefault();
  const n = e.inputEl ?? (o && t instanceof HTMLElement ? t : null);
  n && typeof n.focus == "function" && n.focus({ preventScroll: !0 });
}, Cl = (e) => {
  e.claim();
  const t = e.focusToken.create(), o = typeof document < "u" ? document.activeElement : null;
  return (e.raf ?? requestAnimationFrame)(async () => {
    var s;
    if (!e.focusToken.isActive(t) || (await ((s = e.afterGeometry) == null ? void 0 : s.call(e)), !e.focusToken.isActive(t))) return;
    const i = e.getInput();
    if (!i) return;
    const r = typeof document < "u" ? document.activeElement : null;
    if (r && r !== i && r !== o && !i.contains(r)) {
      const c = r === document.body || r === document.documentElement, a = !!r.closest("[data-inline-ai-focus-root]"), f = r.matches('[contenteditable="true"]');
      if (!c && !a && !f) {
        const l = r.closest(
          'input, textarea, button, select, [contenteditable="true"], [tabindex]'
        );
        if (l && !i.contains(l)) return;
      }
    }
    i.focus({ preventScroll: !0 });
  }), t;
}, Fl = (e) => Ko(e), gn = (e) => e.kind === "geometry" || e.kind === "scroll" || e.kind === "visualViewport", To = (e) => e !== !1 && e !== null && e !== void 0, zl = (e) => {
  const t = async () => {
    await pt(), To(e.activationKey()) && e.input.value && Cl({
      claim: e.claim,
      focusToken: e.focusToken,
      getInput: () => e.input.value
    });
  };
  return Q(
    [e.activationKey, e.input],
    ([o]) => {
      if (!To(o)) {
        e.focusToken.revoke();
        return;
      }
      e.input.value && t();
    },
    { flush: "post", immediate: !0 }
  ), gt(() => {
    e.focusToken.revoke();
  }), {
    requestFocus: t
  };
}, Pl = {
  key: 0,
  class: "zx-inline-ai-surface__sr-only"
}, Vl = ["value", "placeholder", "aria-label", "aria-disabled", "data-testid"], jl = ["disabled", "aria-disabled", "data-testid"], Hl = /* @__PURE__ */ ge({
  __name: "InlineAiPromptComposer",
  props: {
    modelValue: {},
    variant: {},
    activationKey: { type: [String, Number, Boolean, null] },
    submitEnabled: { type: Boolean },
    shortcut: {},
    inputAriaDisabled: { type: [Boolean, String] },
    placeholder: {},
    accessibleLabel: {}
  },
  emits: ["update:modelValue", "submit", "focus-intent"],
  setup(e, { expose: t, emit: o }) {
    const n = e, i = o, r = Re(null), s = Bl(), c = Re(n.modelValue), { messages: a } = Cn(), f = E(() => n.variant === "slash"), l = E(() => n.variant === "selection"), u = E(() => !c.value.trim()), p = E(
      () => n.accessibleLabel ?? (f.value ? a.value.surface.askAi : a.value.surface.editWithAi)
    ), g = E(
      () => n.placeholder ?? (f.value ? a.value.surface.askAiPlaceholder : a.value.surface.editWithAi)
    ), T = E(
      () => l.value ? "inline-ai-edit-with-ai" : "inline-ai-surface-prompt"
    ), L = E(
      () => l.value ? "inline-ai-prompt-send" : "inline-ai-surface-send"
    ), D = E(() => f.value || !u.value), w = E(
      () => l.value ? [
        "zx-inline-ai-prompt-composer",
        "zx-inline-ai-selection-menu__prompt-row"
      ] : [
        "zx-inline-ai-prompt-composer",
        "zx-inline-ai-surface__prompt-row",
        { "zx-inline-ai-surface__prompt-row--slash": f.value }
      ]
    ), k = E(
      () => l.value ? ["zx-inline-ai-prompt-composer__selection-label"] : ["zx-inline-ai-surface__prompt-label"]
    ), v = E(
      () => l.value ? [
        "zx-inline-ai-prompt-composer__control",
        "zx-inline-ai-selection-menu__prompt"
      ] : [
        "zx-inline-ai-prompt-composer__control",
        "zx-inline-ai-surface__prompt",
        { "zx-inline-ai-surface__prompt--slash": f.value }
      ]
    ), O = E(
      () => l.value ? ["zx-inline-ai-selection-menu__send"] : ["zx-inline-ai-surface__send", "zx-inline-ai-surface__hit"]
    ), N = () => {
      const B = r.value;
      if (!B) return;
      const R = getComputedStyle(B), S = Number.parseFloat(R.minHeight) || 0, U = Number.parseFloat(R.maxHeight) || Number.POSITIVE_INFINITY;
      B.style.height = "auto";
      const J = Math.min(
        Math.max(B.scrollHeight, S),
        U
      );
      B.style.height = `${J}px`, B.style.overflowY = B.scrollHeight > U ? "auto" : "hidden";
    };
    zl({
      activationKey: () => n.activationKey,
      claim: () => i("focus-intent"),
      focusToken: s,
      input: r
    }), Q(
      () => n.modelValue,
      (B) => {
        B !== c.value && (c.value = B);
      }
    ), Q([c, () => n.variant], () => {
      pt(N);
    }), Lt(() => {
      N();
    });
    const y = (B) => {
      const R = B.currentTarget;
      c.value = R.value, i("update:modelValue", R.value);
    }, m = () => {
      i("submit");
    }, _ = () => {
      m();
    }, q = (B) => {
      B.key !== "Enter" || B.isComposing || B.keyCode === 229 || Fl(B) || B.shiftKey || B.metaKey || B.ctrlKey || (B.preventDefault(), m());
    }, ne = (B) => {
      Dl({
        event: B,
        claim: () => i("focus-intent"),
        inputEl: r.value,
        focusToken: s
      });
      const R = s.current();
      queueMicrotask(() => {
        s.current() === R && s.revoke();
      });
    }, ie = () => {
      if (s.isActive()) {
        s.revoke();
        return;
      }
      i("focus-intent");
    };
    return t({ focus: () => {
      var B;
      (B = r.value) == null || B.focus({ preventScroll: !0 });
    } }), (B, R) => (C(), V("div", {
      class: H(w.value)
    }, [
      j("label", {
        class: H(k.value)
      }, [
        l.value ? le("", !0) : (C(), V("span", Pl, de(p.value), 1)),
        j("textarea", {
          ref_key: "inputEl",
          ref: r,
          value: c.value,
          class: H(v.value),
          rows: "1",
          placeholder: g.value,
          "aria-label": p.value,
          "aria-disabled": e.inputAriaDisabled,
          "data-testid": T.value,
          "data-inline-ai-edit-with-ai": "",
          onInput: y,
          onPointerdown: ne,
          onFocus: ie,
          onKeydown: q
        }, null, 42, Vl)
      ], 2),
      u.value && e.shortcut ? (C(), V("kbd", {
        key: 0,
        class: H(
          l.value ? "zx-inline-ai-selection-menu__shortcut" : "zx-inline-ai-surface__shortcut"
        ),
        "aria-hidden": "true"
      }, de(e.shortcut), 3)) : le("", !0),
      D.value ? (C(), V("button", {
        key: 1,
        type: "button",
        class: H(O.value),
        disabled: l.value ? void 0 : u.value || n.submitEnabled === !1,
        "aria-disabled": l.value && n.submitEnabled === !1 ? "true" : void 0,
        "aria-label": "Send",
        "data-testid": L.value,
        onClick: _
      }, [
        P(h(Ie), {
          icon: "lucide:arrow-up",
          "aria-hidden": "true"
        })
      ], 10, jl)) : le("", !0)
    ], 2));
  }
}), $l = Object.freeze([
  { id: "paragraph", label: "Text", icon: "lucide:type" },
  { id: "heading-1", label: "Heading 1", icon: "lucide:heading-1" },
  { id: "heading-2", label: "Heading 2", icon: "lucide:heading-2" },
  { id: "heading-3", label: "Heading 3", icon: "lucide:heading-3" },
  { id: "heading-4", label: "Heading 4", icon: "lucide:heading-4" },
  { id: "bullet-list", label: "Bulleted list", icon: "lucide:list" },
  { id: "ordered-list", label: "Numbered list", icon: "lucide:list-ordered" },
  { id: "task-list", label: "To-do list", icon: "lucide:list-checks" },
  { id: "code-block", label: "Code", icon: "lucide:code" },
  { id: "blockquote", label: "Quote", icon: "lucide:quote" }
]), Ul = Object.freeze([
  { id: "color", label: "Text color", glyph: "A" },
  { id: "bold", label: "Bold", glyph: "B" },
  { id: "italic", label: "Italic", glyph: "I" },
  { id: "underline", label: "Underline", glyph: "U" },
  { id: "clear", label: "Clear formatting", glyph: "Tx" },
  { id: "link", label: "Link", glyph: "a/" },
  { id: "strike", label: "Strikethrough", glyph: "S" },
  { id: "code", label: "Code", glyph: "</>" }
]), Te = (e, t) => {
  var i;
  if (!(e != null && e.chain)) return !1;
  const o = e.chain().focus(), n = t(o);
  return ((i = n == null ? void 0 : n.run) == null ? void 0 : i.call(n)) ?? !1;
}, Kl = (e) => e != null && e.isActive ? e.isActive("heading", { level: 1 }) ? "Heading 1" : e.isActive("heading", { level: 2 }) ? "Heading 2" : e.isActive("heading", { level: 3 }) ? "Heading 3" : e.isActive("heading", { level: 4 }) ? "Heading 4" : e.isActive("bulletList") ? "Bulleted list" : e.isActive("orderedList") ? "Numbered list" : e.isActive("taskList") ? "To-do list" : e.isActive("codeBlock") ? "Code" : e.isActive("blockquote") ? "Quote" : "Normal text" : "Normal text", ql = (e) => e != null && e.isActive ? e.isActive("heading", { level: 1 }) ? "heading-1" : e.isActive("heading", { level: 2 }) ? "heading-2" : e.isActive("heading", { level: 3 }) ? "heading-3" : e.isActive("heading", { level: 4 }) ? "heading-4" : e.isActive("bulletList") ? "bullet-list" : e.isActive("orderedList") ? "ordered-list" : e.isActive("taskList") ? "task-list" : e.isActive("codeBlock") ? "code-block" : e.isActive("blockquote") ? "blockquote" : "paragraph" : "paragraph", Gl = (e, t) => {
  switch (t) {
    case "paragraph":
      return Te(e, (o) => {
        var n;
        return (n = o.setParagraph) == null ? void 0 : n.call(o);
      });
    case "heading-1":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 1 });
      });
    case "heading-2":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 2 });
      });
    case "heading-3":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 3 });
      });
    case "heading-4":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleHeading) == null ? void 0 : n.call(o, { level: 4 });
      });
    case "bullet-list":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleBulletList) == null ? void 0 : n.call(o);
      });
    case "ordered-list":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleOrderedList) == null ? void 0 : n.call(o);
      });
    case "task-list":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleTaskList) == null ? void 0 : n.call(o);
      });
    case "blockquote":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleBlockquote) == null ? void 0 : n.call(o);
      });
    case "code-block":
      return Te(e, (o) => {
        var n;
        return (n = o.toggleCodeBlock) == null ? void 0 : n.call(o);
      });
    default:
      return !1;
  }
}, Wl = (e, t) => !(e != null && e.isActive) || t === "clear" || t === "color" ? !1 : t === "link" ? e.isActive("link") : e.isActive(t), Jl = "var(--zx-semantic-action-focus-ring)", Zl = (e, t, o = () => typeof window < "u" ? window.prompt("Link URL", "https://") : null) => {
  var n, i, r, s;
  switch (t) {
    case "color": {
      const c = (i = (n = e == null ? void 0 : e.getAttributes) == null ? void 0 : n.call(e, "textStyle")) == null ? void 0 : i.color;
      return typeof c == "string" && c.length > 0 ? Te(e, (a) => {
        var f;
        return (f = a.unsetColor) == null ? void 0 : f.call(a);
      }) : Te(
        e,
        (a) => {
          var f;
          return (f = a.setColor) == null ? void 0 : f.call(a, Jl);
        }
      );
    }
    case "bold":
      return Te(e, (c) => {
        var a;
        return (a = c.toggleBold) == null ? void 0 : a.call(c);
      });
    case "italic":
      return Te(e, (c) => {
        var a;
        return (a = c.toggleItalic) == null ? void 0 : a.call(c);
      });
    case "underline":
      return Te(e, (c) => {
        var a;
        return (a = c.toggleUnderline) == null ? void 0 : a.call(c);
      });
    case "strike":
      return Te(e, (c) => {
        var a;
        return (a = c.toggleStrike) == null ? void 0 : a.call(c);
      });
    case "code":
      return Te(e, (c) => {
        var a;
        return (a = c.toggleCode) == null ? void 0 : a.call(c);
      });
    case "clear":
      return Te(e, (c) => {
        var a;
        return (a = c.unsetAllMarks) == null ? void 0 : a.call(c);
      });
    case "link": {
      if ((r = e == null ? void 0 : e.isActive) != null && r.call(e, "link"))
        return Te(
          e,
          (a) => {
            var f, l, u;
            return (u = (l = (f = a.extendMarkRange) == null ? void 0 : f.call(a, "link")) == null ? void 0 : l.unsetLink) == null ? void 0 : u.call(l);
          }
        );
      const c = (s = o()) == null ? void 0 : s.trim();
      return c ? Te(
        e,
        (a) => {
          var f, l, u;
          return (u = (l = (f = a.extendMarkRange) == null ? void 0 : f.call(a, "link")) == null ? void 0 : l.setLink) == null ? void 0 : u.call(l, { href: c });
        }
      ) : !1;
    }
    default:
      return !1;
  }
}, Xl = ["aria-label"], Yl = ["aria-expanded", "aria-disabled"], Ql = { class: "zx-inline-ai-selection-menu__turn-into-label" }, ec = ["aria-checked", "data-active", "aria-disabled", "onClick"], tc = {
  class: "zx-inline-ai-selection-menu__turn-into-item-icon",
  "aria-hidden": "true"
}, nc = { class: "zx-inline-ai-selection-menu__turn-into-item-label" }, oc = {
  key: 1,
  class: "zx-inline-ai-selection-menu__check-spacer",
  "aria-hidden": "true"
}, ic = {
  class: "zx-inline-ai-selection-menu__format",
  "data-testid": "inline-ai-format-grid",
  role: "toolbar",
  "aria-label": "Text formatting"
}, rc = ["aria-label", "aria-pressed", "aria-disabled", "data-format", "onClick"], sc = { class: "zx-inline-ai-selection-menu__skills-header" }, ac = { class: "zx-inline-ai-selection-menu__section-label" }, lc = ["aria-label"], cc = ["data-skill-id", "data-testid", "aria-disabled", "onClick"], uc = ["data-reason", "title"], dc = { class: "zx-inline-ai-selection-menu__notice-text" }, fc = {
  key: 1,
  class: "zx-inline-ai-selection-menu__divider",
  "aria-hidden": "true"
}, pc = ["aria-disabled"], mc = ["aria-disabled"], vc = {
  class: "zx-ai-authoring-sr-only",
  "data-testid": "inline-ai-capability-reason",
  role: "status",
  "aria-live": "polite"
}, gc = /* @__PURE__ */ ge({
  __name: "InlineAiSelectionMenu",
  props: {
    skills: {},
    editor: { default: null },
    disabled: { type: Boolean, default: !1 },
    capabilities: { default: null },
    autoFocusPrompt: { type: Boolean, default: !1 },
    notice: { default: null }
  },
  emits: ["skill-invoke", "edit-with-ai", "prompt-submit", "continue-review", "review-refine", "retain-selection", "prompt-draft"],
  setup(e, { emit: t }) {
    const o = t, n = W(!1), i = W(""), r = W(0), s = W(""), c = W(null);
    let a = null;
    const { messages: f, defaultSkills: l } = Cn(), u = E(() => e.skills ?? l.value), p = E(
      () => e.notice ? xo(e.notice, f.value) : ""
    ), g = (oe, be) => {
      var Ve;
      if (e.disabled)
        return { enabled: !1, reason: "authority-mismatch" };
      const re = (Ve = e.capabilities) == null ? void 0 : Ve[oe];
      return re || (be ? { enabled: !0 } : { enabled: !1, reason: "upstream-action-disabled" });
    }, T = E(() => g("format", !0)), L = E(() => g("startAi", !0)), D = E(() => g("submit", !0)), w = E(() => g("continueReview", !1)), k = E(() => g("reviewRefine", !1)), v = E(
      () => e.capabilities !== null && (w.value.enabled || w.value.reason !== "no-open-task")
    ), O = E(
      () => e.capabilities !== null && (k.value.enabled || k.value.reason !== "no-open-task")
    ), N = E(() => ({
      editor: e.editor,
      revision: r.value
    })), y = E(() => Kl(N.value.editor)), m = E(() => ql(N.value.editor)), { text: _ } = Do({
      runtime: _n(),
      bindingId: "textEditor.inlineEdit.open"
    }), q = Ul, ne = $l, ie = () => {
      r.value += 1;
    }, ee = (oe) => {
      oe && (s.value = `authoring.capability.${oe}`);
    }, B = () => {
      a != null && (clearTimeout(a), a = null);
    }, R = () => {
      if (!T.value.enabled) {
        ee(T.value.reason);
        return;
      }
      B(), n.value = !0;
    }, S = () => {
      B(), a = setTimeout(() => {
        n.value = !1, a = null;
      }, 140);
    }, U = () => {
      B(), n.value = !1;
    };
    Q(
      () => e.editor,
      () => {
        r.value += 1, U();
      }
    ), Q(i, (oe) => {
      o("prompt-draft", oe);
    }), Q(
      () => e.notice,
      (oe) => {
        oe && (s.value = xo(
          oe,
          f.value
        ));
      },
      { immediate: !0 }
    ), gt(() => {
      U();
    });
    const J = () => {
      if (!T.value.enabled) {
        ee(T.value.reason);
        return;
      }
      n.value ? U() : R();
    }, fe = (oe) => {
      if (!T.value.enabled) {
        ee(T.value.reason);
        return;
      }
      Gl(e.editor, oe), U(), ie();
    }, G = (oe) => {
      if (!T.value.enabled) {
        ee(T.value.reason);
        return;
      }
      Zl(e.editor, oe), ie();
    }, ce = (oe) => Wl(N.value.editor, oe), ue = (oe) => {
      if (!L.value.enabled) {
        ee(L.value.reason);
        return;
      }
      o("retain-selection"), o("skill-invoke", oe);
    }, De = () => {
      const oe = i.value.trim();
      if (!oe) {
        if (!L.value.enabled) {
          ee(L.value.reason);
          return;
        }
        o("edit-with-ai");
        return;
      }
      if (!D.value.enabled) {
        ee(D.value.reason);
        return;
      }
      o("prompt-submit", oe);
    }, we = () => {
      if (!w.value.enabled) {
        ee(w.value.reason);
        return;
      }
      o("continue-review");
    }, Ge = () => {
      var be;
      const oe = i.value.trim();
      if (!oe) {
        ee("empty-prompt"), (be = c.value) == null || be.focus();
        return;
      }
      if (!k.value.enabled) {
        ee(k.value.reason);
        return;
      }
      o("review-refine", oe);
    }, ve = (oe) => {
      const be = oe.target;
      be != null && be.closest('input, textarea, [contenteditable="true"]') || oe.preventDefault();
    }, Le = () => {
      o("retain-selection");
    }, Ae = (oe) => oe ? void 0 : "true";
    return (oe, be) => (C(), V("div", {
      class: "zx-inline-ai-selection-menu",
      "data-testid": "inline-ai-selection-menu",
      "data-inline-ai-focus-root": "",
      role: "menu",
      "aria-label": h(f).surface.selectionMenuAria,
      onMousedown: ve
    }, [
      j("div", {
        class: "zx-inline-ai-selection-menu__turn-into",
        onMouseenter: R,
        onMouseleave: S
      }, [
        j("button", {
          type: "button",
          class: "zx-inline-ai-selection-menu__turn-into-trigger",
          "data-testid": "inline-ai-turn-into-trigger",
          "aria-haspopup": "menu",
          "aria-expanded": n.value,
          "aria-disabled": Ae(T.value.enabled),
          onClick: J,
          onFocus: R
        }, [
          P(h(Ie), {
            class: "zx-inline-ai-selection-menu__turn-into-icon",
            icon: "lucide:type",
            "aria-hidden": "true"
          }),
          j("span", Ql, de(y.value), 1),
          P(h(Ie), {
            class: "zx-inline-ai-selection-menu__chevron",
            icon: "lucide:chevron-right",
            "aria-hidden": "true"
          })
        ], 40, Yl),
        n.value ? (C(), V("div", {
          key: 0,
          class: "zx-inline-ai-selection-menu__turn-into-panel",
          "data-testid": "inline-ai-turn-into-panel",
          role: "menu",
          "aria-label": "Turn into",
          onMouseenter: R,
          onMouseleave: S
        }, [
          (C(!0), V(Oe, null, Pe(h(ne), (re) => (C(), V("button", {
            key: re.id,
            type: "button",
            class: "zx-inline-ai-selection-menu__turn-into-item",
            role: "menuitemradio",
            "aria-checked": m.value === re.id,
            "data-active": m.value === re.id ? "true" : "false",
            "aria-disabled": Ae(T.value.enabled),
            onClick: (Ve) => fe(re.id)
          }, [
            j("span", tc, [
              P(h(Ie), {
                icon: re.icon
              }, null, 8, ["icon"])
            ]),
            j("span", nc, de(re.label), 1),
            m.value === re.id ? (C(), Be(h(Ie), {
              key: 0,
              class: "zx-inline-ai-selection-menu__check",
              icon: "lucide:check",
              "aria-hidden": "true"
            })) : (C(), V("span", oc))
          ], 8, ec))), 128))
        ], 32)) : le("", !0)
      ], 32),
      be[1] || (be[1] = j("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      j("div", ic, [
        (C(!0), V(Oe, null, Pe(h(q), (re) => (C(), V("button", {
          key: re.id,
          type: "button",
          class: H(["zx-inline-ai-selection-menu__format-btn", {
            "is-active": ce(re.id),
            "is-italic": re.id === "italic",
            "is-underline": re.id === "underline",
            "is-strike": re.id === "strike"
          }]),
          "aria-label": re.label,
          "aria-pressed": ce(re.id),
          "aria-disabled": Ae(T.value.enabled),
          "data-format": re.id,
          onClick: (Ve) => G(re.id)
        }, de(re.glyph), 11, rc))), 128))
      ]),
      be[2] || (be[2] = j("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      j("div", sc, [
        j("span", ac, de(h(f).surface.skills), 1),
        P(h(Ie), {
          class: "zx-inline-ai-selection-menu__skills-icon",
          icon: "lucide:sliders-horizontal",
          "aria-hidden": "true",
          "data-testid": "inline-ai-skills-settings-icon"
        })
      ]),
      j("div", {
        class: "zx-inline-ai-selection-menu__skills",
        "data-testid": "inline-ai-skills-list",
        role: "group",
        "aria-label": h(f).surface.skillsListAria
      }, [
        (C(!0), V(Oe, null, Pe(u.value, (re) => (C(), V("button", {
          key: re.skillId,
          type: "button",
          class: "zx-inline-ai-selection-menu__skill",
          role: "menuitem",
          "data-skill-id": re.skillId,
          "data-testid": `inline-ai-skill-${re.skillId}`,
          "aria-disabled": Ae(L.value.enabled),
          onClick: (Ve) => ue(re)
        }, de(re.label), 9, cc))), 128))
      ], 8, lc),
      e.notice ? (C(), V("p", {
        key: 0,
        class: "zx-inline-ai-selection-menu__notice",
        "data-testid": "inline-ai-selection-notice",
        "data-reason": e.notice.reason,
        title: e.notice.detail,
        role: "note"
      }, [
        P(h(Ie), {
          class: "zx-inline-ai-selection-menu__notice-icon",
          icon: "lucide:info",
          "aria-hidden": "true"
        }),
        j("span", dc, de(p.value), 1)
      ], 8, uc)) : le("", !0),
      v.value || O.value ? (C(), V("div", fc)) : le("", !0),
      v.value ? (C(), V("button", {
        key: 2,
        type: "button",
        class: "zx-inline-ai-selection-menu__skill",
        "data-testid": "inline-ai-continue-review",
        "aria-disabled": Ae(w.value.enabled),
        onClick: we
      }, de(h(f).surface.continueReview), 9, pc)) : le("", !0),
      O.value ? (C(), V("button", {
        key: 3,
        type: "button",
        class: "zx-inline-ai-selection-menu__skill",
        "data-testid": "inline-ai-review-refine",
        "aria-disabled": Ae(k.value.enabled),
        onClick: Ge
      }, de(h(f).surface.reviewRefine), 9, mc)) : le("", !0),
      be[3] || (be[3] = j("div", {
        class: "zx-inline-ai-selection-menu__divider",
        "aria-hidden": "true"
      }, null, -1)),
      P(Hl, {
        ref_key: "promptComposerRef",
        ref: c,
        modelValue: i.value,
        "onUpdate:modelValue": be[0] || (be[0] = (re) => i.value = re),
        variant: "selection",
        "activation-key": e.autoFocusPrompt ? !0 : null,
        "submit-enabled": D.value.enabled,
        shortcut: h(_),
        "input-aria-disabled": Ae(
          i.value.trim() ? D.value.enabled : L.value.enabled || D.value.enabled || D.value.reason === "empty-prompt"
        ),
        onSubmit: De,
        onFocusIntent: Le
      }, null, 8, ["modelValue", "activation-key", "submit-enabled", "shortcut", "input-aria-disabled"]),
      j("div", vc, de(s.value), 1)
    ], 40, Xl));
  }
}), bc = (e = globalThis.matchMedia) => {
  var t;
  try {
    return ((t = e == null ? void 0 : e("(prefers-reduced-motion: reduce)")) == null ? void 0 : t.matches) === !0;
  } catch {
    return !1;
  }
}, hc = (e) => {
  bc() && (e.style.setProperty("transition", "none"), e.style.setProperty("animation", "none"), e.dataset.inlineAiReducedMotion = "true");
}, yc = (e) => {
  const t = e.elements.floating;
  t.style.setProperty(
    "--inline-ai-available-width",
    `${Math.max(0, Math.floor(e.availableWidth))}px`
  ), t.style.setProperty(
    "--inline-ai-available-height",
    `${Math.max(0, Math.floor(e.availableHeight))}px`
  ), t.dataset.inlineAiViewportSource = globalThis.visualViewport ? "visualViewport" : "layoutViewport", hc(t);
}, kc = Object.freeze({
  fallbackPlacements: ["top-start"]
}), wc = Object.freeze({
  padding: qo,
  // A retained target can move outside the viewport while its task remains
  // open. For bottom/top placement, crossAxis is the vertical axis: clamp the
  // recovery surface into the visible viewport instead of following the
  // off-screen document coordinate.
  crossAxis: !0
}), xc = Object.freeze({
  padding: qo,
  apply: yc
}), Tc = (e) => {
  var o;
  if (!e || typeof e != "object") return !1;
  const t = (o = e.toJSON) == null ? void 0 : o.call(e);
  return (t == null ? void 0 : t.type) === "nodeRange";
}, Ao = /* @__PURE__ */ new Set([
  "image",
  "iframe",
  "video",
  "imageGroup",
  "codeBlock",
  "horizontalRule"
]), Ac = Object.freeze({
  strategy: "fixed",
  placement: "bottom-start",
  offset: 8,
  flip: kc,
  shift: wc,
  size: xc
}), Ic = (e = {}) => Object.freeze({
  ...e,
  ...Ac
}), Ec = (e) => Number.isFinite(e.top) && Number.isFinite(e.left) && e.height > 0 && // Allow zero-width caret rects at line ends; reject empty/invalid boxes.
(e.width > 0 || e.height >= 1), Sc = (e) => {
  const t = Array.from(e).filter(Ec);
  return t.length === 0 ? null : t[t.length - 1];
}, Io = (e) => {
  const t = e.clientRects ? Sc(e.clientRects) : null;
  if (t)
    return new DOMRect(t.right, t.top, 0, Math.max(1, t.height));
  const o = Math.max(e.from, e.to), n = o > Math.min(e.from, e.to) ? o - 1 : o, i = e.coordsAtPos(n), r = i.right, s = i.top, c = Math.max(1, i.bottom - i.top);
  return new DOMRect(r, s, 0, c);
}, _c = (e) => {
  if (typeof window > "u" || typeof document > "u")
    return [];
  const t = window.getSelection();
  if (!t || t.isCollapsed || t.rangeCount === 0)
    return [];
  const o = t.getRangeAt(0), n = e.dom;
  return n && !n.contains(o.commonAncestorContainer) && o.commonAncestorContainer !== n ? [] : Array.from(o.getClientRects());
}, Oc = (e, t) => {
  let o, n;
  return () => {
    var i;
    try {
      if (!e || e.isDestroyed) return null;
      const r = e.view;
      if (!((i = r == null ? void 0 : r.state) != null && i.selection) || typeof r.coordsAtPos != "function")
        return null;
      const s = r.coordsAtPos.bind(r), c = r.state.selection, a = (t == null ? void 0 : t()) ?? (c.from === c.to ? null : { from: c.from, to: c.to });
      if (!a || a.from === a.to) return null;
      const f = `${a.from}:${a.to}`;
      f !== o && (o = f, n = void 0);
      const l = Io({
        from: a.from,
        to: a.to,
        coordsAtPos: s
      }), p = c.from === a.from && c.to === a.to ? _c(r) : [], g = p.length > 0 ? Io({
        from: a.from,
        to: a.to,
        coordsAtPos: s,
        clientRects: p
      }) : null;
      g && (n = {
        x: g.x - l.x,
        y: g.y - l.y,
        height: g.height - l.height
      });
      const T = g ?? (n ? new DOMRect(
        l.x + n.x,
        l.y + n.y,
        0,
        Math.max(1, l.height + n.height)
      ) : l);
      return {
        getBoundingClientRect: () => T,
        getClientRects: () => [T]
      };
    } catch {
      return null;
    }
  };
}, Rc = ({
  state: e
}) => {
  var n, i;
  const { selection: t } = e;
  if (t.empty || Tc(t))
    return !1;
  if (t instanceof En) {
    const r = t.node;
    if (r && Ao.has(r.type.name))
      return !1;
  }
  const o = (i = (n = t.$from) == null ? void 0 : n.node) == null ? void 0 : i.call(n, t.$from.depth);
  return !(o && Ao.has(o.type.name));
}, fi = "inlineAiBubbleMenu", Nc = 140, Eo = (e) => e.suppress || e.pointerSelecting && !e.pointerSelectionSettled ? !1 : (e.shouldShow ?? Rc)(e.payload), Lc = (e) => {
  var n, i;
  const t = (n = e.editor) == null ? void 0 : n.view;
  if (!((i = t == null ? void 0 : t.state) != null && i.tr) || typeof t.dispatch != "function") return;
  const o = e.pluginKey ?? fi;
  t.dispatch(t.state.tr.setMeta(o, e.visible ? "show" : "hide"));
}, pi = /* @__PURE__ */ new WeakMap(), md = () => {
  const e = Re(
    null
  ), t = E(
    () => {
      var n;
      return ((n = e.value) == null ? void 0 : n.stage.value) ?? null;
    }
  ), o = {
    stage: t,
    active: E(() => t.value !== null),
    dismiss: () => {
      const n = e.value;
      return (n == null ? void 0 : n.stage.value) == null ? !1 : (n.dismiss(), !0);
    }
  };
  return pi.set(o, { participant: e }), Object.freeze(o);
}, Bc = (e, t) => {
  const o = pi.get(e);
  if (!o)
    throw new TypeError(
      "[text-editor/authoring-ui] Invalid Inline AI Bubble Escape channel"
    );
  if (o.participant.value && o.participant.value !== t)
    throw new TypeError(
      "[text-editor/authoring-ui] Duplicate Inline AI Bubble Escape owner"
    );
  return o.participant.value = t, () => {
    o.participant.value === t && (o.participant.value = null);
  };
}, Mc = Object.freeze([
  "multi-block-selection",
  "explicit-line-break",
  "unsupported-node",
  "collapsed-selection",
  "task-open",
  "capture-failed",
  "unavailable"
]), So = (e) => typeof e == "string" && Mc.includes(
  e
), Dc = (e) => {
  if (typeof e == "string") {
    const t = e.trim();
    return So(t) ? { reason: t } : { reason: "unavailable", ...t ? { detail: t } : {} };
  }
  if (e && typeof e == "object") {
    const { reason: t, detail: o } = e, n = So(t), i = typeof o == "string" && o.trim() ? o.trim() : !n && typeof t == "string" && t.trim() ? t.trim() : void 0;
    return {
      reason: n ? t : "unavailable",
      ...i ? { detail: i } : {}
    };
  }
  return { reason: "unavailable" };
}, Cc = (e) => {
  let t = null;
  return {
    target: e.target,
    get outcome() {
      return t;
    },
    accept() {
      var o;
      return t !== null ? !1 : (t = "accepted", (o = e.onAccept) == null || o.call(e), !0);
    },
    reject(o) {
      var n;
      return t !== null ? !1 : (t = "rejected", ((n = e.onReject) == null ? void 0 : n.call(e, Dc(o))) ?? !1);
    }
  };
}, st = new Mo("inlineAiRetainedSelection"), Fc = "zx-inline-ai-retained-selection", Fn = (e, t, o) => {
  const n = Math.max(0, Math.min(t, o, e)), i = Math.max(0, Math.min(Math.max(t, o), e));
  return i <= n ? null : { from: n, to: i };
}, zc = (e, t) => {
  if (!t) return ut.empty;
  const o = Fn(e.content.size, t.from, t.to);
  return o ? ut.create(e, [
    Cr.inline(o.from, o.to, {
      class: Fc
    })
  ]) : ut.empty;
}, Pc = () => new Bo({
  key: st,
  state: {
    init: () => ut.empty,
    apply: (e, t, o, n) => {
      const i = e.getMeta(
        st
      );
      return (i == null ? void 0 : i.kind) === "clear" ? ut.empty : (i == null ? void 0 : i.kind) === "set" ? zc(n.doc, {
        from: i.from,
        to: i.to
      }) : !e.docChanged || t === ut.empty ? t : t.map(e.mapping, e.doc);
    }
  },
  props: {
    decorations(e) {
      return st.getState(e);
    }
  }
}), Vc = (e) => {
  const t = e.state;
  return st.getState(t) !== void 0;
}, mi = (e) => !e || e.isDestroyed ? !1 : Vc(e) ? !0 : typeof e.registerPlugin != "function" ? !1 : (e.registerPlugin(Pc()), !0), An = (e, t) => {
  if (!e || e.isDestroyed || !e.view || !mi(e)) return !1;
  const { state: o, view: n } = e;
  let i;
  if (!t || t.from === t.to)
    i = o.tr.setMeta(st, {
      kind: "clear"
    });
  else {
    const r = Fn(o.doc.content.size, t.from, t.to);
    r ? i = o.tr.setMeta(st, {
      kind: "set",
      from: r.from,
      to: r.to
    }) : i = o.tr.setMeta(st, {
      kind: "clear"
    });
  }
  return n.dispatch(i), !0;
}, _o = (e) => An(e, null), jc = (e) => {
  if (!(e != null && e.state)) return null;
  const t = st.getState(
    e.state
  );
  if (!t || t === ut.empty) return null;
  let o = Number.POSITIVE_INFINITY, n = Number.NEGATIVE_INFINITY;
  for (const i of t.find())
    o = Math.min(o, i.from), n = Math.max(n, i.to);
  return !Number.isFinite(o) || !Number.isFinite(n) || n <= o ? null : Fn(e.state.doc.content.size, o, n);
}, Hc = Object.freeze({ openCount: 0, active: null }), Oo = (e) => ({
  anchor: e.anchor ?? e.from,
  head: e.head ?? e.to,
  from: e.from,
  to: e.to
}), vi = (e) => ({
  anchor: e.anchor ?? e.from,
  head: e.head ?? e.to,
  from: e.from,
  to: e.to
}), $c = (e, t) => e.from === t.from && e.to === t.to, Uc = (e) => e.active !== null && e.active.phase !== "dismissed", Kc = (e, t) => {
  var o;
  switch (t.kind) {
    case "end":
      return e.active ? { openCount: e.openCount, active: null } : e;
    case "restore":
      return e.active || t.session.openId !== e.openCount ? e : {
        openCount: e.openCount,
        active: { ...t.session, phase: "active", owned: !1 }
      };
    case "dismiss": {
      if (!e.active || e.active.phase === "dismissed" && !t.range) return e;
      const n = t.range ? Oo(t.range) : vi(e.active);
      return {
        openCount: e.openCount,
        active: {
          ...e.active,
          ...n,
          phase: "dismissed",
          owned: !1
        }
      };
    }
    case "chrome-focus":
      return !e.active || e.active.phase === "dismissed" || e.active.owned ? e : {
        openCount: e.openCount,
        active: { ...e.active, owned: !0 }
      };
    case "selection-sync": {
      if ((o = e.active) != null && o.owned && e.active.phase !== "dismissed")
        return e;
      const { eligible: n, range: i } = t;
      if (!n || !i || i.from === i.to)
        return e.active ? { openCount: e.openCount, active: null } : e;
      if (e.active && $c(e.active, i)) return e;
      const r = e.openCount + 1, s = Oo(i);
      return {
        openCount: r,
        active: {
          openId: r,
          ...s,
          phase: "active",
          owned: !1
        }
      };
    }
    default:
      return e;
  }
}, qc = (e) => e.active ? { from: e.active.from, to: e.active.to } : null, Gc = (e) => e.active ? vi(e.active) : null, Wc = (e) => {
  var t;
  return ((t = e.active) == null ? void 0 : t.openId) ?? e.openCount;
}, vd = /* @__PURE__ */ ge({
  name: "InlineAiBubbleMenu",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    skills: {
      type: Array,
      default: void 0
    },
    disabled: {
      type: Boolean,
      default: !1
    },
    capabilities: {
      type: Object,
      default: null
    },
    /**
     * When true (e.g. product shell brewing/reviewing), hide the selection menu
     * so it does not stack under InlineAiSurface.
     */
    suppress: {
      type: Boolean,
      default: !1
    },
    /**
     * Optional per-editor state/action bridge for the catalog-owned Escape
     * adapter. The Bubble itself never registers a key listener.
     */
    escapeChannel: {
      type: Object,
      default: null
    },
    options: {
      type: Object,
      default: () => ({})
    },
    shouldShow: {
      type: Function,
      default: null
    },
    pluginKey: {
      type: [String, Object],
      default: fi
    }
  },
  emits: {
    /**
     * `handoff` is the Bubble's receipt: hosts call `accept()` once their own
     * chrome takes over, or `reject(reason)` when the open fails closed so the
     * Bubble restores itself on the same selection with an inline notice.
     */
    "skill-invoke": (e, t, o) => !0,
    "edit-with-ai": (e, t) => !0,
    "prompt-submit": (e, t, o) => !0,
    "continue-review": () => !0,
    "review-refine": (e) => !0,
    "prompt-draft": (e) => !0
  },
  setup(e, {
    emit: t
  }) {
    const o = Ne("inline-ai-bubble-menu"), {
      defaultSkills: n
    } = Cn(), i = E(() => e.skills ?? n.value), r = jt(), s = vt("editor", null), c = E(() => e.editor ?? (s == null ? void 0 : s.value) ?? null), {
      binding: a
    } = Nt(e.themeOwner), f = E(() => Ic(e.options)), l = W(Hc), u = E(() => qc(l.value)), p = E(() => Gc(l.value)), g = E(() => Uc(l.value)), T = Po(g), L = E(() => {
      var x;
      return g.value ? "bubble" : ((x = l.value.active) == null ? void 0 : x.phase) === "dismissed" ? "selection" : null;
    }), D = W(!1);
    let w = null, k = null, v = !1;
    const O = W(null), N = E(() => {
      const x = O.value, A = l.value.active;
      return !x || !A || A.openId !== x.openId ? null : x;
    }), y = W(!1), m = W(!1);
    let _;
    const q = (x) => {
      l.value = Kc(l.value, x);
    };
    Q(
      () => {
        var x;
        return ((x = l.value.active) == null ? void 0 : x.owned) === !0 && u.value;
      },
      (x) => {
        var K;
        const A = c.value;
        x && ((K = e.capabilities) == null ? void 0 : K.startAi.enabled) !== !1 && (D.value = An(A, x));
      },
      // Pointer focus removes the browser's native selection immediately. Paint
      // the bookmarked range before that focus transfer can invalidate the live
      // selection capability used by the guard above.
      {
        flush: "sync"
      }
    );
    const ne = (x = c.value) => {
      D.value && (_o(x), D.value = !1);
    }, ie = () => {
      if (typeof document > "u") return;
      const x = document.getSelection();
      !x || x.rangeCount === 0 || x.collapseToEnd();
    }, ee = () => {
      const x = c.value;
      if (!x) {
        q({
          kind: "selection-sync",
          eligible: !1,
          range: null
        });
        return;
      }
      const A = x.state, K = Eo({
        payload: {
          editor: x,
          state: A
        },
        suppress: e.suppress,
        pointerSelecting: y.value,
        pointerSelectionSettled: m.value,
        shouldShow: e.shouldShow
      }), Y = A == null ? void 0 : A.selection;
      q({
        kind: "selection-sync",
        eligible: K,
        range: Y ? {
          anchor: Y.anchor,
          from: Y.from,
          head: Y.head,
          to: Y.to
        } : null
      });
    }, B = (x) => {
      var Y;
      const A = Eo({
        payload: x,
        suppress: e.suppress,
        pointerSelecting: y.value,
        pointerSelectionSettled: m.value,
        shouldShow: e.shouldShow
      }), K = (Y = x.state) == null ? void 0 : Y.selection;
      return q({
        kind: "selection-sync",
        eligible: A,
        range: K ? {
          anchor: K.anchor,
          from: K.from,
          head: K.head,
          to: K.to
        } : null
      }), g.value;
    }, R = (x) => {
      Lc({
        editor: c.value,
        pluginKey: e.pluginKey,
        visible: x
      });
    }, S = () => {
      _ !== void 0 && (clearTimeout(_), _ = void 0);
    }, U = () => {
      S(), y.value && (_ = setTimeout(() => {
        _ = void 0, y.value && (m.value = !0, ee(), R(g.value));
      }, Nc));
    }, J = () => {
      y.value && (m.value = !1), ee(), y.value && (R(g.value), U());
    }, fe = (x) => {
      var K, Y;
      const A = g.value;
      if (q({
        kind: "end"
      }), R(!1), x === "handoff") {
        D.value = !1;
        return;
      }
      if (ne(), A) {
        const se = (K = c.value) == null ? void 0 : K.commands;
        (Y = se == null ? void 0 : se.focus) == null || Y.call(se);
      }
    }, G = (x, A) => {
      var Y, se, xe, Fe, d, I, z;
      let K = !1;
      if ((Y = x == null ? void 0 : x.state) != null && Y.doc && ((se = x == null ? void 0 : x.state) != null && se.tr) && (x != null && x.view))
        try {
          const X = rt.create(x.state.doc, A.anchor, A.head);
          x.view.dispatch(x.state.tr.setSelection(X)), K = !0;
        } catch {
        }
      K || (Fe = (xe = x == null ? void 0 : x.commands) == null ? void 0 : xe.setTextSelection) == null || Fe.call(xe, A.anchor === A.head ? A.head : {
        from: A.from,
        to: A.to
      }), typeof ((d = x == null ? void 0 : x.view) == null ? void 0 : d.focus) == "function" ? x.view.focus() : (z = (I = x == null ? void 0 : x.commands) == null ? void 0 : I.focus) == null || z.call(I);
    }, ce = () => {
      if (!g.value) return;
      const x = cn(c.value), A = p.value, K = jc(x), Y = A && K ? {
        anchor: A.anchor > A.head ? K.to : K.from,
        head: A.anchor > A.head ? K.from : K.to,
        from: K.from,
        to: K.to
      } : A;
      q({
        kind: "dismiss",
        range: Y ?? void 0
      }), R(!1), Y && G(x, Y), ne();
    }, ue = () => {
      var K, Y, se;
      if (L.value !== "selection") return;
      const x = cn(c.value), A = p.value;
      q({
        kind: "end"
      }), R(!1), ne(), A ? (G(x, {
        anchor: A.head,
        head: A.head,
        from: A.head,
        to: A.head
      }), ie()) : typeof ((K = x == null ? void 0 : x.view) == null ? void 0 : K.focus) == "function" ? x.view.focus() : (se = (Y = x == null ? void 0 : x.commands) == null ? void 0 : Y.focus) == null || se.call(Y);
    }, De = {
      stage: L,
      dismiss: () => {
        L.value === "bubble" ? ce() : ue();
      }
    };
    let we;
    Q(() => e.escapeChannel, (x) => {
      we == null || we(), we = x ? Bc(x, De) : void 0;
    }, {
      immediate: !0
    }), Q(() => e.suppress, (x) => {
      if (x) {
        S(), m.value = !1, w = null, k = null, O.value = null, q({
          kind: "end"
        }), R(!1), D.value = !1;
        return;
      }
      ee(), R(g.value), ne();
    });
    const Ge = (x) => {
      var Y, se;
      if (!g.value) return;
      const A = x.target;
      if (!A || A.closest(".zx-inline-ai-bubble-menu")) return;
      const K = (se = (Y = c.value) == null ? void 0 : Y.view) == null ? void 0 : se.dom;
      K != null && K.contains(A) || fe("dismiss");
    }, ve = () => {
      var x;
      g.value && ((x = l.value.active) != null && x.owned) && fe("dismiss");
    }, Le = (x) => {
      var K, Y;
      if (x.button !== 0 || (K = l.value.active) != null && K.owned) return;
      const A = x.target;
      (Y = A == null ? void 0 : A.closest) != null && Y.call(A, ".zx-inline-ai-bubble-menu") || (y.value = !0, m.value = !1, S(), l.value.active && (q({
        kind: "end"
      }), R(!1)));
    }, Ae = () => {
      y.value && (S(), y.value = !1, m.value = !1, ee(), R(g.value));
    }, oe = (x) => {
      var K;
      const A = (K = x == null ? void 0 : x.view) == null ? void 0 : K.dom;
      A == null || A.addEventListener("pointerdown", Le);
    }, be = (x) => {
      var K;
      const A = (K = x == null ? void 0 : x.view) == null ? void 0 : K.dom;
      A == null || A.removeEventListener("pointerdown", Le);
    }, re = (x) => {
      var K, Y, se, xe;
      const A = x;
      A != null && A.state && (A != null && A.view) && mi(A), (K = A == null ? void 0 : A.off) == null || K.call(A, "focus", ve), (Y = A == null ? void 0 : A.on) == null || Y.call(A, "focus", ve), (se = A == null ? void 0 : A.off) == null || se.call(A, "selectionUpdate", J), (xe = A == null ? void 0 : A.on) == null || xe.call(A, "selectionUpdate", J), oe(x);
    }, Ve = (x) => {
      var K, Y;
      const A = x;
      (K = A == null ? void 0 : A.off) == null || K.call(A, "focus", ve), (Y = A == null ? void 0 : A.off) == null || Y.call(A, "selectionUpdate", J), be(x);
    };
    Q(c, (x, A) => {
      A && A !== x && ne(A), Ve(A ?? null), re(x);
    }, {
      immediate: !0
    });
    const Ue = () => {
      gn({
        kind: "scroll"
      }), gn({
        kind: "visualViewport"
      }), gn({
        kind: "geometry"
      });
    }, at = () => {
      var A;
      const x = (A = a.value) == null ? void 0 : A.target.querySelector(".zx-inline-ai-bubble-menu");
      x instanceof HTMLElement && (x.dataset.inlineAiViewportSource = window.visualViewport ? "visualViewport" : "layoutViewport");
    };
    Lt(() => {
      var x, A;
      at(), document.addEventListener("pointerdown", Ge, !0), window.addEventListener("pointerup", Ae, !0), window.addEventListener("pointercancel", Ae, !0), window.addEventListener("scroll", Ue, !0), (x = window.visualViewport) == null || x.addEventListener("resize", Ue), (A = window.visualViewport) == null || A.addEventListener("scroll", Ue), re(c.value);
    }), gt(() => {
      var x, A;
      S(), we == null || we(), we = void 0, document.removeEventListener("pointerdown", Ge, !0), window.removeEventListener("pointerup", Ae, !0), window.removeEventListener("pointercancel", Ae, !0), window.removeEventListener("scroll", Ue, !0), (x = window.visualViewport) == null || x.removeEventListener("resize", Ue), (A = window.visualViewport) == null || A.removeEventListener("scroll", Ue), Ve(c.value), ne();
    });
    const yt = (x) => {
      if (w !== x) return null;
      const A = k;
      return w = null, k = null, A;
    }, We = (x, A) => {
      var Fe;
      const K = yt(x);
      if (!K) return !1;
      const Y = cn(c.value);
      _o(Y), D.value = !1;
      const se = l.value.active;
      if (se && se.openId !== K.openId) return !1;
      se && (v = !0, q({
        kind: "end"
      }));
      const xe = (Fe = Y == null ? void 0 : Y.state) == null ? void 0 : Fe.selection;
      return !xe || xe.from !== K.from || xe.to !== K.to || (q({
        kind: "restore",
        session: K
      }), !g.value) ? (R(!1), !1) : (O.value = {
        ...A,
        openId: K.openId
      }, R(!0), !0);
    }, lt = (x) => {
      const A = u.value, K = l.value.active, Y = c.value;
      A && An(Y, A), O.value = null, v = !1, w = null, k = null;
      const se = Cc({
        target: A,
        onAccept: () => {
          yt(se);
        },
        onReject: (Fe) => We(se, Fe)
      });
      w = se, k = K;
      const xe = x(A, se);
      return v ? (v = !1, xe) : (D.value = !1, fe("handoff"), xe);
    }, et = (x) => {
      lt((A, K) => t("skill-invoke", x, A, K));
    }, kt = () => {
      lt((x, A) => t("edit-with-ai", x, A));
    }, tt = (x) => {
      lt((A, K) => t("prompt-submit", x, A, K));
    }, ye = () => {
      q({
        kind: "chrome-focus"
      });
    };
    return () => {
      const x = c.value, A = a.value;
      if (!x || !A) return null;
      const K = Object.fromEntries(Object.entries(r).filter(([d]) => d !== "class" && d !== "style")), Y = Oc(x, () => u.value), se = () => {
        t("continue-review");
      }, xe = (d) => {
        fe("handoff"), t("review-refine", d);
      }, Fe = (d) => {
        t("prompt-draft", d);
      };
      return P(Uo, Qe({
        editor: x,
        pluginKey: e.pluginKey,
        shouldShow: B,
        options: f.value,
        getReferencedVirtualElement: Y,
        appendTo: () => A.target,
        class: [o.b(), "zx-inline-ai-bubble-menu", r.class],
        style: {
          zIndex: T.value
        }
      }, K), {
        default: () => [P(gc, {
          key: Wc(l.value),
          editor: x,
          skills: i.value,
          disabled: e.disabled,
          capabilities: e.capabilities,
          autoFocusPrompt: !1,
          notice: N.value,
          "onSkill-invoke": et,
          "onEdit-with-ai": kt,
          "onPrompt-submit": tt,
          "onContinue-review": se,
          "onReview-refine": xe,
          "onRetain-selection": ye,
          "onPrompt-draft": Fe
        }, null)]
      });
    };
  }
}), gd = /* @__PURE__ */ ge({
  name: "TextEditorFloatingToolbar",
  inheritAttrs: !1,
  props: {
    themeOwner: {
      type: Object,
      default: null
    },
    editor: {
      type: Object,
      default: null
    },
    contributions: {
      type: Array,
      default: () => []
    },
    includeDefaultContribution: {
      type: Boolean,
      default: !0
    },
    options: {
      type: Object,
      default: () => ({})
    }
  },
  setup(e) {
    const t = Ne("text-editor-floating-menu"), o = jt(), n = vt("editor", null), i = E(() => e.editor ?? (n == null ? void 0 : n.value) ?? null), {
      binding: r
    } = Nt(e.themeOwner);
    return () => {
      const s = i.value, c = r.value;
      if (!s || !c)
        return null;
      const a = Object.fromEntries(Object.entries(o).filter(([f]) => f !== "class" && f !== "style"));
      return P(Lr, Qe({
        editor: s,
        appendTo: () => c.target,
        class: [t.b(), o.class]
      }, e.options, a), {
        default: () => [P(Ln, {
          themeOwner: e.themeOwner,
          editor: s,
          surface: "floating",
          contributions: e.contributions,
          includeDefaultContribution: e.includeDefaultContribution,
          style: o.style
        }, null)]
      });
    };
  }
}), Jc = ["value"], Zc = ["value"], Xc = ["value"], Yc = ["value"], bd = /* @__PURE__ */ ge({
  name: "ZxTextEditorFontFamilySelector",
  __name: "font-family-selector",
  props: {
    fontSizes: { default: () => [...Sr] },
    fontFamilies: { default: () => [...Er] }
  },
  setup(e) {
    const t = Ne("text-editor-font-selector"), o = vt("editor"), n = E(() => o != null && o.value && o.value.getAttributes("textStyle").fontSize || ""), i = E(() => o != null && o.value && o.value.getAttributes("textStyle").fontFamily || ""), r = (a, ...f) => {
      var k, v, O, N;
      if (!(o != null && o.value)) return !1;
      const l = (v = (k = o.value).chain) == null ? void 0 : v.call(k), u = ((O = l == null ? void 0 : l.focus) == null ? void 0 : O.call(l)) ?? l, p = u, g = p == null ? void 0 : p[a];
      if (typeof g == "function") {
        const y = g.apply(u, f);
        return ((N = y == null ? void 0 : y.run) == null ? void 0 : N.call(y)) ?? !1;
      }
      const T = o.value.commands, L = T.focus;
      typeof L == "function" && L.call(T);
      const D = T[a];
      if (typeof D != "function")
        return !1;
      const w = D.apply(T, f);
      return typeof w == "boolean" ? w : !0;
    }, s = (a) => {
      const f = a.target.value;
      o != null && o.value && (f ? r("setFontSize", f) : r("unsetFontSize"));
    }, c = (a) => {
      const f = a.target.value;
      o != null && o.value && (f ? r("setFontFamily", f) : r("unsetFontFamily"));
    };
    return (a, f) => (C(), V("div", {
      class: H(h(t).b())
    }, [
      j("select", {
        class: H(h(t).e("size-select")),
        value: n.value,
        onChange: s
      }, [
        f[0] || (f[0] = j("option", { value: "" }, "默认", -1)),
        (C(!0), V(Oe, null, Pe(e.fontSizes, (l) => (C(), V("option", {
          key: l,
          value: l
        }, de(l), 9, Zc))), 128))
      ], 42, Jc),
      j("select", {
        class: H(h(t).e("family-select")),
        value: i.value,
        onChange: c
      }, [
        f[1] || (f[1] = j("option", { value: "" }, "默认字体", -1)),
        (C(!0), V(Oe, null, Pe(e.fontFamilies, (l) => (C(), V("option", {
          key: l.value,
          value: l.value
        }, de(l.label), 9, Yc))), 128))
      ], 42, Xc)
    ], 2));
  }
}), hd = /* @__PURE__ */ ge({
  name: "ZxTextEditorFloatingComments",
  __name: "floating-comments",
  props: {
    editor: {},
    threads: {},
    comments: {},
    activeAnnotationId: {},
    activeCommentId: {},
    currentUser: {},
    readonly: { type: Boolean }
  },
  emits: ["activate", "create", "edit", "delete", "resolve", "reply"],
  setup(e) {
    const t = Ne("text-editor-floating-comments");
    return (o, n) => (C(), V("div", {
      class: H(h(t).b())
    }, [
      Me(o.$slots, "default", {}, () => [
        j("div", {
          class: H(h(t).e("placeholder"))
        }, " FloatingComments 组件需要由应用层提供实现 ", 2)
      ])
    ], 2));
  }
}), Qc = ["value", "placeholder", "disabled", "onKeydown"], yd = /* @__PURE__ */ ge({
  name: "ZxTextEditorCommentEditor",
  __name: "comment-editor",
  props: {
    content: { default: "" },
    editable: { type: Boolean, default: !0 },
    placeholder: { default: "输入评论..." },
    showToolbar: { type: Boolean },
    autofocus: { type: Boolean }
  },
  emits: ["submit", "cancel", "update:content"],
  setup(e, { emit: t }) {
    const o = Ne("text-editor-comment-editor"), n = t, i = (c) => {
      const a = c.target.value;
      n("update:content", a);
    }, r = () => {
      n("submit", e.content);
    }, s = () => {
      n("cancel");
    };
    return (c, a) => (C(), V("div", {
      class: H(h(o).b())
    }, [
      Me(c.$slots, "default", {}, () => [
        j("textarea", {
          class: H(h(o).e("textarea")),
          value: e.content,
          placeholder: e.placeholder,
          disabled: !e.editable,
          onInput: i,
          onKeydown: [
            Zn(_e(r, ["ctrl"]), ["enter"]),
            Zn(s, ["escape"])
          ]
        }, null, 42, Qc),
        j("div", {
          class: H(h(o).e("actions"))
        }, [
          j("button", {
            type: "button",
            class: H(h(o).e("cancel")),
            onClick: s
          }, " 取消 ", 2),
          j("button", {
            type: "button",
            class: H(h(o).e("submit")),
            onClick: r
          }, " 提交 ", 2)
        ], 2)
      ])
    ], 2));
  }
}), eu = ["onClick", "onMouseenter"], kd = /* @__PURE__ */ ge({
  name: "ZxTextEditorEmbedList",
  __name: "embed-list",
  props: {
    items: {},
    query: {},
    command: { type: Function }
  },
  setup(e, { expose: t }) {
    const o = Ne("text-editor-embed-list"), n = e, i = W(0);
    Q(
      () => n.items,
      () => {
        i.value = 0;
      }
    );
    const r = (c) => {
      const a = n.items[c];
      a && n.command(a);
    };
    return t({ onKeyDown: (c) => c.key === "ArrowUp" ? (i.value = (i.value - 1 + n.items.length) % n.items.length, !0) : c.key === "ArrowDown" ? (i.value = (i.value + 1) % n.items.length, !0) : c.key === "Enter" ? (r(i.value), !0) : !1 }), (c, a) => (C(), V("div", {
      class: H(h(o).b())
    }, [
      e.items.length === 0 ? (C(), V("div", {
        key: 0,
        class: H(h(o).e("empty"))
      }, de(e.query ? "未找到匹配的文档" : "输入关键词搜索文档"), 3)) : le("", !0),
      (C(!0), V(Oe, null, Pe(e.items, (f, l) => (C(), V("button", {
        key: f.name,
        type: "button",
        class: H([h(o).e("item"), h(o).is("selected", l === i.value)]),
        onClick: (u) => r(l),
        onMouseenter: (u) => i.value = l
      }, [
        j("span", {
          class: H(h(o).e("icon"))
        }, "📄", 2),
        j("span", {
          class: H(h(o).e("title"))
        }, de(f.title), 3)
      ], 42, eu))), 128))
    ], 2));
  }
}), tu = ["inert"], nu = ["disabled"], ou = /* @__PURE__ */ ge({
  __name: "FieldToolbar",
  props: {
    editor: {},
    themeOwner: {},
    ai: { type: Boolean },
    disabled: { type: Boolean }
  },
  emits: ["ai"],
  setup(e, { emit: t }) {
    const o = e, n = t, i = W(!o.editor.isEmpty);
    Q(
      () => o.editor,
      (a, f, l) => {
        const u = () => {
          i.value = !a.isEmpty;
        };
        u(), a.on("transaction", u), l(() => a.off("transaction", u));
      },
      { immediate: !0 }
    );
    const r = oi(), s = [
      "format.bold",
      "text.color",
      "list.bullet",
      "list.ordered",
      "insert.link"
    ], c = [
      {
        id: "basic-field-toolbar",
        register: (a) => [
          ...r.register(a).filter((f) => s.includes(f.id)).map((f) => ({ ...f, priority: s.indexOf(f.id) * 10 })),
          {
            id: "field.more",
            kind: "dropdown",
            surface: "workbench-top",
            label: "更多格式",
            icon: "mdi:dots-horizontal",
            priority: 100,
            options: [
              { id: "italic", label: "斜体" },
              { id: "clear", label: "清除文字格式" }
            ],
            onOptionSelect: (f) => {
              if (o.disabled) return;
              const l = o.editor.chain().focus();
              f === "italic" ? l.toggleItalic().run() : f === "clear" && l.unsetAllMarks().run();
            }
          }
        ]
      }
    ];
    return (a, f) => (C(), V("div", {
      class: H(["zx-field-toolbar", { "is-disabled": e.disabled }]),
      inert: e.disabled || void 0
    }, [
      e.ai ? (C(), V("button", {
        key: 0,
        type: "button",
        class: "zx-field-toolbar__ai",
        disabled: e.disabled,
        onMousedown: f[0] || (f[0] = _e(() => {
        }, ["prevent"])),
        onClick: f[1] || (f[1] = (l) => n("ai"))
      }, " ✦ " + de(i.value ? "AI 修改" : "AI 帮写"), 41, nu)) : le("", !0),
      P(h(Ln), {
        editor: e.editor,
        "theme-owner": e.themeOwner,
        "include-default-contribution": !1,
        contributions: c,
        surface: "workbench-top"
      }, null, 8, ["editor", "theme-owner"])
    ], 10, tu));
  }
}), iu = ["innerHTML"], ru = /* @__PURE__ */ ge({
  name: "ZxTextEditorView",
  __name: "text-editor-view",
  props: {
    document: {},
    typography: { default: () => ({
      root: { fontSize: { cssValue: "1em", displayValue: "1em" } }
    }) }
  },
  setup(e) {
    const t = e, o = E(
      () => Ho(
        Go({ override: t.typography })
      )
    ), n = E(
      () => t.document ? yn(t.document, { profile: "safe-html" }) : ""
    );
    return (i, r) => (C(), V("div", {
      class: H(["zx-text-editor-view", o.value.className]),
      style: mt(o.value.style)
    }, [
      n.value ? (C(), V("div", {
        key: 0,
        class: "ProseMirror zx-text-editor__prose",
        innerHTML: n.value
      }, null, 8, iu)) : le("", !0)
    ], 6));
  }
}), su = { class: "zx-field-ai__header" }, au = { key: 0 }, lu = { key: 1 }, cu = ["disabled"], uu = {
  class: "zx-field-ai__presets",
  "aria-label": "常用 AI 指令"
}, du = ["disabled", "onClick"], fu = { class: "zx-field-ai__prompt" }, pu = ["disabled"], mu = {
  key: 0,
  role: "alert",
  class: "zx-field-ai__error"
}, vu = {
  key: 1,
  role: "status"
}, gu = {
  key: 2,
  role: "status"
}, bu = {
  key: 3,
  class: "zx-field-ai__candidate",
  "aria-label": "AI 候选内容"
}, hu = {
  key: 1,
  class: "zx-field-ai__stream"
}, yu = { class: "zx-field-ai__actions" }, ku = { key: 0 }, wu = ["disabled"], xu = ["disabled"], Tu = /* @__PURE__ */ ge({
  __name: "FieldAIPanel",
  props: {
    controller: {}
  },
  setup(e) {
    const t = e, {
      instruction: o,
      scope: n,
      target: i,
      candidate: r,
      stream: s,
      error: c,
      stale: a,
      busy: f,
      phase: l,
      canAccept: u,
      generate: p,
      stop: g,
      cancel: T,
      start: L,
      accept: D
    } = t.controller, w = W(), k = [
      { label: "润色", prompt: "请润色表达，保留原意和事实，使文字清晰自然。" },
      { label: "精简", prompt: "请精简内容，保留关键事实和结论，去掉重复表述。" },
      { label: "整理要点", prompt: "请保留原意，将内容整理成简洁清晰的要点列表。" }
    ];
    Lt(() => {
      var O;
      return (O = w.value) == null ? void 0 : O.focus({ preventScroll: !0 });
    });
    function v(O) {
      Ko(O) || (O.key === "Escape" && (O.preventDefault(), T()), O.key === "Enter" && (O.ctrlKey || O.metaKey) && !f.value && (O.preventDefault(), p()));
    }
    return (O, N) => {
      var y;
      return C(), V("section", {
        class: "zx-field-ai",
        "aria-label": "AI 帮写与修改",
        onKeydown: _e(v, ["stop"]),
        onCompositionstart: N[8] || (N[8] = _e(() => {
        }, ["stop"])),
        onCompositionend: N[9] || (N[9] = _e(() => {
        }, ["stop"]))
      }, [
        j("header", su, [
          N[12] || (N[12] = j("strong", null, "AI 帮写与修改", -1)),
          (y = h(i)) != null && y.selection ? (C(), V("label", lu, [
            N[11] || (N[11] = qi(" 修改范围 ", -1)),
            Xn(j("select", {
              "onUpdate:modelValue": N[0] || (N[0] = (m) => hn(n) ? n.value = m : null),
              disabled: h(f)
            }, [...N[10] || (N[10] = [
              j("option", { value: "selection" }, "所选文字", -1),
              j("option", { value: "document" }, "整段内容", -1)
            ])], 8, cu), [
              [Gi, h(n)]
            ])
          ])) : (C(), V("span", au, "整段内容")),
          j("button", {
            type: "button",
            "aria-label": "关闭 AI，保留原文",
            onClick: N[1] || (N[1] = //@ts-ignore
            (...m) => h(T) && h(T)(...m))
          }, " 关闭 ")
        ]),
        j("div", uu, [
          (C(), V(Oe, null, Pe(k, (m) => j("button", {
            key: m.label,
            type: "button",
            disabled: h(f) || h(a) || !h(i),
            onClick: (_) => h(p)(m.prompt)
          }, de(m.label), 9, du)), 64))
        ]),
        j("label", fu, [
          j("span", null, de(h(r) ? "继续修改候选内容" : "描述你希望写什么或如何修改"), 1),
          Xn(j("textarea", {
            ref_key: "input",
            ref: w,
            "onUpdate:modelValue": N[2] || (N[2] = (m) => hn(o) ? o.value = m : null),
            rows: "2",
            maxlength: "2000",
            disabled: h(f) || h(a) || !h(i),
            placeholder: "例如：说明任务延期原因，语气简洁客观…"
          }, null, 8, pu), [
            [Wi, h(o)]
          ])
        ]),
        h(c) ? (C(), V("p", mu, de(h(c)), 1)) : h(f) ? (C(), V("p", vu, "正在生成，原文保持不变…")) : h(l) === "stopped" ? (C(), V("p", gu, "已停止，未修改原文。")) : le("", !0),
        h(s) || h(r) ? (C(), V("div", bu, [
          h(r) ? (C(), Be(ru, {
            key: 0,
            document: h(r)
          }, null, 8, ["document"])) : (C(), V("div", hu, de(h(s)), 1))
        ])) : le("", !0),
        j("footer", yu, [
          h(r) ? (C(), V("span", ku, "确认后才替换" + de(h(n) === "selection" ? "所选文字" : "整段内容") + "，可撤销", 1)) : le("", !0),
          h(f) ? (C(), V("button", {
            key: 1,
            type: "button",
            onClick: N[3] || (N[3] = //@ts-ignore
            (...m) => h(g) && h(g)(...m))
          }, "停止生成")) : h(a) ? (C(), V("button", {
            key: 2,
            type: "button",
            onClick: N[4] || (N[4] = //@ts-ignore
            (...m) => h(L) && h(L)(...m))
          }, " 重新读取原文 ")) : (C(), V("button", {
            key: 3,
            type: "button",
            disabled: !h(o).trim() || !h(i),
            onClick: N[5] || (N[5] = (m) => h(p)())
          }, de(h(r) ? "继续修改" : h(l) === "error" || h(l) === "stopped" ? "重试" : "生成候选"), 9, wu)),
          j("button", {
            type: "button",
            onClick: N[6] || (N[6] = //@ts-ignore
            (...m) => h(T) && h(T)(...m))
          }, de(h(r) ? "舍弃候选" : "取消"), 1),
          h(r) ? (C(), V("button", {
            key: 4,
            type: "button",
            class: "zx-field-ai__accept",
            disabled: !h(u),
            onClick: N[7] || (N[7] = //@ts-ignore
            (...m) => h(D) && h(D)(...m))
          }, " 采用内容 ", 8, xu)) : le("", !0)
        ])
      ], 32);
    };
  }
}), zn = (e) => Dr("zx-text-editor-field-ai:v1", e.getJSON()), In = (e) => dt({
  body: { format: "json", content: e },
  annotations: [],
  assets: []
}), Au = (e, t) => {
  const { from: o, to: n, empty: i } = e.state.selection;
  return {
    fingerprint: zn(e),
    from: o,
    to: n,
    document: qe(In(e.getJSON()), t),
    selection: i ? null : qe(
      In(
        Gr(
          e.state.doc.cut(o, n).toJSON()
        ).content
      ),
      t
    )
  };
}, Ro = (e, t, o, n, i) => {
  if (zn(e) !== t.fingerprint)
    throw new Error("原文已变化，请重新打开 AI 后生成");
  const r = qe(n, i);
  if (!r) throw new Error("AI 没有返回可采用的内容，请重试");
  const s = Zo.fromArray(
    r.body.content.content.map(
      (a) => e.schema.nodeFromJSON(a)
    )
  ), c = e.state.tr;
  if (o === "selection") {
    if (t.from === t.to || !t.selection)
      throw new Error("所选文字已不可用，请重新选择");
    const a = r.body.content.content.every(
      (f) => f.type === "paragraph"
    );
    c.replaceRange(
      t.from,
      t.to,
      new Jo(s, a ? 1 : 0, a ? 1 : 0)
    );
  } else
    c.replaceWith(0, c.doc.content.size, s);
  return Hr(c, c.doc, {
    types: qr()
  }), qe(In(c.doc.toJSON()), i), { candidate: r, transaction: c };
}, No = Wo, Iu = (e) => JSON.parse(JSON.stringify(e));
function Eu(e) {
  const t = W(!1), o = W(
    "idle"
  ), n = W(""), i = W("document"), r = Re(null), s = Re(null), c = W(""), a = W(""), f = W(!1);
  let l = 0, u, p = null;
  const g = E(() => o.value === "generating"), T = E(
    () => o.value === "ready" && !!s.value && !f.value && !e.disabled()
  ), L = () => {
    l++, u == null || u.abort(), u = void 0;
  }, D = () => {
    L(), t.value = !1, s.value = null, c.value = "", o.value = "idle", a.value = "", r.value = null, p = null;
  }, w = () => {
    const y = e.editor();
    if (!(!y || e.disabled() || !e.adapter())) {
      D(), t.value = !0, f.value = !1, n.value = "";
      try {
        r.value = Au(y, e.limits()), i.value = r.value.selection ? "selection" : "document";
      } catch {
        a.value = "请先检查原文的格式和长度，再使用 AI", o.value = "error";
      }
    }
  }, k = () => {
    L(), o.value = "stopped";
  }, v = () => {
    var y;
    D(), e.disabled() || (y = e.editor()) == null || y.commands.focus();
  }, O = async (y = n.value) => {
    const m = e.editor(), _ = e.adapter(), q = r.value;
    if (!m || !_ || !q || e.disabled() || f.value || !y.trim())
      return;
    L();
    const ne = l, ie = new AbortController();
    u = ie, n.value = y;
    const ee = s.value ?? p;
    p = ee, s.value = null, c.value = "", a.value = "", o.value = "generating";
    const B = () => ne === l && t.value && !ie.signal.aborted && !e.disabled();
    try {
      const R = await _.generate(
        Iu({
          instruction: y.trim(),
          target: i.value,
          document: q.document,
          selection: i.value === "selection" ? q.selection : null,
          ...ee ? { candidate: ee } : {}
        }),
        {
          signal: ie.signal,
          onDelta: (S) => {
            B() && typeof S == "string" && (c.value = (c.value + S).slice(0, 1e5));
          }
        }
      );
      if (!B()) return;
      s.value = Ro(
        m,
        q,
        i.value,
        R,
        e.limits()
      ).candidate, o.value = "ready";
    } catch (R) {
      if (!B()) return;
      o.value = "error", a.value = R instanceof Error && !R.message.includes("basic-rich-text:") ? R.message : "AI 结果不符合字段格式或长度限制，请调整要求后重试";
    } finally {
      ne === l && (u = void 0);
    }
  }, N = () => {
    const y = e.editor();
    if (!(!y || !r.value || !T.value))
      try {
        const { transaction: m } = Ro(
          y,
          r.value,
          i.value,
          s.value,
          e.limits()
        ), _ = m.doc;
        if (t.value = !1, y.view.dispatch(No.closeHistory(m)), !y.state.doc.eq(_))
          throw new Error("内容未能应用，请重新生成");
        y.view.dispatch(
          No.closeHistory(y.state.tr).setMeta("addToHistory", !1)
        ), D(), y.commands.focus();
      } catch (m) {
        t.value = !0, a.value = m instanceof Error ? m.message : "内容未能应用，请重试", o.value = "error";
      }
  };
  return Q(
    e.editor,
    (y, m, _) => {
      if (m && D(), !y) return;
      const q = () => {
        !t.value || !r.value || zn(y) === r.value.fingerprint || (L(), f.value = !0, o.value = "error", a.value = "原文已变化，请重新打开 AI 后生成；当前原文已保留");
      };
      y.on("transaction", q), _(() => y.off("transaction", q));
    },
    { immediate: !0 }
  ), Q(
    () => [e.disabled(), e.adapter()],
    () => {
      t.value && D();
    }
  ), Q(i, () => {
    L(), s.value = null, c.value = "", o.value = "idle", p = null;
  }), Ht(L), {
    open: t,
    phase: o,
    instruction: n,
    scope: i,
    target: r,
    candidate: s,
    stream: c,
    error: a,
    stale: f,
    busy: g,
    canAccept: T,
    start: w,
    close: D,
    cancel: v,
    stop: k,
    generate: O,
    accept: N
  };
}
const Su = {
  key: 3,
  class: "zx-text-editor-field__message",
  role: "status"
}, _u = ["role"], wd = /* @__PURE__ */ ge({
  name: "ZxTextEditorField",
  inheritAttrs: !1,
  __name: "text-editor-field",
  props: {
    modelValue: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean },
    placeholder: {},
    id: {},
    contentLimits: {},
    ai: {},
    messages: { default: () => [] }
  },
  emits: ["update:modelValue", "focus", "blur", "edit-state"],
  setup(e, { expose: t, emit: o }) {
    const n = (G) => Object.fromEntries(
      Object.entries(G).filter(([ce]) => ce !== "class" && ce !== "style")
    );
    bn(ri, !0);
    const i = e, r = o, s = {
      root: {
        fontSize: {
          cssValue: "var(--el-font-size-base, 14px)",
          displayValue: "14px"
        },
        fontFamily: { cssValue: "var(--el-font-family)", displayValue: "Default" }
      }
    }, c = Fo(), a = Fr(), f = zr(), l = Pr(), u = Re(c);
    let p = !1;
    Q(
      () => f.ok ? f.value.value : null,
      () => {
        var ue;
        if (c || !a.ok) return;
        const G = ji({
          nearestScope: f.ok ? f.value.value : null,
          nearestScopeAvailable: f.ok,
          app: l.ok ? l.value : null
        });
        if (!G) return;
        p && ((ue = u.value) == null || ue.dispose());
        const ce = Hi(a.value, G);
        ce.ok && (u.value = ce.value, p = !0);
      },
      { immediate: !0 }
    );
    const g = W(), T = W();
    let L = !1;
    function D(G) {
      L || r("focus", G), L = !0;
    }
    async function w(G) {
      var ce, ue;
      G.relatedTarget instanceof Node && ((ce = T.value) != null && ce.contains(G.relatedTarget)) || (await pt(), !((ue = T.value) != null && ue.contains(document.activeElement)) && (L = !1, N.value = "", r("blur", G)));
    }
    const k = (G) => {
      g.value = G ?? void 0;
    }, v = W(!1), O = W(""), N = W(""), y = E(() => {
      var G;
      return ((G = g.value) == null ? void 0 : G.editor) ?? null;
    }), m = Eu({
      editor: () => y.value,
      adapter: () => i.ai,
      disabled: () => !!i.disabled || !!i.readonly || v.value,
      limits: () => i.contentLimits
    }), q = Re({
      version: 2,
      body: {
        format: "json",
        content: {
          type: "doc",
          content: [
            {
              type: "paragraph",
              attrs: {
                textAlign: null,
                blockId: `blk_${crypto.randomUUID().replaceAll("-", "")}`
              }
            }
          ]
        }
      },
      annotations: [],
      assets: [],
      meta: { schemaVersion: "stable-block-identity/v2" }
    }), ne = E(() => i.modelValue ?? q.value), ie = E(() => [
      ...v.value ? [{ severity: "error", message: "请完成输入法输入后再提交" }] : [],
      ...O.value ? [{ severity: "error", message: O.value }] : []
    ]), ee = () => r("edit-state", {
      pending: v.value || m.open.value,
      blocking: ie.value
    });
    function B(G) {
      if (i.disabled || i.readonly || v.value) return;
      let ce = G;
      try {
        ce = qe(G, i.contentLimits), O.value = "", ce === null && (q.value = G);
      } catch (ue) {
        O.value = String(ue).includes("characters") ? "备注正文最多 5,000 个字符，当前输入已保留" : "备注文档超过资源或结构限制，当前输入已保留";
      }
      JSON.stringify(ce) !== JSON.stringify(i.modelValue) && r("update:modelValue", ce), ee();
    }
    function R(G) {
      N.value = G.includes("basic-rich-text:link") ? "链接地址不受支持，请使用 http(s)、mailto 或 tel 链接" : G.includes("basic-rich-text:") ? "该格式不受支持，内容未改变" : G;
    }
    function S() {
      v.value = !0, ee();
    }
    async function U() {
      v.value = !1, await pt(), g.value && B(g.value.getDocument()), ee();
    }
    function J(G) {
      (G.isComposing || v.value || G.keyCode === 229) && G.key === "Enter" && G.stopPropagation();
    }
    Q(
      () => [i.disabled, i.readonly],
      () => ee()
    ), Q(
      () => i.modelValue,
      (G) => {
        try {
          qe(G, i.contentLimits), O.value = "";
        } catch {
          O.value = "备注文档无法读取或超过限制";
        }
        ee();
      },
      { immediate: !0 }
    ), Q([m.open, m.busy], ee), Lt(ee), gt(() => {
      var G;
      p && ((G = u.value) == null || G.dispose());
    });
    function fe() {
      return m.close(), v.value && g.value && (v.value = !1, B(g.value.getDocument())), null;
    }
    return t({
      focus: () => {
        var G;
        return (G = g.value) == null ? void 0 : G.focus();
      },
      validate: () => (ee(), !ie.value.length && !m.open.value),
      captureEdit: fe
    }), (G, ce) => (C(), V("div", {
      ref_key: "fieldRoot",
      ref: T,
      class: H(["zx-text-editor-field", [
        H(G.$attrs.class),
        { "is-disabled": e.disabled, "is-invalid": ie.value.length }
      ]]),
      style: mt(mt(G.$attrs.style)),
      onCompositionstart: S,
      onCompositionend: U,
      onKeydownCapture: J,
      onFocusin: D,
      onFocusout: w
    }, [
      y.value && u.value ? (C(), Be(ou, {
        key: 0,
        editor: y.value,
        "theme-owner": u.value,
        ai: !!e.ai,
        disabled: !!e.disabled || !!e.readonly || v.value,
        onAi: h(m).start
      }, null, 8, ["editor", "theme-owner", "ai", "disabled", "onAi"])) : le("", !0),
      u.value ? (C(), Be(si, Qe({
        key: 1,
        id: e.id,
        ref: k
      }, n(G.$attrs), {
        "theme-owner": u.value,
        "content-profile": "basic-rich-text",
        "bubble-toolbar": !1,
        "content-limits": e.contentLimits,
        "document-value": ne.value,
        "content-type": "document",
        "output-type": "document",
        editable: !e.disabled && !e.readonly,
        typography: s,
        placeholder: e.placeholder ?? (e.ai ? "输入内容，或使用 AI 帮写" : "输入内容，使用上方工具设置格式"),
        "onUpdate:documentValue": B,
        onContentIssue: R
      }), null, 16, ["id", "theme-owner", "content-limits", "document-value", "editable", "placeholder"])) : le("", !0),
      h(m).open.value ? (C(), Be(Tu, {
        key: 2,
        controller: h(m)
      }, null, 8, ["controller"])) : le("", !0),
      N.value ? (C(), V("p", Su, de(N.value), 1)) : le("", !0),
      (C(!0), V(Oe, null, Pe([...e.messages, ...ie.value], (ue, De) => (C(), V("p", {
        key: De,
        class: H(["zx-text-editor-field__message", { "is-error": ue.severity === "error" }]),
        role: ue.severity === "error" ? "alert" : void 0
      }, de(ue.message), 11, _u))), 128))
    ], 38));
  }
}), xd = Jr(si), Ou = (e) => {
  const t = wn(e.shellState);
  return t.kind === "close-presentation" ? ((e.handlers.closePresentation ?? e.handlers.closeIdle)(), { kind: "close-presentation" }) : t.kind === "dismiss-review-ui" ? (e.handlers.dismissReviewUi(), t) : (t.kind === "close-idle" && e.handlers.closeIdle(), t);
}, Lo = (e, t) => _r({
  getState: e,
  run: t,
  subscribe: (o) => Q(e, o, { flush: "sync" })
});
function Td(e) {
  const t = Rr({
    contributions: [Yo],
    kind: "textEditor.authoring",
    roots: () => [
      Xe(e.root),
      ...e.roots ? Xe(e.roots) : []
    ].filter((a) => !!a),
    active: e.active,
    focusRequired: !0
  }), o = () => {
    const a = Xe(e.editorBindingId).trim();
    if (!a) throw new Error("editorBindingId must not be empty");
    return a;
  };
  let n = 0;
  const i = e.inlineEdit ? un(es, {
    owner: t,
    keyboardArgs: () => {
    },
    port: Lo(
      () => {
        const a = Qn(
          e.inlineEdit.getRouteInput()
        );
        return {
          enabled: a.kind !== "closed",
          reason: a.kind === "closed" ? a.reason : void 0
        };
      },
      () => {
        const a = Qn(
          e.inlineEdit.getRouteInput()
        );
        return a.kind === "closed" ? null : a.kind === "reveal" ? e.inlineEdit.owner.dispatch(a.actionId, a.binding).then((f) => {
          var l, u;
          return (u = (l = e.inlineEdit).onRevealReceipt) == null || u.call(l, f), f;
        }) : e.inlineEdit.owner.openInvocation({
          context: a.invocationContext,
          surface: {
            surface: "shortcut",
            invokerToken: `inline-edit-shortcut:${o()}`,
            capturedAtLogical: ++n
          }
        });
      }
    )
  }) : null, r = e.askAI ? un(ts, {
    owner: t,
    keyboardArgs: () => {
    },
    port: {
      ...Lo(
        e.askAI.getState,
        () => e.askAI.openInvocation({ surface: "shortcut" })
      ),
      subscribe: e.askAI.subscribe
    }
  }) : null, s = E(() => {
    var f;
    const a = Xe(e.escape.shellState);
    return wn(a).kind === "noop" && ((f = e.escape.selectionBubble) != null && f.active.value) ? "selection-bubble" : a;
  }), c = un(ns, {
    owner: t,
    keyboardArgs: () => {
    },
    port: Xo({
      getState: () => ({
        enabled: wn(s.value).kind !== "noop",
        reason: "no-ai-surface"
      }),
      subscribe: (a) => Q(s, a, { flush: "sync" }),
      run: () => Ou({
        shellState: s.value,
        handlers: s.value === "selection-bubble" ? {
          ...e.escape.handlers,
          closeIdle: () => {
            var a;
            return (a = e.escape.selectionBubble) == null ? void 0 : a.dismiss();
          }
        } : e.escape.handlers
      })
    })
  });
  return Ht(() => {
    i == null || i.dispose(), r == null || r.dispose(), c.dispose();
  }), {
    owner: t,
    inlineEdit: i ? dn(i, {
      args: void 0,
      bindingId: "textEditor.inlineEdit.open"
    }) : null,
    askAI: r ? dn(r, {
      args: void 0,
      bindingId: "textEditor.askAI.open"
    }) : null,
    escape: dn(c, {
      args: void 0,
      bindingId: "textEditor.inlineAi.escape"
    })
  };
}
function Ad(e) {
  const t = e.runtime ?? _n(), o = $o(), n = Re(null), i = E(
    () => {
      var c, a;
      return Xe(e.root) ?? ((a = (c = Xe(e.editor)) == null ? void 0 : c.view) == null ? void 0 : a.dom) ?? null;
    }
  );
  let r = () => {
  };
  const s = Q(
    [() => Xe(e.editor), i],
    ([c, a]) => {
      if (r(), r = () => {
      }, n.value = null, !c || !a) return;
      const f = Co(c);
      if (f) {
        if (f.runtime.runtimeId !== t.runtimeId)
          throw new Error("external-editor-shortcut-runtime-mismatch");
        r = zo(c, (T) => {
          if (T && T.runtime.runtimeId !== t.runtimeId)
            throw new Error("external-editor-shortcut-runtime-mismatch");
          n.value = (T == null ? void 0 : T.editLink) ?? null;
        });
        return;
      }
      const l = t.createOwner({
        contributions: [Yo],
        kind: "textEditor.editor",
        parent: o,
        focusRequired: !0
      }), u = t.attachAction(os, {
        owner: l,
        keyboardArgs: () => {
        },
        port: Xo({
          getState: () => ({
            enabled: Xe(e.active) !== !1 && !c.isDestroyed && c.isEditable !== !1 && typeof c.commands.openLinkEditor == "function",
            reason: "link-command-unavailable"
          }),
          subscribe: (T) => {
            var D, w;
            const L = Q(() => Xe(e.active), T, {
              flush: "sync"
            });
            return (D = c.on) == null || D.call(c, "transaction", T), (w = c.on) == null || w.call(c, "update", T), () => {
              var k, v;
              L(), (k = c.off) == null || k.call(c, "transaction", T), (v = c.off) == null || v.call(c, "update", T);
            };
          },
          run: () => {
            const T = c.commands.openLinkEditor;
            if (typeof T != "function")
              throw new Error("link-command-unavailable");
            return T.call(c.commands) === !0;
          }
        })
      }), p = Nr(t, l, { roots: [a] }), g = (T) => p.dispatch(T, "editor");
      a.addEventListener("keydown", g, !0), n.value = u.forArgs(void 0, {
        bindingId: "textEditor.link.edit"
      }), r = () => {
        a.removeEventListener("keydown", g, !0), p.dispose(), u.dispose(), l.dispose();
      };
    },
    { immediate: !0, flush: "sync" }
  );
  return Ht(() => {
    s(), r();
  }), { action: n };
}
export {
  ci as A,
  ld as B,
  cd as C,
  hl as D,
  ud as E,
  rd as F,
  dd as G,
  fd as H,
  oa as I,
  pd as J,
  Ln as K,
  pa as L,
  vd as M,
  gd as N,
  bd as O,
  hd as P,
  yd as Q,
  Js as T,
  xd as Z,
  kd as _,
  ga as a,
  oi as b,
  md as c,
  ad as d,
  Ou as e,
  Za as f,
  fl as g,
  Ad as h,
  wd as i,
  ru as j,
  fn as k,
  ss as l,
  Gs as m,
  ms as n,
  Ot as o,
  hs as p,
  ws as q,
  pn as r,
  Is as s,
  _t as t,
  Td as u,
  _s as v,
  sd as w,
  Xs as x,
  Zs as y,
  va as z
};
//# sourceMappingURL=use-text-editor-command-keybindings-D-qndR_F.mjs.map
