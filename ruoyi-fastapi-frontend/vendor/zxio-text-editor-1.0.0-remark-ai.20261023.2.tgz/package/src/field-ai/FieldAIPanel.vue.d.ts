import { useFieldAI } from './use-field-ai';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    controller: ReturnType<typeof useFieldAI>;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {
    input: HTMLTextAreaElement;
}, HTMLElement>;
export default _default;
//# sourceMappingURL=FieldAIPanel.vue.d.ts.map