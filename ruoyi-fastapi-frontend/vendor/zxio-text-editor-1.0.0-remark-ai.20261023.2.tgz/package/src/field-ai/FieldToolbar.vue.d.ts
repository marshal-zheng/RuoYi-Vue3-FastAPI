import { Editor } from '@tiptap/core';
import { EditorThemeOwner } from '../theme-owner';
import { DefineComponent, ComponentOptionsMixin, PublicProps, ComponentProvideOptions } from 'vue';
type __VLS_Props = {
    editor: Editor;
    themeOwner: EditorThemeOwner;
    ai: boolean;
    disabled: boolean;
};
declare const _default: DefineComponent<__VLS_Props, {}, {}, {}, {}, ComponentOptionsMixin, ComponentOptionsMixin, {
    ai: () => any;
}, string, PublicProps, Readonly<__VLS_Props> & Readonly<{
    onAi?: (() => any) | undefined;
}>, {}, {}, {}, {}, string, ComponentProvideOptions, false, {}, HTMLDivElement>;
export default _default;
//# sourceMappingURL=FieldToolbar.vue.d.ts.map