export declare const PROPOSAL_ENVELOPE_LIMITS_V1: {
    maxBytes: number;
    maxDepth: number;
    maxArrayEntries: number;
    maxObjectKeys: number;
    maxTotalObjectKeys: number;
};
export declare const PROPOSAL_RICH_DIFF_LIMITS_V1: {
    maxInputBytes: number;
    maxOutputBytes: number;
    maxHunks: number;
};
export declare const isRecord: (value: unknown) => value is Record<string, unknown>;
export declare const hasExactKeys: (value: unknown, required: readonly string[], optional?: readonly string[]) => value is Record<string, unknown>;
export declare const isNonEmptyString: (value: unknown) => value is string;
export declare const isSafeInteger: (value: unknown) => value is number;
export declare const fingerprintDomain: (domain: string, value: unknown) => string;
export declare const withoutFingerprint: <TValue extends {
    readonly fingerprint: unknown;
}>(value: TValue) => Omit<TValue, "fingerprint">;
export declare const canonicalClone: <TValue>(value: TValue) => TValue;
export declare const canonicalEqual: (left: unknown, right: unknown) => boolean;
export declare const isDeepFrozen: (value: unknown, seen?: Set<object>) => boolean;
export declare const canonicalByteLength: (value: unknown) => number;
export declare const sortedUnique: (values: readonly string[]) => readonly string[];
export declare const sortedUniqueNumbers: (values: readonly number[]) => readonly number[];
//# sourceMappingURL=internal.d.ts.map