import { G as f } from "./use-text-editor-command-keybindings-D-qndR_F.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-link-CFJ1N_EA.mjs.map
