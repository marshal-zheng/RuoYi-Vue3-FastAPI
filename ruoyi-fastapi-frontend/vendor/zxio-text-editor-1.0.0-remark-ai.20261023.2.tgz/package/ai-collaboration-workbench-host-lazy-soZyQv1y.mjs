const a = async (o) => (await import("./ai-collaboration-workbench-host-ColP286K.mjs")).createAICollaborationWorkbenchCommitHost(o), n = async (o) => (await import("./ai-collaboration-workbench-host-ColP286K.mjs")).readAICollaborationWorkbenchCanonicalDocument(o);
export {
  a as c,
  n as r
};
//# sourceMappingURL=ai-collaboration-workbench-host-lazy-soZyQv1y.mjs.map
