import { E as f } from "./use-text-editor-command-keybindings-D-qndR_F.mjs";
export {
  f as default
};
//# sourceMappingURL=insert-video-yY1AMgig.mjs.map
