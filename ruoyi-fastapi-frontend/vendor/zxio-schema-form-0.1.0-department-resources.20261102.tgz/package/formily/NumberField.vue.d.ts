import type { FieldEditState } from '../fields/types';
import type { Json } from '../types';
type __VLS_Props = {
    modelValue?: number | null;
    disabled?: boolean;
    readonly?: boolean;
    min?: number;
    max?: number;
    step?: number;
    precision?: number;
    stepStrictly?: boolean;
    disabledScientific?: boolean;
    controls?: boolean;
    controlsPosition?: '' | 'right';
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
    validate: () => boolean;
    captureEdit: () => {
        text: string;
        composition: string[];
    };
    restoreEdit(draft: Json): void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    blur: (value: FocusEvent) => any;
    focus: (value: FocusEvent) => any;
    "update:modelValue": (value: number | null) => any;
    "edit-state": (state: FieldEditState) => any;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: number | null) => any) | undefined;
    "onEdit-state"?: ((state: FieldEditState) => any) | undefined;
}>, {
    step: number;
    controls: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
