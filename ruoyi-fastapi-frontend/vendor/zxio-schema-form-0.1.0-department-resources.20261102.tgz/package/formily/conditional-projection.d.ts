import type { Json } from '../types';
import type { ConditionalLimits, ReadGrant, SafeValue } from './conditional-types';
export { matchesValueShape as matches, isValueShape as validShape, } from '../value-shape';
export declare const limits: Readonly<ConditionalLimits>;
export declare class ConditionalError extends Error {
    readonly code: string;
    constructor(code: string);
}
export declare const reject: (code: string) => never;
export declare const safeKey: (key: string) => boolean;
export declare const bytes: (value: unknown) => number;
export declare function freeze<T>(value: T): T;
/** Descriptor reads precede value reads. Never invokes accessors/toJSON. */
export declare function jsonCopy(value: unknown, budget?: number): Json;
export declare function project(value: Json, grant: ReadGrant): Json | undefined;
export declare function visibleValue(present: boolean, value: Json | undefined, grant: ReadGrant): SafeValue | undefined;
export declare function validGrant(grant: ReadGrant): boolean;
