import type { Json } from '../types';
import type { ValueShape } from '../value-shape';
export type { ValueShape } from '../value-shape';
export type RowId = string | number;
export type RowSelector = {
    row: RowId;
} | {
    inserted: string;
};
export type EditAddress = readonly (string | RowSelector)[];
export type PolicyPath = readonly (string | {
    row: true;
})[];
export type ReadGrant = {
    kind: 'none';
} | {
    kind: 'all';
} | {
    kind: 'object';
    properties: Readonly<Record<string, ReadGrant>>;
} | {
    kind: 'array';
    items: ReadGrant;
};
export interface ConditionalFieldRule {
    path: PolicyPath;
    describe: boolean;
    read: ReadGrant;
    write: boolean;
    atomic: boolean;
    shape: ValueShape;
    clear?: {
        kind: 'remove';
    } | {
        kind: 'value';
        value: Json;
    };
}
export interface ConditionalArrayRule {
    path: PolicyPath;
    describe: boolean;
    readRows: boolean;
    readKeys: boolean;
    key: string;
    insert: boolean;
    remove: boolean;
    move: boolean;
    insertFields: readonly ConditionalFieldRule[];
    defaults?: Readonly<Record<string, Json>>;
}
export interface ApprovalBinding {
    owner: string;
    candidateRef: string;
    operationRef: string;
    observationRef: string;
    baseRevision: string;
    policyGeneration: number;
}
export interface ConditionalEditPolicy {
    fields: readonly ConditionalFieldRule[];
    arrays: readonly ConditionalArrayRule[];
    authorizeApply?: (proposal: Readonly<ApprovalBinding>, credential: unknown) => boolean;
}
export type ConditionalChange = {
    kind: 'set';
    target: EditAddress;
    value: Json;
} | {
    kind: 'clear';
    target: EditAddress;
} | {
    kind: 'arrayInsert';
    target: EditAddress;
    localRef: string;
    before: RowSelector | null;
    value: Readonly<Record<string, Json>>;
} | {
    kind: 'arrayRemove';
    target: EditAddress;
    row: RowSelector;
} | {
    kind: 'arrayMove';
    target: EditAddress;
    row: RowSelector;
    before: RowSelector | null;
};
export interface ConditionalEligibility {
    canApply: boolean;
    reasons: readonly string[];
}
export interface ConditionalChecks {
    performed: readonly string[];
    deferred: readonly string[];
    issues: readonly {
        code: string;
        action?: number;
    }[];
}
export interface SafeValue {
    present: boolean;
    value?: Json;
}
export interface SafeDifference {
    target: EditAddress;
    before?: SafeValue;
    after?: SafeValue;
}
export interface ConditionalPreview {
    changes: readonly SafeDifference[];
    previewComplete: boolean;
    issuesComplete: boolean;
}
export interface SnapshotField {
    target: EditAddress;
    value?: SafeValue;
    actions: readonly string[];
    shape: ValueShape;
    clear?: {
        kind: 'remove';
    } | {
        kind: 'value';
        value?: SafeValue;
    };
}
export interface SnapshotArray {
    target: EditAddress;
    rows?: readonly RowId[];
    actions: readonly string[];
}
export interface ConditionalLimits {
    actions: number;
    addressDepth: number;
    planBytes: number;
    domainBytes: number;
    outputBytes: number;
    observations: number;
    candidates: number;
    operations: number;
    observationMs: number;
    candidateMs: number;
    retentionMs: number;
    retainedBytes: number;
    verificationMs: number;
    waiters: number;
    waitMs: number;
    maxWaitMs: number;
}
/** Omitted options keep the whole permitted projection with values. */
export interface SnapshotOptions {
    /** Address prefixes; omitted selects every described target. */
    select?: readonly EditAddress[];
    /** false returns the structure view: no field values, rows/actions kept. */
    values?: boolean;
    /** 1..limits.outputBytes; larger values use the owner limit. */
    maxBytes?: number;
}
/** `credential`: the policy installed `authorizeApply`, so apply checks the
 * caller's credential. `none`: apply accepts without one. */
export type ApplyAuthorization = 'credential' | 'none';
export interface SnapshotScope {
    select: readonly EditAddress[] | null;
    values: boolean;
}
export type SnapshotResult = {
    status: 'observed';
    observationRef: string;
    revision: string;
    /** Complete only for this scope. */
    complete: true;
    scope: SnapshotScope;
    fields: readonly SnapshotField[];
    arrays: readonly SnapshotArray[];
    eligibility: ConditionalEligibility;
    authorization: ApplyAuthorization;
    limits: ConditionalLimits;
} | {
    status: 'unavailable';
    reason: string;
    complete: false;
};
export type PrepareResult = {
    status: 'prepared';
    candidateRef: string;
    operationRef: string;
    baseRevision: string;
    expiresAt: number;
    preview: ConditionalPreview;
    checks: ConditionalChecks;
    eligibility: ConditionalEligibility;
    authorization: ApplyAuthorization;
} | {
    status: 'rejected';
    reasons: readonly string[];
    checks: ConditionalChecks;
};
export interface OperationView {
    operationRef: string;
    candidateRef: string;
    phase: 'not-started' | 'authorizing' | 'writing' | 'settled';
    detailsComplete: boolean;
    write: null | {
        outcome: 'not-applied' | 'applied' | 'partial' | 'unknown';
        reason?: string;
        started: readonly number[];
        completed: readonly number[];
        actualDiff: readonly SafeDifference[];
        diffComplete: boolean;
        recoveryRequired: boolean;
    };
    verification: {
        status: 'not-started' | 'pending' | 'valid' | 'invalid' | 'superseded' | 'unverified';
        reason?: string;
        coverage: readonly string[];
        issues: readonly {
            code: string;
        }[];
        revision?: string;
        current: boolean;
        issuesComplete: boolean;
    };
}
export type ApplyResult = {
    status: 'recorded';
    operation: OperationView;
} | {
    status: 'unavailable';
    reason: string;
};
export type OperationResult = {
    status: 'available';
    operation: OperationView;
} | {
    status: 'unavailable';
    reason: string;
};
export type DiscardResult = {
    status: 'discarded' | 'not-discardable';
    operationRef: string;
} | {
    status: 'unavailable';
    reason: string;
};
export type WaitResult = OperationResult | {
    status: 'timed-out' | 'wait-cancelled';
    operationRef: string;
    latest?: OperationView;
};
export interface ConditionalEditApi {
    readSnapshot(options?: SnapshotOptions): SnapshotResult;
    prepareEdit(changes: readonly ConditionalChange[], options: {
        observationRef: string;
    }): PrepareResult;
    applyPrepared(candidateRef: string, options?: {
        signal?: AbortSignal;
        credential?: unknown;
    }): ApplyResult;
    discardPrepared(candidateRef: string): DiscardResult;
    getOperation(operationRef: string): OperationResult;
    waitOperation(operationRef: string, options?: {
        signal?: AbortSignal;
        timeoutMs?: number;
    }): Promise<WaitResult>;
}
