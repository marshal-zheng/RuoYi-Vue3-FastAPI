import type { FieldAttachment, FieldUpload } from './attachment';
import type { FieldEditState, FieldMessage } from './types';
import type { Json } from '../types';
type __VLS_Props = {
    modelValue?: FieldAttachment[];
    upload: FieldUpload;
    disabled?: boolean;
    readonly?: boolean;
    multiple?: boolean;
    accept?: string;
    maxSize?: number;
    limit?: number;
    buttonText?: string;
    /** Path-scoped messages; `[index]` addresses a committed attachment. */
    messages?: readonly FieldMessage[];
};
declare const _default: import("vue").DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
    validate: () => boolean;
    captureEdit(): Json;
    restoreEdit(draft: Json): void;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    "update:modelValue": (value: FieldAttachment[]) => void;
    "edit-state": (state: FieldEditState) => void;
    blur: (value: FocusEvent) => void;
    focus: (value: FocusEvent) => void;
}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: FieldAttachment[]) => any) | undefined;
    "onEdit-state"?: ((state: FieldEditState) => any) | undefined;
}>, {
    multiple: boolean;
    modelValue: FieldAttachment[];
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
