"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const AttachmentInput_vue_vue_type_script_setup_true_lang = require("../AttachmentInput.vue_vue_type_script_setup_true_lang-Bh5gEOS5.js");
const vue = require("vue");
const input = require("@zxio/zxui/input");
const json = require("../json-BupWnDag.js");
const _sfc_main$1 = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxNumberTextInput", inheritAttrs: false },
  __name: "NumberTextInput",
  props: {
    text: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean }
  },
  emits: ["edit"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const input$1 = vue.shallowRef();
    function setInput(value) {
      input$1.value = value;
    }
    function edit(text) {
      emit("edit", { text, badInput: AttachmentInput_vue_vue_type_script_setup_true_lang.parseNumberText(text).status === "invalid" });
    }
    __expose({ focus: () => {
      var _a;
      return (_a = input$1.value) == null ? void 0 : _a.focus();
    } });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.unref(input.ZxInput), vue.mergeProps({ ref: setInput }, _ctx.$attrs, {
        type: "text",
        inputmode: "decimal",
        "model-value": __props.text,
        disabled: __props.disabled,
        readonly: __props.readonly,
        "onUpdate:modelValue": edit
      }), null, 16, ["model-value", "disabled", "readonly"]);
    };
  }
});
function parseJsonText(text) {
  if (!text.trim()) return { status: "empty" };
  try {
    const value = JSON.parse(text);
    json.safeJson(value, "$", false);
    return { status: "valid", value };
  } catch {
    return { status: "invalid" };
  }
}
const _sfc_main = /* @__PURE__ */ vue.defineComponent({
  ...{ name: "ZxJsonTextInput", inheritAttrs: false },
  __name: "JsonTextInput",
  props: {
    text: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean }
  },
  emits: ["edit"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const input$1 = vue.shallowRef();
    function setInput(value) {
      input$1.value = value;
    }
    function edit(text) {
      emit("edit", { text, badInput: parseJsonText(text).status === "invalid" });
    }
    __expose({ focus: () => {
      var _a;
      return (_a = input$1.value) == null ? void 0 : _a.focus();
    } });
    return (_ctx, _cache) => {
      return vue.openBlock(), vue.createBlock(vue.unref(input.ZxInput), vue.mergeProps({ ref: setInput }, _ctx.$attrs, {
        type: "textarea",
        "model-value": __props.text,
        disabled: __props.disabled,
        readonly: __props.readonly,
        "onUpdate:modelValue": edit
      }), null, 16, ["model-value", "disabled", "readonly"]);
    };
  }
});
exports.FieldUploadError = AttachmentInput_vue_vue_type_script_setup_true_lang.FieldUploadError;
exports.ZxAttachmentInput = AttachmentInput_vue_vue_type_script_setup_true_lang._sfc_main$2;
exports.ZxDateInput = AttachmentInput_vue_vue_type_script_setup_true_lang._sfc_main$1;
exports.ZxField = AttachmentInput_vue_vue_type_script_setup_true_lang._sfc_main;
exports.parseNumberText = AttachmentInput_vue_vue_type_script_setup_true_lang.parseNumberText;
exports.useInputComposition = AttachmentInput_vue_vue_type_script_setup_true_lang.useInputComposition;
exports.ZxJsonTextInput = _sfc_main;
exports.ZxNumberTextInput = _sfc_main$1;
exports.parseJsonText = parseJsonText;
