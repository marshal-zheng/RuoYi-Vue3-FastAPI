import type { Json } from '../types';
/** Data addressing only; interpretation and stable row identity belong to the host. */
export type FieldPath<T = unknown> = unknown extends T ? readonly (string | number)[] : DataPath<T>;
/** A bounded tuple union; dynamic records and open object types without
 * declared keys (`object`, `{}`, an uninferred form generic) deliberately keep
 * dynamic paths. */
type DataPath<T, Depth extends unknown[] = []> = Depth['length'] extends 8 ? never : T extends readonly (infer Item)[] ? readonly [number] | readonly [number, ...DataPath<Item, [...Depth, unknown]>] : T extends object ? string extends keyof T ? readonly (string | number)[] : [keyof T] extends [never] ? readonly (string | number)[] : {
    [K in Extract<keyof T, string | number>]-?: readonly [K] | readonly [K, ...DataPath<T[K], [...Depth, unknown]>];
}[Extract<keyof T, string | number>] : never;
export interface FieldMessage {
    severity: 'error' | 'warning' | 'info';
    message: string;
    /** Relative to the receiving composite field. */
    path?: FieldPath;
}
/** A complete snapshot: omitted pending/commitPending/blocking mean false/false/empty in every host. */
export interface FieldEditState {
    /** Monotonic genuine raw edits; report synchronously before canonical updates. */
    editSequence?: number;
    /** Activity indicator. Non-blocking option refreshes may set this alone. */
    pending?: boolean;
    /** Awaiting canonical owner acceptance; blocks commits without retiring the
     * same value's validation when acceptance completes. Report editSequence for
     * the actual user edit before publishing the value. */
    commitPending?: boolean;
    /** Unfinished edits that the host must check at every commit entry point. */
    blocking?: readonly FieldMessage[];
}
export interface FieldControl {
    /** Retained raw draft for temporary hiding; never restore an active DOM IME session. */
    captureEdit?(): Json;
    restoreEdit?(draft: Json): void;
    focus(path?: FieldPath): void;
    /** Commit validation feedback only through the supplied ownership context. */
    validate?(context: FieldValidationContext): boolean | Promise<boolean>;
}
export interface FieldValidationContext {
    readonly signal: AbortSignal;
    /** False after input, replacement, timeout or a newer validation. */
    current(): boolean;
    /** Runs synchronously only while this validation still owns its feedback. */
    commit(update: () => void): boolean;
}
export interface FieldControlAttrs {
    id: string;
    'aria-required'?: true;
    'aria-invalid'?: true;
    'aria-describedby'?: string;
    'aria-labelledby'?: string;
}
export interface NumberTextEdit {
    text: string;
    badInput: boolean;
}
export type ParsedNumberText = {
    status: 'empty';
} | {
    status: 'valid';
    value: number;
} | {
    status: 'invalid';
};
export interface JsonTextEdit {
    text: string;
    badInput: boolean;
}
export type ParsedJsonText = {
    status: 'empty';
} | {
    status: 'valid';
    value: Json;
} | {
    status: 'invalid';
};
export {};
