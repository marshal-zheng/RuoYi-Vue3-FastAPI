# 条件编辑

条件编辑针对一个独立保存域，复用唯一的 Formily canonical 值、真实联动、输入状态和校验。它修改草稿，不提交服务器，也不推进保存基线。人、普通 API 与受控 adapter 使用同一套协议。可运行的公开消费示例见 [工作台](../../examples/conditional-edit/Workbench.vue)。

## Host 安装与六方法

只通过 `@zxio/schema-form/formily` 导入 `ZxSchemaForm`、`SchemaFormInstance`、`ConditionalEditApi`、`ConditionalEditPolicy`。根与 `/fields` 保持无 Formily 引擎边界。

Host 用 `initialConditionalEditPolicy` 在创建时安装策略；缺失或非法策略默认拒绝。授权来源改变时，必须先同步调用 `form.setConditionalEditPolicy(next)`，再调用任何观察或操作方法。修改初始 prop、原始策略对象、回调闭包或等待 Vue 更新都不能代替此屏障。传 `undefined` 会立即关闭能力。

adapter 只接收绑定实例的六方法：`readSnapshot`、`prepareEdit`、`applyPrepared`、`discardPrepared`、`getOperation`、`waitOperation`。不要把完整实例的 `read/setValues/submit/reconcile` 或策略 setter 暴露为模型工具。

```ts
import type {
  ConditionalEditApi,
  SchemaFormInstance,
} from '@zxio/schema-form/formily'
function capability(form: SchemaFormInstance): ConditionalEditApi {
  return {
    readSnapshot: form.readSnapshot,
    prepareEdit: form.prepareEdit,
    applyPrepared: form.applyPrepared,
    discardPrepared: form.discardPrepared,
    getOperation: form.getOperation,
    waitOperation: form.waitOperation,
  }
}
```

1. `readSnapshot(options?)` 返回有界、独立、冻结的公开 JSON；只有 `observed/complete:true` 才含有效 observationRef。可选范围、结构视图与本次输出上限见下文“有界观察”。
2. `prepareEdit(changes, { observationRef })` 冻结计划和顺序，检查形状、身份、权限与资格；成功时预绑定 candidateRef/operationRef。预览是拟改值，不执行真实 reaction、资源、validate 或 authorizeApply。
3. `applyPrepared(candidateRef)` 在当前整域版本重新整体预检，并在任何授权回调前预占。失败零写入，开始写后逐步复核并保留前缀事实；重复提交只查询原 operation。
4. `getOperation` 只查询原操作。`waitOperation` 独立等待，signal/timeout 仅结束本次等待，不撤销领域工作。未启动操作立即返回。
5. `discardPrepared` 只撤销未开始资格，不能撤销已应用工作。

`authorizeApply(binding, credential)` 只由可信 Host 在 apply 时同步执行，绑定 owner、candidate、operation、observation、revision、policyGeneration；仅严格返回 true 才放行。模型的 `confirmed:true` 不具有授权含义。回调内丢弃、取消、换策略或重入均不能复活资格。

观察结果与成功的准备结果都带 `authorization`：策略安装了 `authorizeApply` 时为 `credential`，否则为 `none`（apply 不校验凭证）。要求审批的调用方（如 Page Agent 官方表单 adapter）据此拒绝 `none`，不必假设 Host 已安装授权回调。

### 有界观察

中等以上表单的完整快照可能超过调用方（如 Page Agent 工具输出）预算。`readSnapshot` 接受三项可选参数，全部省略时与完整快照一致：

```ts
form.readSnapshot({
  select: [['items', { row: 'b' }], ['name']], // 地址前缀，最多 64 条、每条最多 32 层
  values: false, // 结构视图：不含字段值，保留 target/actions/shape/clear 与数组 rows/actions
  maxBytes: 12 * 1024, // 本次输出上限；大于 256 KiB 时按 owner 上限处理
})
```

- 结果携带 `scope: { select, values }`，省略参数时为 `{ select: null, values: true }`。`complete:true` 只对该范围成立，范围外目标不出现。
- 前缀按地址元素逐项比较；`{ row }` 按业务 ID 比较且区分类型，`{ inserted }` 不能出现在 select。非数组、空列表、超过条数或层数、未知元素形状返回 `unavailable/invalid-select`；未知参数键、访问器、非布尔 `values` 或非正安全整数 `maxBytes` 返回 `unavailable/invalid-options`。不执行 getter。
- 输出超过本次 `maxBytes` 返回 `unavailable/output-limit`，不截断、不静默删字段。调用方可先取结构视图，再按需要的地址前缀 select。
- 观察记录保存范围；`prepareEdit` 在计划前检查：结构视图观察返回 `rejected/structure-only-observation`，任一 `change.target` 不在 select 前缀内返回 `rejected/target-not-observed`。数组插入/删除/重排的 target 是数组容器本身，需选中容器地址。观察仍保存整域捕获作为计划与差异基线；保留、容量、TTL 与 revision 失效规则不变。

## 权限与纯规则

字段规则分别声明 `describe`、`read: ReadGrant`、`write`、`atomic`、`shape: ValueShape` 与可选 `clear`。`describe` 许可地址、形状和动作；不自动授予值。`ReadGrant` 支持 `none/all/object.properties/array.items`；缺省子键拒绝，父 none 不可被后代复活。整个 atomic 值可写但只读部分子键。任何历史事实都按查询当时策略重新投影，不回放旧敏感 DTO。

`ValueShape` 支持 null、boolean、number（minimum/maximum/integer）、string（minLength/maxLength）、array（items/minItems/maxItems）、object（properties/required，未知属性拒绝）、enum（values）。不执行 JS、正则字符串、Formily validator 或任意纯检查回调。普通字段不能用整对象/数组替换结构容器；复合 JSON 必须显式 atomic 且无结构子字段。clear 只接受字段声明的 remove 或 value；null 不是通用清空。

运行时 readonly/disabled/可用性只能收窄直接写入。合法同域联动可以更新非直接可写字段，结果仍受读取权限限制。可信 JS 没有被沙箱隔离；跨域动作、保存和外部副作用必须使用独立 Host 契约。

## 数组与身份

地址按字面键解释，如 `['items', { row: 'a' }, 'quantity']`；禁止点语法、数字索引及原型键。字符串/数字 ID 类型敏感且必须唯一，嵌套数组逐层使用所属容器的业务 ID。不要用渲染 key 做授权身份。配置 `arrayKeys` 与策略行 key 保持一致，以复用现有错误迁移和渲染身份。策略中的 `{ row: true }` 匹配所有 concrete 数字行索引；任意层、任一匹配容器的 key 冲突都会在安装时同步拒绝策略。

数组规则的 insert/remove/move 分别授权。插入的 `insertFields` 单独声明调用方载荷许可；未知初始化属性整体拒绝。每个实际提供的初始化字段（含 atomic 根及嵌套字段）还须通过 schema 的静态只读/禁用限制；不能用插入载荷绕过普通字段的直接写限制。Host 静态 defaults 不授予覆盖权限；业务 ID 由 Host 生成后经获准且可写的初始化字段传入，或由 Host 在观察之前安装到可信 defaults（适用于只读 ID），库不生成 ID。工作台选择后一种方式；收权后普通准备不会重新安装授权策略。`localRef` 可供同一候选后续 `{ inserted: 'new' }` 使用；不允许前向引用、删除后引用或删除后复用 ID。共享容器的有序结构操作合法；重复字段、父子整值与删除已编辑行等歧义整体拒绝。

## 输入、版本与恢复

canonical ABA、raw 同值编辑（如 1→01）、相等配置替换、控件/schema/binding/authority/reset/reconcile/策略变化都会失效旧观察与资格。纯 focus 不失效；独立保存域互不影响。

`binding.editObservation` 明确声明 canonical 或 raw-sequence。真实 raw/IME/复合草稿先同步递增并上报 `FieldEditState.editSequence`，再发 canonical；重复 validate/report 不递增。未完成输入通过 blocking 上报，隐藏保留或 validationActive=false 仍受保护。快照与准备不会调用可能提交 IME 的 captureEdit。未声明或不能可靠观测 raw 的自定义控件不能条件写；这不阻断既有人工/Host API。

内建文本、数字适配与随包 JSON/附件/检查项/协议示例提供观测协议。复杂控件的专用动作不在本片范围；没有观测协议的 binding（包括未适配的标签输入）使整域返回 `input-observation-unavailable`，不能冒充 canonical-only。普通 required/range 校验错误可被纠正；必要资源未就绪、runtime fault、未知锁与忙碌分别拒绝，可选 pending 不单独阻断。

写入事实为 `not-applied/applied/partial/unknown`，核验独立为 `not-started/pending/valid/invalid/superseded/unverified`。applied 表示直接动作已执行，联动仍可能改写最终值，且不代表验证或保存成功。unknown 锁存恢复要求；只有可信 Host 经 reconcile 核对权威值后释放，不能通过新候选或详情过期绕过。没有自动回滚。当前受管核验包括同步联动、登记资源和校验，不包括未登记异步回调与服务器保存。

## 固定预算

每请求 64 动作、32 层地址；计划 256 KiB、保存域捕获 1 MiB、公开输出 256 KiB（快照可用 `maxBytes` 进一步收窄单次输出）。16 个观察保留 60 秒、8 个待应用候选保留 5 分钟、32 个操作终态详情保留 10 分钟。候选独立于观察 TTL，活候选不被静默驱逐。未知引用永不变成新写请求。

总保留数据配额 8 MiB，按 UTF-8 载荷与固定记录开销计账；prepare 预留 8 KiB 事实头，apply 在业务回调前预留 before/after/diff 工作空间各 1 MiB。它不是 JavaScript 实际堆大小承诺。核验预算 30 秒、每操作最多 16 等待者；单 wait 默认 30 秒、最多 60 秒。输出过大明确标 complete=false；不截断写计划、不用缺失详情推断零写入。

## 验证与运行

包测试：`pnpm -C packages/schema-form test`，类型与构建分别使用同包 `typecheck`、`build`。独立消费者：先构建必要公开依赖和 schema-form，再运行 `node scripts/contracts/check-form-conditional-edit-packed.mjs`。该命令独立 tarball 安装、类型检查、happy-dom 挂载和 Vite 构建，并以关闭 `skipLibCheck` 的方式检查本包全部已发布声明，保留输出目录；不等同于真实浏览器验收。浏览器运行需单独用户授权。模型与生产 RuoYi 联调不是本片强制门。性能与实际堆只记录实测场景，不承诺未测 SLA。

## 受管控件核验

参与条件编辑的 composite binding 还须声明 `validationOwnership: 'managed'`。`FieldControl.validate(context)` 接收公开 `/fields` 的 `FieldValidationContext`；同步纯检查可直接返回 boolean，异步完成后所有本地反馈写入必须使用 `context.commit(() => { ... })`，并可用 `context.signal` 取消请求。`context.current()` 在人工 raw/canonical 编辑、控件/owner 替换或超时后返回 false；commit 此时不执行回调。未声明该协议的复合控件没有条件写资格。

```ts
async function validate(context: FieldValidationContext) {
  const issues = await checkCurrentValue(context.signal)
  if (
    !context.commit(() => {
      feedback.value = issues
    })
  )
    return false
  return issues.length === 0
}
```

Host 仍负责遵守受管提交契约；能力声明不沙箱化任意 JavaScript。超时不伪造回滚，尚未结束的控件核验仍保持排他。
