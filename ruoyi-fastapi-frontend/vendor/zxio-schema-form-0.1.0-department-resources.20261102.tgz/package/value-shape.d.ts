import type { Json } from './types';
export type ValueShape = {
    type: 'null' | 'boolean';
} | {
    type: 'number';
    minimum?: number;
    maximum?: number;
    integer?: boolean;
} | {
    type: 'string';
    minLength?: number;
    maxLength?: number;
} | {
    type: 'array';
    items: ValueShape;
    minItems?: number;
    maxItems?: number;
} | {
    type: 'object';
    properties: Readonly<Record<string, ValueShape>>;
    required?: readonly string[];
} | {
    type: 'enum';
    values: readonly Json[];
};
/** A closed, finite JSON shape. Invalid untyped input is rejected without throwing. */
export declare function isValueShape(input: unknown): input is ValueShape;
/** The same value contract is shared by standalone consumers and Formily. */
export declare function matchesValueShape(value: unknown, shape: ValueShape): boolean;
