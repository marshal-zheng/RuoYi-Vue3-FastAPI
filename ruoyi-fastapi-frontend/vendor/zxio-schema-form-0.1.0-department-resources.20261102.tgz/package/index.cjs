"use strict";
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const json = require("./json-BupWnDag.js");
function isData(value) {
  const ancestors = /* @__PURE__ */ new Set();
  const inspect = (input, depth) => {
    if (depth > 40) return false;
    if (input === null || typeof input !== "object") return true;
    if (ancestors.has(input)) return false;
    const array = Array.isArray(input);
    if (Object.getPrototypeOf(input) !== (array ? Array.prototype : Object.prototype))
      return false;
    ancestors.add(input);
    const descriptors = Object.getOwnPropertyDescriptors(input);
    const keys = Reflect.ownKeys(descriptors);
    if (keys.some((key) => typeof key !== "string")) return false;
    const entries = Object.entries(descriptors).filter(
      ([key]) => !(array && key === "length")
    );
    if (array && entries.length !== input.length) return false;
    for (const [key, descriptor] of entries) {
      if (!("value" in descriptor) || !descriptor.enumerable) return false;
      if (array && (!/^(0|[1-9]\d*)$/.test(key) || Number(key) >= input.length))
        return false;
      if (!inspect(descriptor.value, depth + 1)) return false;
    }
    ancestors.delete(input);
    return true;
  };
  try {
    if (!inspect(value, 0)) return false;
    json.safeJson(value, "$", false);
    return true;
  } catch {
    return false;
  }
}
const allowed = {
  null: [],
  boolean: [],
  number: ["minimum", "maximum", "integer"],
  string: ["minLength", "maxLength"],
  array: ["items", "minItems", "maxItems"],
  object: ["properties", "required"],
  enum: ["values"]
};
const record = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
const range = (min, max, integer) => [min, max].every(
  (value) => value === void 0 || typeof value === "number" && Number.isFinite(value) && (!integer || Number.isInteger(value) && value >= 0)
) && (min === void 0 || max === void 0 || min <= max);
function shapeMatches(input) {
  if (!record(input) || typeof input.type !== "string" || !Object.hasOwn(allowed, input.type))
    return false;
  if (Object.keys(input).some(
    (key) => key !== "type" && !allowed[input.type].includes(key)
  ))
    return false;
  switch (input.type) {
    case "array":
      return shapeMatches(input.items) && range(input.minItems, input.maxItems, true);
    case "object": {
      const properties = input.properties;
      const required = input.required;
      return record(properties) && Object.values(properties).every(shapeMatches) && (required === void 0 || Array.isArray(required) && required.every(
        (key) => typeof key === "string" && Object.hasOwn(properties, key)
      ));
    }
    case "enum":
      return Array.isArray(input.values) && input.values.length > 0;
    case "string":
      return range(input.minLength, input.maxLength, true);
    case "number":
      return range(input.minimum, input.maximum, false) && (input.integer === void 0 || typeof input.integer === "boolean");
    default:
      return true;
  }
}
function isValueShape(input) {
  try {
    return isData(input) && shapeMatches(input);
  } catch {
    return false;
  }
}
function matchesValueShape(value, shape) {
  try {
    return isValueShape(shape) && isData(value) && matches(value, shape);
  } catch {
    return false;
  }
}
function matches(value, shape) {
  switch (shape.type) {
    case "null":
      return value === null;
    case "boolean":
      return typeof value === "boolean";
    case "enum":
      return shape.values.some((item) => json.equal(item, value));
    case "number":
      return typeof value === "number" && Number.isFinite(value) && (!shape.integer || Number.isInteger(value)) && (shape.minimum === void 0 || value >= shape.minimum) && (shape.maximum === void 0 || value <= shape.maximum);
    case "string":
      return typeof value === "string" && (shape.minLength === void 0 || value.length >= shape.minLength) && (shape.maxLength === void 0 || value.length <= shape.maxLength);
    case "array":
      return Array.isArray(value) && (shape.minItems === void 0 || value.length >= shape.minItems) && (shape.maxItems === void 0 || value.length <= shape.maxItems) && value.every((item) => matches(item, shape.items));
    case "object":
      return !!value && typeof value === "object" && !Array.isArray(value) && Object.keys(value).every(
        (key) => Object.hasOwn(shape.properties, key) && matches(value[key], shape.properties[key])
      ) && (shape.required ?? []).every((key) => Object.hasOwn(value, key));
    default:
      return false;
  }
}
exports.copy = json.copy;
exports.equal = json.equal;
exports.isValueShape = isValueShape;
exports.matchesValueShape = matchesValueShape;
