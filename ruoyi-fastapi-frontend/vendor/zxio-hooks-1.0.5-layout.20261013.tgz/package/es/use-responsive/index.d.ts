import { ComputedRef, MaybeRef, Ref } from 'vue';
export * from './container-fit';
export interface BreakpointConfig {
    [name: string]: number;
}
/** Tailwind CSS 风格默认断点 */
export declare const DEFAULT_BREAKPOINTS: BreakpointConfig;
export interface ResponsiveOptions {
    /** 断点配置，默认使用 Tailwind 风格 */
    breakpoints?: BreakpointConfig;
    /** 默认宽度 (SSR) */
    defaultWidth?: number;
    /** 默认高度 (SSR) */
    defaultHeight?: number;
    /** resize debounce 间隔，默认 100ms */
    debounce?: number;
    /** 监听目标，默认 window */
    target?: MaybeRef<Window | HTMLElement | null>;
}
export interface UseResponsiveReturn {
    /** 视口宽度 */
    width: Ref<number>;
    /** 视口高度 */
    height: Ref<number>;
    /** 当前匹配的断点名称 */
    breakpoint: ComputedRef<string>;
    /** 所有匹配的断点 */
    matchedBreakpoints: ComputedRef<string[]>;
    /** 是否匹配指定断点 */
    isMatch: (breakpointName: string) => boolean;
    /** 是否大于等于指定断点 */
    isAbove: (breakpointName: string) => boolean;
    /** 是否小于指定断点 */
    isBelow: (breakpointName: string) => boolean;
    /** 是否在两个断点之间 */
    isBetween: (min: string, max: string) => boolean;
    /** 媒体查询风格 API */
    matches: (query: string) => ComputedRef<boolean>;
}
export declare function useResponsive(options?: ResponsiveOptions): UseResponsiveReturn;
