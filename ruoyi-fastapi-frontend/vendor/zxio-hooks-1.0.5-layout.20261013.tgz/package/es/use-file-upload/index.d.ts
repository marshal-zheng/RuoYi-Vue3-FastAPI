import { ComputedRef } from 'vue';
export interface UploadOptions {
    endpoint: string;
    method?: 'POST' | 'PUT' | 'PATCH';
    headers?: Record<string, string>;
    fieldName?: string;
    data?: Record<string, string | Blob | number | boolean>;
    withCredentials?: boolean;
    onProgress?: (event: ProgressEvent<EventTarget>) => void;
}
export interface UploadResponse {
    data: unknown;
    status: number;
    headers: Record<string, string>;
}
export interface UploadState {
    uploading: boolean;
    progress: number;
    uploaded: number;
    total: number;
    error: Error | null;
    result: UploadResponse | null;
}
export declare function useFileUpload(): {
    upload: (file: File | null, options: UploadOptions) => Promise<UploadResponse>;
    reset: () => void;
    state: {
        uploading: boolean;
        progress: number;
        uploaded: number;
        total: number;
        error: Error | null;
        result: {
            data: unknown;
            status: number;
            headers: Record<string, string>;
        } | null;
    };
    isUploading: ComputedRef<boolean>;
    progress: ComputedRef<number>;
    error: ComputedRef<Error | null>;
    result: ComputedRef<{
        data: unknown;
        status: number;
        headers: Record<string, string>;
    } | null>;
};
