import { InjectionKey, Ref, PropType, ComputedRef } from 'vue';
import { ComponentSize } from '@zxio/types';
import { EpPropMergeType } from '@zxio/shared';
export declare const useSizeProp: {
    readonly type: PropType<EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
    readonly required: false;
    readonly validator: ((val: unknown) => boolean) | undefined;
    __epPropKey: true;
};
export declare const useSizeProps: {
    size: {
        readonly type: PropType<EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
};
export interface SizeContext {
    size: Ref<ComponentSize>;
}
export declare const SIZE_INJECTION_KEY: InjectionKey<SizeContext>;
export declare const useGlobalSize: () => ComputedRef<ComponentSize>;
