# Release notes

## 1.0.0

- Add the Army Pine Theme v4 package with 162 deterministic variants.
- Anchor light chrome to a screen-safe reconstruction of PLA 07 松枝绿
  (cool grey-green). Dark canvas keeps the same hue family at a readable
  lightness, with wider body / elevated steps and lifted status colors.
- Distinct from `@zxio/theme-defense-green`, which stays the generic
  Western-anchored defense skin.
