# @zxio/theme-army-pine

Army Pine is a PLA Army 07-series 松枝绿 Theme v4 package. Identity is the
cool grey-green service uniform, not US Army Green and not the ceremonial
grass-green flag bar.

Run `pnpm -C packages/theme-army-pine build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
