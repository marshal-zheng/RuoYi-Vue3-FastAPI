/** Numeric schema fields retain editable text and expose the composite contract. */
export declare function createZxuiBindings(): {
    ZxInputNumber: {
        component: import('vue').Raw<import('vue').DefineComponent<{
            modelValue?: number | null;
            disabled?: boolean;
            readonly?: boolean;
            min?: number;
            max?: number;
            step?: number;
            precision?: number;
            stepStrictly?: boolean;
            disabledScientific?: boolean;
            controls?: boolean;
            controlsPosition?: string;
            messages?: readonly import('../fields').FieldMessage[];
        }, {
            focus: () => void | undefined;
            validate: () => boolean;
            captureEdit: () => string;
            restoreEdit(draft: import('..').Json): void;
        }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
            blur: (value: FocusEvent) => any;
            focus: (value: FocusEvent) => any;
            "update:modelValue": (value: number | null) => any;
            "edit-state": (state: import('../fields').FieldEditState) => any;
        }, string, import('vue').PublicProps, Readonly<{
            modelValue?: number | null;
            disabled?: boolean;
            readonly?: boolean;
            min?: number;
            max?: number;
            step?: number;
            precision?: number;
            stepStrictly?: boolean;
            disabledScientific?: boolean;
            controls?: boolean;
            controlsPosition?: string;
            messages?: readonly import('../fields').FieldMessage[];
        }> & Readonly<{
            onBlur?: ((value: FocusEvent) => any) | undefined;
            onFocus?: ((value: FocusEvent) => any) | undefined;
            "onUpdate:modelValue"?: ((value: number | null) => any) | undefined;
            "onEdit-state"?: ((state: import('../fields').FieldEditState) => any) | undefined;
        }>, {
            step: number;
            controls: boolean;
        }, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
            input: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<{
                text: string;
                disabled?: boolean;
                readonly?: boolean;
            }> & Readonly<{
                onEdit?: ((edit: import('../fields').NumberTextEdit) => any) | undefined;
            }>, {
                focus: () => void | undefined;
            }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
                edit: (edit: import('../fields').NumberTextEdit) => any;
            }, import('vue').PublicProps, {}, false, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
                P: {};
                B: {};
                D: {};
                C: {};
                M: {};
                Defaults: {};
            }, Readonly<{
                text: string;
                disabled?: boolean;
                readonly?: boolean;
            }> & Readonly<{
                onEdit?: ((edit: import('../fields').NumberTextEdit) => any) | undefined;
            }>, {
                focus: () => void | undefined;
            }, {}, {}, {}, {}> | null;
        }, any>>;
        composite: true;
        group: boolean;
    };
};
export declare function createZxuiDefinitionPolicy(): import('./types').DefinitionPolicy;
