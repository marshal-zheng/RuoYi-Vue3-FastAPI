import { FieldEditState, FieldMessage, NumberTextEdit } from '../fields/types';
import { Json } from '../types';
type __VLS_Props = {
    modelValue?: number | null;
    disabled?: boolean;
    readonly?: boolean;
    min?: number;
    max?: number;
    step?: number;
    precision?: number;
    stepStrictly?: boolean;
    disabledScientific?: boolean;
    controls?: boolean;
    controlsPosition?: string;
    messages?: readonly FieldMessage[];
};
declare const _default: import('vue').DefineComponent<__VLS_Props, {
    focus: () => void | undefined;
    validate: () => boolean;
    captureEdit: () => string;
    restoreEdit(draft: Json): void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    blur: (value: FocusEvent) => any;
    focus: (value: FocusEvent) => any;
    "update:modelValue": (value: number | null) => any;
    "edit-state": (state: FieldEditState) => any;
}, string, import('vue').PublicProps, Readonly<__VLS_Props> & Readonly<{
    onBlur?: ((value: FocusEvent) => any) | undefined;
    onFocus?: ((value: FocusEvent) => any) | undefined;
    "onUpdate:modelValue"?: ((value: number | null) => any) | undefined;
    "onEdit-state"?: ((state: FieldEditState) => any) | undefined;
}>, {
    step: number;
    controls: boolean;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, false, {
    input: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<{
        text: string;
        disabled?: boolean;
        readonly?: boolean;
    }> & Readonly<{
        onEdit?: ((edit: NumberTextEdit) => any) | undefined;
    }>, {
        focus: () => void | undefined;
    }, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
        edit: (edit: NumberTextEdit) => any;
    }, import('vue').PublicProps, {}, false, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<{
        text: string;
        disabled?: boolean;
        readonly?: boolean;
    }> & Readonly<{
        onEdit?: ((edit: NumberTextEdit) => any) | undefined;
    }>, {
        focus: () => void | undefined;
    }, {}, {}, {}, {}> | null;
}, any>;
export default _default;
