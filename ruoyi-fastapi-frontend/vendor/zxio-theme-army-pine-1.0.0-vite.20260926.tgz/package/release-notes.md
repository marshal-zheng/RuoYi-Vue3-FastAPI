# Release notes

## 1.0.0

- Add the Forest Theme v4 package with 162 deterministic variants. The
  package id remains `army-pine`.
- Anchor light chrome to a cool grey-green. Dark canvas keeps the same hue
  family at a readable lightness, with wider body / elevated steps and lifted
  status colors.
- Distinct from `@zxio/theme-defense-green`, which stays the moss skin.
