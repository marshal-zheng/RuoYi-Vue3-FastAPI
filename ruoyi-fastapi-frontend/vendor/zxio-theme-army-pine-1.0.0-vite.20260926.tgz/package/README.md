# @zxio/theme-army-pine

Forest is a cool grey-green Theme v4 package. The package id remains
`army-pine`.

Run `pnpm -C packages/theme-army-pine build` only for an intentional
generated-output refresh. Checks and tests are repository-readonly.
