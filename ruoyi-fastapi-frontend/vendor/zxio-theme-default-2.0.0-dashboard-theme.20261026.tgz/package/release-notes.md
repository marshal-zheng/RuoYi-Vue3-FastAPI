# @zxio/theme-default Release Notes

Version: `1.0.0`

## 2026-10-16 Focus visibility

- Increase the seed focus-ring opacity to keep the normal-contrast canvas
  outline at or above 3:1 in both light and dark mode.
- Regenerate all theme artifacts from source; public names and theme identity
  stay unchanged.

## Affected Components

- `@zxio/zxui@1.0.18`
- `@zxio/drive@1.0.0`
- `@zxio/text-editor@1.0.0`

## Upgrade Impact

- Variable-only theme package; no structure-style payload.
- Compatible with `@zxio/zxui` major `1`.
- Public contract is `./theme.css`, `./manifest.json`, `./typegen`, scoped
  `./variants/*`, Element Plus CSS, and DTCG 2025.10 token exports.
- `theme.manifest.json` records `validatedAgainst.elementPlus = 2.13.0` as the
  current verified Element Plus baseline. This is not an install lock; it only
  records what the theme matrix has actually validated while host peer ranges
  remain broader.
- Legacy `light.css`, `dark.css`, `tokens.light.json`, `tokens.dark.json` exports
  are removed.
- Runtime consumers should load the published static CSS and Manifest v1
  exports; runtime provider behavior remains outside this package.
- `--zx-transition-all` and `--el-transition-all` are removed from the formal
  contract and bridge. Use explicit-property tokens such as
  `--zx-transition-opacity`, `--zx-transition-transform`,
  `--zx-transition-color`, `--zx-transition-border`,
  `--zx-transition-box-shadow`, or `--zx-transition-interactive`.
- High-perception radius tokens now resolve through semantic roles:
  `--zx-border-radius-control`, `--zx-border-radius-container`,
  `--zx-border-radius-popup`, `--zx-border-radius-sheet`,
  `--zx-border-radius-document`, and `--zx-border-radius-tooltip`.
- State color separation and key UI chrome contrast are enforced by
  `pnpm theme:check:design-quality`.

## Theme Mental Model

- business apps switch themes, they do not compose themes
- components add deltas, they do not rebuild global theme structure
- Element Plus consumes the bridge; it is not the theme source of truth
- recommended business entry is `themeId + mode + scope` through `ZxConfigProvider`

## Runtime Protocol

- This package publishes static artifacts only. Runtime attribute ownership,
  system preference handling, SSR bootstrap, and hydration behavior are
  defined by the runtime-provider integration contract.

## Scope Notes

- No external migration guide is published for this version because the
  component library does not yet have public adopters.
- SSR first-paint theme injection, anti-flash handling, and hydration-specific
  theme bootstrap are out of scope for this release.
