import type { Json } from '../types';
/** Durable asset identity. Upload transport and server deletion belong to the host. */
export type FieldAttachment = {
    id: string | number;
    name: string;
    url?: string;
    metadata?: Json;
};
export type FieldUpload = (file: File, context: {
    signal: AbortSignal;
}) => Promise<FieldAttachment>;
/**
 * Reject a FieldUpload with this error to show its message as the user-facing
 * failure reason. Any other rejection shows the generic localized message, so
 * transport details never reach the user.
 */
export declare class FieldUploadError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
/** Matches by name so a second installed copy of this package still matches. */
export declare const isFieldUploadError: (error: unknown) => error is FieldUploadError;
/** Reject File/Response/Date and malformed results before they enter canonical values. */
export declare function attachment(value: unknown): FieldAttachment;
