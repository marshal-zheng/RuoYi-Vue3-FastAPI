import type { FieldControlAttrs, FieldMessage } from '../fields/types';
type __VLS_Props = {
    label: string;
    required?: boolean;
    messages?: readonly FieldMessage[];
};
type __VLS_Slots = {
    default(props: {
        controlProps: FieldControlAttrs;
    }): unknown;
};
declare const __VLS_component: import("vue").DefineComponent<__VLS_Props, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<__VLS_Props> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
