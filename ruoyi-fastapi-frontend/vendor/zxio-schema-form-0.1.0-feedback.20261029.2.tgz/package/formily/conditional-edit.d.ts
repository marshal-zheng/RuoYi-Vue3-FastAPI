import type { PlannedAction } from './conditional-plan';
import type { ISchema } from '@formily/vue';
import type { Json } from '../types';
import type { ConditionalChange, ConditionalEditPolicy, OperationView } from './conditional-types';
interface Ports {
    alive(): boolean;
    capture(): Json;
    currentValues(): Json;
    schema(): ISchema;
    arrayKeys(): readonly {
        path: readonly (string | number)[];
        key: string;
    }[];
    eligibility(): readonly string[];
    available(path: readonly (string | number)[], inserted: boolean): boolean;
    installArrays(rules: readonly import('./conditional-types').ConditionalArrayRule[]): void;
    write(action: PlannedAction, token: object): void;
    verify(token: object, signal: AbortSignal, current: () => boolean): Promise<'valid' | 'invalid' | 'unverified'>;
    recovery(required: boolean): void;
}
/** Session-owned immutable conditions/facts, never a second live form store. */
export declare function createConditionalEdit(ports: Ports): {
    readSnapshot: (options?: import("./conditional-types").SnapshotOptions | undefined) => import("./conditional-types").SnapshotResult;
    prepareEdit: (changes: readonly ConditionalChange[], options: {
        observationRef: string;
    }) => import("./conditional-types").PrepareResult;
    applyPrepared: (candidateRef: string, options?: {
        signal?: AbortSignal;
        credential?: unknown;
    } | undefined) => import("./conditional-types").ApplyResult;
    discardPrepared: (candidateRef: string) => import("./conditional-types").DiscardResult;
    getOperation: (operationRef: string) => import("./conditional-types").OperationResult;
    waitOperation: (operationRef: string, options?: {
        signal?: AbortSignal;
        timeoutMs?: number;
    } | undefined) => Promise<{
        status: "available";
        operation: OperationView;
    } | {
        status: "unavailable";
        reason: string;
    } | {
        status: "timed-out" | "wait-cancelled";
        operationRef: string;
        latest?: OperationView;
    }>;
    changed: (token?: object) => void;
    readonly busy: boolean;
    setConditionalEditPolicy(next: ConditionalEditPolicy | undefined): void;
    refreshRuntime(): void;
    authorityChanged(): void;
    reconciled(): void;
    dispose(): void;
};
export {};
