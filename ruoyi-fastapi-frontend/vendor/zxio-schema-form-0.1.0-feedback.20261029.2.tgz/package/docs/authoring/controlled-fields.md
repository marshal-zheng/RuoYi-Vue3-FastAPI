# 在 DAG 或 Dashboard 中复用受控字段

适用于已有 draft、history、预览、事务或提交策略的配置面板。使用 `@zxio/schema-form/fields` 与必要的根入口 JSON 工具；该路线不加载 Formily。普通业务记录的表单会话见 [CRUD](crud.md)。

## 保留宿主所有权

schema 字段负责输入、解析、消息和焦点；现有宿主继续拥有 canonical draft、raw 状态归属、history、记录身份及所有提交入口。复用字段契约不要求把图编辑器改为 CRUD 会话，也不要求复制一套 Schema 或保存会话。

现有 DAG 适配入口为 `@zxio/x6-devkit-dag/zxui`，使用该包的消费者按其公开文档扩展 `renderField`。其他 Vue Flow / Dashboard 宿主可直接把同一 `/fields` 契约接入已有编辑管线，无需依赖 X6 或该 DAG 适配器；本包不替它新增通用 history/事务框架。

## 组织字段与输入

`ZxField` 提供 label、description、required、messages。把默认 slot 的 `controlProps` 绑定给真实输入或有对应可访问语义的复合控件，而不是外层布局 div。对象/数组组使用 `group`，得到 fieldset/legend 和 aria-labelledby。

`ZxNumberTextInput` / `ZxJsonTextInput` 接收 `text/disabled/readonly`，发出 `edit({ text, badInput })`，暴露 focus。用 `parseNumberText` / `parseJsonText` 解析，结果是 `empty | valid(value) | invalid`。保留用户 raw 文本，只有 valid 才提交 canonical 值；invalid 报告阻断。empty 如何转换由领域定义，JSON 字面量 `null` 是有效的已有值，不等于 empty；解析器不执行表达式。

完整签名和状态分支直接见 [字段类型](../../fields/types.d.ts)；共享 JSON 与 bindings 类型见 [共享类型](../../types.d.ts)。不复制另一套宽松字符串/数字转换规则来替换解析器。

## 接通阻断、资源和错误

自定义控件遵循 [复合字段](composite-fields.md) 的 `FieldMessage`、`FieldControl` 与 `FieldEditState` 语义。每次 `edit-state` 是完整快照，pending 本身不禁止提交，blocking 必须在全部提交路由检查，包括自动保存、切换前应用、快捷键和显式保存。

宿主将字段相对路径映射到自身 draft；raw、messages 与行身份一起移动。宿主切换、重置、删除或替换字段时，退役旧回调与活动；控件取消或废弃异步工作，避免迟到结果写入另一个编辑上下文。DAG 已有适配器负责它的会话和编辑器记录；其他宿主复用自己的等价机制。

组件自己渲染 messages、正确关联 ARIA 并提供 focus，不把未知后代错误丢掉。复用对象/数组控件可参考 [MeasurementRows.vue](../../examples/inspection/MeasurementRows.vue) 和 [ProtocolConfig.vue](../../examples/protocol/ProtocolConfig.vue)，但这些 recipe 的领域状态和 CRUD 的 `arrayKeys` 不是所有宿主都必须照搬的存储模型。

## 运行与验证

步进数字复用 `ZxInputNumber` 的受控 `text` 入口，只在 Schema 适配层处理 raw 解析、会话 blocking 和消息，不再维护独立按钮或步进算法。单纯数字/JSON 文本继续复用 `ZxInput` 的 text/textarea。只读单选和选择器使用原生禁用交互，标签使用自身只读能力。只读/禁用模型拒绝控件反向写入；保存中已发出的合法编辑仍按会话票据处理。

`ZxField` 的展示层复用 `ElFormItem`，不提供 `prop` 或另一份 model/rules；值与校验继续由宿主所有。标签位置与宽度继承 SchemaForm 的展示配置，独立使用时默认顶部标签。间距、提示行高、占位和多行展开使用 ZXUI ThemeHost 已有的全局表单反馈契约（`--zx-form-feedback-lines` / `--zx-form-feedback-space`），不维护 Schema 专属的另一套数值。

字段级反馈只有一个归属：`ZxField` 按控件、帮助、反馈排列，反馈行始终存在并消费全局预留（`--zx-form-feedback-min-block-size` / `--zx-form-feedback-padding`），因此各类字段行高一致，帮助说明紧随所属控件。空占位不加入控件的 `aria-describedby`；多条或换行消息按实际高度展开。独立使用 `/fields` 控件时，宿主把控件 `edit-state` 报告的 blocking 与自己的校验结果合成后传给 `ZxField` 的 `messages`，blocking 优先；`ZxDateInput`、`ZxAttachmentInput` 在语言切换时重新报告 blocking 文案。Formily 绑定已处理这些关系。

宿主提供 Vue、Element Plus、ZXUI；导入 `@zxio/schema-form/style.css`，浮层继续使用现有 ThemeHost `bind(app)` 与 `ZxThemeProvider`。安装的可选适配包可能已包含相应结构样式，遵循其公开入口。

检查同一个无效 raw 能阻止真实宿主的全部提交入口，修正后能恢复提交；检查 reset/切换/移动后的回调和 history 仍由原宿主管理。完整入口依赖边界见 [参考](reference.md)。代码定义的复杂对象与数组不受 JSON 导入 profile 的字段数限制。
