<script setup lang="ts">
import { computed, ref, useAttrs, useId, useTemplateRef, watch } from 'vue'
import { equal } from '@zxio/schema-form'
import {
  ZxJsonTextInput,
  parseJsonText,
  useInputComposition,
} from '@zxio/schema-form/fields'

import type { Json } from '@zxio/schema-form'
import type { FieldEditState, FieldMessage } from '@zxio/schema-form/fields'

defineOptions({ name: 'JsonSettingsField', inheritAttrs: false })
const props = defineProps<{
  modelValue: Json
  disabled?: boolean
  /** Path-scoped messages that point inside the JSON document. */
  messages?: readonly FieldMessage[]
}>()
const emit = defineEmits<{
  (event: 'update:modelValue', value: Json): void
  (event: 'edit-state', state: FieldEditState): void
}>()
const attrs = useAttrs()
const input = useTemplateRef<{ focus(): void }>('input')
const messagesId = `json-settings-${useId()}`
// The parent owns only canonical JSON. Unfinished text never replaces that value.
const rawText = ref(JSON.stringify(props.modelValue, null, 2))
const composition = useInputComposition()
const parsed = computed(() => parseJsonText(rawText.value))
const blocking = computed<FieldMessage[]>(() =>
  !composition.blocked.value && parsed.value.status === 'valid'
    ? []
    : [
        {
          severity: 'error',
          message:
            parsed.value.status === 'empty'
              ? '请输入 JSON；如需空值，请输入 null'
              : '请输入有效的 JSON',
        },
      ]
)
// The field presents raw blocking and field-level feedback; this editor lists
// only messages that address a path inside the document.
const pathMessages = computed(() => props.messages ?? [])
const describedBy = computed(
  () =>
    [attrs['aria-describedby'], pathMessages.value.length ? messagesId : '']
      .filter(Boolean)
      .join(' ') || undefined
)

let editSequence = 0
function report() {
  emit('edit-state', { blocking: blocking.value, editSequence })
}
function edit(text: string) {
  rawText.value = text
  editSequence++
  report()
  if (!composition.blocked.value && parsed.value.status === 'valid')
    emit('update:modelValue', parsed.value.value)
}
function nativeInput(event: Event) {
  composition.observe(event)
  edit((event.target as HTMLTextAreaElement).value)
}
watch(
  () => props.modelValue,
  (value) => {
    if (composition.blocked.value) return
    // Parent echoes and unchanged saves preserve the user's valid formatting.
    if (parsed.value.status === 'valid' && equal(parsed.value.value, value))
      return
    rawText.value = JSON.stringify(value, null, 2)
    report()
  }
)
function validate() {
  report()
  return !composition.blocked.value && parsed.value.status === 'valid'
}
defineExpose({
  focus: () => input.value?.focus(),
  validate,
  captureEdit: () => ({
    text: rawText.value,
    composition: composition.keys.value,
  }),
  restoreEdit(draft: Json) {
    if (
      draft &&
      typeof draft === 'object' &&
      !Array.isArray(draft) &&
      typeof draft.text === 'string'
    ) {
      rawText.value = draft.text
      composition.restore(draft.composition)
      report()
    }
  },
})
</script>

<template>
  <div
    data-json-settings
    @input.capture="nativeInput"
    @compositionstart.capture="nativeInput"
    @compositionend.capture="nativeInput"
  >
    <ZxJsonTextInput
      ref="input"
      v-bind="$attrs"
      :text="rawText"
      :disabled="disabled"
      :validate-event="false"
      :aria-invalid="
        attrs['aria-invalid'] ||
        pathMessages.some((message) => message.severity === 'error') ||
        undefined
      "
      :aria-describedby="describedBy"
      @edit="({ text }) => edit(text)"
    />
    <ul v-if="pathMessages.length" :id="messagesId" role="alert">
      <li
        v-for="(message, index) in pathMessages"
        :key="index"
        :data-severity="message.severity"
      >
        <code>{{ JSON.stringify(message.path) }}</code>
        {{ message.message }}
      </li>
    </ul>
  </div>
</template>
