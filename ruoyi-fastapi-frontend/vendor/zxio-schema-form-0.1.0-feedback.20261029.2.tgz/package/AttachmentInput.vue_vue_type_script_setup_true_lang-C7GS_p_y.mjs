var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { defineComponent, useId, inject, computed, createBlock, openBlock, resolveDynamicComponent, mergeProps, withCtx, createElementBlock, createCommentVNode, createVNode, createTextVNode, toDisplayString, unref, createSlots, createElementVNode, renderSlot, Fragment, renderList, shallowRef, useAttrs, ref, watch, onBeforeUnmount, onMounted, onUpdated, nextTick, withKeys, normalizeStyle, normalizeClass } from "vue";
import { ElFormItem, dayjs, ElTimePicker } from "element-plus";
import { ZxDatePicker } from "@zxio/zxui/date-picker";
import { useRequiredThemePortalBinding, createThemePopperOptions } from "@zxio/zxui/theme-provider";
import { e as equal, r as record, c as copy } from "./index-BiqhT_5-.mjs";
import { ZxUpload } from "@zxio/zxui/upload";
import { ZxButton } from "@zxio/zxui/button";
import { useLocale } from "@zxio/zxui/hooks";
const fieldLayoutKey = Symbol("schema-field-layout");
const _hoisted_1$1 = ["id"];
const _hoisted_2$1 = {
  key: 0,
  "aria-hidden": "true",
  class: "zx-schema-field__required"
};
const _hoisted_3$1 = ["id"];
const _hoisted_4$1 = { class: "zx-schema-field__control" };
const _hoisted_5$1 = ["id"];
const _hoisted_6$1 = ["id"];
const _hoisted_7 = ["data-severity"];
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  ...{ name: "ZxField", inheritAttrs: false },
  __name: "Field",
  props: {
    label: {},
    description: {},
    required: { type: Boolean },
    group: { type: Boolean },
    messages: {}
  },
  setup(__props) {
    const props = __props;
    const id = `zx-field-${useId()}`;
    const layout = inject(fieldLayoutKey, void 0);
    const error = computed(
      () => {
        var _a;
        return (_a = props.messages) == null ? void 0 : _a.find((item) => item.severity === "error");
      }
    );
    const controlProps = computed(() => {
      var _a;
      return {
        id,
        "aria-required": !props.group && props.required || void 0,
        "aria-labelledby": props.label ? `${id}-label` : void 0,
        "aria-invalid": !!error.value || void 0,
        "aria-describedby": [
          props.description ? `${id}-help` : "",
          ((_a = props.messages) == null ? void 0 : _a.length) ? `${id}-messages` : ""
        ].filter(Boolean).join(" ") || void 0
      };
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(resolveDynamicComponent(__props.group ? "fieldset" : "div"), mergeProps(_ctx.$attrs, { class: "zx-schema-field" }), {
        default: withCtx(() => {
          var _a, _b, _c;
          return [
            __props.group ? (openBlock(), createElementBlock("legend", {
              key: 0,
              id: `${id}-label`,
              class: "zx-schema-field__label"
            }, [
              createTextVNode(toDisplayString(__props.label), 1),
              __props.required ? (openBlock(), createElementBlock("span", _hoisted_2$1, " *")) : createCommentVNode("", true)
            ], 8, _hoisted_1$1)) : createCommentVNode("", true),
            createVNode(unref(ElFormItem), {
              label: __props.group ? void 0 : __props.label,
              for: __props.group ? void 0 : id,
              "label-position": __props.group ? "top" : ((_a = unref(layout)) == null ? void 0 : _a.labelPosition) ?? "top",
              "label-width": __props.group ? void 0 : (_b = unref(layout)) == null ? void 0 : _b.labelWidth,
              required: !__props.group && __props.required,
              error: (_c = error.value) == null ? void 0 : _c.message,
              "show-message": false
            }, createSlots({
              default: withCtx(() => [
                createElementVNode("div", _hoisted_4$1, [
                  renderSlot(_ctx.$slots, "default", { controlProps: controlProps.value })
                ]),
                __props.description ? (openBlock(), createElementBlock("small", {
                  key: 0,
                  id: `${id}-help`,
                  class: "zx-schema-field__help"
                }, toDisplayString(__props.description), 9, _hoisted_5$1)) : createCommentVNode("", true),
                createElementVNode("ul", {
                  id: `${id}-messages`,
                  class: "el-form-item__error zx-schema-field__messages",
                  "aria-live": "polite"
                }, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(__props.messages, (item, index) => {
                    return openBlock(), createElementBlock("li", {
                      key: index,
                      "data-severity": item.severity
                    }, toDisplayString(item.message), 9, _hoisted_7);
                  }), 128))
                ], 8, _hoisted_6$1)
              ]),
              _: 2
            }, [
              !__props.group ? {
                name: "label",
                fn: withCtx(() => [
                  createElementVNode("span", {
                    id: `${id}-label`,
                    class: "zx-schema-field__label"
                  }, toDisplayString(__props.label), 9, _hoisted_3$1)
                ]),
                key: "0"
              } : void 0
            ]), 1032, ["label", "for", "label-position", "label-width", "required", "error"])
          ];
        }),
        _: 3
      }, 16);
    };
  }
});
function parseNumberText(text) {
  const value = text.trim();
  if (!value) return { status: "empty" };
  if (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(value))
    return { status: "invalid" };
  const number = Number(value);
  return Number.isFinite(number) ? { status: "valid", value: number } : { status: "invalid" };
}
const messages = {
  en: {
    initializing: "Initializing",
    updated: "The form has changed. Please submit again.",
    reconcileRequired: "Reload the server record to verify the save result.",
    structureUpdated: "The form structure has changed.",
    waitingResources: "Waiting for required resources",
    initializationBlocked: "Initialization does not satisfy the submission constraints.",
    loaded: "Loaded",
    authorityCancelled: "New edits cancelled the authoritative update.",
    baselineRestored: "Saved baseline restored",
    baselineFailed: "Baseline initialization failed.",
    reconciled: "Server record verified",
    validating: "Validating",
    checkErrors: "Please check the form errors.",
    valid: "Validation passed",
    saving: "Saving",
    saveRejected: "Save rejected. Correct the errors and try again.",
    savedReconcile: "Saved. Reload the server record to verify the displayed values.",
    saved: "Saved",
    validationFailed: "Validation failed.",
    updatedOrInvalid: "The form has changed or contains errors. Please submit again.",
    conditionalReconcile: "The host must verify the conditional edit result.",
    bindingReplaced: "Field controls have changed.",
    completeInput: "Please complete the input.",
    completeNumber: "Please enter a complete, valid number.",
    completeDate: "Please enter a complete, valid date or time.",
    dateNotAccepted: "The form did not accept the date value.",
    chooseAttachments: "Choose attachments",
    uploadPending: "Uploading. Please wait or cancel.",
    uploadCancelled: "Upload cancelled. Select the file again or remove it.",
    attachmentLimit: "Select at most {limit} attachments. Remove this selection.",
    uploadReadonly: "The field is read only. Select the file again or remove it.",
    attachmentDuplicate: "Duplicate attachment identifier. Remove this selection.",
    attachmentNotAccepted: "The form did not accept the attachment.",
    uploadFailed: "Upload failed. Select the file again or remove it.",
    fileTooLarge: "The file is too large. Select another file or remove it.",
    fileTypeUnsupported: "Unsupported file type. Select another file or remove it.",
    attachments: "Attachments",
    remove: "Remove",
    removeNamed: "Remove {name}",
    cancelUpload: "Cancel upload",
    cancelUploadNamed: "Cancel upload {name}",
    resourceProjectionFailed: "Resource projection failed.",
    resourceReadFailed: "Resource loading failed.",
    resourcePending: "Please wait for required resources.",
    resourceNotReady: "Required resources are not ready. Please retry.",
    definitionInvalid: "The field value does not match the defined type or range.",
    invalid: "This field is invalid",
    required: "The field value is required",
    pattern: "This field is invalid",
    number: "The field value is not a number",
    integer: "The field value is not an integer",
    whitespace: "This field cannot contain only whitespace.",
    len: "The length or number of entries must be {len}",
    min: "The length or number of entries must be at least {min}",
    max: "The length or number of entries must be at most {max}",
    minLength: "The length or number of entries must be at least {minLength}",
    maxLength: "The length or number of entries must be at most {maxLength}",
    minItems: "The length or number of entries must be at least {minItems}",
    maxItems: "The length or number of entries must be at most {maxItems}",
    maximum: "The field value cannot be greater than {maximum}",
    minimum: "The field value cannot be less than {minimum}",
    exclusiveMaximum: "The field value must be less than {exclusiveMaximum}",
    exclusiveMinimum: "The field value must be greater than {exclusiveMinimum}",
    enum: "The field value must be one of {enum}",
    const: "The field value must be equal to {const}",
    multipleOf: "The field value must be divisible by {multipleOf}",
    maxProperties: "The number of field properties cannot exceed {maxProperties}",
    minProperties: "The number of field properties must be at least {minProperties}",
    uniqueItems: "Array elements must be unique",
    url: "The field value is not a valid URL format",
    email: "The field value is not a valid email format",
    ipv6: "The field value is not a valid IPv6 format",
    ipv4: "The field value is not a valid IPv4 format",
    idcard: "The field value is not a valid ID card format",
    qq: "The field value is not a valid QQ number format",
    phone: "The field value is not a valid phone number format",
    money: "The field value is not a valid currency format",
    zh: "The field value is not a valid Chinese text format",
    date: "The field value is not a valid date format",
    zip: "The field value is not a valid postal code format"
  },
  zh: {
    initializing: "初始化中",
    updated: "表单已更新，请重新提交",
    reconcileRequired: "保存结果需重新载入核对",
    structureUpdated: "表单结构已更新",
    waitingResources: "等待必要资源",
    initializationBlocked: "初始化未满足提交约束",
    loaded: "已载入",
    authorityCancelled: "权威回填已因新编辑取消",
    baselineRestored: "已恢复保存基线",
    baselineFailed: "基线初始化失败",
    reconciled: "已核对服务端记录",
    validating: "校验中",
    checkErrors: "请检查表单中的错误",
    valid: "校验通过",
    saving: "保存中",
    saveRejected: "保存被拒绝，请纠正后重试",
    savedReconcile: "已保存，当前显示需重新载入核对",
    saved: "已保存",
    validationFailed: "校验失败",
    updatedOrInvalid: "表单已更新或包含错误，请重新提交",
    conditionalReconcile: "条件编辑结果需 Host 核对",
    bindingReplaced: "字段控件已替换",
    completeInput: "请完成输入",
    completeNumber: "请输入完整、有效的数字",
    completeDate: "请完成有效的日期/时间输入",
    dateNotAccepted: "日期结果未被表单接受",
    chooseAttachments: "选择附件",
    uploadPending: "上传中，请等待或取消",
    uploadCancelled: "上传已取消，请重新选择或移除",
    attachmentLimit: "最多选择 {limit} 个附件，请移除本次选择",
    uploadReadonly: "字段已只读，请重新选择或移除",
    attachmentDuplicate: "附件标识重复，请移除本次选择",
    attachmentNotAccepted: "附件结果未被表单接受",
    uploadFailed: "上传失败，请重新选择或移除",
    fileTooLarge: "文件过大，请重新选择或移除",
    fileTypeUnsupported: "文件类型不支持，请重新选择或移除",
    attachments: "附件",
    remove: "移除",
    removeNamed: "移除 {name}",
    cancelUpload: "取消上传",
    cancelUploadNamed: "取消上传 {name}",
    resourceProjectionFailed: "资源投影失败",
    resourceReadFailed: "资源读取失败",
    resourcePending: "请等待必要资源完成",
    resourceNotReady: "必要资源未就绪，请重试",
    definitionInvalid: "字段值类型或范围不符合定义",
    invalid: "该字段不是一个合法的字段",
    required: "该字段是必填字段",
    pattern: "该字段不是一个合法的字段",
    number: "该字段不是合法的数字",
    integer: "该字段不是合法的整型数字",
    whitespace: "不能为纯空白字符串",
    len: "长度或条目数必须为{len}",
    min: "长度或条目数不能小于{min}",
    max: "长度或条目数不能大于{max}",
    minLength: "长度或条目数不能小于{minLength}",
    maxLength: "长度或条目数不能大于{maxLength}",
    minItems: "长度或条目数不能小于{minItems}",
    maxItems: "长度或条目数不能大于{maxItems}",
    maximum: "数值不能大于{maximum}",
    minimum: "数值不能小于{minimum}",
    exclusiveMaximum: "数值必须小于{exclusiveMaximum}",
    exclusiveMinimum: "数值必须大于{exclusiveMinimum}",
    enum: "字段值必须为{enum}其中一个",
    const: "字段值必须等于{const}",
    multipleOf: "字段值必须能被{multipleOf}整除",
    maxProperties: "字段属性数量不能大于{maxProperties}",
    minProperties: "字段属性数量不能小于{minProperties}",
    uniqueItems: "数组元素不唯一",
    url: "该字段不是有效的网址格式",
    email: "该字段不是有效的邮箱格式",
    ipv6: "该字段不是有效的IPv6格式",
    ipv4: "该字段不是有效的IPv4格式",
    idcard: "该字段不是有效的身份证格式",
    qq: "该字段不是有效的QQ号格式",
    phone: "该字段不是有效的手机号格式",
    money: "该字段不是有效的货币格式",
    zh: "该字段不是有效的中文字符串格式",
    date: "该字段不是有效的日期格式",
    zip: "该字段不是有效的邮编格式"
  }
};
const interpolate = (message, options) => message.replace(/\{(\w+)\}/g, (_, key) => `${(options == null ? void 0 : options[key]) ?? `{${key}}`}`);
const defaultSchemaLocale = {
  t: (key, options) => interpolate(messages.en[key], options),
  source: () => void 0
};
function useSchemaLocale() {
  const { lang, locale, t: translate } = useLocale();
  const t = (key, options) => {
    const path = `zx.schemaForm.${key}`;
    const translated = translate(path, options);
    if (translated !== path) return translated;
    return interpolate(
      messages[lang.value.toLowerCase().startsWith("zh") ? "zh" : "en"][key],
      options
    );
  };
  return { lang, t, source: () => locale.value };
}
const resolver = Symbol("schema-form-localized-message");
function localizedMessage(value, message) {
  return { ...value, message: message(), [resolver]: message };
}
function resolveMessage(value) {
  const message = value[resolver];
  return message ? { ...value, message: message() } : value;
}
const resolveText = (value) => typeof value === "function" ? value() : value;
const validatorDefaults = /* @__PURE__ */ new WeakMap();
function withValidatorMessage(validator, key) {
  if (key) validatorDefaults.set(validator, key);
  return validator;
}
const validatorMessageKey = (validator) => validator && validatorDefaults.get(validator);
function schemaLocaleKey(value) {
  return Object.hasOwn(messages.en, value) ? value : void 0;
}
function inheritMessageSource(source, target) {
  const message = source[resolver];
  return message ? { ...target, [resolver]: message } : target;
}
function useInputComposition() {
  const pending = shallowRef(/* @__PURE__ */ new Set());
  let active;
  const has = (key = "value") => pending.value.has(key);
  function observe(event, key = "value") {
    const next = new Set(pending.value);
    if (event.type === "compositionstart" || event.type === "input" && event.isComposing === true) {
      active = { key, target: event.target };
      next.add(key);
    } else if (event.type === "compositionend") {
      if ((active == null ? void 0 : active.key) === key && active.target === event.target) {
        active = void 0;
        next.delete(key);
      }
    } else if (event.type === "input" && ((active == null ? void 0 : active.key) !== key || active.target !== event.target)) {
      next.delete(key);
    }
    pending.value = next;
  }
  function acceptChange(key = "value") {
    if ((active == null ? void 0 : active.key) === key || !has(key)) return false;
    const next = new Set(pending.value);
    next.delete(key);
    pending.value = next;
    return true;
  }
  function restore(keys) {
    active = void 0;
    pending.value = new Set(
      Array.isArray(keys) ? keys.filter((key) => typeof key === "string") : []
    );
  }
  function prune(keys) {
    const keep = new Set(keys);
    if (active && !keep.has(active.key)) active = void 0;
    const next = new Set([...pending.value].filter((key) => keep.has(key)));
    if (next.size === pending.value.size) return false;
    pending.value = next;
    return true;
  }
  return {
    blocked: computed(() => pending.value.size > 0),
    keys: computed(() => [...pending.value]),
    has,
    observe,
    acceptChange,
    restore,
    prune
  };
}
const dateDisplayFormat = (type) => type.startsWith("time") ? "HH:mm:ss" : type.startsWith("datetime") ? "YYYY-MM-DD HH:mm:ss" : type.startsWith("month") ? "YYYY-MM" : type.startsWith("year") ? "YYYY" : "YYYY-MM-DD";
const dateIsRange = (type) => type.endsWith("range");
const dateIsMultiple = (type) => ["dates", "months", "years"].includes(type);
function displayDate(value, format, valueFormat, lang) {
  const values = Array.isArray(value) ? value : value == null ? [] : [value];
  return values.map((part) => dayjs(part, valueFormat, lang).format(format));
}
function parseDateText(text, type, format, valueFormat, lang) {
  const range = dateIsRange(type);
  if (text.every((part) => !part.trim()))
    return { valid: true, value: null };
  const parts = dateIsMultiple(type) ? text[0].split(",").map((part) => part.trim()) : [...text];
  if (range && parts.length !== 2 || parts.some((part) => !part))
    return { valid: false };
  const dates = parts.map((part) => dayjs(part, format, lang, true));
  if (dates.some((part) => !part.isValid()) || range && dates[0].isAfter(dates[1]))
    return { valid: false };
  return {
    valid: true,
    value: range || dateIsMultiple(type) ? dates.map((part) => part.format(valueFormat)) : dates[0].format(valueFormat),
    dates
  };
}
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  ...{ inheritAttrs: false },
  __name: "DateInput",
  props: {
    modelValue: { default: null },
    valueFormat: {},
    format: {},
    type: { default: "date" },
    editable: { type: Boolean, default: true },
    disabled: { type: Boolean },
    readonly: { type: Boolean }
  },
  emits: ["update:modelValue", "edit-state", "focus", "blur"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const { lang, t, source } = useSchemaLocale();
    const attrs = useAttrs();
    const root = ref();
    const picker = ref();
    const portal = useRequiredThemePortalBinding();
    const target = computed(
      () => {
        var _a;
        return portal.ok ? (_a = portal.value.binding.value) == null ? void 0 : _a.target : void 0;
      }
    );
    const popperOptions = computed(
      () => createThemePopperOptions(
        attrs.popperOptions
      )
    );
    const composition = useInputComposition();
    const raw = ref();
    const notAccepted = ref(false);
    const confirming = ref(false);
    const displayFormat = computed(
      () => props.format || dateDisplayFormat(props.type)
    );
    const editable = computed(
      () => props.type !== "week" && !dateIsMultiple(props.type) && props.editable !== false
    );
    const locked = computed(() => props.disabled || props.readonly || !target.value);
    const multiple = computed(
      () => dateIsRange(props.type) || dateIsMultiple(props.type)
    );
    function assertValue(value2) {
      if (value2 != null && !(multiple.value ? Array.isArray(value2) && value2.every((part) => typeof part === "string") : typeof value2 === "string"))
        throw new Error(
          "Date fields require formatted JSON strings, arrays or null"
        );
    }
    const value = computed(() => {
      if (!props.valueFormat || ["x", "X"].includes(props.valueFormat))
        throw new Error("Date fields require an explicit string valueFormat");
      assertValue(props.modelValue);
      return props.modelValue ?? null;
    });
    function parse() {
      const result = parseDateText(
        raw.value ?? [],
        props.type,
        displayFormat.value,
        props.valueFormat,
        lang.value
      );
      if (result.valid && result.dates) {
        const disabledDate = attrs.disabledDate ?? attrs["disabled-date"];
        const disabledHours = attrs.disabledHours ?? attrs["disabled-hours"];
        const disabledMinutes = attrs.disabledMinutes ?? attrs["disabled-minutes"];
        const disabledSeconds = attrs.disabledSeconds ?? attrs["disabled-seconds"];
        if (result.dates.some((date, index) => {
          const role = index ? "end" : "start";
          return (disabledDate == null ? void 0 : disabledDate(date.toDate())) || (disabledHours == null ? void 0 : disabledHours(role).includes(date.hour())) || (disabledMinutes == null ? void 0 : disabledMinutes(date.hour(), role).includes(date.minute())) || (disabledSeconds == null ? void 0 : disabledSeconds(date.hour(), date.minute(), role).includes(
            date.second()
          ));
        }))
          return { valid: false };
      }
      return result;
    }
    const blocking = computed(
      () => raw.value && (composition.blocked.value || !parse().valid || notAccepted.value) ? [
        localizedMessage(
          { severity: "error", message: "" },
          () => t(notAccepted.value ? "dateNotAccepted" : "completeDate")
        )
      ] : []
    );
    let editSequence = 0;
    let publication = 0;
    let nativeCommit = false;
    function nativeBoundary(event) {
      if ((event == null ? void 0 : event.type) === "change") event.stopPropagation();
      nativeCommit = true;
      nextTick(() => {
        nativeCommit = false;
        reflect();
      });
    }
    function report() {
      emit("edit-state", {
        editSequence,
        pending: confirming.value,
        commitPending: confirming.value,
        blocking: blocking.value
      });
    }
    watch(source, () => blocking.value.length && report());
    function textFor(next) {
      const parts = displayDate(
        next,
        displayFormat.value,
        props.valueFormat,
        lang.value
      );
      return dateIsRange(props.type) ? [parts[0] ?? "", parts[1] ?? ""] : [dateIsMultiple(props.type) ? parts.join(", ") : parts[0] ?? ""];
    }
    const display = () => textFor(value.value);
    function reflect() {
      var _a;
      (_a = root.value) == null ? void 0 : _a.querySelectorAll("input").forEach((input, index) => {
        var _a2;
        for (const name of [
          "id",
          "aria-label",
          "aria-labelledby",
          "aria-describedby",
          "aria-invalid",
          "aria-required"
        ]) {
          const item = name === "id" && index ? void 0 : attrs[name];
          if (item == null || item === false) input.removeAttribute(name);
          else input.setAttribute(name, String(item));
        }
        if (((_a2 = raw.value) == null ? void 0 : _a2[index]) !== void 0) input.value = raw.value[index];
      });
    }
    onBeforeUnmount(() => {
      publication++;
    });
    onMounted(reflect);
    onUpdated(() => nextTick(reflect));
    async function publish(next) {
      const current = ++publication;
      confirming.value = true;
      report();
      if (current !== publication || !raw.value) return;
      emit("update:modelValue", next);
      await nextTick();
      if (current !== publication || !raw.value) return;
      confirming.value = false;
      notAccepted.value = !equal(value.value, next);
      if (!notAccepted.value) raw.value = void 0;
      report();
      reflect();
    }
    function nativeEdit(event) {
      var _a;
      const input = event.target;
      const inputs = [...((_a = root.value) == null ? void 0 : _a.querySelectorAll("input")) ?? []];
      const index = inputs.indexOf(input);
      if (index < 0 || !editable.value || locked.value) return;
      event.stopPropagation();
      publication++;
      confirming.value = false;
      raw.value = raw.value ? [...raw.value] : display();
      raw.value[index] = input.value;
      composition.observe(event, String(index));
      notAccepted.value = false;
      editSequence++;
      const parsed = parse();
      if (!composition.blocked.value && parsed.valid) publish(parsed.value);
      else report();
    }
    function update(next) {
      if (locked.value || composition.blocked.value) return;
      const normalized = next === "" || next === void 0 || Array.isArray(next) && !next.length ? null : next;
      assertValue(normalized);
      if (raw.value && (!parse().valid || composition.blocked.value) && nativeCommit) {
        nextTick(reflect);
        return;
      }
      raw.value = textFor(normalized);
      notAccepted.value = false;
      editSequence++;
      publish(normalized);
    }
    function clear() {
      if (locked.value) return;
      raw.value = textFor(null);
      composition.restore([]);
      notAccepted.value = false;
      editSequence++;
      publish(null);
    }
    const controlAttrs = computed(
      () => Object.fromEntries(
        Object.entries(attrs).filter(
          ([key]) => key !== "id" && !key.startsWith("aria-")
        )
      )
    );
    function boundary(event, type) {
      var _a;
      if (!((_a = root.value) == null ? void 0 : _a.contains(event.relatedTarget)))
        emit(type, event);
      if (type === "blur") nextTick(reflect);
    }
    watch(
      () => props.modelValue,
      () => {
        if (!raw.value) return;
        const parsed = parse();
        if (parsed.valid && equal(parsed.value, props.modelValue)) {
          notAccepted.value = false;
          report();
          return;
        }
        publication++;
        confirming.value = false;
        raw.value = void 0;
        composition.restore([]);
        notAccepted.value = false;
        report();
      }
    );
    watch(
      () => [props.type, props.valueFormat, props.format],
      () => {
        publication++;
        confirming.value = false;
        raw.value = void 0;
        composition.restore([]);
        notAccepted.value = false;
        report();
      }
    );
    watch(lang, () => {
      report();
      nextTick(reflect);
    });
    watch(target, (next) => {
      var _a;
      if (!next) (_a = picker.value) == null ? void 0 : _a.handleClose();
    });
    __expose({
      focus: () => {
        var _a;
        return (_a = picker.value) == null ? void 0 : _a.focus();
      },
      validate: () => {
        report();
        return !confirming.value && !blocking.value.length;
      },
      captureEdit() {
        publication++;
        confirming.value = false;
        const parsed = parse();
        if (raw.value && parsed.valid && !equal(parsed.value, value.value))
          notAccepted.value = true;
        report();
        return raw.value ? {
          text: raw.value,
          composition: composition.keys.value,
          notAccepted: notAccepted.value
        } : null;
      },
      restoreEdit(draft) {
        if (!record(draft) || !Array.isArray(draft.text) || !draft.text.every((part) => typeof part === "string"))
          return;
        raw.value = [...draft.text];
        composition.restore(draft.composition);
        const parsed = parse();
        notAccepted.value = parsed.valid && !equal(parsed.value, value.value);
        report();
        nextTick(reflect);
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "root",
        ref: root,
        class: "schema-form__date-field",
        onChangeCapture: nativeBoundary,
        onKeydownCapture: withKeys(nativeBoundary, ["enter"]),
        onFocusoutCapture: nativeBoundary,
        onInputCapture: nativeEdit,
        onCompositionstartCapture: nativeEdit,
        onCompositionendCapture: nativeEdit,
        onFocusin: _cache[0] || (_cache[0] = ($event) => boundary($event, "focus")),
        onFocusout: _cache[1] || (_cache[1] = ($event) => boundary($event, "blur"))
      }, [
        (openBlock(), createBlock(resolveDynamicComponent(__props.type.startsWith("time") ? unref(ElTimePicker) : unref(ZxDatePicker)), mergeProps({
          ref_key: "picker",
          ref: picker
        }, controlAttrs.value, {
          "model-value": value.value,
          type: __props.type,
          "is-range": __props.type === "timerange",
          "value-format": __props.valueFormat,
          format: displayFormat.value,
          disabled: locked.value,
          readonly: __props.readonly,
          editable: editable.value,
          "validate-event": false,
          "value-on-clear": null,
          "append-to": target.value,
          teleported: true,
          "popper-options": popperOptions.value,
          "onUpdate:modelValue": update,
          onClear: clear
        }), null, 16, ["model-value", "type", "is-range", "value-format", "format", "disabled", "readonly", "editable", "append-to", "popper-options"]))
      ], 544);
    };
  }
});
class FieldUploadError extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "FieldUploadError";
  }
}
const isFieldUploadError = (error) => error instanceof Error && error.name === "FieldUploadError" && error.message.length > 0;
function attachment(value) {
  const result = copy(value);
  if (!record(result) || !(typeof result.id === "string" && result.id.length > 0 || typeof result.id === "number" && Number.isFinite(result.id)) || typeof result.name !== "string" || !result.name || result.url !== void 0 && typeof result.url !== "string" || Object.keys(result).some(
    (key) => !["id", "name", "url", "metadata"].includes(key)
  ))
    throw new Error("Expected a JSON attachment with id and name");
  return result;
}
const _hoisted_1 = ["aria-label"];
const _hoisted_2 = ["id"];
const _hoisted_3 = ["data-severity"];
const _hoisted_4 = ["aria-busy"];
const _hoisted_5 = {
  key: 0,
  class: "zx-schema-field__messages zx-schema-attachments__messages",
  role: "alert"
};
const _hoisted_6 = ["data-severity"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  ...{ inheritAttrs: false },
  __name: "AttachmentInput",
  props: {
    modelValue: { default: () => [] },
    upload: {},
    disabled: { type: Boolean },
    readonly: { type: Boolean },
    multiple: { type: Boolean, default: true },
    accept: {},
    maxSize: {},
    limit: {},
    buttonText: {},
    messages: {}
  },
  emits: ["update:modelValue", "edit-state", "focus", "blur"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    class TransferRejectionError extends Error {
      constructor(key2) {
        super(key2);
        __publicField(this, "key");
        this.name = "TransferRejectionError";
        this.key = key2;
      }
    }
    const { t, source } = useSchemaLocale();
    const root = ref();
    const uploader = ref();
    const selected = ref([]);
    const transfers = shallowRef([]);
    const committed = shallowRef(props.modelValue.map(attachment));
    const messagePrefix = `schema-attachments-${useId()}`;
    const seen = /* @__PURE__ */ new WeakSet();
    let sequence = 0;
    let key = 0;
    let alive = true;
    let publication = 0;
    const locked = computed(() => props.disabled || props.readonly);
    const blocking = computed(
      () => transfers.value.map(
        (item) => localizedMessage(
          { severity: "error", message: "" },
          () => `${item.name}: ${item.reason ?? t(
            item.controller ? "uploadPending" : item.error ?? "uploadCancelled",
            { limit: props.limit ?? 0 }
          )}`
        )
      )
    );
    const messagesFor = (index) => (props.messages ?? []).filter((message) => {
      var _a;
      return ((_a = message.path) == null ? void 0 : _a[0]) === index;
    });
    const unplaced = computed(
      () => (props.messages ?? []).filter((message) => {
        var _a;
        const index = (_a = message.path) == null ? void 0 : _a[0];
        return typeof index !== "number" || !committed.value[index];
      })
    );
    function associateTrigger() {
      var _a, _b;
      const trigger = (_b = (_a = root.value) == null ? void 0 : _a.querySelector('input[type="file"]')) == null ? void 0 : _b.parentElement;
      if (trigger) {
        trigger.setAttribute("role", "presentation");
        trigger.setAttribute("tabindex", "-1");
      }
    }
    onMounted(associateTrigger);
    onUpdated(associateTrigger);
    function report() {
      emit("edit-state", {
        editSequence: sequence,
        pending: transfers.value.some((item) => !!item.controller),
        blocking: blocking.value
      });
    }
    watch(source, () => blocking.value.length && report());
    function edited() {
      sequence++;
      report();
    }
    function publish(value) {
      const current = ++publication;
      committed.value = value.map(attachment);
      emit("update:modelValue", committed.value.map(attachment));
      nextTick(() => {
        if (alive && publication === current && !equal(props.modelValue, committed.value))
          committed.value = props.modelValue.map(attachment);
      });
    }
    function retire(retain) {
      const previous = transfers.value;
      transfers.value = retain ? previous.map((item) => ({
        key: item.key,
        name: item.name,
        error: item.error ?? "uploadCancelled",
        ...item.reason ? { reason: item.reason } : {}
      })) : [];
      previous.forEach((item) => {
        var _a;
        return (_a = item.controller) == null ? void 0 : _a.abort();
      });
      report();
    }
    function fail(name, reason) {
      transfers.value = [...transfers.value, { key: ++key, name, error: reason }];
      edited();
    }
    function start(file) {
      if (locked.value || !alive || seen.has(file)) return;
      seen.add(file);
      if (props.limit !== void 0 && committed.value.length + transfers.value.length >= props.limit) {
        fail(file.name, "attachmentLimit");
        return;
      }
      const controller = new AbortController();
      const transfer = { key: ++key, name: file.name, controller };
      transfers.value = [...transfers.value, transfer];
      edited();
      const active = () => alive && transfers.value.includes(transfer) && !controller.signal.aborted;
      Promise.resolve().then(() => {
        if (!active()) return void 0;
        return props.upload(file, { signal: controller.signal });
      }).then(async (result) => {
        if (!active()) return;
        const asset = attachment(result);
        if (locked.value) throw new TransferRejectionError("uploadReadonly");
        if (committed.value.some((item) => item.id === asset.id))
          throw new TransferRejectionError("attachmentDuplicate");
        publish([...committed.value, asset]);
        await nextTick();
        if (!active()) return;
        if (!props.modelValue.some((item) => equal(item, asset)))
          throw new TransferRejectionError("attachmentNotAccepted");
        transfers.value = transfers.value.filter((item) => item !== transfer);
        report();
      }).catch((error) => {
        if (!active()) return;
        const failure = error instanceof TransferRejectionError ? { error: error.key } : isFieldUploadError(error) ? { error: "uploadFailed", reason: error.message } : { error: "uploadFailed" };
        transfers.value = transfers.value.map(
          (item) => item === transfer ? { key: item.key, name: item.name, ...failure } : item
        );
        report();
      });
    }
    function select(files) {
      for (const file of files) if (file.raw) start(file.raw);
      nextTick(() => {
        var _a;
        selected.value = [];
        (_a = uploader.value) == null ? void 0 : _a.clearFiles();
      });
    }
    function removeTransfer(item) {
      var _a;
      if (locked.value) return;
      transfers.value = transfers.value.filter((candidate) => candidate !== item);
      (_a = item.controller) == null ? void 0 : _a.abort();
      edited();
    }
    function removeAsset(index) {
      if (locked.value) return;
      edited();
      publish(committed.value.filter((_, position) => position !== index));
    }
    watch(
      () => props.modelValue,
      (value) => {
        const next = value.map(attachment);
        if (equal(next, committed.value)) return;
        retire(false);
        committed.value = next;
      }
    );
    onBeforeUnmount(() => {
      alive = false;
      retire(false);
    });
    function boundary(event, type) {
      var _a;
      if (!((_a = root.value) == null ? void 0 : _a.contains(event.relatedTarget)))
        emit(type, event);
    }
    __expose({
      focus: () => {
        var _a, _b;
        return (_b = (_a = root.value) == null ? void 0 : _a.querySelector("button")) == null ? void 0 : _b.focus();
      },
      validate: () => {
        report();
        return !blocking.value.length;
      },
      captureEdit() {
        retire(true);
        return transfers.value.map((item) => ({
          name: item.name,
          error: item.error ?? "uploadCancelled",
          ...item.reason ? { reason: item.reason } : {}
        }));
      },
      restoreEdit(draft) {
        if (!Array.isArray(draft)) return;
        transfers.value = draft.filter(
          (item) => record(item) && typeof item.name === "string" && typeof item.error === "string"
        ).map((item) => {
          const { name, error, reason } = item;
          return {
            key: ++key,
            name,
            error,
            ...typeof reason === "string" && reason ? { reason } : {}
          };
        });
        report();
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "root",
        ref: root,
        class: normalizeClass([_ctx.$attrs.class, "zx-schema-attachments"]),
        style: normalizeStyle(_ctx.$attrs.style),
        onFocusin: _cache[2] || (_cache[2] = ($event) => boundary($event, "focus")),
        onFocusout: _cache[3] || (_cache[3] = ($event) => boundary($event, "blur"))
      }, [
        createVNode(unref(ZxUpload), {
          ref_key: "uploader",
          ref: uploader,
          modelValue: selected.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selected.value = $event),
          disabled: locked.value,
          multiple: __props.multiple,
          accept: __props.accept,
          "max-size": __props.maxSize,
          "auto-upload": false,
          "show-file-list": false,
          "show-tip": false,
          "allow-preview": false,
          "allow-download": false,
          "allow-remove": false,
          onChange: select,
          onReject: _cache[1] || (_cache[1] = ({ file, reason }) => !locked.value && fail(
            file.name,
            reason === "size" ? "fileTooLarge" : "fileTypeUnsupported"
          ))
        }, {
          default: withCtx(() => [
            createVNode(unref(ZxButton), {
              id: _ctx.$attrs.id,
              "native-type": "button",
              "enable-loading": false,
              disabled: locked.value,
              "aria-label": _ctx.$attrs["aria-label"],
              "aria-labelledby": _ctx.$attrs["aria-labelledby"],
              "aria-required": _ctx.$attrs["aria-required"],
              "aria-describedby": _ctx.$attrs["aria-describedby"],
              "aria-invalid": _ctx.$attrs["aria-invalid"]
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(__props.buttonText ?? unref(t)("chooseAttachments")), 1)
              ]),
              _: 1
            }, 8, ["id", "disabled", "aria-label", "aria-labelledby", "aria-required", "aria-describedby", "aria-invalid"])
          ]),
          _: 1
        }, 8, ["modelValue", "disabled", "multiple", "accept", "max-size"]),
        createElementVNode("ul", {
          class: "zx-schema-attachments__list",
          "aria-label": unref(t)("attachments")
        }, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(committed.value, (asset, index) => {
            return openBlock(), createElementBlock("li", {
              key: asset.id
            }, [
              createElementVNode("span", null, toDisplayString(asset.name), 1),
              createVNode(unref(ZxButton), {
                "native-type": "button",
                "enable-loading": false,
                disabled: locked.value,
                "aria-label": unref(t)("removeNamed", { name: asset.name }),
                "aria-describedby": messagesFor(index).length ? `${messagePrefix}-${index}` : void 0,
                onClick: ($event) => removeAsset(index)
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(t)("remove")), 1)
                ]),
                _: 1
              }, 8, ["disabled", "aria-label", "aria-describedby", "onClick"]),
              messagesFor(index).length ? (openBlock(), createElementBlock("ul", {
                key: 0,
                id: `${messagePrefix}-${index}`,
                class: "zx-schema-field__messages zx-schema-attachments__messages"
              }, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(messagesFor(index), (message, position) => {
                  return openBlock(), createElementBlock("li", {
                    key: position,
                    "data-severity": message.severity
                  }, toDisplayString(message.message), 9, _hoisted_3);
                }), 128))
              ], 8, _hoisted_2)) : createCommentVNode("", true)
            ]);
          }), 128)),
          (openBlock(true), createElementBlock(Fragment, null, renderList(transfers.value, (item) => {
            return openBlock(), createElementBlock("li", {
              key: `transfer-${item.key}`,
              "aria-busy": !!item.controller
            }, [
              createElementVNode("span", null, toDisplayString(item.name), 1),
              createVNode(unref(ZxButton), {
                "native-type": "button",
                "enable-loading": false,
                disabled: locked.value,
                "aria-label": unref(t)(item.controller ? "cancelUploadNamed" : "removeNamed", {
                  name: item.name
                }),
                onClick: ($event) => removeTransfer(item)
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(unref(t)(item.controller ? "cancelUpload" : "remove")), 1)
                ]),
                _: 2
              }, 1032, ["disabled", "aria-label", "onClick"])
            ], 8, _hoisted_4);
          }), 128))
        ], 8, _hoisted_1),
        unplaced.value.length ? (openBlock(), createElementBlock("ul", _hoisted_5, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(unplaced.value, (message, index) => {
            return openBlock(), createElementBlock("li", {
              key: index,
              "data-severity": message.severity
            }, toDisplayString(message.message), 9, _hoisted_6);
          }), 128))
        ])) : createCommentVNode("", true)
      ], 38);
    };
  }
});
export {
  FieldUploadError as F,
  _sfc_main$2 as _,
  _sfc_main$1 as a,
  _sfc_main as b,
  useSchemaLocale as c,
  defaultSchemaLocale as d,
  resolveText as e,
  fieldLayoutKey as f,
  inheritMessageSource as i,
  localizedMessage as l,
  parseNumberText as p,
  resolveMessage as r,
  schemaLocaleKey as s,
  useInputComposition as u,
  validatorMessageKey as v,
  withValidatorMessage as w
};
