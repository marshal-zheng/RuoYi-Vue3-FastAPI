declare module 'vue' {
  // GlobalComponents for Volar
  export interface GlobalComponents {
    ZxButton: typeof import('@zxio/zxui')['ZxButton']
    ZxButtonGroup: typeof import('@zxio/zxui')['ZxButtonGroup']
    ZxTooltipOrPopover: typeof import('@zxio/zxui')['ZxTooltipOrPopover']
    ZxEmpty: typeof import('@zxio/zxui')['ZxEmpty']
    ZxInput: typeof import('@zxio/zxui')['ZxInput']
    ZxInputNumber: typeof import('@zxio/zxui')['ZxInputNumber']
    ZxDatePicker: typeof import('@zxio/zxui')['ZxDatePicker']
    ZxIcon: typeof import('@zxio/zxui')['ZxIcon']
    ZxSearch: typeof import('@zxio/zxui')['ZxSearch']
    ZxTag: typeof import('@zxio/zxui')['ZxTag']
    ZxTagsInput: typeof import('@zxio/zxui')['ZxTagsInput']
    ZxList: typeof import('@zxio/zxui')['ZxList']
    ZxListView: typeof import('@zxio/zxui')['ZxListView']
    ZxTabs: typeof import('@zxio/zxui')['ZxTabs']
    ZxConfirmInput: typeof import('@zxio/zxui')['ZxConfirmInput']
    ZxFloatingPanel: typeof import('@zxio/zxui')['ZxFloatingPanel']
    ZxFlexView: typeof import('@zxio/zxui')['ZxFlexView']
    ZxPageLayout: typeof import('@zxio/zxui')['ZxPageLayout']
    ZxMoreAction: typeof import('@zxio/zxui')['ZxMoreAction']
    ZxSplitBox: typeof import('@zxio/zxui')['ZxSplitBox']
    ZxTimeline: typeof import('@zxio/zxui')['ZxTimeline']
    ZxTimelineDivider: typeof import('@zxio/zxui')['ZxTimelineDivider']
    ZxTimelineItem: typeof import('@zxio/zxui')['ZxTimelineItem']
    ZxSparkline: typeof import('@zxio/zxui')['ZxSparkline']
    ZxProgressLinear: typeof import('@zxio/zxui')['ZxProgressLinear']
    ZxIconSelect: typeof import('@zxio/zxui')['ZxIconSelect']
    ZxTextEditor: typeof import('@zxio/text-editor')['ZxTextEditor']
    ZxTextEditorMenu: typeof import('@zxio/text-editor')['ZxTextEditorMenu']
    ZxTextEditorFixedMenu: typeof import('@zxio/text-editor')['ZxTextEditorFixedMenu']
    ZxTextEditorBubbleMenu: typeof import('@zxio/text-editor')['ZxTextEditorBubbleMenu']
    ZxTextEditorFloatingMenu: typeof import('@zxio/text-editor')['ZxTextEditorFloatingMenu']
  }

  interface ComponentCustomProperties {
    $message: typeof import('element-plus')['ElMessage']
    $notify: typeof import('element-plus')['ElNotification']
    $msgbox: typeof import('element-plus')['ElMessageBox']
    $messageBox: typeof import('element-plus')['ElMessageBox']
    $alert: typeof import('element-plus')['ElMessageBox']['alert']
    $confirm: typeof import('element-plus')['ElMessageBox']['confirm']
    $prompt: typeof import('element-plus')['ElMessageBox']['prompt']
    $loading: typeof import('element-plus')['ElLoadingService']
  }
}

export {}
