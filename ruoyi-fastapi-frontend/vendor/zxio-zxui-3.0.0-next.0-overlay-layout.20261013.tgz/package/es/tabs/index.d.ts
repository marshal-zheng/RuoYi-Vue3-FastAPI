export { default } from '../components/tabs/index';
export * from '../components/tabs/index';
