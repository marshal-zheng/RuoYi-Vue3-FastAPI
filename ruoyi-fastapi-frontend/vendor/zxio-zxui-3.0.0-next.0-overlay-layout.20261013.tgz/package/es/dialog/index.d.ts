export { default } from '../components/dialog/index';
export * from '../components/dialog/index';
