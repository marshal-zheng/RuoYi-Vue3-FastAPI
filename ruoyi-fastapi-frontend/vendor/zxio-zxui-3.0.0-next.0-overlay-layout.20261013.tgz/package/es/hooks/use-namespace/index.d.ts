export { defaultNamespace, namespaceContextKey, useGetDerivedNamespace, useNamespace, type UseNamespaceReturn, } from '@zxio/shared';
