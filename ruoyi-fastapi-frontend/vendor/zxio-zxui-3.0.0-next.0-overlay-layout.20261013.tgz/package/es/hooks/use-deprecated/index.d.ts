import { Ref } from 'vue';
type DeprecationParam = {
    from: string;
    replacement: string;
    scope: string;
    version: string;
    ref: string;
    type?: 'API' | 'Attribute' | 'Event' | 'Slot';
};
type MaybeRef<T> = Ref<T> | T;
export declare const useDeprecated: ({ from, replacement, scope, version, ref, type }: DeprecationParam, condition: MaybeRef<boolean>) => void;
export {};
