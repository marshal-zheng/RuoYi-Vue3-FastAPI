import type { InjectionKey, Ref } from 'vue';
import type { ComponentSize } from '@zxio/types';
export declare const useSizeProp: {
    readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
    readonly required: false;
    readonly validator: ((val: unknown) => boolean) | undefined;
    __epPropKey: true;
};
export declare const useSizeProps: {
    size: {
        readonly type: import("vue").PropType<import("@zxio/shared").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
};
export interface SizeContext {
    size: Ref<ComponentSize>;
}
export declare const SIZE_INJECTION_KEY: InjectionKey<SizeContext>;
export declare const useGlobalSize: () => import("vue").ComputedRef<ComponentSize>;
