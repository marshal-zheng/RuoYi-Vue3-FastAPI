import type { InjectionKey } from 'vue';
export type NavigationDirection = 'up' | 'down' | 'left' | 'right';
export type NavigationAction = NavigationDirection | 'activate' | 'back';
export interface DirectionalItem {
    readonly id: string;
    readonly element: () => HTMLElement | null;
    readonly disabled?: () => boolean;
    /** Virtual consumers resolve their stable item before focus; honor cancellation. */
    readonly ensureVisible?: (signal: AbortSignal) => void | Promise<void>;
    readonly activate?: () => void | Promise<void>;
}
export interface DirectionalGroup {
    readonly id: string;
    readonly root: HTMLElement;
    readonly items: () => readonly DirectionalItem[];
    readonly orientation?: 'horizontal' | 'vertical' | 'grid';
    readonly columns?: number;
    readonly links?: Partial<Record<NavigationDirection, string>>;
    readonly back?: () => void | Promise<void>;
    /** Explicit widget adapter: true yields keys to the widget, false delegates to this group. */
    readonly nativeKeys?: (event: KeyboardEvent) => boolean;
}
export interface DirectionalLayer {
    readonly id: string;
    readonly groups: readonly string[];
    /** Includes explicitly registered child regions inside this owned modal root. */
    readonly root?: HTMLElement;
    /** Opening owner can preserve focus before children mount or autofocus. */
    readonly returnFocus?: HTMLElement | null;
    /** Route/dialog owner performs its ordinary guarded close. False keeps the layer. */
    readonly back: () => boolean | void | Promise<boolean | void>;
}
/** Explicit group graph; never scans the application for spatial neighbours. */
export declare function createDirectionalNavigation(options?: {
    readonly enabled?: boolean;
    readonly keys?: Readonly<Record<string, NavigationAction>>;
}): {
    enabled: Readonly<import("vue").Ref<boolean, boolean>>;
    /** Widget adapters can yield caret/selection keys after native input admission. */
    isEditing(element: HTMLElement): boolean;
    setEnabled(value: boolean): void;
    focus: (groupId: string, itemId?: string) => Promise<boolean>;
    register(group: DirectionalGroup): () => void;
    pushLayer(layer: DirectionalLayer): () => void;
    dispose(): void;
};
export type DirectionalNavigation = ReturnType<typeof createDirectionalNavigation>;
export declare const directionalNavigationKey: InjectionKey<DirectionalNavigation>;
export declare function useDirectionalNavigation(): {
    enabled: Readonly<import("vue").Ref<boolean, boolean>>;
    /** Widget adapters can yield caret/selection keys after native input admission. */
    isEditing(element: HTMLElement): boolean;
    setEnabled(value: boolean): void;
    focus: (groupId: string, itemId?: string) => Promise<boolean>;
    register(group: DirectionalGroup): () => void;
    pushLayer(layer: DirectionalLayer): () => void;
    dispose(): void;
} | null;
/** Register a deliberately bounded UI region, using stable DOM identities for
 * ordinary controls. Virtual collections should supply explicit data ids. */
export declare function useDirectionalRegion(options: {
    readonly id: string;
    readonly root: () => HTMLElement | null;
    readonly active?: () => boolean;
    readonly orientation?: DirectionalGroup['orientation'];
    readonly columns?: DirectionalGroup['columns'];
    readonly links?: DirectionalGroup['links'];
    readonly back?: () => void | Promise<void>;
    readonly modal?: boolean | (() => boolean);
    readonly items?: () => readonly DirectionalItem[];
    readonly nativeKeys?: DirectionalGroup['nativeKeys'];
}): {
    enabled: Readonly<import("vue").Ref<boolean, boolean>>;
    /** Widget adapters can yield caret/selection keys after native input admission. */
    isEditing(element: HTMLElement): boolean;
    setEnabled(value: boolean): void;
    focus: (groupId: string, itemId?: string) => Promise<boolean>;
    register(group: DirectionalGroup): () => void;
    pushLayer(layer: DirectionalLayer): () => void;
    dispose(): void;
} | null;
