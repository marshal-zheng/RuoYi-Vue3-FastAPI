import { type ComputedRef, type MaybeRef, type Ref } from 'vue';
export interface Position {
    x: number;
    y: number;
}
export interface Bounds {
    left?: number;
    right?: number;
    top?: number;
    bottom?: number;
}
export type BoundsResolver = Bounds | 'parent' | 'window' | ((element: HTMLElement) => Bounds) | null;
export interface DraggableOptions {
    /** 目标元素 */
    target?: MaybeRef<HTMLElement | null>;
    /** 拖拽手柄 (可选，默认整个元素可拖拽) */
    handle?: MaybeRef<HTMLElement | null>;
    /** 拖拽前置判断 */
    shouldStart?: (event: MouseEvent | TouchEvent) => boolean;
    /** 拖拽阈值，默认 3px */
    threshold?: number;
    /** 是否禁用 */
    disabled?: MaybeRef<boolean>;
    /** 是否阻止默认行为，默认 true */
    preventDefault?: boolean;
    /** 是否阻止冒泡，默认 false */
    stopPropagation?: boolean;
    /** 边界约束 */
    bounds?: MaybeRef<BoundsResolver>;
    /** 初始位置 */
    initialPosition?: Position;
    /** 轴向约束 */
    axis?: 'x' | 'y' | 'both';
    /** 生命周期回调 */
    onDragStart?: (position: Position, event: MouseEvent | TouchEvent) => void | false;
    onDrag?: (position: Position, event: MouseEvent | TouchEvent) => void;
    onDragEnd?: (position: Position, event: MouseEvent | TouchEvent) => void;
}
export interface UseDraggableReturn {
    /** 是否正在拖拽 */
    isDragging: Ref<boolean>;
    /** 当前位置 */
    position: Ref<Position>;
    /** 拖拽增量 */
    delta: Ref<Position>;
    /** mousedown 事件处理器 */
    onMousedown: (e: MouseEvent) => void;
    /** touchstart 事件处理器 */
    onTouchstart: (e: TouchEvent) => void;
    /** 设置位置 */
    setPosition: (x: number, y: number) => void;
    /** 重置位置 */
    resetPosition: () => void;
    /** 样式绑定 */
    style: ComputedRef<{
        transform: string;
        cursor: string;
    }>;
}
export declare function useDraggable(options?: DraggableOptions): UseDraggableReturn;
