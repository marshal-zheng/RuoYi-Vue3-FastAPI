import type { Ref } from 'vue';
export interface ContainerFitOptions {
    /** Content threshold, measured with the container's inherited fonts and CSS variables. */
    readonly minWidth: string;
    /** Extra space required to leave compact mode. Defaults to 2em. */
    readonly exitMargin?: string;
}
/** True means the container needs a compact layout. Does not resize the target. */
export declare function useContainerFit(target: Readonly<Ref<HTMLElement | null | undefined>>, options: ContainerFitOptions): Readonly<Ref<boolean, boolean>>;
