export type TranslatePair = {
    [key: string]: string | readonly string[] | TranslatePair;
};
export interface ElementPlusLocale {
    name: string;
    el: TranslatePair;
}
declare const English: {
    readonly name: "en";
    readonly el: {
        readonly button: {
            readonly loading: "Loading...";
        };
        readonly form: {
            readonly required: "This field is required";
        };
    };
};
export default English;
export type Language = Partial<ElementPlusLocale> & Record<string, unknown>;
