export { default } from '../components/empty/index';
export * from '../components/empty/index';
