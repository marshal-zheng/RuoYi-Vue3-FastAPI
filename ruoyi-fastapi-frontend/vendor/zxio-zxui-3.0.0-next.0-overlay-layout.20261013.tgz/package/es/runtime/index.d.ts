export { buildProps, definePropType, withInstall, type SFCWithInstall, } from '@zxio/shared';
