export { ZxPageLayout, default } from '../components/page-layout/index';
export type { PageLayoutProps, ZxPageLayoutInstance, } from '../components/page-layout/index';
