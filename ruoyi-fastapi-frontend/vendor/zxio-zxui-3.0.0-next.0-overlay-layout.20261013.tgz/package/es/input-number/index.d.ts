export { default } from '../components/input-number/index';
export * from '../components/input-number/index';
