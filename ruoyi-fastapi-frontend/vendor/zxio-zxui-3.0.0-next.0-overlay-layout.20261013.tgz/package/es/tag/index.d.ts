export { default } from '../components/tag/index';
export * from '../components/tag/index';
