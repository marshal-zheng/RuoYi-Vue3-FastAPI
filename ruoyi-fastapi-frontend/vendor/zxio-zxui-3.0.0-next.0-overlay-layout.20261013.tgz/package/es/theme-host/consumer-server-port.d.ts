import type { ThemeConsumerAbi } from '@zxio/theme-consumer';
import type { ThemeConsumerFactory } from '../components/theme-provider/src/context';
import type { SsrThemeRuntime } from '../theme-runtime/ssr';
export declare const serverConsumerAbi: ThemeConsumerAbi;
export declare function createServerConsumerFactory(runtime: SsrThemeRuntime, destination?: (input: {
    scopeKey: string;
    parentDestinationKey?: string;
}) => string): ThemeConsumerFactory;
