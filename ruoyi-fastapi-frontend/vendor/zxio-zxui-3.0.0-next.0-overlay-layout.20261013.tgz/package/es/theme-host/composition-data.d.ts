/** Key order is not part of a user's theme configuration. */
export declare function compositionJson(value: unknown): string;
export declare function compositionRecord(value: unknown): value is Record<string, unknown>;
