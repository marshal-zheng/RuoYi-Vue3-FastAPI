import type { ZxDisplayMetricsSnapshot } from './display-metrics';
import type { ThemeLayoutPort } from '../theme-runtime/layout-contract';
import type { ThemeScopeIdentity } from '../theme-runtime/composition-contract';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
import type { ThemeRuntime } from '../theme-runtime/runtime';
import type { ZxDisplayLayoutState } from './display-layout-observer';
export type { ZxDisplayLayoutState } from './display-layout-observer';
/** A proposed CSS measurement; layoutRevision exists only after a commit. */
export type ZxDisplayLayoutCandidate = Omit<ZxDisplayMetricsSnapshot, 'layoutRevision'>;
export interface ZxDisplayLayoutContext {
    /** Owned focus before an external layout change made the region inert. */
    readonly focusedElement: HTMLElement | null;
}
export interface ZxDisplayLayoutParticipant {
    readonly id: string;
    readonly metrics: readonly string[];
    prepare(next: ZxDisplayLayoutCandidate, signal: AbortSignal, context?: ZxDisplayLayoutContext): Promise<{
        commit(): void | Promise<void>;
        rollback(): void | Promise<void>;
        dispose(): void;
    }>;
}
/** Host-owned staging for JS geometry that must move with theme CSS. */
export declare function createDisplayLayoutCoordinator(metrics: ReadonlyMap<string, {
    readonly variable: string;
    readonly moduleId?: string;
}>, runtimeId: string, runtime: Pick<ThemeRuntime, 'readScopeConsumption' | 'refreshDisplay' | 'subscribeScope'>): Readonly<{
    port: ThemeLayoutPort;
    register(scope: ThemeScopeIdentity, region: HTMLElement, participant: ZxDisplayLayoutParticipant): ThemeRuntimeResult<() => void>;
    observe(scope: ThemeScopeIdentity, region: HTMLElement, participant: ZxDisplayLayoutParticipant, listener: (state: ZxDisplayLayoutState, diagnostics: readonly string[]) => void): ThemeRuntimeResult<{
        retry: () => Promise<ThemeRuntimeResult<unknown>>;
        dispose(): void;
    }>;
    isReady: (scopeId: string) => boolean;
    layoutRevision: (scopeId: string, root: HTMLElement, advance?: boolean) => number;
    subscribeState: (scope: ThemeScopeIdentity, listener: (state: ZxDisplayLayoutState, diagnostics: readonly string[]) => void) => Readonly<{
        ok: false;
        diagnostics: readonly import("..").ThemeRuntimeDiagnostic[];
    }> | Readonly<{
        ok: true;
        value: () => void;
        diagnostics: readonly [];
    }>;
    dispose(): void;
}>;
export type ZxDisplayLayoutCoordinator = ReturnType<typeof createDisplayLayoutCoordinator>;
