import type { ManifestIdentity } from '../theme-runtime/adapter-contract';
import type { ThemeAssetResolver } from '../theme-runtime/asset-resolver';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
/** Browser-only view of the deployment protocol; no Compiler runtime dependency. */
export interface ThemeDeploymentMapV1 {
    readonly schema: 'zx.theme-deployment/1';
    readonly manifests: readonly Readonly<{
        identity: ManifestIdentity;
        manifestSha256: string;
    }>[];
    readonly entries: readonly Readonly<{
        packageName: string;
        packageVersion: string;
        exportPath: string;
        sha256: string;
        assetPath: string;
        integrity: string;
        byteLength: number;
    }>[];
}
export interface ThemeDeploymentResolverOptions {
    readonly deployment: unknown;
    /** Trusted application deployment directory, including its origin. */
    readonly baseURL: string;
    /** Additional trusted CDN directories; deployment JSON cannot authorize origins. */
    readonly allowedAssetBases?: readonly string[];
}
export declare function createThemeDeploymentResolver(options: ThemeDeploymentResolverOptions): ThemeRuntimeResult<ThemeAssetResolver>;
