import type { ZxThemeCompositionRequest } from './composition-core';
export declare function parseCompositionRequest(input: unknown): ZxThemeCompositionRequest;
