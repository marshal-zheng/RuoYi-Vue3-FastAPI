import type { App, ShallowRef } from 'vue';
import type { ThemeRuntimeDiagnostic } from '../theme-runtime/diagnostics';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
import type { ThemeInitializationPhase, ThemeRuntime } from '../theme-runtime/runtime';
import type { ThemeScopeRequest } from '../theme-runtime/selection-resolver';
import type { SystemPreferencePort } from '../theme-runtime/system-preference';
import type { ValidatedThemeBootstrap } from './bootstrap-metadata';
export interface ZxThemeHostBootstrapState {
    readonly phase: ThemeInitializationPhase;
    readonly retryable: boolean;
    readonly request: ThemeScopeRequest;
    readonly systemMode: 'light' | 'dark';
    readonly diagnostics: readonly ThemeRuntimeDiagnostic[];
}
export interface ZxThemeHostBootstrap {
    readonly state: Readonly<ShallowRef<ZxThemeHostBootstrapState>>;
    /** Resolves with the first completed initialization attempt, including failure. */
    settled(): Promise<ThemeRuntimeResult<void>>;
    /** Waits for the barrier; a retained failed profile requires retry before navigation. */
    beforeNavigation(): Promise<boolean>;
    /** Explicit user intent; the original invalid SSR input cannot be retried. */
    retry(request: ThemeScopeRequest): Promise<ThemeRuntimeResult<void>>;
}
export declare function createThemeBootstrapController(runtime: ThemeRuntime, input: ValidatedThemeBootstrap, system: SystemPreferencePort): {
    api: ZxThemeHostBootstrap;
    install(app: App, disposeHost: () => void): void;
    dispose(): void;
};
