import type { ZxThemeCompositionOptions } from './composition-core';
import type { RuntimeThemeManifest } from '../theme-runtime/adapter-contract';
export type * from './composition-core';
export { parseCompositionRequest } from './composition-request';
export declare function createHostThemeComposition(options: ZxThemeCompositionOptions, themes: readonly RuntimeThemeManifest[]): import("..").ThemeRuntimeResult<{
    readonly port: import("..").ThemeScopeCompositionPort;
    readonly bundles: readonly import("@zxio/tokens/extensions").ValidatedThemeExtensionBundleV1[];
    readonly manifests: readonly RuntimeThemeManifest[];
    dispose(): void;
}>;
