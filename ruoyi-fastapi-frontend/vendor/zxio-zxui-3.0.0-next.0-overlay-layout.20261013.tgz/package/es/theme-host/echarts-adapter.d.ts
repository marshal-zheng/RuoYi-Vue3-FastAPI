import type { ZxThemeJsAdapter } from './consumption';
export interface ZxEChartsThemeOption {
    readonly backgroundColor: string;
    readonly color: readonly string[];
    readonly textStyle: {
        readonly color: string;
    };
    readonly legend: {
        readonly textStyle: {
            readonly color: string;
        };
    };
    readonly xAxis: {
        readonly axisLine: {
            readonly lineStyle: {
                readonly color: string;
            };
        };
        readonly axisLabel: {
            readonly color: string;
        };
        readonly splitLine: {
            readonly lineStyle: {
                readonly color: string;
            };
        };
    };
    readonly yAxis: ZxEChartsThemeOption['xAxis'];
}
/** Pure, optional projection; the host application supplies its actual chart instance. */
export declare function createEChartsThemeAdapter(): ZxThemeJsAdapter<ZxEChartsThemeOption>;
