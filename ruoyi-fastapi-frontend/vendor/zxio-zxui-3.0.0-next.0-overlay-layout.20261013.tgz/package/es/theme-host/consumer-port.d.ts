import { themeConsumerFactoryKey } from '../components/theme-provider/src/context';
import type { ThemeConsumerAbi, ThemeConsumerCssInput, ThemeConsumerResult } from '@zxio/theme-consumer';
import type { CompiledThemeCssAdapterV1, ValidatedThemeExtensionBundleV1 } from '@zxio/tokens/extensions';
import type { ThemeConsumerFactory } from '../components/theme-provider/src/context';
import type { ThemeRuntime } from '../theme-runtime/runtime';
export { themeConsumerFactoryKey };
export declare const browserConsumerAbi: ThemeConsumerAbi;
export declare const consumerDiscovery: (abi: ThemeConsumerAbi) => Readonly<{
    schema: "zx.theme-consumer.discovery/1";
    abis: readonly ThemeConsumerAbi[];
}>;
export declare function consumerFailure(code: string, phase: string, details?: Readonly<Record<string, unknown>>): {
    readonly ok: false;
    readonly diagnostics: readonly import('@zxio/theme-consumer').ThemeConsumerDiagnostic[];
};
export declare function validateConsumerAdapter(adapters: ReadonlyMap<string, CompiledThemeCssAdapterV1>, input: ThemeConsumerCssInput): ThemeConsumerResult<CompiledThemeCssAdapterV1>;
export declare function createBrowserConsumerFactory(runtime: ThemeRuntime, appKey: string, bundles: readonly ValidatedThemeExtensionBundleV1[]): ThemeConsumerFactory;
export declare function createConsumerAdmission(bundles: readonly ValidatedThemeExtensionBundleV1[]): {
    validate: (input: ThemeConsumerCssInput) => ThemeConsumerResult<CompiledThemeCssAdapterV1>;
};
