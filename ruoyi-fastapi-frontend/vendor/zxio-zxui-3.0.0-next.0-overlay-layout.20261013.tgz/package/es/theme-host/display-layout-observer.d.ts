import type { ThemeRuntime } from '../theme-runtime/runtime';
import type { ThemeScopeIdentity } from '../theme-runtime/composition-contract';
import type { ThemeRuntimeResult } from '../theme-runtime/result';
export type ZxDisplayLayoutState = 'pending' | 'preparing' | 'committing' | 'ready' | 'error';
export interface DisplayLayoutRegion {
    readonly region: HTMLElement;
    readonly participant: {
        readonly metrics: readonly string[];
    };
    readonly initialized: boolean;
}
/** Nested layout transactions share one original boundary instead of restoring stale styles. */
export declare function holdDisplayRegion(region: HTMLElement): () => void;
/** A parent busy boundary may have already invalidated a nested region's focus. */
export declare function readDisplayRegionFocus(region: HTMLElement): HTMLElement | null;
type RuntimePort = Pick<ThemeRuntime, 'readScopeConsumption' | 'refreshDisplay' | 'subscribeScope'>;
type Listener = (state: ZxDisplayLayoutState, diagnostics: readonly string[]) => void;
/** One observation loop per scope, sharing the existing Runtime layout transaction. */
export declare function createDisplayLayoutObserver(runtime: RuntimePort, metrics: ReadonlyMap<string, {
    readonly variable: string;
}>, regionsOf: (scopeId: string) => readonly DisplayLayoutRegion[]): Readonly<{
    observe(scope: ThemeScopeIdentity, listener: Listener): Readonly<{
        ok: false;
        diagnostics: readonly import("..").ThemeRuntimeDiagnostic[];
    }> | Readonly<{
        ok: true;
        value: {
            retry: () => Promise<ThemeRuntimeResult<unknown>>;
            dispose(): void;
        };
        diagnostics: readonly [];
    }>;
    preparing(scopeId: string): void;
    candidate(scopeId: string, pixels: Readonly<Record<string, number>>): void;
    committing(scopeId: string): void;
    settled(scopeId: string, succeeded: boolean, diagnostics?: readonly string[]): void;
    retainRecovery(scopeId: string, release: () => void): boolean;
    isReady(scopeId: string): boolean;
    subscribeState(scope: ThemeScopeIdentity, listener: Listener): Readonly<{
        ok: false;
        diagnostics: readonly import("..").ThemeRuntimeDiagnostic[];
    }> | Readonly<{
        ok: true;
        value: () => void;
        diagnostics: readonly [];
    }>;
    dispose(): void;
}>;
export {};
