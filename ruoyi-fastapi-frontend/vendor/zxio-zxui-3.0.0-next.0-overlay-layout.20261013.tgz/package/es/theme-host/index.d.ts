import type { ZxDefaultBrowserThemeHostOptions, ZxThemeHostOptions } from './browser-core';
export * from './browser-core';
export * from './composition';
export * from './composition-seeds';
export declare function createZxThemeHost(options: ZxThemeHostOptions): import("..").ThemeRuntimeResult<import("./browser-core").ZxThemeHost>;
export declare function createDefaultBrowserThemeHost(options: ZxDefaultBrowserThemeHostOptions): import("..").ThemeRuntimeResult<import("./browser-core").ZxThemeHost>;
