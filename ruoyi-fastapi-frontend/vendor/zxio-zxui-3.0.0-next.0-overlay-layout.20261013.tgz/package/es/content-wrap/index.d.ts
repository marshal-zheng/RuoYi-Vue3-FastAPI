export { ZxContentWrap, default, createContentWrapSaveController, } from '../components/content-wrap/index';
export type { ContentWrapProps, ContentWrapPublicProps, ZxContentWrapInstance, ContentWrapSaveControllerOptions, } from '../components/content-wrap/index';
