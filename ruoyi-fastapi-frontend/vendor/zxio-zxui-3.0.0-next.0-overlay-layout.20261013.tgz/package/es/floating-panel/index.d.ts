export { default } from '../components/floating-panel/index';
export * from '../components/floating-panel/index';
