export { default } from '../components/upload/index';
export * from '../components/upload/index';
