export type ZxTabsInstance = HTMLElement & {};
