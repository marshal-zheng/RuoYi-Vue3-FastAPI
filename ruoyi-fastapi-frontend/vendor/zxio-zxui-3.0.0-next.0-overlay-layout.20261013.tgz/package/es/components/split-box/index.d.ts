import { type SFCWithInstall } from '@zxio/shared';
import SplitBoxComponent from './src/split-box.vue';
export declare const ZxSplitBox: SFCWithInstall<typeof SplitBoxComponent>;
export default ZxSplitBox;
export * from './src/props';
export type { ZxSplitBoxInstance } from './src/instance';
