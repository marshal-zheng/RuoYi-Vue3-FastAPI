import type SplitBox from './split-box.vue';
export type ZxSplitBoxInstance = InstanceType<typeof SplitBox>;
