import { type SFCWithInstall } from '@zxio/shared';
import InputNumber from './src/input-number.vue';
export declare const ZxInputNumber: SFCWithInstall<typeof InputNumber>;
export default ZxInputNumber;
export * from './src/props';
export type { ZxInputNumberInstance } from './src/instance';
