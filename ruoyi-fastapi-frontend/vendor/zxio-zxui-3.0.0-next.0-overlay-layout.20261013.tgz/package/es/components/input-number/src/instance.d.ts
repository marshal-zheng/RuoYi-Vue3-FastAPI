import type InputNumber from './input-number-core.vue';
export type ZxInputNumberInstance = InstanceType<typeof InputNumber>;
