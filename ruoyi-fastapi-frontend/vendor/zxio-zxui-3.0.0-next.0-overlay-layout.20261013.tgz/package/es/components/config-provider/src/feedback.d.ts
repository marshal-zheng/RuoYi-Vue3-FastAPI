import type { ThemeFeedback, ThemeMessageBoxFeedback, ThemeMessageBoxOptions, ThemeRuntimeResult } from '../../theme-provider';
import type { ZxConfigProviderContext } from './types';
import type { MaybeRefOrGetter } from 'vue';
import type { ZxMessageParams } from '../../message';
import type { ZxNotificationParams } from '../../notification';
export interface ZxFeedbackApi {
    message(options: ZxMessageParams): ReturnType<ThemeFeedback['message']>;
    notification(options: ZxNotificationParams): ReturnType<ThemeFeedback['notification']>;
    modal: Readonly<{
        confirm(options: ThemeMessageBoxOptions): ReturnType<ThemeFeedback['confirm']>;
        alert(options: ThemeMessageBoxOptions): ReturnType<ThemeMessageBoxFeedback['alert']>;
        prompt(options: ThemeMessageBoxOptions): ReturnType<ThemeMessageBoxFeedback['prompt']>;
    }>;
}
export declare function createZxFeedback(feedback: ThemeFeedback & Partial<Pick<ThemeMessageBoxFeedback, 'alert' | 'prompt'>>, config?: MaybeRefOrGetter<Partial<ZxConfigProviderContext>>): ZxFeedbackApi;
export declare function useZxFeedback(): ThemeRuntimeResult<ZxFeedbackApi>;
