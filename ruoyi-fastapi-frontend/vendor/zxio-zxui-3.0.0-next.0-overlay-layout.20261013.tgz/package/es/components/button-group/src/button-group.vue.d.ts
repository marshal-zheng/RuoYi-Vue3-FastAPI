declare const _default: import("vue").DefineComponent<unknown, {
    rootRef: import("vue").Ref<any, any>;
    classes: import("vue").ComputedRef<(string | {
        [x: string]: any;
        'el-button-group': any;
    })[]>;
    groupStyle: import("vue").ComputedRef<{
        flexDirection: string;
        gap: string | undefined;
        alignItems: string;
    } | {
        flexDirection?: undefined;
        gap?: undefined;
        alignItems?: undefined;
    }>;
    groupSize: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    'update:modelValue': (value: string | number) => boolean;
    input: (value: string | number) => boolean;
}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{
    onInput?: ((value: string | number) => any) | undefined;
    "onUpdate:modelValue"?: ((value: string | number) => any) | undefined;
}>, {
    readonly flat: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly round: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly modelValue: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | (((new (...args: any[]) => string | number) | (() => string | number)) | null)[], unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<StringConstructor, "small" | "default" | "large", unknown>;
    readonly enabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly vertical: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly rowGap: number;
    readonly shape: import("@zxio/shared").EpPropMergeType<StringConstructor, "" | "circle" | "round", unknown>;
    readonly activeClass: string;
    readonly defaultFirstChecked: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {
    ElButtonGroup: import("element-plus/es/utils").SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
    readonly direction: {
        readonly type: import("vue").PropType<"horizontal" | "vertical">;
        readonly values: readonly [
            "horizontal",
            "vertical"
        ];
        readonly default: "horizontal";
    };
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    readonly direction: "horizontal" | "vertical";
    readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
    readonly direction: {
        readonly type: import("vue").PropType<"horizontal" | "vertical">;
        readonly values: readonly [
            "horizontal",
            "vertical"
        ];
        readonly default: "horizontal";
    };
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    readonly direction: "horizontal" | "vertical";
    readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
    readonly direction: {
        readonly type: import("vue").PropType<"horizontal" | "vertical">;
        readonly values: readonly [
            "horizontal",
            "vertical"
        ];
        readonly default: "horizontal";
    };
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    readonly direction: "horizontal" | "vertical";
    readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly type: import("element-plus/es/utils").EpPropFinalized<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown, "", boolean>;
    readonly direction: {
        readonly type: import("vue").PropType<"horizontal" | "vertical">;
        readonly values: readonly [
            "horizontal",
            "vertical"
        ];
        readonly default: "horizontal";
    };
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    readonly direction: "horizontal" | "vertical";
    readonly type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        default?: (props: {}) => any;
    };
} }>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
