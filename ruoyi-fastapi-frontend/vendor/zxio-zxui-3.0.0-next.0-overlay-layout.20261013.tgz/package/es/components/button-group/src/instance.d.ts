import type ButtonGroup from './button-group.vue';
export type ZxButtonGroupInstance = InstanceType<typeof ButtonGroup>;
