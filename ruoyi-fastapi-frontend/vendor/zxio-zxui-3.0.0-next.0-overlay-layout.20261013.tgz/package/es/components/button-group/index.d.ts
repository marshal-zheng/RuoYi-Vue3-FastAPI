import { type SFCWithInstall } from '@zxio/shared';
export declare const ZxButtonGroup: SFCWithInstall<any>;
export default ZxButtonGroup;
export * from './src/props';
export type { ZxButtonGroupInstance } from './src/instance';
