declare const _default: Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    focus: (...args: Parameters<import("element-plus").InputInstance["focus"]>) => any;
    blur: (...args: Parameters<import("element-plus").InputInstance["blur"]>) => any;
    select: (...args: Parameters<import("element-plus").InputInstance["select"]>) => any;
    clear: (...args: Parameters<import("element-plus").InputInstance["clear"]>) => any;
    input: import("vue").ComputedRef<any>;
    textarea: import("vue").ComputedRef<any>;
    textareaStyle: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    id: string;
    type: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | ((new (...args: any[]) => string) | (() => import("element-plus").InputType))[], unknown, unknown>;
    disabled: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    tabindex: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    modelValue: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined))[], unknown, unknown>;
    clearable: boolean;
    autofocus: boolean;
    tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig)) | null)[], unknown, unknown>;
    inputmode: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown>;
    modelModifiers: import("element-plus").InputModelModifiers;
    autosize: import("element-plus").InputAutoSize;
    autocomplete: AutoFill;
    readonly: boolean;
    showPassword: boolean;
    showWordLimit: boolean;
    wordLimitPosition: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "outside" | "inside", unknown>;
    containerRole: string;
    validateEvent: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    inputStyle: import("vue").StyleValue;
    rows: number;
    tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown>;
    tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger)) | null)[], unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    focus: (...args: Parameters<import("element-plus").InputInstance["focus"]>) => any;
    blur: (...args: Parameters<import("element-plus").InputInstance["blur"]>) => any;
    select: (...args: Parameters<import("element-plus").InputInstance["select"]>) => any;
    clear: (...args: Parameters<import("element-plus").InputInstance["clear"]>) => any;
    input: import("vue").ComputedRef<any>;
    textarea: import("vue").ComputedRef<any>;
    textareaStyle: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    id: string;
    type: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | ((new (...args: any[]) => string) | (() => import("element-plus").InputType))[], unknown, unknown>;
    disabled: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    tabindex: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    modelValue: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined))[], unknown, unknown>;
    clearable: boolean;
    autofocus: boolean;
    tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig)) | null)[], unknown, unknown>;
    inputmode: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown>;
    modelModifiers: import("element-plus").InputModelModifiers;
    autosize: import("element-plus").InputAutoSize;
    autocomplete: AutoFill;
    readonly: boolean;
    showPassword: boolean;
    showWordLimit: boolean;
    wordLimitPosition: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "outside" | "inside", unknown>;
    containerRole: string;
    validateEvent: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    inputStyle: import("vue").StyleValue;
    rows: number;
    tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown>;
    tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger)) | null)[], unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    focus: (...args: Parameters<import("element-plus").InputInstance["focus"]>) => any;
    blur: (...args: Parameters<import("element-plus").InputInstance["blur"]>) => any;
    select: (...args: Parameters<import("element-plus").InputInstance["select"]>) => any;
    clear: (...args: Parameters<import("element-plus").InputInstance["clear"]>) => any;
    input: import("vue").ComputedRef<any>;
    textarea: import("vue").ComputedRef<any>;
    textareaStyle: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    id: string;
    type: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | ((new (...args: any[]) => string) | (() => import("element-plus").InputType))[], unknown, unknown>;
    disabled: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    tabindex: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    modelValue: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined))[], unknown, unknown>;
    clearable: boolean;
    autofocus: boolean;
    tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig)) | null)[], unknown, unknown>;
    inputmode: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown>;
    modelModifiers: import("element-plus").InputModelModifiers;
    autosize: import("element-plus").InputAutoSize;
    autocomplete: AutoFill;
    readonly: boolean;
    showPassword: boolean;
    showWordLimit: boolean;
    wordLimitPosition: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "outside" | "inside", unknown>;
    containerRole: string;
    validateEvent: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    inputStyle: import("vue").StyleValue;
    rows: number;
    tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown>;
    tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger)) | null)[], unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {
    focus: (...args: Parameters<import("element-plus").InputInstance["focus"]>) => any;
    blur: (...args: Parameters<import("element-plus").InputInstance["blur"]>) => any;
    select: (...args: Parameters<import("element-plus").InputInstance["select"]>) => any;
    clear: (...args: Parameters<import("element-plus").InputInstance["clear"]>) => any;
    input: import("vue").ComputedRef<any>;
    textarea: import("vue").ComputedRef<any>;
    textareaStyle: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    id: string;
    type: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | ((new (...args: any[]) => string) | (() => import("element-plus").InputType))[], unknown, unknown>;
    disabled: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    tabindex: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [
        StringConstructor,
        NumberConstructor
    ], unknown, unknown>;
    modelValue: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined))[], unknown, unknown>;
    clearable: boolean;
    autofocus: boolean;
    tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").InputTooltipConfig) | (() => string | import("@zxio/zxui").InputTooltipConfig)) | null)[], unknown, unknown>;
    inputmode: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown>;
    modelModifiers: import("element-plus").InputModelModifiers;
    autosize: import("element-plus").InputAutoSize;
    autocomplete: AutoFill;
    readonly: boolean;
    showPassword: boolean;
    showWordLimit: boolean;
    wordLimitPosition: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "outside" | "inside", unknown>;
    containerRole: string;
    validateEvent: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    inputStyle: import("vue").StyleValue;
    rows: number;
    tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown>;
    tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("@zxio/zxui").InputTooltipTrigger)) | null)[], unknown, unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        prefix?(props: Record<string, unknown>): unknown;
        suffix?(props: Record<string, unknown>): unknown;
        prepend?(props: Record<string, unknown>): unknown;
        append?(props: Record<string, unknown>): unknown;
    };
} };
export default _default;
