import type { InputInstance } from 'element-plus';
type __VLS_Slots = {
    prefix?(props: Record<string, unknown>): unknown;
    suffix?(props: Record<string, unknown>): unknown;
    prepend?(props: Record<string, unknown>): unknown;
    append?(props: Record<string, unknown>): unknown;
};
declare const __VLS_component: import("vue").DefineComponent<unknown, {
    focus: (...args: Parameters<InputInstance["focus"]>) => any;
    blur: (...args: Parameters<InputInstance["blur"]>) => any;
    select: (...args: Parameters<InputInstance["select"]>) => any;
    clear: (...args: Parameters<InputInstance["clear"]>) => any;
    input: import("vue").ComputedRef<any>;
    textarea: import("vue").ComputedRef<any>;
    textareaStyle: import("vue").ComputedRef<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    id: string;
    type: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").InputType) | ((new (...args: any[]) => string) | (() => import("element-plus").InputType))[], unknown, unknown>;
    disabled: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    tabindex: import("element-plus/es/utils").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    modelValue: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number | null | undefined) | ((new (...args: any[]) => string | number) | (() => string | number | null | undefined))[], unknown, unknown>;
    clearable: boolean;
    autofocus: boolean;
    tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("./props").InputTooltipConfig) | (() => string | import("./props").InputTooltipConfig) | (((new (...args: any[]) => string | import("./props").InputTooltipConfig) | (() => string | import("./props").InputTooltipConfig)) | null)[], unknown, unknown>;
    inputmode: import("element-plus/es/utils").EpPropMergeType<(new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined) | ((new (...args: any[]) => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal") | (() => "search" | "text" | "none" | "url" | "email" | "tel" | "numeric" | "decimal" | undefined))[], unknown, unknown>;
    modelModifiers: import("element-plus").InputModelModifiers;
    autosize: import("element-plus").InputAutoSize;
    autocomplete: AutoFill;
    readonly: boolean;
    showPassword: boolean;
    showWordLimit: boolean;
    wordLimitPosition: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "outside" | "inside", unknown>;
    containerRole: string;
    validateEvent: import("element-plus/es/utils").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    inputStyle: import("vue").StyleValue;
    rows: number;
    tooltipPlacement: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement) | (((new (...args: any[]) => string) | (() => import("@zxio/zxui").Placement)) | null)[], unknown, unknown>;
    tooltipTrigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("./props").InputTooltipTrigger) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover") | (() => import("./props").InputTooltipTrigger)) | null)[], unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & {
    $slots: S;
} };
