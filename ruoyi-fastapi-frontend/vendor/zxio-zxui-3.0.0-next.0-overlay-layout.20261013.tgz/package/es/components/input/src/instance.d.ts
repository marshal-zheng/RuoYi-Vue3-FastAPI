import type Input from './input-core.vue';
export type ZxInputInstance = InstanceType<typeof Input>;
