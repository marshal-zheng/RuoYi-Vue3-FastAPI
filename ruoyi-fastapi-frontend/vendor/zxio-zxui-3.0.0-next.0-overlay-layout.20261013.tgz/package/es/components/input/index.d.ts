import { type SFCWithInstall } from '@zxio/shared';
import Input from './src/input.vue';
export declare const ZxInput: SFCWithInstall<typeof Input>;
export default ZxInput;
export * from './src/props';
export type { ZxInputInstance } from './src/instance';
