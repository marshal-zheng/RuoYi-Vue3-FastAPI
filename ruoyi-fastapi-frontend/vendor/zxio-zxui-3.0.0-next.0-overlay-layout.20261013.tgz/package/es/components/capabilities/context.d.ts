import type { Component, FunctionalComponent, Plugin } from 'vue';
export interface ZxUiCapabilities {
    /** Synchronously available names. Prefer component references for individual icons. */
    readonly icons?: Readonly<Record<string, Component>>;
    /** Pass ZxTooltipOrPopover to enable the existing tooltip/popover implementation. */
    readonly tooltip?: Component;
}
interface CapabilityContext extends ZxUiCapabilities {
    readonly fallbackIcons?: Readonly<Record<string, Component>>;
}
/** Owns configuration per app/request. It never mutates a module-wide registry. */
export declare function createZxUiCapabilities(options?: ZxUiCapabilities): Plugin;
export declare function withComponentCapabilities<T extends Component>(component: T, capabilities: ZxUiCapabilities): T;
export declare function resolveCapabilityIcon(capabilities: CapabilityContext, name: string): Component | undefined;
export declare function useZxUiCapabilities(): CapabilityContext;
/** Explicitly unconfigured core components keep their synchronous trigger. */
export declare const UnconfiguredTooltip: FunctionalComponent;
export {};
