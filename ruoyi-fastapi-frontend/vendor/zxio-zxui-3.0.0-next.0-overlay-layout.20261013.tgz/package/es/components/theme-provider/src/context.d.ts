import type { PortalBinding, PreparedSsrThemeScope, PreparedThemeScope, ThemeAppHandle, ThemeRequiredPortalTarget, ThemeRuntimePort, ThemeScopeHandle, ThemeSsrRuntimePort } from './types';
import type { InjectionKey, Ref, ShallowRef } from 'vue';
export declare const themeRuntimeKey: InjectionKey<ThemeRuntimePort>;
export declare const themeAppKey: InjectionKey<ThemeAppHandle>;
export declare const themeScopeKey: InjectionKey<Readonly<ShallowRef<ThemeScopeHandle | null>>>;
export declare const preparedThemeScopeKey: InjectionKey<PreparedThemeScope>;
export declare const themeSsrRuntimeKey: InjectionKey<ThemeSsrRuntimePort>;
export declare const preparedSsrThemeScopeKey: InjectionKey<PreparedSsrThemeScope>;
export declare const themePortalTargetKey: InjectionKey<Readonly<Ref<ThemeRequiredPortalTarget | undefined>>>;
export declare const themePortalBindingKey: InjectionKey<Readonly<Ref<PortalBinding | null>>>;
export interface ThemeConsumerFactoryOwner {
    readonly prepared: PreparedThemeScope | PreparedSsrThemeScope;
    readonly current: Readonly<ShallowRef<ThemeScopeHandle | null>>;
    readonly portalTarget: Readonly<Ref<ThemeRequiredPortalTarget | undefined>>;
    readonly consumerDiagnostics?: Readonly<Ref<readonly import('@zxio/theme-consumer').ThemeConsumerDiagnostic[]>>;
    readonly portalBinding?: Readonly<Ref<PortalBinding | null>> | null;
}
export type ThemeConsumerFactory = {
    (owner: ThemeConsumerFactoryOwner): {
        readonly port: import('@zxio/theme-consumer').ThemeConsumerScopePort<HTMLElement, HTMLElement>;
        dispose(): void;
    };
    retainFailedHydration?(input: {
        parent: PreparedThemeScope | null;
        scopeKey?: string;
    }): string | null;
};
export declare const themeConsumerFactoryKey: InjectionKey<ThemeConsumerFactory>;
