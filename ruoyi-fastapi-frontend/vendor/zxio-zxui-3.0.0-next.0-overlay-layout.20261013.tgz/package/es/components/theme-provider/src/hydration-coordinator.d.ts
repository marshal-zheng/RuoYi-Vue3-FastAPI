import type { PreparedThemeScope, ThemeAppHandle, ThemeRuntimePort, ThemeRuntimeResult, ThemeScopeHandle } from './types';
export declare function adoptHydratedThemeScope(runtime: ThemeRuntimePort, prepared: PreparedThemeScope, root: HTMLElement, stylesheetElements?: readonly HTMLElement[]): ThemeRuntimeResult<ThemeScopeHandle>;
export declare function completeThemeHydration(app: ThemeAppHandle): ThemeRuntimeResult<void>;
