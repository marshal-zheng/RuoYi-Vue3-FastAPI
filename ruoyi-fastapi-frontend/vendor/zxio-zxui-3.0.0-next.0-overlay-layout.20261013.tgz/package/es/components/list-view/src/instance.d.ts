import type ListView from './list-view.vue';
export type ZxListViewInstance = InstanceType<typeof ListView>;
