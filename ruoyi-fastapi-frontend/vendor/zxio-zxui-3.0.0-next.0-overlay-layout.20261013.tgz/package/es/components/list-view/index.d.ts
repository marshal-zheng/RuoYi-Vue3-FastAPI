import { type SFCWithInstall } from '@zxio/shared';
export declare const ZxListView: SFCWithInstall<any>;
export default ZxListView;
export * from './src/props';
export type { ZxListViewInstance } from './src/instance';
