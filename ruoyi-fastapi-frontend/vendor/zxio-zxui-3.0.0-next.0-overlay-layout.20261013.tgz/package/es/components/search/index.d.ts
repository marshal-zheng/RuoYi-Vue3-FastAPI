import { type SFCWithInstall } from '@zxio/shared';
import SearchComponent from './src/search.vue';
export declare const ZxSearch: SFCWithInstall<typeof SearchComponent>;
export default ZxSearch;
export * from './src/props';
export type { ZxSearchInstance } from './src/instance';
