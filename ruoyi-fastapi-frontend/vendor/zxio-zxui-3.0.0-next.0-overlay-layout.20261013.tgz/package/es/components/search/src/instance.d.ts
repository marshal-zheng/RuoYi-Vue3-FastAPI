import type { ComponentPublicInstance } from 'vue';
export type ZxSearchInstance = ComponentPublicInstance & {
    focus?: () => void;
};
