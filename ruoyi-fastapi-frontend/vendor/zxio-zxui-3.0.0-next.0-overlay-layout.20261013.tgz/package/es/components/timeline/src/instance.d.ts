import type Timeline from './timeline.vue';
import type TimelineItem from './timeline-item.vue';
import type TimelineDivider from './timeline-divider.vue';
import type TimelineCard from './timeline-card.vue';
export type ZxTimelineInstance = InstanceType<typeof Timeline>;
export type ZxTimelineItemInstance = InstanceType<typeof TimelineItem>;
export type ZxTimelineDividerInstance = InstanceType<typeof TimelineDivider>;
export type ZxTimelineCardInstance = InstanceType<typeof TimelineCard>;
