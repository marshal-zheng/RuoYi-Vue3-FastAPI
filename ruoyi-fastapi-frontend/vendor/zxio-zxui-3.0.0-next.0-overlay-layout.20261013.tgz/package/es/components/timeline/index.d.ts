import { type SFCWithInstall } from '@zxio/shared';
import Timeline from './src/timeline.vue';
export declare const ZxTimeline: SFCWithInstall<typeof Timeline>;
export declare const ZxTimelineItem: SFCWithInstall<import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    rootRef: import("vue").Ref<HTMLElement | undefined, HTMLElement | undefined>;
    dotRef: import("vue").Ref<{
        dotEl: HTMLElement | null;
    } | null, {
        dotEl: HTMLElement | null;
    } | {
        dotEl: HTMLElement | null;
    } | null>;
    rootClasses: import("vue").ComputedRef<string[]>;
    itemRole: import("vue").ComputedRef<"listitem" | undefined>;
    rootStyles: import("vue").ComputedRef<Record<string, string>>;
    bodyStyles: import("vue").ComputedRef<{
        height: string;
        maxHeight: string;
        maxWidth: string;
        minHeight: string;
        minWidth: string;
        width: string;
    }>;
    showOppositeContainer: import("vue").ComputedRef<boolean>;
    showOppositeContent: import("vue").ComputedRef<boolean>;
    resolvedDotColor: import("vue").ComputedRef<any>;
    resolvedFillDot: import("vue").ComputedRef<any>;
    resolvedIconColor: import("vue").ComputedRef<any>;
    resolvedLineColor: import("vue").ComputedRef<string | undefined>;
    resolvedSize: import("vue").ComputedRef<import("./src/timeline").TimelineSize | undefined>;
    resolvedProcessCursor: import("vue").ComputedRef<boolean>;
    resolvedProgressIndicator: import("vue").ComputedRef<import("./src/hooks/use-timeline-progress-indicator-config.js").TimelineProgressIndicatorResolvedOptions>;
    progressIndicatorAnchorState: import("vue").ComputedRef<import("./src/hooks/use-timeline-progress-indicator-anchor.js").TimelineProgressIndicatorAnchorState>;
    progressIndicatorRenderState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState>;
    edgeGeometry: import("vue").Ref<{
        length: number;
        offset: number;
        startRadius: number;
        endRadius: number;
    } | null, import("./src/hooks/use-timeline-edge-geometry.js").TimelineEdgeGeometry | {
        length: number;
        offset: number;
        startRadius: number;
        endRadius: number;
    } | null>;
    edgeMeasured: import("vue").ComputedRef<boolean>;
    tag: any;
    elevation: any;
    icon: any;
    rounded: any;
    hideDot: any;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
    readonly progress: number;
    readonly tag: string;
    readonly width: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly height: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly status: import("@zxio/shared").EpPropMergeType<StringConstructor, "success" | "error" | "wait" | "process", unknown>;
    readonly density: import("@zxio/shared").EpPropMergeType<StringConstructor, "default" | "compact" | "comfortable", unknown>;
    readonly rounded: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown>;
    readonly maxHeight: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly maxWidth: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly minHeight: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly minWidth: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly side: import("@zxio/shared").EpPropMergeType<StringConstructor, "end" | "start", unknown>;
    readonly lineColor: string;
    readonly dotColor: string;
    readonly fillDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly hideOpposite: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconColor: string;
    readonly lineInset: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly processCursor: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly processLineColorOwner: import("@zxio/shared").EpPropMergeType<StringConstructor, "split" | "process", unknown>;
    readonly progressIndicator: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./src/timeline").TimelineProgressIndicatorOptions) | (() => import("./src/timeline").TimelineProgressIndicator) | (((new (...args: any[]) => boolean | import("./src/timeline").TimelineProgressIndicatorOptions) | (() => import("./src/timeline").TimelineProgressIndicator)) | null)[], unknown, unknown>;
    readonly hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly elevation: number;
    readonly lineStatus: import("@zxio/shared").EpPropMergeType<StringConstructor, "success" | "error" | "wait" | "process", unknown>;
    readonly lineProgress: number;
}, {}, {
    ZxTimelineDivider: import("vue").DefineComponent<unknown, {
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        dotEl: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
        rootClasses: import("vue").ComputedRef<string[]>;
        dotClasses: import("vue").ComputedRef<string[]>;
        dotStyles: import("vue").ComputedRef<Record<string, string>>;
        innerDotClasses: import("vue").ComputedRef<string[]>;
        innerDotStyles: import("vue").ComputedRef<Record<string, string>>;
        dotAnchorClasses: import("vue").ComputedRef<string[]>;
        beforeClasses: import("vue").ComputedRef<string[]>;
        afterClasses: import("vue").ComputedRef<string[]>;
        edgeClasses: import("vue").ComputedRef<string[]>;
        edgeTrackClasses: import("vue").ComputedRef<string[]>;
        lineStyles: import("vue").ComputedRef<{
            backgroundColor: any;
        } | undefined>;
        slotProps: import("vue").ComputedRef<{
            icon: any;
            iconColor: any;
            size: any;
        }>;
        iconSize: import("vue").ComputedRef<string | number | undefined>;
        edgeEnabled: import("vue").ComputedRef<boolean>;
        dotAnchorVisible: import("vue").ComputedRef<boolean>;
        edgeAnchorVisible: import("vue").ComputedRef<boolean>;
        progressIndicatorState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState | null>;
        hideDot: any;
        icon: any;
        iconColor: any;
        progressIndicatorRenderState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState> | null;
    }, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
        readonly size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown>;
        readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
        readonly rounded: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown>;
        readonly lineColor: string;
        readonly dotColor: string;
        readonly fillDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly iconColor: string;
        readonly hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly elevation: number;
    }, {}, {
        ZxIcon: SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        popoverContent?: (props: {}) => any;
    };
} }>;
        ZxTimelineAnchor: import("vue").DefineComponent<unknown, () => string | number | boolean | void | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
            [key: string]: any;
        }> | import("vue").VNodeArrayChildren | null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    }, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
export declare const ZxTimelineDivider: SFCWithInstall<import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    dotEl: import("vue").Ref<HTMLElement | null, HTMLElement | null>;
    rootClasses: import("vue").ComputedRef<string[]>;
    dotClasses: import("vue").ComputedRef<string[]>;
    dotStyles: import("vue").ComputedRef<Record<string, string>>;
    innerDotClasses: import("vue").ComputedRef<string[]>;
    innerDotStyles: import("vue").ComputedRef<Record<string, string>>;
    dotAnchorClasses: import("vue").ComputedRef<string[]>;
    beforeClasses: import("vue").ComputedRef<string[]>;
    afterClasses: import("vue").ComputedRef<string[]>;
    edgeClasses: import("vue").ComputedRef<string[]>;
    edgeTrackClasses: import("vue").ComputedRef<string[]>;
    lineStyles: import("vue").ComputedRef<{
        backgroundColor: any;
    } | undefined>;
    slotProps: import("vue").ComputedRef<{
        icon: any;
        iconColor: any;
        size: any;
    }>;
    iconSize: import("vue").ComputedRef<string | number | undefined>;
    edgeEnabled: import("vue").ComputedRef<boolean>;
    dotAnchorVisible: import("vue").ComputedRef<boolean>;
    edgeAnchorVisible: import("vue").ComputedRef<boolean>;
    progressIndicatorState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState | null>;
    hideDot: any;
    icon: any;
    iconColor: any;
    progressIndicatorRenderState: import("vue").ComputedRef<import("./src/timeline-indicator.js").TimelineProgressIndicatorRenderState> | null;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
    readonly size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize) | (((new (...args: any[]) => string | number) | (() => import("./src/timeline").TimelineSize)) | null)[], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly rounded: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | number | boolean) | (() => string | number | boolean) | (((new (...args: any[]) => string | number | boolean) | (() => string | number | boolean)) | null)[], unknown, unknown>;
    readonly lineColor: string;
    readonly dotColor: string;
    readonly fillDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconColor: string;
    readonly hideDot: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly elevation: number;
}, {}, {
    ZxIcon: SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        popoverContent?: (props: {}) => any;
    };
} }>;
    ZxTimelineAnchor: import("vue").DefineComponent<unknown, () => string | number | boolean | void | import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }> | import("vue").VNodeArrayChildren | null, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
export declare const ZxTimelineCard: SFCWithInstall<import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    showHeader: import("vue").ComputedRef<boolean>;
    cardClasses: import("vue").ComputedRef<string[]>;
    headerClasses: import("vue").ComputedRef<string[]>;
    computedHeaderStyles: import("vue").ComputedRef<import("vue").CSSProperties>;
    bodyStyles: import("vue").ComputedRef<import("vue").CSSProperties>;
    footerStyles: import("vue").ComputedRef<import("vue").CSSProperties>;
    cardVars: import("vue").ComputedRef<Record<string, string>>;
    shadow: LooseRequired<any>;
    icon: LooseRequired<any>;
    iconSize: LooseRequired<any>;
    iconColor: LooseRequired<any>;
    title: LooseRequired<any>;
    subtitle: LooseRequired<any>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
    readonly title: string;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly bodyPadding: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly footerPadding: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly headerPadding: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly shadow: import("@zxio/shared").EpPropMergeType<StringConstructor, "always" | "never" | "hover", unknown>;
    readonly subtitle: string;
    readonly iconColor: string;
    readonly iconSize: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly headerStyle: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("vue").CSSProperties) | (() => string | import("vue").CSSProperties) | (((new (...args: any[]) => string | import("vue").CSSProperties) | (() => string | import("vue").CSSProperties)) | null)[], unknown, unknown>;
    readonly headerTextColor: string;
}, {}, {
    ElCard: import("element-plus/es/utils/index.js").SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly header: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly footer: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly bodyStyle: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, "", boolean>;
    readonly headerClass: StringConstructor;
    readonly bodyClass: StringConstructor;
    readonly footerClass: StringConstructor;
    readonly shadow: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "always" | "never" | "hover", unknown, undefined, boolean>;
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    readonly footer: string;
    readonly header: string;
    readonly bodyStyle: import("vue").StyleValue;
    readonly shadow: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "always" | "never" | "hover", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly header: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly footer: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly bodyStyle: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, "", boolean>;
    readonly headerClass: StringConstructor;
    readonly bodyClass: StringConstructor;
    readonly footerClass: StringConstructor;
    readonly shadow: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "always" | "never" | "hover", unknown, undefined, boolean>;
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    readonly footer: string;
    readonly header: string;
    readonly bodyStyle: import("vue").StyleValue;
    readonly shadow: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "always" | "never" | "hover", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly header: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly footer: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly bodyStyle: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, "", boolean>;
    readonly headerClass: StringConstructor;
    readonly bodyClass: StringConstructor;
    readonly footerClass: StringConstructor;
    readonly shadow: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "always" | "never" | "hover", unknown, undefined, boolean>;
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    readonly footer: string;
    readonly header: string;
    readonly bodyStyle: import("vue").StyleValue;
    readonly shadow: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "always" | "never" | "hover", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly header: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly footer: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
    readonly bodyStyle: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown, "", boolean>;
    readonly headerClass: StringConstructor;
    readonly bodyClass: StringConstructor;
    readonly footerClass: StringConstructor;
    readonly shadow: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "always" | "never" | "hover", unknown, undefined, boolean>;
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {
    readonly footer: string;
    readonly header: string;
    readonly bodyStyle: import("vue").StyleValue;
    readonly shadow: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "always" | "never" | "hover", unknown>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        header?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    } & {
        footer?: (props: {}) => any;
    };
} }>;
    ZxIcon: SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [
        NumberConstructor,
        StringConstructor
    ], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig) | (((new (...args: any[]) => string | import("@zxio/zxui").TooltipConfig) | (() => string | import("@zxio/zxui").TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        popoverContent?: (props: {}) => any;
    };
} }>;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
export default ZxTimeline;
export * from './src/timeline';
export type { ZxTimelineDividerInstance, ZxTimelineInstance, ZxTimelineItemInstance, ZxTimelineCardInstance, } from './src/instance';
