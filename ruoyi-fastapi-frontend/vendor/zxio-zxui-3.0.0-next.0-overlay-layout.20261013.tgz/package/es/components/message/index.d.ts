export declare const ZxMessage: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<unknown, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    close: () => true;
}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{
    onClose?: (() => any) | undefined;
}>, {
    type: NonNullable<import("element-plus/es/utils").EpPropMergeType<StringConstructor, "primary" | "success" | "warning" | "info" | "error", unknown> | undefined>;
    dangerouslyUseHTMLString: boolean;
    showClose: boolean;
    announce: boolean;
}, import("vue").SlotsType<import("./src/types").ZxMessageSlots>, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export default ZxMessage;
export type { ZxMessageAction, ZxMessageAppearance, ZxMessageConfig, ZxMessageOptions, ZxMessageParams, ZxMessageSlotScope, ZxMessageSlots, } from './src/types';
