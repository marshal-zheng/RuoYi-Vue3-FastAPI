import { type SFCWithInstall } from '@zxio/shared';
import ListToolbar from './src/list-toolbar.vue';
export declare const ZxListToolbar: SFCWithInstall<typeof ListToolbar>;
export default ZxListToolbar;
