import type { ZxToolbarAction } from './toolbar-actions';
declare var __VLS_1: {
    action: any;
};
type __VLS_Slots = {} & {
    action?: (props: typeof __VLS_1) => any;
};
declare const __VLS_component: import("vue").DefineComponent<unknown, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    action: (action: ZxToolbarAction) => any;
}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{
    onAction?: ((action: ZxToolbarAction) => any) | undefined;
}>, {
    label: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & {
    $slots: S;
} };
