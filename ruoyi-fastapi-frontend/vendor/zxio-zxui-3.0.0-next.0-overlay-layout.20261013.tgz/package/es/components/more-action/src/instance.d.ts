import type MoreAction from './more-action.vue';
export type ZxMoreActionInstance = InstanceType<typeof MoreAction>;
