export declare const ZxMoreAction: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    portalTarget: import("vue").ComputedRef<HTMLElement | undefined>;
    dropdownVisible: import("vue").Ref<boolean, boolean>;
    popperOptions: import("vue").ComputedRef<Partial<import("element-plus").Options>>;
    handleSelect: (command: string) => void;
    handleVisibleChange: (visible: boolean) => void;
    shouldShowDivider: (index: number) => boolean;
    MoreFilled: import("vue").DefineComponent<{}, void, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<{}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    size: any;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    select: (_item: import("./src/props").ActionItem) => boolean;
    close: () => boolean;
    open: () => boolean;
}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{
    onSelect?: ((_item: import("./src/props").ActionItem) => any) | undefined;
    onClose?: (() => any) | undefined;
    onOpen?: (() => any) | undefined;
}>, {
    size: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium") | (((new (...args: any[]) => "small" | "default" | "large" | "medium") | (() => "small" | "default" | "large" | "medium")) | null)[], unknown, unknown>;
    trigger: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[]) | (((new (...args: any[]) => "click" | "contextmenu" | "focus" | "hover" | import("./src/props").TriggerType[]) | (() => import("./src/props").TriggerType | import("./src/props").TriggerType[])) | null)[], unknown, unknown>;
    list: import("./src/props").ActionItem[];
}, {}, {
    ElDropdown: {
        new (...args: any[]): any;
        __isFragment?: never;
        __isTeleport?: never;
        __isSuspense?: never;
    } & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
        readonly trigger: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").Arrayable<"click" | "contextmenu" | "hover">>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
            readonly default: "hover";
        };
        readonly triggerKeys: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => string[]) | (() => string[]) | ((new (...args: any[]) => string[]) | (() => string[]))[], unknown, unknown, () => string[], boolean>;
        readonly virtualTriggering: BooleanConstructor;
        readonly virtualRef: {
            readonly type: import("vue").PropType<import("element-plus").Measurable>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly effect: {
            readonly default: "light";
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | ((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            readonly __epPropKey: true;
        };
        readonly type: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger") | (() => import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>) | ((new (...args: any[]) => "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger") | (() => import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "" | "text" | "default" | "primary" | "success" | "warning" | "info" | "danger", unknown>))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly placement: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | ((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement))[], unknown, unknown, "bottom", boolean>;
        readonly popperOptions: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>) | ((new (...args: any[]) => Partial<import("element-plus").Options>) | (() => Partial<import("element-plus").Options>))[], unknown, unknown, () => {}, boolean>;
        readonly id: StringConstructor;
        readonly size: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly splitButton: BooleanConstructor;
        readonly hideOnClick: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly loop: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showArrow: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly showTimeout: import("element-plus/es/utils/index.js").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly hideTimeout: import("element-plus/es/utils/index.js").EpPropFinalized<NumberConstructor, unknown, unknown, 150, boolean>;
        readonly tabindex: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown, 0, boolean>;
        readonly maxHeight: import("element-plus/es/utils/index.js").EpPropFinalized<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown, "", boolean>;
        readonly popperClass: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | (() => string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | ((new (...args: any[]) => string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | any)[])[])[])[])[])[])[])[])[])[])[]) | (() => string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | (string | {
                [x: string]: boolean;
            } | any)[])[])[])[])[])[])[])[])[])[])[]))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly popperStyle: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue) | ((new (...args: any[]) => string | false | import("vue").CSSProperties | import("vue").StyleValue[]) | (() => import("vue").StyleValue))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly disabled: BooleanConstructor;
        readonly role: import("element-plus/es/utils/index.js").EpPropFinalized<StringConstructor, "dialog" | "menu" | "grid" | "listbox" | "tooltip" | "tree" | "group" | "navigation", unknown, "menu", boolean>;
        readonly buttonProps: {
            readonly type: import("vue").PropType<Partial<import("element-plus").ButtonProps>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly teleported: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly appendTo: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | ((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement))[], unknown, unknown>) | ((new (...args: any[]) => string | HTMLElement) | (() => import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement) | ((new (...args: any[]) => string | HTMLElement) | (() => string | HTMLElement))[], unknown, unknown>))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly persistent: import("element-plus/es/utils/index.js").EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
    }>> & {
        onClick?: ((...args: any[]) => any) | undefined;
        "onVisible-change"?: ((...args: any[]) => any) | undefined;
        onCommand?: ((...args: any[]) => any) | undefined;
    }, {
        t: import("element-plus").Translator;
        ns: {
            namespace: import("vue").ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        scrollbar: import("vue").Ref<null>;
        wrapStyle: import("vue").ComputedRef<import("vue").CSSProperties>;
        dropdownTriggerKls: import("vue").ComputedRef<string[]>;
        dropdownSize: import("vue").ComputedRef<"" | "small" | "default" | "large">;
        triggerId: import("vue").ComputedRef<string>;
        currentTabId: import("vue").Ref<string | null>;
        handleCurrentTabIdChange: (id: string) => void;
        handlerMainButtonClick: (event: MouseEvent) => void;
        handleClose: () => void;
        handleOpen: () => void;
        handleBeforeShowTooltip: () => void;
        handleShowTooltip: (event?: Event) => void;
        handleBeforeHideTooltip: () => void;
        popperRef: import("vue").Ref<import("element-plus").TooltipInstance | undefined>;
        contentRef: import("vue").Ref<HTMLElement | undefined>;
        triggeringElementRef: import("vue").Ref<any>;
        referenceElementRef: import("vue").Ref<any>;
    }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "visible-change" | "command")[], "click" | "visible-change" | "command", {
        readonly disabled: boolean;
        readonly tabindex: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>;
        readonly maxHeight: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>;
        readonly size: string;
        readonly placement: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement) | ((new (...args: any[]) => "left" | "right" | "top" | "bottom" | "auto" | "auto-start" | "auto-end" | "top-start" | "top-end" | "bottom-start" | "bottom-end" | "right-start" | "right-end" | "left-start" | "left-end") | (() => import("element-plus").Placement))[], unknown, unknown>;
        readonly effect: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string) | (() => import("element-plus").PopperEffect) | ((new (...args: any[]) => string) | (() => import("element-plus").PopperEffect))[], unknown, unknown>;
        readonly role: import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "dialog" | "menu" | "grid" | "listbox" | "tooltip" | "tree" | "group" | "navigation", unknown>;
        readonly teleported: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly trigger: import("element-plus/es/utils/typescript.js").Arrayable<"click" | "contextmenu" | "hover">;
        readonly virtualTriggering: boolean;
        readonly loop: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly popperOptions: Partial<import("element-plus").Options>;
        readonly triggerKeys: string[];
        readonly persistent: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showArrow: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly hideOnClick: import("element-plus/es/utils/index.js").EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly showTimeout: number;
        readonly hideTimeout: number;
        readonly splitButton: boolean;
    }, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps & import("vue").ObjectPlugin & {
        DropdownItem: import("vue").DefineComponent<{
            readonly command: import("element-plus/es/utils/index.js").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
            readonly disabled: BooleanConstructor;
            readonly divided: BooleanConstructor;
            readonly textValue: StringConstructor;
            readonly icon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }, {
            handleClick: (event: PointerEvent) => void;
            handlePointerMove: (event: PointerEvent) => void;
            handlePointerLeave: (event: PointerEvent) => void;
            propsAndAttrs: import("vue").ComputedRef<{
                disabled: boolean;
                command: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
                divided: boolean;
                icon: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown> | undefined;
                textValue: string | undefined;
                onClick: ((...args: any[]) => any) | undefined;
                onPointerleave: ((...args: any[]) => any) | undefined;
                onPointermove: ((...args: any[]) => any) | undefined;
            }>;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "pointerleave" | "pointermove")[], "click" | "pointerleave" | "pointermove", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            readonly command: import("element-plus/es/utils/index.js").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
            readonly disabled: BooleanConstructor;
            readonly divided: BooleanConstructor;
            readonly textValue: StringConstructor;
            readonly icon: {
                readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>> & {
            onClick?: ((...args: any[]) => any) | undefined;
            onPointerleave?: ((...args: any[]) => any) | undefined;
            onPointermove?: ((...args: any[]) => any) | undefined;
        }, {
            readonly disabled: boolean;
            readonly command: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
            readonly divided: boolean;
        }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
        DropdownMenu: import("vue").DefineComponent<{
            onKeydown: {
                readonly type: import("vue").PropType<(e: KeyboardEvent) => void>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }, {
            size: import("vue").ComputedRef<string> | undefined;
            rovingFocusGroupRootStyle: import("vue").Ref<import("vue").StyleValue>;
            dropdownKls: import("vue").ComputedRef<string[]>;
            role: import("vue").ComputedRef<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "dialog" | "menu" | "grid" | "listbox" | "tooltip" | "tree" | "group" | "navigation", unknown>>;
            triggerId: import("vue").ComputedRef<string>;
            dropdownListWrapperRef: (el: Element | import("vue").ComponentPublicInstance | null) => void;
            handleKeydown: (event: KeyboardEvent) => void;
            onBlur: (e: Event) => void;
            handleFocus: (e: FocusEvent) => void;
            onMousedown: (e: Event) => void;
        }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
            onKeydown: {
                readonly type: import("vue").PropType<(e: KeyboardEvent) => void>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
        }>>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
    };
    ElDropdownMenu: import("element-plus/es/utils/index.js").SFCWithInstall<import("vue").DefineComponent<{
        onKeydown: {
            readonly type: import("vue").PropType<(e: KeyboardEvent) => void>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }, {
        size: import("vue").ComputedRef<string> | undefined;
        rovingFocusGroupRootStyle: import("vue").Ref<import("vue").StyleValue>;
        dropdownKls: import("vue").ComputedRef<string[]>;
        role: import("vue").ComputedRef<import("element-plus/es/utils/index.js").EpPropMergeType<StringConstructor, "dialog" | "menu" | "grid" | "listbox" | "tooltip" | "tree" | "group" | "navigation", unknown>>;
        triggerId: import("vue").ComputedRef<string>;
        dropdownListWrapperRef: (el: Element | import("vue").ComponentPublicInstance | null) => void;
        handleKeydown: (event: KeyboardEvent) => void;
        onBlur: (e: Event) => void;
        handleFocus: (e: FocusEvent) => void;
        onMousedown: (e: Event) => void;
    }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
        onKeydown: {
            readonly type: import("vue").PropType<(e: KeyboardEvent) => void>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
    ElDropdownItem: import("element-plus/es/utils/index.js").SFCWithInstall<import("vue").DefineComponent<{
        readonly command: import("element-plus/es/utils/index.js").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
        readonly disabled: BooleanConstructor;
        readonly divided: BooleanConstructor;
        readonly textValue: StringConstructor;
        readonly icon: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }, {
        handleClick: (event: PointerEvent) => void;
        handlePointerMove: (event: PointerEvent) => void;
        handlePointerLeave: (event: PointerEvent) => void;
        propsAndAttrs: import("vue").ComputedRef<{
            disabled: boolean;
            command: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
            divided: boolean;
            icon: import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown> | undefined;
            textValue: string | undefined;
            onClick: ((...args: any[]) => any) | undefined;
            onPointerleave: ((...args: any[]) => any) | undefined;
            onPointermove: ((...args: any[]) => any) | undefined;
        }>;
    }, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, ("click" | "pointerleave" | "pointermove")[], "click" | "pointerleave" | "pointermove", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
        readonly command: import("element-plus/es/utils/index.js").EpPropFinalized<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown, () => {}, boolean>;
        readonly disabled: BooleanConstructor;
        readonly divided: BooleanConstructor;
        readonly textValue: StringConstructor;
        readonly icon: {
            readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | ((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
    }>> & {
        onClick?: ((...args: any[]) => any) | undefined;
        onPointerleave?: ((...args: any[]) => any) | undefined;
        onPointermove?: ((...args: any[]) => any) | undefined;
    }, {
        readonly disabled: boolean;
        readonly command: import("element-plus/es/utils/index.js").EpPropMergeType<readonly [ObjectConstructor, StringConstructor, NumberConstructor], unknown, unknown>;
        readonly divided: boolean;
    }, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>>;
    ElIcon: import("element-plus/es/utils/index.js").SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly color: {
        readonly type: import("vue").PropType<string>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly color: {
        readonly type: import("vue").PropType<string>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly color: {
        readonly type: import("vue").PropType<string>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<import("vue").ExtractPropTypes<{
    readonly size: {
        readonly type: import("vue").PropType<import("element-plus/es/utils/index.js").EpPropMergeType<(new (...args: any[]) => string | number) | (() => string | number) | ((new (...args: any[]) => string | number) | (() => string | number))[], unknown, unknown>>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
    readonly color: {
        readonly type: import("vue").PropType<string>;
        readonly required: false;
        readonly validator: ((val: unknown) => boolean) | undefined;
        __epPropKey: true;
    };
}>>, unknown, unknown, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, {}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        default?: (props: {}) => any;
    };
} }>;
    ZxButton: any;
}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export declare const ZxActionBar: import("@zxio/shared").SFCWithInstall<Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    onAction?: ((action: import("./src/toolbar-actions").ZxToolbarAction) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    action: (action: import("./src/toolbar-actions").ZxToolbarAction) => any;
}, string, {
    label: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    onAction?: ((action: import("./src/toolbar-actions").ZxToolbarAction) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    action: (action: import("./src/toolbar-actions").ZxToolbarAction) => any;
}, string, {
    label: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    onAction?: ((action: import("./src/toolbar-actions").ZxToolbarAction) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    action: (action: import("./src/toolbar-actions").ZxToolbarAction) => any;
}, string, {
    label: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<Readonly<unknown> & Readonly<{
    onAction?: ((action: import("./src/toolbar-actions").ZxToolbarAction) => any) | undefined;
}>, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    action: (action: import("./src/toolbar-actions").ZxToolbarAction) => any;
}, string, {
    label: string;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        action?: (props: {
            action: any;
        }) => any;
    };
} }> & Record<string, any>;
export default ZxMoreAction;
export * from './src/props';
export * from './src/instance';
export type { ZxToolbarAction } from './src/toolbar-actions';
