import type List from './list.vue';
export type ZxListInstance = InstanceType<typeof List>;
