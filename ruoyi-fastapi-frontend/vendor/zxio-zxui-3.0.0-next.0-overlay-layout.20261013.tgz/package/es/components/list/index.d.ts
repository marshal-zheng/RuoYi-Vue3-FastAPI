import { type SFCWithInstall } from '@zxio/shared';
import ListComponent from './src/list.vue';
export declare const ZxList: SFCWithInstall<typeof ListComponent>;
export default ZxList;
export * from './src/props';
export type { ZxListInstance } from './src/instance';
