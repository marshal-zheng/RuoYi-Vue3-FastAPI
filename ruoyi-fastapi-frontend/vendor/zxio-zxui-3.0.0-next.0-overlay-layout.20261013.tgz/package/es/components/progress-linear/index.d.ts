import { type SFCWithInstall } from '@zxio/shared';
import ProgressLinear from './src/progress-linear.vue';
export declare const ZxProgressLinear: SFCWithInstall<typeof ProgressLinear>;
export default ZxProgressLinear;
export * from './src/props';
export type { ZxProgressLinearInstance } from './src/instance';
