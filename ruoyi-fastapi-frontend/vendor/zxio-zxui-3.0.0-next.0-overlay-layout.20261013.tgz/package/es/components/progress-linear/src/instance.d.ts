import type ProgressLinear from './progress-linear.vue';
export type ZxProgressLinearInstance = InstanceType<typeof ProgressLinear>;
