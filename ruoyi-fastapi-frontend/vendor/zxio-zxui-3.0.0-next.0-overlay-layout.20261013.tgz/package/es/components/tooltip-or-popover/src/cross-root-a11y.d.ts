export declare function repairCrossRootDescription(trigger: HTMLElement, portalTarget: HTMLElement | undefined, description: string): boolean;
