import type ZxTooltipOrPopover from './tooltip-or-popover.vue';
export type ZxTooltipOrPopoverInstance = InstanceType<typeof ZxTooltipOrPopover>;
