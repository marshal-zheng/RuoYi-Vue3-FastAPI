import { type SFCWithInstall } from '@zxio/shared';
import ZxTooltipOrPopoverComponent from './src/tooltip-or-popover.vue';
export declare const ZxTooltipOrPopover: SFCWithInstall<typeof ZxTooltipOrPopoverComponent>;
export default ZxTooltipOrPopover;
export * from './src/props';
export type { ZxTooltipOrPopoverInstance } from './src/instance';
