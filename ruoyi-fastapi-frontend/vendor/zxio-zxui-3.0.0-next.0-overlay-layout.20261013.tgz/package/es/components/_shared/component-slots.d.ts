import type { ComponentObjectPropsOptions, ComponentOptions, ComponentPublicInstance, EmitFn, EmitsOptions, EmitsToProps, ExtractPublicPropTypes, PublicProps } from 'vue';
/** Keep one public constructor when generated intersected constructors collapse
 * to any in consumer language tools. Runtime options and identity stay intact. */
export type SFCWithSlots<Props extends ComponentObjectPropsOptions, Emits extends EmitsOptions, Slots, Expose> = ComponentOptions<ExtractPublicPropTypes<Props> & EmitsToProps<Emits>> & {
    new (): Omit<ComponentPublicInstance, '$slots' | '$props' | '$emit'> & Expose & {
        $props: ExtractPublicPropTypes<Props> & EmitsToProps<Emits> & PublicProps;
        $slots: Slots;
        $emit: EmitFn<Emits>;
    };
};
