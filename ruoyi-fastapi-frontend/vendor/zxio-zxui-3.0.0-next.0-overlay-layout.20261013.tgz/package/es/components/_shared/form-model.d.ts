/** Detach Vue proxies, including nested proxies, before taking a snapshot. */
export declare function cloneFormModel<T>(model: T): T;
