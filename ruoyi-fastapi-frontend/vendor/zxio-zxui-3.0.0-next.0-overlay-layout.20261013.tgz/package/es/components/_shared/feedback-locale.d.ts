import type { Language } from '@zxio/hooks/use-locale';
/** Same locale override/fallback convention as Dialog's own labels. */
export declare function feedbackCloseLabel(channel: 'message' | 'notification', locale?: Language): string;
