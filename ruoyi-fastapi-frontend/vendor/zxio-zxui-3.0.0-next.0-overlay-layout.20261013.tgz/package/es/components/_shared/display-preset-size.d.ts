/** Named UI presets follow their owning scope; explicit lengths bypass this. */
export declare function useDisplayPresetSize(): (basePixels: number) => string | number;
