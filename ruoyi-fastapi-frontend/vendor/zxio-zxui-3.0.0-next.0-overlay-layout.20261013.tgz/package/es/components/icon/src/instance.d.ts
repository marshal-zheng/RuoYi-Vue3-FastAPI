export type ZxIconInstance = HTMLSpanElement & {};
