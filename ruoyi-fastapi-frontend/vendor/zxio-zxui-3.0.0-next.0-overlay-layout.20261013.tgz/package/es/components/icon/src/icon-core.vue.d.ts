import type { TooltipConfig } from './props';
declare var __VLS_40: {};
type __VLS_Slots = {} & {
    popoverContent?: (props: typeof __VLS_40) => any;
};
declare const __VLS_component: import("vue").DefineComponent<unknown, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {
    readonly name: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly disabled: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly size: import("@zxio/shared").EpPropMergeType<readonly [NumberConstructor, StringConstructor], unknown, unknown>;
    readonly icon: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component) | (((new (...args: any[]) => (string | import("vue").Component) & {}) | (() => string | import("vue").Component)) | null)[], unknown, unknown>;
    readonly color: string;
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | TooltipConfig) | (() => string | TooltipConfig) | (((new (...args: any[]) => string | TooltipConfig) | (() => string | TooltipConfig)) | null)[], unknown, unknown>;
    readonly hoverColor: string;
    readonly className: string;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & {
    $slots: S;
} };
