import { type SFCWithInstall } from '@zxio/shared';
import IconComponent from './src/icon.vue';
export declare const ZxIcon: SFCWithInstall<typeof IconComponent>;
export default ZxIcon;
export * from './src/props';
export type { ZxIconInstance } from './src/instance';
