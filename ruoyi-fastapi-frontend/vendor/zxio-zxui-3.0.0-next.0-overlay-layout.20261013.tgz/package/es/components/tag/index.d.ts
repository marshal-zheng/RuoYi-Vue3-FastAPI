import { type SFCWithInstall } from '@zxio/shared';
import TagComponent from './src/tag.vue';
export declare const ZxTag: SFCWithInstall<typeof TagComponent>;
export default ZxTag;
export * from './src/props';
export type { TagInstance as ZxTagInstance } from './src/instance';
