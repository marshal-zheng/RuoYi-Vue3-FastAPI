import type { ComponentPublicInstance } from 'vue';
import type { ZxTagProps } from './props';
export type TagInstance = ComponentPublicInstance<ZxTagProps>;
