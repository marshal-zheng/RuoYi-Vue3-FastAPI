import type { DeepReadonly, VNode } from 'vue';
import type { GridListState, GridListStateSnapshot } from './props';
import type { GridListLoadOptions } from './use-grid-request';
export type ZxGridListInstance = {
    loadData: (params?: Record<string, unknown>, options?: GridListLoadOptions) => Promise<void> | undefined;
    refresh: (options?: GridListLoadOptions) => Promise<void> | undefined;
    state: DeepReadonly<GridListState>;
    updateState: (key: string, value: unknown) => void;
    updateMultiState: (state: Partial<GridListState>) => void;
    clearTableSelection: () => void;
    getStateSnapshot: () => GridListStateSnapshot;
    renderTableEmpty: () => VNode;
};
