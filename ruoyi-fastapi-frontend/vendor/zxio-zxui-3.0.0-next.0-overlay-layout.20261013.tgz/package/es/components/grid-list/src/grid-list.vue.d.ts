import type { GridListStateSnapshot } from './props';
import type { MutableGridListState } from './use-grid-state';
declare var __VLS_1: {
    query: any;
    data: any;
    loading: any;
    refresh: any;
    updateState: any;
    updateMultiState: any;
}, __VLS_3: {
    grid: any;
    loading: any;
    refresh: any;
    updateState: any;
    updateMultiState: any;
    hasData: any;
    isEmpty: boolean;
    emptySlot: any;
    renderEmpty: any;
}, __VLS_5: {
    error: any;
    retry: any;
}, __VLS_7: {
    refresh: any;
    error: any;
    isError: any;
}, __VLS_12: {}, __VLS_30: {
    pager: any;
};
type __VLS_Slots = {} & {
    form?: (props: typeof __VLS_1) => any;
} & {
    table?: (props: typeof __VLS_3) => any;
} & {
    error?: (props: typeof __VLS_5) => any;
} & {
    empty?: (props: typeof __VLS_7) => any;
} & {
    emptyImage?: (props: typeof __VLS_12) => any;
} & {
    pagination?: (props: typeof __VLS_30) => any;
};
declare const __VLS_component: import("vue").DefineComponent<unknown, {
    loadData: (params?: Record<string, any>, loadOptions?: import("./use-grid-request").GridListLoadOptions) => Promise<void> | undefined;
    refresh: (loadOptions?: import("./use-grid-request").GridListLoadOptions) => Promise<void> | undefined;
    state: {
        readonly [x: string]: any;
        readonly query: {
            readonly [x: string]: any;
        };
        readonly pager: {
            readonly page: number;
            readonly size: number;
            readonly total: number;
        };
        readonly list: readonly any[];
        readonly loading: boolean;
        readonly error: Readonly<unknown>;
        readonly lastLoadTime: number | null;
        readonly silent: boolean;
    };
    updateState: (key: string, value: any) => void;
    updateMultiState: (newState: Partial<MutableGridListState>) => void;
    clearTableSelection: () => void;
    getStateSnapshot: () => GridListStateSnapshot;
    renderTableEmpty: () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
        [key: string]: any;
    }>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    readonly small: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly fill: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly initialState: Partial<import("./props").GridListState<Record<string, any>, any>>;
    readonly showPagination: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly pageSizes: unknown[];
    readonly paginationLayout: string;
    readonly paginationBackground: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly loadOnMounted: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly queryTransform: Function;
    readonly paramsTransform: Function;
    readonly autoRefresh: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig) | (((new (...args: any[]) => boolean | import("./props").GridListAutoRefreshConfig) | (() => boolean | import("./props").GridListAutoRefreshConfig)) | null)[], unknown, unknown>;
    readonly clearSelectionOnLoad: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly syncUrlState: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly urlStateKey: string;
    readonly pageFrom0: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly debounceDelay: number;
    readonly defaultPageSize: number;
    readonly emptyDescription: string;
    readonly emptyImage: string;
    readonly emptyImageSize: import("@zxio/shared").EpPropMergeType<readonly [StringConstructor, NumberConstructor], unknown, unknown>;
    readonly showRefreshButton: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly showTableBorder: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & {
    $slots: S;
} };
