import { type SFCWithInstall } from '@zxio/shared';
import FlexView from './src/flex-view.vue';
export declare const ZxFlexView: SFCWithInstall<typeof FlexView>;
export default ZxFlexView;
export * from './src/props';
export type { ZxFlexViewInstance } from './src/instance';
