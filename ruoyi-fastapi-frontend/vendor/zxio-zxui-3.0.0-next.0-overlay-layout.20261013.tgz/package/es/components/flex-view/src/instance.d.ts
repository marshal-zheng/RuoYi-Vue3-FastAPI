import type FlexView from './flex-view.vue';
export type ZxFlexViewInstance = InstanceType<typeof FlexView>;
