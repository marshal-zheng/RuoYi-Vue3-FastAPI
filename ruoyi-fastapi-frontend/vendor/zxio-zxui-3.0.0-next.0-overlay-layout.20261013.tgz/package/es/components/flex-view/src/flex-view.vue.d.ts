import type { CSSProperties } from 'vue';
declare const _default: import("vue").DefineComponent<unknown, {
    ns: {
        namespace: import("vue").ComputedRef<string>;
        b: (blockSuffix?: string) => string;
        e: (element?: string) => string;
        m: (modifier?: string) => string;
        be: (blockSuffix?: string, element?: string) => string;
        em: (element?: string, modifier?: string) => string;
        bm: (blockSuffix?: string, modifier?: string) => string;
        bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
        is: {
            (name: string, state: boolean | undefined): string;
            (name: string): string;
        };
        cssVar: (object: Record<string, string>) => Record<string, string>;
        cssVarName: (name: string) => string;
        cssVarBlock: (object: Record<string, string>) => Record<string, string>;
        cssVarBlockName: (name: string) => string;
    };
    flexStyle: import("vue").ComputedRef<CSSProperties>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{}>, {
    readonly column: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly wrap: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly shrink: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => number | boolean) | (() => number | boolean) | (((new (...args: any[]) => number | boolean) | (() => number | boolean)) | null)[], unknown, unknown>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default _default;
