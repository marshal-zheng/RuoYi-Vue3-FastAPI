import { type SFCWithInstall } from '@zxio/shared';
import Sparkline from './src/sparkline.vue';
export declare const ZxSparkline: SFCWithInstall<typeof Sparkline>;
export default ZxSparkline;
export * from './src/props';
export type { ZxSparklineInstance } from './src/instance';
