import type Sparkline from './sparkline.vue';
export type ZxSparklineInstance = InstanceType<typeof Sparkline>;
