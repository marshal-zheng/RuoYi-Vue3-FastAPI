import type { ComponentPublicInstance } from 'vue';
import type { ZxDialogProps } from './props';
export interface ZxDialogExpose {
    open: () => void;
    close: () => Promise<void>;
    cancel: () => Promise<void>;
    submit: () => Promise<void>;
    validate: () => Promise<boolean>;
    resetForm: () => void;
    scrollToFirstError: () => void;
    prev: () => void;
    next: () => Promise<void>;
    toggleFullscreen: () => void;
    readonly isFullscreen: boolean;
    readonly isDirty: boolean;
    readonly isSubmitting: boolean;
    readonly currentStep: number;
    readonly isFirstStep: boolean;
    readonly isLastStep: boolean;
    /** @deprecated Submission state settles automatically; this is a compatibility no-op. */
    resetSubmitting: () => void;
}
export type ZxDialogInstance = ComponentPublicInstance<ZxDialogProps> & ZxDialogExpose;
