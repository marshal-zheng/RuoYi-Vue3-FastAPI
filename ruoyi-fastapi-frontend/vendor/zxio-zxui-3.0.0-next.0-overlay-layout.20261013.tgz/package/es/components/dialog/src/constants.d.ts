export { BUTTON_KEYS } from '../../_shared/footer-buttons';
export type { FooterButtonConfig, StepEventParams, } from '../../_shared/footer-buttons';
export type DialogSize = 'sm' | 'md' | 'lg' | 'xl' | 'small' | 'large';
export type DialogCloseReason = 'cancel' | 'close';
export interface DialogDescriptionItem {
    label: string;
    value?: unknown;
}
export interface DialogConfirmContext {
    /** Explicitly finish this session; bypasses dismissal guards. */
    close: () => void;
    setLoading: (loading: boolean) => void;
    setDisabled: (disabled: boolean) => void;
    setTitle: (title: string) => void;
    readonly isFullscreen: boolean;
    readonly isDirty: boolean;
}
export type DialogConfirm = (context: DialogConfirmContext) => unknown | Promise<unknown>;
export type DialogDirtyGuard = (context: DialogConfirmContext) => boolean | Promise<boolean>;
export type DialogBeforeClose = (done: (cancel?: boolean) => void) => void | Promise<void>;
export declare const DIALOG_SIZE_PRESETS: Readonly<{
    sm: 440;
    md: 640;
    lg: 880;
    xl: 1120;
    small: 440;
    large: 880;
}>;
export declare const DIALOG_PRIMARY_BUTTON_KEYS: ReadonlySet<string>;
/** Only these declared props belong to Element Plus. All other props are wrapper-owned. */
export declare const DIALOG_FORWARDED_PROPS: readonly ["showClose", "modal", "modalClass", "closeOnClickModal", "closeOnPressEscape", "destroyOnClose"];
export declare const DIALOG_INTERACTIVE_SELECTOR = "button,a,input,textarea,select,[contenteditable]:not([contenteditable=\"false\"]),[role=\"button\"],[role=\"combobox\"],[role=\"slider\"],[data-drag-exclude]";
