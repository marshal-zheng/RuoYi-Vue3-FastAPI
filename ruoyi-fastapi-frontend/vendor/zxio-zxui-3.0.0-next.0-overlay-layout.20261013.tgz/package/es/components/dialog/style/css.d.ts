import '@zxio/zxui/style.css/dialog.css';
