export declare function resetZIndex(seed?: number): void;
export declare function allocateZIndex(seed?: number): number;
