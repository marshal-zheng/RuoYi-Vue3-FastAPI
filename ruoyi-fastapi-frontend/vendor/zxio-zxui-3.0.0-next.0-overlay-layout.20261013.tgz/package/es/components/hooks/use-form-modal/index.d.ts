import type { ComputedRef, Ref } from 'vue';
import type { FooterButtonConfig, FormModalMessages, FormModalProps } from '@zxio/constants/form-modal';
type EmitFn = (event: string, ...args: unknown[]) => void;
type MaybeRef<T> = T | Ref<T>;
export interface UseFormModalOptions<P extends FormModalProps = FormModalProps> {
    props: P;
    emit: EmitFn;
    visible: Ref<boolean>;
    scrollToFirstError?: () => void;
    confirmRunner?: () => Promise<unknown>;
    onSaveSuccess?: () => void;
    onCancel?: () => void | Promise<void>;
    /** Localized footer copy; falls back to the built-in Chinese defaults. */
    messages?: () => Partial<FormModalMessages>;
    /** Extra disabled source merged into `isDisabled` (for example a confirm context). */
    extraDisabled?: MaybeRef<boolean>;
    /** Replacing an open draft starts a new transaction even without closing. */
    session?: () => unknown;
}
export interface UseFormModalReturn {
    normalizedButtons: ComputedRef<FooterButtonConfig[]>;
    isSubmitting: Ref<boolean>;
    isDisabled: ComputedRef<boolean>;
    /** True when `formModel` differs from the snapshot taken on open. */
    isDirty: ComputedRef<boolean>;
    handlePrev: () => void;
    handleNext: () => Promise<void>;
    handleContinue: () => void;
    handleSave: () => Promise<void>;
    handleOk: () => Promise<void>;
    onButtonClick: (button: FooterButtonConfig) => Promise<void>;
    snapshotFormModel: () => void;
    resetForm: () => void;
    executeSave: () => Promise<void>;
    resetSteps: (value?: number) => void;
    validateCurrentStep: () => Promise<boolean>;
    currentStepValue: ComputedRef<number>;
    isFirstStep: ComputedRef<boolean>;
    isLastStep: ComputedRef<boolean>;
}
export declare function useFormModal<P extends FormModalProps>(options: UseFormModalOptions<P>): UseFormModalReturn;
export {};
