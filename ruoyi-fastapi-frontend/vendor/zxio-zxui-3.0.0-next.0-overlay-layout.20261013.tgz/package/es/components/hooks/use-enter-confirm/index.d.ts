import type { Ref } from 'vue';
type MaybeRef<T> = T | Ref<T>;
export interface UseEnterConfirmOptions {
    confirm: () => void | Promise<void>;
    disabled?: MaybeRef<boolean>;
    loading?: MaybeRef<boolean>;
    excludeSelector?: string;
}
export declare const useEnterConfirm: (options: UseEnterConfirmOptions) => {
    handleEnterKey: (event: KeyboardEvent) => void;
};
export {};
