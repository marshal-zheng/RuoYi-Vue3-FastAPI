import { type SFCWithInstall } from '@zxio/shared';
import UploadComponent from './src/upload.vue';
export declare const ZxUpload: SFCWithInstall<typeof UploadComponent>;
export default ZxUpload;
export * from './src/props';
export type { ZxUploadInstance } from './src/instance';
