export type ZxUploadInstance = {
    submit: () => void;
    clearFiles: () => void;
    abort: (file?: any) => void;
};
