declare var __VLS_14: {}, __VLS_19: {}, __VLS_21: {}, __VLS_32: {}, __VLS_37: {};
type __VLS_Slots = {} & {
    default?: (props: typeof __VLS_14) => any;
} & {
    loading?: (props: typeof __VLS_19) => any;
} & {
    'tooltip-content'?: (props: typeof __VLS_21) => any;
} & {
    default?: (props: typeof __VLS_32) => any;
} & {
    loading?: (props: typeof __VLS_37) => any;
};
declare const __VLS_component: import("vue").DefineComponent<unknown, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, import("vue").PublicProps, any, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
declare const _default: __VLS_WithSlots<typeof __VLS_component, __VLS_Slots>;
export default _default;
type __VLS_WithSlots<T extends abstract new (...args: never[]) => { $props: unknown }, S> = Omit<T, never> & { new (...args: ConstructorParameters<T>): Omit<InstanceType<T>, '$slots'> & Pick<InstanceType<T>, '$props'> & {
    $slots: S;
} };
