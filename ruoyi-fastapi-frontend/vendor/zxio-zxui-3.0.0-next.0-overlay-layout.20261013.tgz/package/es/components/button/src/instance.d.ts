import type ZxButton from './button.vue';
export type ZxButtonInstance = InstanceType<typeof ZxButton>;
