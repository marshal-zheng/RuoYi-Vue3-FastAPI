declare const _default: Omit<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps, never> & { new (...args: ConstructorParameters<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>): Omit<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$slots'> & Pick<InstanceType<{
    new (...args: any[]): any;
    __isFragment?: never;
    __isTeleport?: never;
    __isSuspense?: never;
} & import("vue").ComponentOptionsBase<any, {}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, any, string, {
    readonly tooltip: import("@zxio/shared").EpPropMergeType<(new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>) | (((new (...args: any[]) => string | Record<string, any>) | (() => string | Record<string, any>)) | null)[], unknown, unknown>;
    readonly debounce: number;
    readonly throttle: number;
    readonly enableLoading: import("@zxio/shared").EpPropMergeType<BooleanConstructor, unknown, unknown>;
    readonly iconRight: string;
    readonly iconRightProps: Record<string, any>;
}, {}, string, {}, import("vue").GlobalComponents, import("vue").GlobalDirectives, string, import("vue").ComponentProvideOptions> & import("vue").VNodeProps & import("vue").AllowedComponentProps & import("vue").ComponentCustomProps>, '$props'> & {
    $slots: {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    } & {
        'tooltip-content'?: (props: {}) => any;
    } & {
        default?: (props: {}) => any;
    } & {
        loading?: (props: {}) => any;
    };
} };
export default _default;
