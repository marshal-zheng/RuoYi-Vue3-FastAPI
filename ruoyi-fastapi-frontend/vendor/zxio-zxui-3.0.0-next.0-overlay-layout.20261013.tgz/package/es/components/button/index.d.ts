import { type SFCWithInstall } from '@zxio/shared';
export declare const ZxButton: SFCWithInstall<any>;
export default ZxButton;
export * from './src/props';
export type { ZxButtonInstance } from './src/instance';
