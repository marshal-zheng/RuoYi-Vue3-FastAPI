import { type SFCWithInstall } from '@zxio/shared';
import DatePicker from './src/date-picker';
import type { DatePickerInstance } from 'element-plus';
export declare const ZxDatePicker: SFCWithInstall<typeof DatePicker>;
export default ZxDatePicker;
export { datePickerProps as zxDatePickerProps } from 'element-plus';
export type { DatePickerPropsPublic as ZxDatePickerProps } from 'element-plus';
export type ZxDatePickerInstance = Pick<DatePickerInstance, 'focus' | 'blur' | 'handleOpen' | 'handleClose'>;
