import { type SFCWithInstall } from '@zxio/shared';
import SelectComponent from './src/select.vue';
export declare const ZxSelect: SFCWithInstall<typeof SelectComponent>;
export default ZxSelect;
export * from './src/props';
export type { ZxSelectInstance } from './src/instance';
