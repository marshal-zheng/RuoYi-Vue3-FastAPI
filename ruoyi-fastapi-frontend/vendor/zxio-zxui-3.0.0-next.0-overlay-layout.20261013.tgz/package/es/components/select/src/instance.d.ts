export type ZxSelectInstance = HTMLDivElement & {};
