export declare const componentKeyboardEnabled: import("@zxio/keybindings/core").ContextKey<true>;
export declare const contentWrapSaveAction: import("@zxio/keybindings/core").ActionToken<void, void>;
export declare const contentWrapCancelAction: import("@zxio/keybindings/core").ActionToken<void, void>;
export declare const overlayFullscreenAction: import("@zxio/keybindings/core").ActionToken<void, void>;
export declare const searchFocusAction: import("@zxio/keybindings/core").ActionToken<void, void>;
export declare const componentShortcuts: import("@zxio/keybindings/core").ShortcutContribution;
