import type { IconCategory, IconMeta, IconSearchPlacement, IconSelectStorage, IconSource, IconTabMode } from './props';
type __VLS_Props = {
    modelValue?: string;
    sources?: IconSource[];
    iconifyCollections?: string[];
    customIcons?: IconMeta[];
    tabMode?: IconTabMode;
    searchPlacement?: IconSearchPlacement;
    showTabs?: boolean;
    categories?: IconCategory[];
    recentKey?: string;
    recentKeyPrefix?: string;
    recentStorage?: IconSelectStorage;
    recentScope?: 'global' | 'source' | 'category' | 'custom';
    recentScopeKey?: string;
    recentScopeResolver?: (icon: IconMeta) => string;
    recentSaveStrategy?: 'select' | 'confirm' | 'close';
    confirmText?: string;
    columns?: number;
    itemHeight?: number;
    panelHeight?: number;
    searchable?: boolean;
    showRecent?: boolean;
    showFooter?: boolean;
    recentMax?: number;
    allowModeSwitch?: boolean;
    panelMode?: 'popover' | 'dialog';
};
/**
 * 重置滚动位置
 */
declare function resetScroll(): void;
declare const _default: import("vue").DefineComponent<{} | __VLS_Props, {
    focusSearch: () => void;
    resetScroll: typeof resetScroll;
    setSearchValue: (value: string) => void;
    clearSearchValue: () => void;
    commitRecent: () => void;
    filteredCount: import("vue").ComputedRef<number>;
}, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {} & {
    [x: string]: never;
}, string, import("vue").PublicProps, Readonly<{} | __VLS_Props> & Readonly<{
    [x: `on${Capitalize<any>}`]: ((...args: unknown[]) => any) | undefined;
}>, {}, {}, {}, {}, string, import("vue").ComponentProvideOptions, false, {}, any>;
export default _default;
