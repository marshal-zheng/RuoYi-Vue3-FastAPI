import type IconSelect from './icon-select.vue';
export type ZxIconSelectInstance = InstanceType<typeof IconSelect>;
