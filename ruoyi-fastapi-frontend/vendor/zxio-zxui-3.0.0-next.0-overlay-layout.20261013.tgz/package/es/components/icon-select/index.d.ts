import { type SFCWithInstall } from '@zxio/shared';
import IconSelect from './src/icon-select.vue';
export declare const ZxIconSelect: SFCWithInstall<typeof IconSelect>;
export default ZxIconSelect;
export * from './src/props';
export type { ZxIconSelectInstance } from './src/instance';
