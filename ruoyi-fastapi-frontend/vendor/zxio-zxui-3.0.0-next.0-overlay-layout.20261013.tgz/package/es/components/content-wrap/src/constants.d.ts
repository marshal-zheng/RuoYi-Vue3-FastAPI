/**
 * Content Wrap 组件常量定义
 * 消除 magic strings，提高代码可维护性
 */
/** 按钮 key 常量 */
export declare const BUTTON_KEYS: {
    readonly SAVE: "save";
    readonly SUBMIT: "submit";
    readonly CANCEL: "cancel";
    readonly PREV: "prev";
    readonly NEXT: "next";
};
/** CSS 类名常量 */
export declare const CSS_CLASSES: {
    readonly HAS_FIXED_FOOTER: "has-fixed-footer";
};
/** Element Plus 选择器 */
export declare const SELECTORS: {
    readonly FORM_ERROR: ".el-form-item.is-error";
};
export type ButtonKey = (typeof BUTTON_KEYS)[keyof typeof BUTTON_KEYS];
