import type { ComponentPublicInstance } from 'vue';
import type { ContentWrapInstance, ContentWrapPublicProps } from './props';
export type ZxContentWrapInstance = ComponentPublicInstance<ContentWrapPublicProps> & ContentWrapInstance;
