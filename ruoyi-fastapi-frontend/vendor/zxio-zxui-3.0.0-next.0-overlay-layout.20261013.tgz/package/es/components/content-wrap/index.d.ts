import { type SFCWithInstall } from '@zxio/shared';
import ContentWrapComponent from './src/content-wrap.vue';
import type { ContentWrapPublicProps } from './src/props';
type OriginalInstance = InstanceType<typeof ContentWrapComponent>;
type PublicComponent = Omit<typeof ContentWrapComponent, 'props'> & {
    new (): Omit<OriginalInstance, '$props'> & {
        $props: Omit<OriginalInstance['$props'], keyof ContentWrapPublicProps | 'onSave' | 'onSaveStart'> & ContentWrapPublicProps;
    };
};
export declare const ZxContentWrap: SFCWithInstall<PublicComponent>;
export default ZxContentWrap;
export * from './src/props';
export * from './src/save-controller';
export type { ZxContentWrapInstance } from './src/instance';
