import type { ComponentPublicInstance } from 'vue';
import type { ZxDrawerProps } from './props';
/**
 * Methods and state reachable through a template ref. Refs are unwrapped on
 * the public instance, so the state members read as plain values.
 */
export interface ZxDrawerExpose {
    open: () => void;
    close: () => Promise<void>;
    toggleFullScreen: () => void;
    resetForm: () => void;
    scrollToFirstError: () => void;
    /** Sets the cross-axis size in px (clamped to the resizable bounds). */
    resize: (size: number) => void;
    /** Returns to the size derived from the `size` prop and clears persistence. */
    resetSize: () => void;
    readonly isFullScreen: boolean;
    readonly confirmLoading: boolean;
    readonly isDirty: boolean;
}
export type ZxDrawerInstance = ComponentPublicInstance<ZxDrawerProps> & ZxDrawerExpose;
