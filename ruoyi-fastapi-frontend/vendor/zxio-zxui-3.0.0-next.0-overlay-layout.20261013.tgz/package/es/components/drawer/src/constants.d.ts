export type DrawerPlacement = 'left' | 'right' | 'top' | 'bottom';
export type DrawerDirection = 'ltr' | 'rtl' | 'ttb' | 'btt';
export type DrawerSizePreset = 'sm' | 'md' | 'lg' | 'xl' | 'full';
export type DrawerMode = 'modal' | 'inline' | 'push';
export type DrawerMobileFallback = 'none' | 'full' | 'bottom-sheet';
export type DrawerResizeSource = 'pointer' | 'keyboard' | 'reset' | 'api';
export type DrawerCloseReason = 'confirm' | 'cancel' | 'close';
export interface DrawerResizableOptions {
    /** Smallest size in px along the drawer's cross axis. */
    min?: number;
    /** Largest size in px; defaults to 95% of the viewport. */
    max?: number;
    /** Keyboard step in px (Shift multiplies by 4). Defaults to 16. */
    step?: number;
    /** When set, the last user size is stored in localStorage under this key. */
    persistKey?: string;
}
export interface DrawerResizePayload {
    size: number;
    source: DrawerResizeSource;
}
export interface DrawerDescriptionItem {
    label: string;
    value?: unknown;
}
export interface DrawerConfirmContext {
    close: () => void;
    setLoading: (loading: boolean) => void;
    setDisabled: (disabled: boolean) => void;
    setTitle: (title: string) => void;
    readonly isFullScreen: boolean;
    readonly isDirty: boolean;
}
export type DrawerDirtyGuard = (context: DrawerConfirmContext) => boolean | Promise<boolean>;
/** Preset cross-axis sizes in px, per axis. `full` resolves to 100%. */
export declare const DRAWER_SIZE_PRESETS: Readonly<{
    horizontal: Readonly<{
        sm: 400;
        md: 560;
        lg: 760;
        xl: 960;
    }>;
    vertical: Readonly<{
        sm: 280;
        md: 400;
        lg: 560;
        xl: 720;
    }>;
}>;
export declare const DRAWER_SIZE_PRESET_KEYS: readonly DrawerSizePreset[];
export declare const DRAWER_MODES: readonly DrawerMode[];
export declare const DRAWER_MOBILE_FALLBACKS: readonly DrawerMobileFallback[];
/** Offset applied to a parent drawer while a nested drawer is open. */
export declare const DRAWER_PUSH_OFFSET = 180;
/** Viewport query under which the mobile fallback applies. */
export declare const DRAWER_MOBILE_QUERY = "(max-width: 768px)";
export declare const DRAWER_DEFAULT_PUSH_TARGET = "[data-zx-push-host]";
export declare const DRAWER_SIZE_STORAGE_PREFIX = "zx-drawer:size:";
/** Footer keys whose button reflects the confirm loading state. */
export declare const DRAWER_PRIMARY_BUTTON_KEYS: ReadonlySet<string>;
/**
 * Props declared on ZxDrawer that Element Plus also understands and that are
 * forwarded verbatim. Everything else declared in `zxDrawerProps` is owned by
 * the wrapper; undeclared attrs are forwarded as well.
 */
export declare const DRAWER_FORWARDED_PROPS: readonly string[];
/** Attrs consumed by the wrapper and therefore not forwarded to `el-drawer`. */
export declare const DRAWER_CONSUMED_ATTRS: ReadonlySet<string>;
export declare const DRAWER_DOCS_URL = "/zh-CN/component/drawer";
