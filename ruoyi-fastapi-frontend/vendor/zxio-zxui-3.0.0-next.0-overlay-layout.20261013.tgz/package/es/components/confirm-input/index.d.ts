declare const Comp: any;
export default Comp;
export declare const ZxConfirmInput: any;
export * from './src/props';
export { createBoundConfirmInputFactory } from './src/service';
export type { BoundConfirmInputFactory, BoundConfirmInputHandle, BoundConfirmInputOptions, } from './src/service';
