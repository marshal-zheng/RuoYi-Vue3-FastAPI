import { type SFCWithInstall } from '@zxio/shared';
import PageLayout from './src/page-layout.vue';
export declare const ZxPageLayout: SFCWithInstall<typeof PageLayout>;
export default ZxPageLayout;
export * from './src/props';
export type ZxPageLayoutInstance = InstanceType<typeof PageLayout>;
