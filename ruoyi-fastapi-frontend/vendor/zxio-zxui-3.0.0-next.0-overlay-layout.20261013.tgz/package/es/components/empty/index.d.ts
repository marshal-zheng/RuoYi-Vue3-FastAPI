import { type SFCWithInstall } from '@zxio/shared';
import Empty from './src/empty.vue';
export declare const ZxEmpty: SFCWithInstall<typeof Empty>;
export default ZxEmpty;
export * from './src/props';
export type { ZxEmptyInstance } from './src/instance';
