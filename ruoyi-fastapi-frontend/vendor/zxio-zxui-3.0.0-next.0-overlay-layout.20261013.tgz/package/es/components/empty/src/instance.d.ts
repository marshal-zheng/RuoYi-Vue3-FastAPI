import type { ComponentPublicInstance } from 'vue';
export type ZxEmptyInstance = ComponentPublicInstance;
