export declare const ZxNotification: import("@zxio/shared").SFCWithInstall<import("vue").DefineComponent<unknown, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, {
    close: () => true;
    click: (_event: MouseEvent) => true;
}, string, import("vue").PublicProps, Readonly<unknown> & Readonly<{
    onClick?: ((_event: MouseEvent) => any) | undefined;
    onClose?: (() => any) | undefined;
}>, {
    title: any;
    type: import("element-plus/es/utils").EpPropMergeType<StringConstructor, "" | "primary" | "success" | "warning" | "info" | "error", unknown>;
    message: any;
    dangerouslyUseHTMLString: any;
    icon: any;
    showClose: boolean;
    appearance: any;
    action: any;
    closeLabel: any;
    customStyle: any;
    announce: any;
}, import("vue").SlotsType<import("./src/types").ZxNotificationSlots>, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>> & Record<string, any>;
export default ZxNotification;
export type { ZxNotificationConfig, ZxNotificationOptions, ZxNotificationParams, ZxNotificationSlots, } from './src/types';
