import { type SFCWithInstall } from '@zxio/shared';
import FloatingPanel from './src/floating-panel.vue';
export declare const ZxFloatingPanel: SFCWithInstall<typeof FloatingPanel>;
export default ZxFloatingPanel;
export * from './src/props';
export type { ZxFloatingPanelInstance } from './src/instance';
