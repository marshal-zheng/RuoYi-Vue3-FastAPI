export { default } from '../components/icon/index';
export * from '../components/icon/index';
