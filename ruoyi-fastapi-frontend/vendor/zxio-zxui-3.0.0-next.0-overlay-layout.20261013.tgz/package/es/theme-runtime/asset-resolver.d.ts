import type { ManifestIdentity, ThemeStylesheetLoadPlanEntry } from './adapter-contract';
import type { ThemeRuntimeResult } from './result';
export type ResolvedThemeAsset = Readonly<{
    kind: 'external-link';
    url: string;
    integrity: string;
    sha256: string;
}> | Readonly<{
    kind: 'css-text';
    text: string;
    sha256: string;
}>;
export interface ThemeAssetResolveInput {
    readonly manifestIdentity: ManifestIdentity;
    readonly entry: ThemeStylesheetLoadPlanEntry;
    readonly signal: AbortSignal;
}
export interface ThemeAssetResolver {
    resolve(input: ThemeAssetResolveInput): Promise<ThemeRuntimeResult<ResolvedThemeAsset>>;
}
export type UnverifiedThemeAsset = Readonly<{
    kind: 'external-link';
    url: string;
    integrity: string;
}> | Readonly<{
    kind: 'css-text';
    text: string;
}>;
export interface ThemePublicExportResolver {
    resolve(input: {
        readonly packageName: string;
        readonly packageVersion: string;
        readonly exportPath: string;
        readonly signal: AbortSignal;
    }): Promise<ThemeRuntimeResult<UnverifiedThemeAsset>>;
}
export interface ThemeAssetResolverOptions {
    readonly exports: ThemePublicExportResolver;
    readonly digestText?: (text: string) => Promise<string>;
}
export declare function createThemeAssetResolver({ exports, digestText: hashText, }: ThemeAssetResolverOptions): ThemeAssetResolver;
