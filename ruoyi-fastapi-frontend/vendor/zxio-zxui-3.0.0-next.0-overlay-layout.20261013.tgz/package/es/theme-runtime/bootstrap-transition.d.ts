import type { ThemeRuntimeDiagnostic } from './diagnostics';
import type { ThemeRuntimeResult } from './result';
import type { ThemeScopeRequest } from './selection-resolver';
export type ThemeInitializationPhase = 'adopting' | 'transitioning' | 'active' | 'held-failure' | 'disposed';
export interface ThemeBootstrapTransitionInput {
    readonly rootRequest: ThemeScopeRequest;
    readonly systemMode: 'light' | 'dark';
    readonly signal?: AbortSignal;
}
/**
 * What the transition needs from the runtime. Scope records never cross this
 * boundary: the runtime keeps ownership of its tree and exposes only the three
 * operations the bootstrap sequence performs on it.
 */
export interface BootstrapRuntimePort {
    isActive(): boolean;
    phase(): ThemeInitializationPhase;
    setPhase(phase: ThemeInitializationPhase): void;
    /** Hydration completion is one-way; the transition never clears it. */
    markHydrationComplete(): void;
    frozenSystemMode(): 'light' | 'dark' | null;
    setFrozenSystemMode(mode: 'light' | 'dark' | null): void;
    systemMode(): 'light' | 'dark';
    /** System mode recorded by SSR, or null when this runtime did not hydrate. */
    snapshotSystemMode(): 'light' | 'dark' | null;
    selectionSystemMode(): 'light' | 'dark';
    validateAdoptedScopes(): ThemeRuntimeResult<void>;
    clearPendingHydrationReconcile(): void;
    /** True only when the root scope exists, is mounted and has been published. */
    hasCommittedRoot(): boolean;
    transitionRoot(request: ThemeScopeRequest, systemMode: 'light' | 'dark', controller: AbortController): Promise<ThemeRuntimeResult<void>>;
    /** No-op when the root is gone; reconciles one observed system change. */
    scheduleSystemRefresh(): void;
    notifyConsumptionReady(): void;
    recordDiagnostics(diagnostics: readonly ThemeRuntimeDiagnostic[]): void;
}
export interface BootstrapTransition {
    /** Resolves once the runtime leaves `adopting`/`transitioning`. */
    wait(): Promise<void>;
    releaseWaiters(): void;
    /** Aborts an in-flight transition; used by runtime disposal. */
    abort(): void;
    hold(): ThemeRuntimeResult<void>;
    releaseSystem(): ThemeRuntimeResult<void>;
    transition(input: ThemeBootstrapTransitionInput): Promise<ThemeRuntimeResult<void>>;
}
export declare function createBootstrapTransition(port: BootstrapRuntimePort): BootstrapTransition;
