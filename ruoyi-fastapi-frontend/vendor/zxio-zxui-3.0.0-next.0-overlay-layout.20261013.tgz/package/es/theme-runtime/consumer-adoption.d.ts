import type { ThemeConsumerCssInput, ThemeConsumerLease, ThemeConsumerPortalSnapshot, ThemeConsumerResourceState, ThemeConsumerResult } from '@zxio/theme-consumer';
import type { PortalBinding as PublicPortalBinding, PreparedThemeScope as PublicPreparedThemeScope } from '../components/theme-provider/index';
import type { AdapterContractPort, ThemeStylesheetPolicy } from './adapter-contract';
import type { ThemeScopeIdentity } from './composition-contract';
import type { ValidatedCompositionHydration } from './composition-hydration';
import type { CompositionOwner } from './composition-owner';
import type { ValidatedConsumerHydration } from './consumer-hydration';
import type { ConsumerClaims } from './runtime-foundation';
import type { ThemeRuntimeId, ThemeScopeId } from './contracts';
import type { ThemeRuntimeDiagnostic } from './diagnostics';
import type { ThemeHydrationSnapshotV1 } from './hydration-schema';
import type { ThemeManifestRegistry } from './manifest-registry';
import type { PortalRegistry, PortalScopeSnapshot } from './portal-registry';
import type { ThemeRuntimeResult } from './result';
import type { ResolvedThemeState, ScopeRecord, ThemeScopeHandle } from './scope-record';
import type { ThemeSelectionResolution } from './selection-resolver';
import type { StylesheetRegistry } from './stylesheet-registry';
export interface CompositionTargetBinding {
    scopeId: ThemeScopeId;
    adapterId: string;
    consumerId?: string;
    releaseCore: () => void;
}
/**
 * Everything the consumer adoption transaction reaches for inside the runtime.
 *
 * It is deliberately wide: completing consumer hydration commits the very same
 * scope records the normal activation path commits, so the two share the
 * runtime's scope bookkeeping rather than a narrow value contract. Narrowing
 * this port means first extracting a shared scope-adoption primitive; until
 * then the width is an honest description of the coupling, not a disguise for
 * it.
 */
export interface ConsumerAdoptionHost {
    readonly runtimeId: ThemeRuntimeId;
    readonly registry: ThemeManifestRegistry;
    readonly defaultThemeId: string;
    readonly contract: AdapterContractPort;
    readonly policy: ThemeStylesheetPolicy;
    readonly stylesheet: StylesheetRegistry;
    readonly portal: PortalRegistry;
    readonly compositionOwner: CompositionOwner;
    readonly compositionTargets: Map<HTMLElement, CompositionTargetBinding>;
    hydrationSnapshot(): ThemeHydrationSnapshotV1 | null;
    hydrationStylesheetElements(): readonly HTMLElement[];
    hydrationStylesheetOwnership(): 'transferred' | 'external';
    compositionHydration(): ValidatedCompositionHydration | null;
    hydrationComplete(): boolean;
    scope(scopeId: string): ScopeRecord | undefined;
    rootPreparedScopeId(): string | null;
    managedCoreProperties(themeId: string): readonly string[];
    portalScope(record: ScopeRecord, resolved: ResolvedThemeState | null, root: HTMLElement): PortalScopeSnapshot;
    publish(record: ScopeRecord, resolution: ThemeSelectionResolution, notify: boolean): ThemeScopeHandle;
    trackHydratedSystem(record: ScopeRecord): void;
    emitScope(record: ScopeRecord, handle: ThemeScopeHandle): void;
    holdFailure(): void;
    recordDiagnostics(diagnostics: readonly ThemeRuntimeDiagnostic[]): void;
}
export interface ConsumerAdoptionState {
    readonly hydration: ValidatedConsumerHydration | null;
    readonly claims: ConsumerClaims | null;
    readonly preflight: (() => ValidatedConsumerHydration) | null;
}
export interface ConsumerAdoption {
    /** True while consumer claims exist and hydration has not completed. */
    readonly active: boolean;
    /** True when this runtime was constructed with consumer claims at all. */
    readonly present: boolean;
    registerScopeClaim(scopeId: string, prepared: PublicPreparedThemeScope, root: HTMLElement): ThemeRuntimeResult<void>;
    releasePortalStyle(host: HTMLElement): void;
    releaseConsumerPortal(binding: PublicPortalBinding): void;
    retainFailedConsumerScope(input: {
        parent: ThemeScopeIdentity | null;
        scopeKey?: string;
    }): string | null;
    claimConsumerTarget(scope: ThemeScopeIdentity, element: HTMLElement, input: ThemeConsumerCssInput): ThemeConsumerResult<ThemeConsumerLease<ThemeConsumerResourceState>>;
    claimConsumerPortal(scope: ThemeScopeIdentity, localId: string, target?: unknown): ThemeConsumerResult<ThemeConsumerLease<ThemeConsumerPortalSnapshot<HTMLElement>>>;
    complete(): ThemeRuntimeResult<void>;
    dispose(): void;
}
export declare function createConsumerAdoption(host: ConsumerAdoptionHost, state: ConsumerAdoptionState): ConsumerAdoption;
