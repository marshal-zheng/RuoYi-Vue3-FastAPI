import type { ConcreteThemeSelection, ManifestIdentity, ThemeStylesheetPolicy } from './adapter-contract';
import type { ResolvedRequestedThemeState } from './selection-resolver';
import type { ThemeRuntimeResult } from './result';
export declare const THEME_HYDRATION_SCHEMA: "zx.theme-hydration/1";
export interface SsrStylesheetRef {
    readonly manifestIdentity: ManifestIdentity;
    readonly packageName: string;
    readonly packageVersion: string;
    readonly exportPath: string;
    readonly artifactPath: string;
    readonly sha256: string;
    readonly purpose: 'core-css' | 'aggregate-css' | 'element-plus-alias' | 'element-plus-resolved';
    readonly loadPhase: 'theme' | 'variant';
    readonly adoptionMarker: string;
}
export interface ThemeScopeHydrationRecord {
    readonly scopeId: string;
    readonly parentScopeId: string | null;
    readonly requested: ResolvedRequestedThemeState;
    readonly selection: ConcreteThemeSelection;
    readonly themeId: string;
    readonly variantKey: string;
    readonly selector: string;
    readonly portalPolicy: 'deferred-runtime-target';
}
export interface ThemeHydrationSnapshotV1 {
    readonly schema: typeof THEME_HYDRATION_SCHEMA;
    readonly appKey: string;
    readonly runtimeContractVersion: '4.0.0';
    readonly stylesheetPolicy: ThemeStylesheetPolicy;
    readonly system: Readonly<{
        mode: 'light' | 'dark';
        source: string;
    }>;
    readonly manifests: readonly ManifestIdentity[];
    readonly scopes: readonly ThemeScopeHydrationRecord[];
    readonly stylesheets: readonly SsrStylesheetRef[];
}
export declare function validateThemeHydrationSnapshot(input: unknown): ThemeRuntimeResult<ThemeHydrationSnapshotV1>;
export declare function serializeThemeHydrationSnapshot(snapshot: ThemeHydrationSnapshotV1): string;
export declare function renderThemeHydrationScript(snapshot: ThemeHydrationSnapshotV1, options?: Readonly<{
    nonce?: string;
    id?: string;
}>): string;
