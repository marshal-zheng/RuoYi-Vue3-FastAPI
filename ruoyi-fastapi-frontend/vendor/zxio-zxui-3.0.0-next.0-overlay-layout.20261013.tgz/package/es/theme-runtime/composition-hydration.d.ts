import type { PreparedThemeComposition, ThemeCompositionHydrationInput, ThemeCompositionHydrationSnapshot, ThemeScopeCompositionPort } from './composition-contract';
import type { ThemeHydrationSnapshotV1 } from './hydration-schema';
import type { ThemeRuntimeResult } from './result';
import type { ThemeTargetCoordinatorResolver } from './target-coordinator';
export declare function sameCompositionData(left: unknown, right: unknown): boolean;
export interface ValidatedCompositionHydration {
    readonly snapshot: ThemeCompositionHydrationSnapshot;
    readonly prepared: Readonly<{
        get(scopeId: string): PreparedThemeComposition | undefined;
    }>;
    readonly roots: Readonly<{
        get(scopeId: string): HTMLElement | undefined;
    }>;
}
/** Validates the COMPLETE app before any stylesheet ownership or DOM mutation. */
export declare function preflightCompositionHydration(input: {
    readonly core: ThemeHydrationSnapshotV1;
    readonly coreStyleElements: readonly HTMLElement[];
    readonly hydration: ThemeCompositionHydrationInput;
    readonly port: ThemeScopeCompositionPort;
    readonly targets: ThemeTargetCoordinatorResolver;
    readonly scopeArtifactHashes: ReadonlyMap<string, readonly string[]>;
    readonly scopeManagedProperties: ReadonlyMap<string, readonly string[]>;
}): ThemeRuntimeResult<ValidatedCompositionHydration>;
