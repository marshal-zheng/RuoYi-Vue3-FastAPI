import type { ThemeConsumerCssInput, ThemeConsumerResult, ThemePreparedCssTarget } from '@zxio/theme-consumer';
import type { ThemeConsumerAdmission } from './consumer-contract';
import type { PreparedSsrThemeScope, ThemeSsrOutput } from './ssr';
/** Request-owned collection; the original SSR Runtime proves the scope record. */
export declare function createSsrConsumerRegistry(appKey: string, admission: ThemeConsumerAdmission | undefined, getScope: (id: string) => PreparedSsrThemeScope | undefined): {
    prepareTarget(scope: PreparedSsrThemeScope, input: ThemeConsumerCssInput): ThemeConsumerResult<ThemePreparedCssTarget>;
    preparePortal(scope: PreparedSsrThemeScope, localId: string, destinationKey: string): ThemeConsumerResult<{
        leaseId: string;
        target: string;
    }>;
    collect(output: ThemeSsrOutput): ThemeConsumerResult<ThemeSsrOutput>;
    dispose(): void;
};
