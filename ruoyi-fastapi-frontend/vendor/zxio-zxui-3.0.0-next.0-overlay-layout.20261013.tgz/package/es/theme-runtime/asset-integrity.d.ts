/** Synchronous verification preserves the existing synchronous adoption API. */
export declare function hashThemeCss(text: string): string;
export declare function themeAssetIntegrity(hash: string): string;
