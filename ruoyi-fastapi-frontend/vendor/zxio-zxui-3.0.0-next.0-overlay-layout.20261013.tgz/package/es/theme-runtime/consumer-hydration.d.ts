import type { ThemeConsumerCssInput, ThemeConsumerLease, ThemeConsumerPortalSnapshot, ThemeConsumerResourceState, ThemeConsumerResult } from '@zxio/theme-consumer';
import type { ThemeConsumerAdmission, ThemeConsumerHydrationInput } from './consumer-contract';
import type { ValidatedCompositionHydration } from './composition-hydration';
import type { ThemeHydrationSnapshotV1 } from './hydration-schema';
import type { ThemeTargetCoordinatorResolver } from './target-coordinator';
export declare function preflightConsumerHydration(input: {
    core: ThemeHydrationSnapshotV1;
    composition: ValidatedCompositionHydration;
    hydration: ThemeConsumerHydrationInput;
    admission: ThemeConsumerAdmission;
    targets: ThemeTargetCoordinatorResolver;
}): {
    snapshot: import("./consumer-contract").ThemeConsumerHydrationSnapshot;
    nodes: Map<string, HTMLElement>;
    hosts: Map<string, HTMLElement>;
    destinations: Map<string, HTMLElement>;
    ownedDestinations: Set<HTMLElement>;
};
export type ValidatedConsumerHydration = ReturnType<typeof preflightConsumerHydration>;
export declare function createConsumerClaims(validated: ValidatedConsumerHydration): {
    targets: Map<string, {
        scopeId: string;
        input: ThemeConsumerCssInput;
        element: HTMLElement;
        lease: ThemeConsumerLease<ThemeConsumerResourceState>;
    }>;
    portals: Map<string, {
        scopeId: string;
        lease: ThemeConsumerLease<ThemeConsumerPortalSnapshot<HTMLElement>>;
    }>;
    claimTarget(scopeId: string, element: HTMLElement, input: ThemeConsumerCssInput): ThemeConsumerResult<ThemeConsumerLease<ThemeConsumerResourceState>>;
    claimPortal(scopeId: string, localId: string): ThemeConsumerResult<ThemeConsumerLease<ThemeConsumerPortalSnapshot<HTMLElement>>>;
    validate(): ThemeConsumerResult<void>;
    transfer(id: string, release: () => void): void;
    commit(): void;
    dispose(): void;
    fail: <T>(reason: string) => ThemeConsumerResult<T>;
};
