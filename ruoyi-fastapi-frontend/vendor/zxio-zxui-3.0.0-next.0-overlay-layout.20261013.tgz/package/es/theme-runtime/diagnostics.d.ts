export type ThemeRuntimeDiagnosticCode = 'TR_COMPOSITION_INVALID' | 'TR_COMPOSITION_TARGET_CONFLICT' | 'TR_COMPOSITION_HYDRATION_INVALID' | 'TR_DEPENDENCY_REFRESH_REQUIRED' | 'TR_RUNTIME_ALREADY_INSTALLED' | 'TR_RUNTIME_OWNER_REQUIRED' | 'TR_RUNTIME_DISPOSED' | 'TR_MANIFEST_INVALID' | 'TR_MANIFEST_IDENTITY_MISMATCH' | 'TR_THEME_UNKNOWN' | 'TR_AXIS_UNKNOWN' | 'TR_DISPLAY_INVALID' | 'TR_DISPLAY_ASSET_UNSUPPORTED' | 'TR_AXIS_VALUE_UNSUPPORTED' | 'TR_VARIANT_MISSING' | 'TR_VARIANT_AMBIGUOUS' | 'TR_ASSET_REF_INVALID' | 'TR_ASSET_RESOLVE_FAILED' | 'TR_ASSET_HASH_MISMATCH' | 'TR_ASSET_CACHE_DISPOSED' | 'TR_STYLESHEET_LOAD_FAILED' | 'TR_TARGET_SELECTOR_CONFLICT' | 'TR_TARGET_COORDINATOR_REQUIRED' | 'TR_TRANSACTION_STALE' | 'TR_SCOPE_ROOT_UNAVAILABLE' | 'TR_SCOPE_KEY_DUPLICATE' | 'TR_SCOPE_DISPOSED' | 'TR_RESOURCE_LIMIT_EXCEEDED' | 'TR_PORTAL_TARGET_INVALID' | 'TR_FEEDBACK_OWNER_REQUIRED' | 'TR_FEEDBACK_ADAPTER_REQUIRED' | 'TR_SSR_SYSTEM_INPUT_INVALID' | 'TR_HYDRATION_SNAPSHOT_INVALID' | 'TR_HYDRATION_IDENTITY_MISMATCH' | 'TR_HYDRATION_STYLESHEET_MISSING' | 'TR_INTERNAL_FAILURE';
export type ThemeRuntimeDiagnosticPhase = 'dependency' | 'owner' | 'manifest' | 'selection' | 'asset' | 'stylesheet' | 'transaction' | 'scope' | 'resource' | 'portal' | 'feedback' | 'ssr' | 'hydration' | 'internal';
export type ThemeRuntimeDiagnosticScalar = string | number | boolean | null;
export interface ThemeRuntimeDiagnosticObject {
    readonly [key: string]: ThemeRuntimeDiagnosticValue;
}
export type ThemeRuntimeDiagnosticValue = ThemeRuntimeDiagnosticScalar | readonly ThemeRuntimeDiagnosticValue[] | ThemeRuntimeDiagnosticObject;
export interface ThemeRuntimeDiagnostic {
    readonly code: ThemeRuntimeDiagnosticCode;
    readonly phase: ThemeRuntimeDiagnosticPhase;
    readonly details: Readonly<Record<string, ThemeRuntimeDiagnosticValue>>;
}
export declare function diagnostic(code: ThemeRuntimeDiagnosticCode, details?: Readonly<Record<string, unknown>>): ThemeRuntimeDiagnostic;
export declare function compareDiagnostics(left: ThemeRuntimeDiagnostic, right: ThemeRuntimeDiagnostic): number;
export declare function stableDiagnostics(diagnostics: readonly ThemeRuntimeDiagnostic[]): readonly ThemeRuntimeDiagnostic[];
