import type { ThemeStylesheetLoadPlan } from './adapter-contract';
import type { ThemeHydrationSnapshotV1, ThemeScopeHydrationRecord } from './hydration-schema';
import type { ThemeRuntimeResult } from './result';
export declare function hydrationScope(snapshot: ThemeHydrationSnapshotV1, scopeId: string): ThemeRuntimeResult<ThemeScopeHydrationRecord>;
export declare function hydrationStylesheetElements(plan: ThemeStylesheetLoadPlan, elements: readonly HTMLElement[]): ThemeRuntimeResult<readonly HTMLElement[]>;
