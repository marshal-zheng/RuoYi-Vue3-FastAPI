import type { ThemeCompositionStyle } from './composition-contract';
import type { ThemeTargetCoordinatorResolver } from './target-coordinator';
export interface CompositionStyleLease {
    commit(): void;
    release(): void;
}
export declare function compositionTargetRoot(node: Node): Document | ShadowRoot;
/** App-owned immutable CSS registry. Every portal retains its own lease. */
export declare function createCompositionStyleRegistry(options: {
    readonly targets: ThemeTargetCoordinatorResolver;
    readonly nonce?: string;
    readonly adopted?: readonly HTMLElement[];
    readonly ownership?: 'transferred' | 'external';
}): {
    acquire: (node: Node, styles: readonly ThemeCompositionStyle[]) => CompositionStyleLease;
    snapshot: () => {
        id: string;
        hash: string;
        references: number;
    }[];
    dispose(): void;
};
export type CompositionStyleRegistry = ReturnType<typeof createCompositionStyleRegistry>;
