import type { PreparedThemeComposition } from './composition-contract';
export declare const consumerTargetAttributeNames: readonly ["data-zx-consumer", "data-zx-consumer-state"];
export declare function consumerAdapterState(composition: PreparedThemeComposition | null, adapterId: string): 'ready' | 'inactive';
export declare function consumerTargetAttributes(composition: PreparedThemeComposition | null, adapterId: string, consumerId?: string): Readonly<Record<string, string>>;
/** Reversible UTF-16 encoding, with separators preserving empty segments. */
export declare function consumerIdentity(appKey: string, localId: string): string;
