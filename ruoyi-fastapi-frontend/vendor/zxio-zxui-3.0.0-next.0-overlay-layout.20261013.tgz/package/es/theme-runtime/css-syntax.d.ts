/**
 * Return executable CSS text for boundary checks. Quoted strings and comments
 * are data; escapes in identifiers still participate in function/at-rule names.
 * This scanner does not parse declarations or replace the typed CSS encoder.
 */
export declare function cssSyntaxText(css: string): string;
