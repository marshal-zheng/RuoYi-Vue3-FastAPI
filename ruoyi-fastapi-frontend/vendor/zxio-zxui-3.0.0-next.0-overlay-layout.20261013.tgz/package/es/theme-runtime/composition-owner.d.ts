import type { PreparedThemeComposition } from './composition-contract';
import type { CompositionStyleRegistry } from './composition-styles';
type Attributes = Readonly<Record<string, string>>;
export interface PreparedCompositionEffect {
    validate(): void;
    apply(nodes: readonly HTMLElement[]): () => void;
    commit(): void;
    finalize(): void;
    rollback(): void;
}
/** One reversible attribute/CSS owner for roots, portals and explicit targets. */
export declare function createCompositionOwner(styles: CompositionStyleRegistry): {
    prepare: (scopeId: string, composition: PreparedThemeComposition | null, nodes: readonly HTMLElement[], extra?: (node: HTMLElement) => Attributes, coreProperties?: readonly string[]) => PreparedCompositionEffect;
    attach(scopeId: string, composition: PreparedThemeComposition | null, node: HTMLElement, extra?: Attributes, coreProperties?: readonly string[]): void;
    detach(node: HTMLElement): void;
    has(node: HTMLElement): boolean;
    dispose(): void;
};
export type CompositionOwner = ReturnType<typeof createCompositionOwner>;
export {};
