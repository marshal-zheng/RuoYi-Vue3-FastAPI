import type { ManifestIdentity, ThemeStylesheetLoadPlanEntry } from './adapter-contract';
import type { ResolvedThemeAsset } from './asset-resolver';
import type { ThemeRuntimeResult } from './result';
export type ThemeAssetCacheKey = string & {
    readonly __opaque__: 'ThemeAssetCacheKey';
};
export interface ThemeAssetLease {
    readonly key: ThemeAssetCacheKey;
    readonly value: ResolvedThemeAsset;
    release(): void;
}
export interface ThemeAssetCacheSnapshot {
    readonly state: 'active' | 'disposed';
    readonly entries: readonly Readonly<{
        key: ThemeAssetCacheKey;
        state: 'loading' | 'ready' | 'error';
        ownerCount: number;
        bytes: number;
        lastAccessSequence: number;
    }>[];
    readonly totalBytes: number;
}
export interface ThemeAssetCache {
    acquire(input: {
        readonly key: ThemeAssetCacheKey;
        readonly ownerId: string;
        readonly load: (signal: AbortSignal) => Promise<ThemeRuntimeResult<ResolvedThemeAsset>>;
    }): Promise<ThemeRuntimeResult<ThemeAssetLease>>;
    releaseOwner(ownerId: string): ThemeRuntimeResult<void>;
    snapshot(): ThemeAssetCacheSnapshot;
    dispose(): Promise<ThemeRuntimeResult<void>>;
}
export interface ThemeAssetCacheOptions {
    readonly maxEntries?: number;
    readonly maxBytes?: number;
}
export declare function createThemeAssetCacheKey(identity: ManifestIdentity, entry: ThemeStylesheetLoadPlanEntry): ThemeAssetCacheKey;
export declare function createThemeAssetCache({ maxEntries, maxBytes, }?: ThemeAssetCacheOptions): ThemeAssetCache;
