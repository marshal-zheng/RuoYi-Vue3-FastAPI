import type { ThemeConsumerCssInput, ThemeConsumerResult } from '@zxio/theme-consumer';
import type { PreparedThemeComposition } from './composition-contract';
export interface ThemeConsumerAdmission {
    validate(input: ThemeConsumerCssInput): ThemeConsumerResult<{
        readonly selectorKey: string;
    }>;
}
export interface ThemeConsumerTargetRecord {
    readonly targetId: string;
    readonly localId: string;
    readonly scopeId: string;
    readonly adapterId: string;
    readonly actualVersion: string;
    readonly compositionHash: string;
    readonly state: 'ready' | 'inactive';
    readonly attrs: Readonly<Record<string, string>>;
    readonly portalLeaseId?: string;
}
export interface ThemeConsumerDestinationRecord {
    readonly destinationKey: string;
    readonly id: string;
    readonly ownership: 'transferred' | 'external';
}
export interface ThemeConsumerPortalRecord {
    readonly hostId: string;
    readonly scopeId: string;
    readonly destinationKey: string;
    readonly attrs: Readonly<Record<string, string>>;
    readonly leaseIds: readonly string[];
    readonly styleIds: readonly string[];
}
export interface ThemeConsumerHydrationSnapshot {
    readonly schema: 'zx.theme-consumer-hydration/1';
    readonly appKey: string;
    readonly coreSnapshotHash: string;
    readonly compositionSnapshotHash: string;
    readonly targets: readonly ThemeConsumerTargetRecord[];
    readonly destinations: readonly ThemeConsumerDestinationRecord[];
    readonly portalHosts: readonly ThemeConsumerPortalRecord[];
    readonly integrity: string;
}
export interface ThemeConsumerHydrationInput {
    readonly snapshot: unknown;
    readonly portalRoots?: Readonly<Record<string, Document | ShadowRoot | HTMLElement>>;
}
export declare function consumerCanonical(value: unknown): string;
export declare function sealConsumerSnapshot(value: Omit<ThemeConsumerHydrationSnapshot, 'integrity'>): ThemeConsumerHydrationSnapshot;
export declare function validateConsumerSnapshot(input: unknown): ThemeConsumerHydrationSnapshot;
export declare function consumerCompositionState(composition: PreparedThemeComposition | null, selector: string): 'ready' | 'inactive';
