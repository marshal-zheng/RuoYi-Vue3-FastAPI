export type Opaque<Value, Name extends string> = Value & {
    readonly __opaque__: Name;
};
export type ThemeRuntimeId = Opaque<string, 'ThemeRuntimeId'>;
export type ThemeAppId = Opaque<string, 'ThemeAppId'>;
export type ThemeScopeId = Opaque<string, 'ThemeScopeId'>;
export type ThemePortalId = Opaque<string, 'ThemePortalId'>;
export type ThemeAssetId = Opaque<string, 'ThemeAssetId'>;
export type ThemeRuntimeLifecycle = 'active' | 'disposing' | 'disposed';
export type ThemeScopeLifecycle = 'pending' | 'ready' | 'updating' | 'error' | 'disposed';
export declare const THEME_RUNTIME_CONTRACT_VERSION: "4.0.0";
export interface ThemeRuntimeIdentitySnapshot {
    readonly runtimeId: ThemeRuntimeId;
    readonly state: ThemeRuntimeLifecycle;
}
export interface ThemeScopeIdentitySnapshot {
    readonly runtimeId: ThemeRuntimeId;
    readonly scopeId: ThemeScopeId;
    readonly parentScopeId: ThemeScopeId | null;
    readonly generation: number;
    readonly state: ThemeScopeLifecycle;
}
export declare function opaqueIdentity<Name extends string>(value: string, name: Name): Opaque<string, Name>;
export declare function runtimeId(value: string): ThemeRuntimeId;
export declare function appId(value: string): ThemeAppId;
export declare function scopeId(value: string): ThemeScopeId;
export declare function portalId(value: string): ThemePortalId;
export declare function assetId(value: string): ThemeAssetId;
export declare function deepReadonly<T>(value: T, seen?: WeakSet<object>): T;
