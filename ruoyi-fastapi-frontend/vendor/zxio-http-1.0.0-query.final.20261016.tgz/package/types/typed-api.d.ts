import type { HttpClient, RequestOptions } from './types.js';
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
export interface APIEndpointDefinition<TResponse = unknown, TParams = unknown, TData = unknown, TUrl extends string = string> {
    method: HttpMethod;
    url: TUrl;
    _response?: TResponse;
    _params?: TParams;
    _data?: TData;
}
export type APIDefinitions = Record<string, APIEndpointDefinition<any, any, any, any>>;
/**
 * 提取 URL 中的路径参数
 * 例如: '/users/:id/posts/:postId' => { id: string | number; postId: string | number }
 */
export type ExtractPathParams<T extends string> = T extends `${infer _Start}:${infer Param}/${infer Rest}` ? {
    [K in Param | keyof ExtractPathParams<`/${Rest}`>]: string | number;
} : T extends `${infer _Start}:${infer Param}` ? {
    [K in Param]: string | number;
} : Record<string, never>;
/**
 * 检查路径是否包含参数
 */
export type HasPathParams<T extends string> = T extends `${infer _Start}:${infer _Rest}` ? true : false;
/**
 * 替换 URL 中的路径参数
 */
export declare function substitutePathParams(url: string, params: Record<string, string | number>): string;
/**
 * 定义 API 端点
 */
export declare function defineEndpoint<TResponse = unknown, TParams = Record<string, unknown>, TData = Record<string, unknown>, TUrl extends string = string>(method: HttpMethod, url: TUrl): APIEndpointDefinition<TResponse, TParams, TData, TUrl>;
/**
 * 类型安全的 API 调用参数
 */
export interface TypedAPICallOptions<TDef extends APIEndpointDefinition<any, any, any>, TUrl extends string = string> {
    pathParams?: HasPathParams<TUrl> extends true ? ExtractPathParams<TUrl> : never;
    params?: TDef['_params'];
    data?: TDef['_data'];
    signal?: AbortSignal;
    options?: RequestOptions;
}
/**
 * 类型安全的 API 客户端类型
 */
export type TypedAPIClient<T extends APIDefinitions> = {
    [K in keyof T]: T[K] extends APIEndpointDefinition<infer TResponse, infer TParams, infer TData, string> ? T[K]['url'] extends string ? HasPathParams<T[K]['url']> extends true ? (pathParams: ExtractPathParams<T[K]['url']>, callOptions?: {
        params?: TParams;
        data?: TData;
        signal?: AbortSignal;
        options?: RequestOptions;
    }) => Promise<TResponse> : (callOptions?: {
        params?: TParams;
        data?: TData;
        signal?: AbortSignal;
        options?: RequestOptions;
    }) => Promise<TResponse> : never : never;
};
/**
 * 创建类型安全的 API 客户端
 */
export declare function createTypedAPI<T extends APIDefinitions>(client: HttpClient, definitions: T): TypedAPIClient<T>;
/**
 * API 定义构建器，提供更好的类型推导
 */
export declare class APIBuilder<T extends APIDefinitions = Record<string, never>> {
    private definitions;
    constructor(definitions?: T);
    /**
     * 添加 GET 端点
     */
    get<TName extends string, TUrl extends string, TResponse = unknown, TParams = Record<string, unknown>>(name: TName, url: TUrl): APIBuilder<T & {
        [K in TName]: APIEndpointDefinition<TResponse, TParams, never, TUrl>;
    }>;
    /**
     * 添加 POST 端点
     */
    post<TName extends string, TUrl extends string, TResponse = unknown, TParams = Record<string, unknown>, TData = Record<string, unknown>>(name: TName, url: TUrl): APIBuilder<T & {
        [K in TName]: APIEndpointDefinition<TResponse, TParams, TData, TUrl>;
    }>;
    /**
     * 添加 PUT 端点
     */
    put<TName extends string, TUrl extends string, TResponse = unknown, TParams = Record<string, unknown>, TData = Record<string, unknown>>(name: TName, url: TUrl): APIBuilder<T & {
        [K in TName]: APIEndpointDefinition<TResponse, TParams, TData, TUrl>;
    }>;
    /**
     * 添加 DELETE 端点
     */
    delete<TName extends string, TUrl extends string, TResponse = unknown, TParams = Record<string, unknown>>(name: TName, url: TUrl): APIBuilder<T & {
        [K in TName]: APIEndpointDefinition<TResponse, TParams, never, TUrl>;
    }>;
    /**
     * 构建 API 定义
     */
    build(): T;
    /**
     * 使用 HttpClient 创建类型安全的 API 客户端
     */
    create(client: HttpClient): TypedAPIClient<T>;
}
/**
 * 创建 API 构建器
 */
export declare function createAPIBuilder(): APIBuilder;
