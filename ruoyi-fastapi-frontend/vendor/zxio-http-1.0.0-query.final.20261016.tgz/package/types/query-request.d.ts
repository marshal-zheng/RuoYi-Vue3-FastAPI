import type { RequestOptions } from './types.js';
/** Marks requests whose cancellation, retries and error feedback belong to a query owner. */
export declare const QUERY_REQUEST_CONTEXT_KEY = "@zxio/http/query-request";
export type QueryRequestContext = Readonly<{
    signal: AbortSignal;
    options: RequestOptions;
}>;
/** Compose ordinary HTTP call arguments without creating a client or mutating options. */
export declare function queryRequest(signal: AbortSignal, options?: RequestOptions): QueryRequestContext;
/** Let a business HTTP bridge transfer ordinary query error feedback to its consumer. */
export declare function isQueryRequest(options?: RequestOptions): boolean;
